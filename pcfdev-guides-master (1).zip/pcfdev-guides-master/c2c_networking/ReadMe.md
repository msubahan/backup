# Container to Container Networking

Container to Container (C2C) networking enables apps hosted in a single PCF foundation to communicate with each other 
securely and directly without the request leaving the foundation and getting routed again via GoRouter and HAProxy. 
To understand the architecture of C2C networking, read the <a href="https://docs.pivotal.io/application-service/2-10/concepts/understand-cf-networking.html" target="_blank"><b>Pivotal Docs</b></a>.

C2C networking uses overlay network, which are not externally routable to communicate between app instances. To enable 
communication between apps using overlay network, a network policy has to be defined. A single network policy enables one way 
communication between two apps. If two way communication is required, a second network policy shall be defined to enable the same.

A network policy  tracks an app using the app's GUID. If an app's GUID changes, typically during a Blue-Green deployment,
a new network policy has to be defined. This is required when either the source or destination app's GUID changes.
Refer to [Automation](#automation) section below for details on Dev Enablement's pipeline offering 
that automates the steps for creating network policies during each Blue-Green deployment.

Reaching an app using C2C networking requires resolving to the app's overlay network IP address. This can be achieved in two ways, using 
BOSH DNS or App Service Discovery. This guide details both approaches and provides instruction on how to implement them.

## Bosh DNS
Apps can connect with each other internally using Bosh DNS by mapping a route with '**apps.internal**' domain. 
Requests to apps using the *.apps.internal domain gets resolved by Bosh DNS to the overlay network IP address of the app's container.

:white_check_mark: Use `cf map-route my-app apps.internal --hostname my-host` to map a route to your app with 'apps.internal' domain.

:white_check_mark: Create a network policy between the source and destination apps, which needs to communicate using C2C networking. 
Refer to [Network Policies](#network-policies) section to create a network policy.

:white_check_mark: You can now connect from your source app to destination app using the internal url, which typically looks like 
**http\://my-app.apps.internal:8080**. The destination app is not accessible outside of the PCF foundation using this URL 
or within the foundation by any other source app without defining a network policy.

>**Note**: Requests to apps.internal domain urls are load balanced among available instances of the respective app. 
>
>Any other domain route mapped to the app will make the app still accessible outside of PCF foundation using that domain's URL.
>In this case, security requirements need to be addressed separately.

## App Service Discovery
App Service Discovery is another way of accomplishing C2C networking by just registering the apps in the 
Service Registry using '**direct**' registration method and by adding the required network policies.

:white_check_mark: If your app uses Service Registry, it most probably uses the default registration method, which is '**route**'. 
To use C2C networking with Eureka Service Registry, change the app registration method to '**direct**' by setting the 
below property in application.properties file.

`spring.cloud.services.registrationMethod=direct`

The Service Registry management dashboard below shows how the apps register themselves in the registry 
when using different registration methods.

![Service Registry - Registration Method](img/Eureka_Registration_Method.png)

:white_check_mark: Create a network policy between the source and destination apps, which needs to communicate using C2C networking. 
Refer to [Network Policies](#network-policies) section to create a network policy.

:white_check_mark: You can now discover your destination app using the Service Registry and connect from your source app using the 
client-side load balanced URL **lb://SERVICE_NAME_IN_REGISTRY**.

## Network Policies
A network policy is required between apps to communicate with each other. Use the below command to create a network policy 
from your source to destination app using default HTTP protocol and default port 8080.

`cf add-network-policy source-app-name --destination-app destination-app-name` 

>**Note:** The above cf command assumes that you are already logged in to PCF foundation and targeted to the Org and Space 
>where both your source and destination apps exist. If your destination app is in a different Org / Space, 
>you can supply those arguments in the cf command. Refer to [Cloud Foundry Reference Guide](http://cli.cloudfoundry.org/en-US/cf/) for more options.

## Automation
Recreating network policies during every Blue-Green deployment, where a new app is created each time for the updated application version, 
can become a tedious process. Dev Enablement's [Jenkins Pipeline](../pipeline-jenkins) 
and [Gradle Boost Plugin](../../../../gradle-boost-plugin) offerings 
provide an easy automation to recreate these policies during the app deployments.

>**Note:** The automation only supports apps that exist in the same Org and Space within a PCF foundation. 

>**Note on Proxy settings:** If the consumer app uses `NO_PROXY` settings in the app, it should add `.apps.internal` domain in to the no-proxy list. This would help consumer app to not use proxy for the connection.

Follow the below steps to automate network policy creations:

- Make sure you are using Gradle Boost plugin version 3.0.0+ and Jenkins Pipeline offering version 3.0.0+.

- In the pipeline.configuration.groovy file, under **c2cNetworkPolicies** section, 

    - Set `enabled` flag as `true` 
    
    - List the outbound and inbound app names delimited by ',' in the `outbound` and `inbound` sections respectively, for network policy creation. 
    
    - Set `createAppsInternalRoute` flag as `true` to resolve the app using BOSH DNS; set as `false` if using App Service Discovery. 
    
    - Set `deleteExternalRoutesForThisApp` flag as `true` if you want to delete all container external domain routes 
    of the current app, after executing the acceptance tests, if any. Set the flag as `false` to leave the external domain routes as-is.
        
        > **Note**: Apps without container external domain route are not accessible outside of PCF foundation. 
        If you have health checks configured for individual apps, you need to have an external route unless the health 
        checks are routed through a Gateway service that connects to the individual app using C2C networking.
    
- For App Service Registry implementation, update the service registration method to **`direct`** in the application.properties 
file and access the outbound app using a load balanced URL as stated in [App Service Discovery](#app-service-discovery) section.

## Use Cases
C2C networking solution is suitable for any suite of apps managed by a team that talks to each other to serve a single client request.
C2C networking offers secured and direct communication between apps, improving efficiency and response time. By combining C2C networking
with a Gateway Service solution, most of the key security requirements can be addressed in a single point of entry. <!-- and downstream services 
can simply trust the requests from the gateway service by thoughtfully relaxing the individual service level security. 
The above described security relaxation is well suited only when the downstream services are accessible only internally using C2C networking.-->

## Reference Application
The above documented C2C Networking solution (both Bosh DNS and App Service Discovery implementations), along with Spring Cloud Gateway
are implemented in the Dev Enablement Team's reference applications [**CAB Gateway**](https://github.ford.com/PCFDev-CAB/cab-service-gateway) 
and [**CAB FordAir**](https://github.ford.com/PCFDev-CAB/cab-service-fordair).
