package com.ford.cloudnative.devenablement.email.message;


import static org.mockito.Matchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.hamcrest.core.StringStartsWith;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Import;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.ResultActions;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultHandlers;
import org.springframework.web.servlet.mvc.method.annotation.RequestMappingHandlerAdapter;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ford.cloudnative.base.app.web.exception.handler.ExceptionHandlerConfiguration;
import com.ford.cloudnative.base.test.response.BaseBodyErrorResultMatchers;
import com.ford.cloudnative.devenablement.email.message.api.EmailRequest;
import com.ford.cloudnative.devenablement.email.message.EmailController;
import com.ford.cloudnative.devenablement.email.message.EmailService;


@RunWith(SpringRunner.class)
@WebMvcTest(controllers = {EmailController.class})
@Import(ExceptionHandlerConfiguration.class)
public class EmailControllerIntegrationTest {

    @Rule
    public ExpectedException exception = ExpectedException.none();

    @Autowired
    MockMvc mockMvc;

    @Autowired
    ObjectMapper objectMapper;

    @Autowired
    RequestMappingHandlerAdapter adapter;

    @MockBean
    private EmailService emailService;

    /***********************************************************************************************
     * ENDPOINT: POST /api/v1/messages
     ***********************************************************************************************/

    @Test
    public void should_return200ReponseWithFieldsPopulated_forMessagesEndpoint() throws Exception {

        String[] toEmailAddress = new String[] {"dummy@ford.com"};
        String subject = "test";
        String message = "this is a test";

        EmailRequest emailRequest = EmailRequest.builder()
                .to(toEmailAddress)
                .subject(subject)
                .message(message)
                .build();

        when(emailService.sendMail(subject, message, toEmailAddress)).thenReturn(true);


        jsonPost("/api/v1/messages", emailRequest)
                .andExpect(status().isOk())
                // controller unit tests test completeness of response object; we only smoke test here that a JSON response is returned
                .andExpect(jsonPath("$.result.status").value(StringStartsWith.startsWith("email message sent successfully")));


        verify(emailService).sendMail(any(), any(), any());
    }

    @Test
    public void should_validateNameField_forMessagesEndpoint() throws Exception {

        String subject = "test";
        String message = "this is a test";

        EmailRequest emailRequest = EmailRequest.builder()
                .to(null)
                .subject(subject)
                .message(message)
                .build();

        when(emailService.sendMail(subject, message )).thenThrow(IllegalStateException.class);

        jsonPost("/api/v1/messages", emailRequest)
                .andExpect(status().isBadRequest())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andExpect(BaseBodyErrorResultMatchers.dataErrorWithCode("to", "NotNull").exists())
        ;

    }


    ResultActions jsonPost(String url, Object entity) throws Exception {
        return
                this.mockMvc.perform(MockMvcRequestBuilders
                        .post(url)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(entity))
                )
                        .andDo(MockMvcResultHandlers.print());
    }
}
