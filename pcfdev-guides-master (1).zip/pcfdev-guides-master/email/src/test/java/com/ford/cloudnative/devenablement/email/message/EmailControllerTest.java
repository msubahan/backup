package com.ford.cloudnative.devenablement.email.message;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import com.ford.cloudnative.devenablement.email.message.api.EmailRequest;
import com.ford.cloudnative.devenablement.email.message.api.EmailResponse;
import com.ford.cloudnative.devenablement.email.message.EmailController;
import com.ford.cloudnative.devenablement.email.message.EmailService;

@RunWith(MockitoJUnitRunner.class)
public class EmailControllerTest {

    EmailController emailController;

    @Mock
    private EmailService emailService;


    @Before
    public void setup() {
        emailController = new EmailController(emailService);
    }

    @Test
    public void testMessage() throws Exception {

        String[] toEmailAddress = new String[] {"dummy@ford.com"};
        String subject = "test";
        String message = "this is a test";

        EmailRequest emailRequest = EmailRequest.builder()
                .to(toEmailAddress)
                .subject(subject)
                .message(message)
                .build();

        when(emailService.sendMail(subject, message, toEmailAddress)).thenReturn(true);

        EmailResponse response = emailController.sendEmail(emailRequest);

        assertThat(response.getError()).isNull();
        assertThat(response.getResult()).isNotNull();

        assertThat(response.getResult().getStatus()).contains("success");

        verify(emailService).sendMail(any(), any(), any());
    }


}
