package com.ford.cloudnative.devenablement.email.message;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

@Service
public class EmailService {

    @Value("${from-email-address}")
    private String fromEmailAddress;

    private JavaMailSender javaMailSender;

    @Autowired
    public EmailService(JavaMailSender javaMailSender) {
        this.javaMailSender = javaMailSender;
    }

    public boolean sendMail(String subject, String message, String... toEmailAddresses) {

        this.validateFromAddressIsFordEmailAddress();

        SimpleMailMessage mailMessage = new SimpleMailMessage();
        mailMessage.setTo(toEmailAddresses);
        mailMessage.setSubject(subject);
        mailMessage.setText(message);
        mailMessage.setFrom(fromEmailAddress);

        javaMailSender.send(mailMessage);

        return true;
    }

    private void validateFromAddressIsFordEmailAddress() {
        if (!StringUtils.endsWithIgnoreCase(fromEmailAddress, "ford.com")) {
            throw new IllegalStateException("All email sent from Ford must contain a '@ford.com' from address. Unfortunately application is currently configured to use from address --> " + fromEmailAddress);
        }
    }

}
