package com.ford.cloudnative.devenablement.email.message;

import java.time.LocalDateTime;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ford.cloudnative.devenablement.email.message.api.EmailRequest;
import com.ford.cloudnative.devenablement.email.message.api.EmailResponse;
import com.ford.cloudnative.devenablement.email.message.api.EmailResponse.EmailResponseResult;

import io.swagger.annotations.ApiOperation;

@RestController
@RequestMapping(path = "/api/v1/messages", produces = MediaType.APPLICATION_JSON_VALUE)
public class EmailController {

    private EmailService emailService;

    @Autowired
    public EmailController(EmailService emailService) {
        this.emailService = emailService;
    }


    @ApiOperation(value = "Send an Email", notes = "Sends an email and provides you a status of message being sent")
    @PostMapping
    public EmailResponse sendEmail(@RequestBody @Valid EmailRequest emailRequest) {

        emailService.sendMail(emailRequest.getSubject(), emailRequest.getMessage(), emailRequest.getTo());

        EmailResponseResult result = EmailResponseResult.builder()
                .status("email message sent successfully at " + LocalDateTime.now().toString())
                .build();

        return EmailResponse.result(result, EmailResponse.class);
    }
}
