package com.ford.cloudnative.devenablement.email.message.api;

import com.ford.cloudnative.base.api.BaseBodyResponse;
import com.ford.cloudnative.devenablement.email.message.api.EmailResponse.EmailResponseResult;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

public class EmailResponse extends BaseBodyResponse<EmailResponseResult> {
	
	@Data
	@NoArgsConstructor
	@AllArgsConstructor
	@Builder
	public static class EmailResponseResult {
		String status;
	}

}
