# Scheduling Jobs in PCF Applications

There are many options available to team that need to run some "Job" on a scheduled basis. The focus of 
this guide will be to cover some of the more popular options available and assume the "Job" to run is 
implemented in a Java Spring Boot application running in PCF. The term "Job" or "Batch Job" are fairly 
broad terms, so for the purposes of this guide these terms will refer to any business logic that needs 
to be executed using a scheduled time as the event that causes the execution of this business logic.

Ultimately, the option that is best for your situation will depend on many factors including your requirements and the characteristics and architecture of your application. To help with your evaluation, we have listed some pros and cons of each of the scheduling options below. 


## Scheduler Tools and Options

Below is a list of some of the more popular options at Ford. This list is not exhaustive, but represents
proven solutions that also have been tested by our Dev Enablement team:

* Autosys
* Spring's `@Scheduled` annotation
* PCF Scheduler using a Spring Boot Application

We will also discuss the Spring Batch Framework, as Batch processing typically goes hand in hand with scheduling.

## Autosys
A [guide](https://github.ford.com/DevEnablement/pcfdev-guides/tree/master/batchjob-autosys) already 
exists for AutoSys integration with applications running in PCF.

#### Pros
* Ford's standard and supported job scheduling tool
* Solution is managed, monitored, and highly available. Your schedule is backed up and centrally 
* There is a management UI where job status and details can be reviewed
* Autosys can trigger PCF using HTTP/API calls, allowing load balancers to distribute the work across data centers and application instances in PCF.

#### Cons
* Long running jobs initiated by HTTP will not be able to report status back to Autosys. These need to be run asynchronously in PCF, and the application will need to support job status tracking and reporting.
* Must rely on 3rd party to manage your jobs; creation and edits to jobs require requests to Autosys team.



## Spring @Scheduled annotation
Use of the `@Scheduled` annotation is well documented in this [guide](https://www.baeldung.com/spring-scheduled-tasks) that is part of the very useful [Baeldung](https://www.baeldung.com/start-here) site. This site is a great resource for Spring related technologies.

One concern with use of the `@Scheduled` annotation, is that if your application is running in PCF with multiple instances, each instance will execute on the same schedule. In some cases this is not desired behavior. The SchedLock library can help alleviate this situation, and is also documented in a [Baeldung guide](https://www.baeldung.com/shedlock-spring).

#### Pros
* The functionality is provided by the core Spring framework.
* When running multiple instances, and each instance needs to perform some logic, this approach works nicely.
* All your logic and schedule can all be contained in the application, and not dependent on external sources. The schedule also will be versioned in your SCM tool since it will be part of the application code. 

#### Cons
* When running multiple instances of your application, if you want the job to run in only one instances you do need to introduce an additional library as described above.


## PCF Scheduler

The PCF Scheduler enables developers to create, run, and schedule jobs and view job history. This is all managed in the PCF platform, and can be managed via the PCF Apps Manager UI or the CF CLI.

The PCF Scheduler is documented on the [vendor's website](https://docs.pivotal.io/scheduler/1-2/index.html), and details schedules, jobs, and use of the CF CLI plugin for schedules.

A pattern that we have proven with the PCF Scheduler is to use a Spring Boot application that has been configured to run some batch job and immediately shutdown after completion of the batch processing. The application is always in a stopped state in PCF, and only starts when the schedule causes it to do so. This is accomplished by configuring the Job in the PCF Scheduler to use a specific command that will cause the Spring Boot application to start. See this [demo app's repo](https://github.ford.com/DevEnablement/devenablement-service-scheduledjob) for the sample Spring Boot application and associated README page that explains the details of this approach. 



#### Pros
* Application is only running for the time needed to perform the "Job", thus only consuming resources for minimal time (and lower hosting costs).
* Schedule is totally under control of application team, as it is managed in PCF Apps Manager or via a CF CLI plugin.

#### Cons
* You must monitor the status yourself, as their are no alerts when jobs fail.
* If you application is hosted in multiple data centers (EDC1 & EDC2), you have to choose if it needs to run in both, or if I can only run in a single data center.which one to run the schedule in.


## Spring Batch
The Spring Batch framework does not necessarily provide scheduling, but most people seeking a scheduling solution are doing so because they have some "Batch Job" type processing that they need to perform. The [Spring Batch](https://spring.io/projects/spring-batch) framework provides reusable functions that are essential in processing large volumes of records, including logging/tracing, transaction management, job processing statistics, job restart, skip, and resource management. It can simplify your batch applications, and can be combined with one of the previously mentioned scheduling techniques to allow this "Batch Job" logic to be performed on a set schedule. 

We have a brief writeup on Spring Batch in this [document](https://github.ford.com/DevEnablement/devenablement-service-batch/blob/master/README.md) and the document refers to a demo app where we integrated Spring Batch into a EcoBoost generated application.
