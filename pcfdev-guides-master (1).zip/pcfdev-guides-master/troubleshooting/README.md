## Troubleshooting &amp; Support

_The following are links to some of the key resources managed by the Dev Enablement Team, and provide key information, guidance, and tooling to support the Software Engineering Community._

_In order for us to best assist you, please start with our Getting Started page that provides many useful links for many of the resources you may need. Also, check Dev Guides for many guides to commonly asked tasks. Our CAB application also provides an excellent reference of sample code for Spring Boot cloud native applications. /dev/central/station provides a one-stop shop solution for EcoBoost where you are able to generate a Spring Boot cloud native application._

### Start here.

See our [About Us](https://devservices.ford.com/aboutus) page for more information on the links below.

[**Getting Started**](https://devservices.ford.com/on-boarding) **|** [**Dev Guides**](https://devservices.ford.com/dev-guides) **|** [**CAB Reference Application**](https://github.ford.com/PCFDev-CAB) **|** [**/dev/central/station**](http://dcs.ford.com/)

### Need more help?

[**Web Enablement**](https://azureford.sharepoint.com/sites/WebCOE/Pages/Default.aspx) - The Web Enablement team provides you with the recommended tools, ​frameworks, and guidelines to help you when making web user interfaces.

[**Mobile Enablement**](https://azureford.sharepoint.com/sites/mobilecoe/Pages/default.aspx) - The Web &amp; Mobile Enablement teams provide you with the recommended tools, patterns, ​frameworks, and guidelines to help you when creating mobile applications &amp; interfaces.

[**Software Development Ecosystem (SDE)**](https://azureford.sharepoint.com/sites/mobilecoe/Pages/default.aspx) - Software Development Ecosystem portal covering developer related topics for Cloud Native, WAS Liberty, PCF, and OpenShift CaaS.

[**EAMS**](https://www.eams.ford.com/home.faces?dswid=9586)(Enterprise Architecture Management System) – TM process and its associated TSL will no longer track open source 3rd party libraries in EAMS. TM will defer open source management and reporting to the FOSSA tool, but will continue to manage open source approval for software (e.g., open source tools) that cannot be used with the FOSSA tool.

[**FOSSA**](https://azureford.sharepoint.com/sites/SDE/SitePages/FOSSA.aspx)(Open Source Management for Enterprise Teams) – To determine if a FOSS technology is supported by the FOSSA tool, please view the FOSSA Supported Application Technologies spreadsheet.

[**Design Enablement**](https://azureford.sharepoint.com/sites/design/Pages/home.aspx) - Resources to help craft superb user experience through research, visual design, interaction design, and usability.​​

[**WAS Liberty Ford Java Frameworks**](https://azureford.sharepoint.com/sites/sde/sitepages/jee_was_liberty.aspx) – Go to source for everything WAS Liberty including information on how to migrate your WAS app to PCF.

[**AutoSys**](https://autosys.ford.com/index.html) – Here you can find all of the resources, manuals, and contact information for using Autosys at Ford.

[**Google/Stack Overflow**](https://stackoverflow.com/) – By using Google and/or Stack Overflow you can find solutions to many of your problems.

[**SpringBoot**](https://www.baeldung.com/) – Here you can find all of the latest information, guides, and tutorials on SpringBoot.

[**Spring**](https://spring.io/guides) – Spring guides and resources.

### Ask for help.

_Search the following communities to see if your question has been previously answered. If your question is still unanswered, please contact us through only one of the following channels._

**PLEASE NOTE:** _Due to the limited availability of Ford&#39;s resources, please do not contact multiple team members for the same issue. Please only post your question to either WebEx Teams or Yammer, not individual team members. This allows us to provide you with a faster response. Your question is also shared with multiple people who can quickly solve and learn from your problem._

**WebEx Teams** - The Dev Enablement team and other helpful members of the community can be reached on WebEx Teams at the following team space names:

- [**/dev/central/station**](https://www.webexteams.ford.com/space?r=fz8y)
- **Cloud Foundry (PCF)**
- [**Ford FOSSA community**](https://www.webexteams.ford.com/space?r=ukki)
- [**API Lounge**](https://www.webexteams.ford.com/space?r=hf8y)
- [**GIT**](https://www.webexteams.ford.com/space?r=0nxp)
- **CASS**

**Note:** Other public spaces can be found on [**WebEx Teams&#39; public index page.**](https://www.webexteams.ford.com/publicspaceindex)

[**Dev Community**](https://www.yammer.com/ford.com/#/threads/inGroup?type=in_group&amp;feedId=7970611200&amp;view=all) – You can also find the Dev Community on **Yammer** where members of the community can engage in discussions around cloud application development. Lots of Q&amp;A in the discussion forum. This is also place where Dev Enablement team&#39;s release announcements are managed.

[**Slack**](https://ford.enterprise.slack.com/) – You can find the Dev community on Slack as well: **Dev-central-station** or **API-lounge**

[**Index Page**](https://azureford.sharepoint.com/sites/SDE/SitePages/Index.aspx) – Multiple useful links to Ford&#39;s resources and others.
