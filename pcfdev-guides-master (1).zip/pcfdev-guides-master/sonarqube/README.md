# SonarQube Integration

This guide will explain how your cloud native java project can leverage the Ford SonarQube offering. SonarQube is an automatic code review tool to detect bugs, vulnerabilities and code smells in your code. It can integrate with your existing workflow to enable continuous code inspection across your project branches and pull requests.

This guide will specifically detail how to register your project for use of SonarQube and then explain how to use the Dev Enablement team's GradleBoost plugin and Jenkins pipeline options (both delivered to EcoBoost generated applications) to automatically submit project code to SonarQube for analysis. If you wish not to use GradleBoost or the Dev Enablement Jenkins Pipeline offering, you will have to look elsewhere for SonarQube integration instructions. If you are looking for an example of how to use SonarQube in a mobile Jenkins pipeline, see the [Android Jenkins guide](https://github.ford.com/WaMCOE/mobile-devguides/tree/master/android-jenkins) or [iOS Jenkins guide](https://github.ford.com/WaMCOE/mobile-devguides/tree/master/iOS-Jenkins-Pipeline). To see a web Jenkins pipeline example using SonarQube, see the [WAME frf-starter project](https://github.ford.com/WaMCOE/frf-starter/blob/master/Jenkinsfile). 


## 1. Register your project

In order to use SonarQube, you need to register your project. Before you register for access, you will want to insure that you have a generic ID that registered so that you can provide that detail in the registration form. This generic user account will be configured in your Jenkins pipeline so that Jenkins can login to SonarQube to send the project information during pipeline execution.

You need to fill out a SharePoint form that is available at this [location](https://azureford.sharepoint.com/sites/SDE/SitePages/SonarQube.aspx). In this form you will provide the generic id information, as well as the cds id's for the developers on your team so that they can all view the results using the SonarQube site.

Once your process is complete, your project admin (as defined in the form) will receive email notification letting them know that you can use SonarQube. You will be provided a SonarQube project key that you need to confgure in your application. You will be able to login to SonarQube to view Analysis results at [https://www.sonarqube.ford.com](https://www.sonarqube.ford.com) after this registration process has been completed.

## 2. Generate a SonarQube Token

As we stated in previous section, use of a generic account is the preferred way to have your application login to SonarQube. In addition to this, the preferred way to authenticate as this generic user is using SonarQube's user token feature. This allows you to provide a token at login as opposed to the generic ID's actual user ID and password combination. See the SonarQube vendor's documentation on [how to generate a user token](https://docs.sonarqube.org/latest/user-guide/user-token/). Keep the token somewhere safe for use in a later step of this guide.

## 3. Store your SonarQube Token in Jenkins Credentials

To avoid your user token from having to be stored in code or direcly in a configuration file or pipeline file, we have opted for leveraging the Jenkins Credentials plugin. When storing your user token, opt for the "Global credentials (unrestricted)" domain, and store it as a Kind type "Username with password". Fill in the User Name (can be anything but not empty), ID, user Token as Password, and Description fields. The Description field should be some meaningful description of what you are using this credential for. The ID field can be anything you want, and the ID that will be in the default configuration file is named `sonar-private`. **Whatever you choose for the ID field will be used later when you edit you configuration file for your pipeline.**

If you are not familiar with Jenkins Credentials, see the [Jenkins Credentials documentation](
https://jenkins.io/doc/book/using/using-credentials/), and look specifically at the section on "Adding new Global Credentials".



## 4. Configure your Application

In this section, we will focus on the necessary steps to configure your application so that it is submitted to SonarQube for Quality Analysis. 
You will see that there are two options for getting you code to SonarQube for analysis and they both use the same Gradle task:
1. workstation command line using the `gradlew pipelineQualityCheck` task.
2. Jenkins pipeline using the pipeline.configuration.groovy file to configure execution of the pipelineQualityCheck task.

The pipelineQualityCheck task mentioned above is part of the Dev Enablement Gradle plugin called **GradleBoost**. 
If your application was generated using EcoBoost, then you already have GradleBoost implementation. 
If you did not use EcoBoost, then you can read the [GradleBoost plugin documentation](https://github.ford.com/DevEnablement/gradle-boost-plugin) 
and implement it in your Spring Boot application before following any of the further steps outlined in this guide.

Similar to the fact that GradleBoost comes with EcoBoost generated applications, the Dev Enablement Jenkins pipeline solution is also 
available (although it is an option and not a default like GradleBoost) when creating an application using EcoBoost. 
If you are not using EcoBoost and/or you did not include the Dev Enablement Jenkins pipeline offering, 
you will need to follow the [Jenkins Pipeline guide](https://github.ford.com/DevEnablement/ecoboost-pipeline/blob/master/README.md) before you can use our instructions for SonarQube Jenkins integration.


### Configure Jenkins pipeline with SonarQube Integration

The remaining steps involve editing 3 lines in the Dev Enablement provided [pipeline.configuration.groovy](https://github.ford.com/DevEnablement/ecoboost-pipeline/blob/master/pipeline/pipeline.configuration.groovy) file. The changes are as follows:

1. Set the `integrations.thirdParty.sonarQube.enabled` property as `true`  
2. Set the `integrations.thirdParty.sonarQube.credentialsId` property with the Jenkins Credentials ID that you have created above in step 3.   
3. Set the `integrations.thirdParty.sonarQube.projectKey` property with the project key value provided by the Ford SonarQube team when you registered your application.   
3. Set the `integrations.thirdParty.sonarQube.enableBreakBuildOnIssue` property as `true`, if you want to break the Jenkins pipeline 
build when the SonarQube analysis fails with an issue. Additional steps are required for this. 
Refer to [Break Jenkins Pipeline Build on Issue](#Break-Jenkins-Pipeline-Build-on-Issue) section for details.   

Here is the template provided by EcoBoost:
```
// third-party integrations
integrations: [
    // third-party integrations
    thirdParty: [
        ...
        sonarQube: [
            enabled: false,
            credentialsId: 'sonar-private',   // Jenkins credentials ID
            projectKey: '[SONARQUBE-PROJECT-KEY]',
            enableBreakBuildOnIssue: false,
        ],
        ...
    ]
],
```
Refer to [CAB reference application](https://github.ford.com/PCFDev-CAB/cab-service-fordair/blob/master/pipeline/pipeline.configuration.groovy) for an example.

Now that you have performed the required steps, the SonarQube site will contain the analysis results after your pipeline has executed. 
In theory, once you commit the changes to the `pipeline.configuration.groovy` file that we detailed in step 4 above, 
your pipeline will integrate with SonarQube, and will look like [the picture from our Jenkins Pipeline guide](https://github.ford.com/DevEnablement/ecoboost-pipeline#pipeline-stages). 
If your pipeline is configured to run on every commit to GitHub (and we hope it is!), SonarQube analysis will occur on every commit. This allows you to keep tabs on your code quality metrics.

> Note: When running the SonarQube analysis through Dev Enablement pipeline offering with Jenkins Org Scan or with a multi-branch pipeline, 
> the pipeline expose the Source Code Management (SCM) branch name through an environment variable `BRANCH_NAME`, which is used by Dev Enablement pipeline 
> to target the SonarQube analysis to a specific branch. Whenever this value is not available, the analysis is targetted to `master` branch by default. 
> You can set/override the analysis branch name by setting an explicit environment variable `BOOST_SONARQUBE_SONAR_BRANCH_NAME` with a valid SCM branch name.

### Break Jenkins Pipeline Build on Issue
**Prerequisite:** _In order to utilize this feature, application teams are required to install the **_SonarQube scanner for Jenkins plugin_**._
Refer to **SonarQube** section in [Jenkins Server setup guide](https://github.ford.com/DevEnablement/ecoboost-pipeline/blob/master/MIGRATE_TO_JENK8S.md)
for instructions on how to install the plugin.
 
Dev Enablement pipeline offers application teams the ability to break a Jenkins pipeline build when the SonarQube analysis fails due to a Quality Gate failure. 
_Quality Gate is the term used by SonarQube to refer to a set of threshold measures against which the project is analyzed_. This is enabled by setting the pipeline configuration property 
`integrations.thirdParty.sonarQube.enableBreakBuildOnIssue` as `true`.

In addition to setting the above pipeline configuration property, you also need to create a SonarQube webhook to notify 
Jenkins server when the analysis is complete and the Quality Gate results are available. Follow the below steps to create a SonarQube webhook:

1. Login to Ford SonarQube server.
2. Search your project using the project name or project key provided to you.
3. Click on the project name, and then click on the '**Webhooks**' option from the '**Administration**' tab.
4. In the Webhooks screen, click on 'Create' and in the pop-up window, 
    - provide a name for the webhook
    - provide the url as `<your Jenkins instance>/sonarqube-webhook/` _(Note: The suffix '/' is required)._
        <br/>
        Example: `https://jen-jenkins-devenjen.jenkins.app.caas.ford.com/sonarqube-webhook/`
    - leave the Secret blank if you don't want to use a key to generate the Quality Gate analysis result.    
    
>**Note:** The webhook need to be setup for each Sonarqube project individually.

For additional details, refer to [SonarQube website](https://docs.sonarqube.org/latest/analysis/scan/sonarscanner-for-jenkins/).

### Run SonarQube Analysis from Local Command Prompt
If you wish to run the analysis from your local machine, and not want to commit code to GitHub and wait for a pipeline to run, 
you have the option of performing the analysis from the command prompt. You will need access to the user token to achieve this. The steps are:
1. Set an environment variable to hold the user token
2. Set an environment variable to hold the project key
3. Run the in `pipelineQualityCheck` gradle task to perform the analysis

Example command for our reference app CAB, on a Mac/Unix (the token below is not valid so don't try to use it):
```
$ export BOOST_SONARQUBE_SONAR_LOGIN=abc123dsfkjsdfksjdflksdjf
$ export BOOST_SONARQUBE_SONAR_PROJECTKEY=com.ford.cloudnative:CAB-FordAir
$ ./gradlew pipelineQualityCheck

```

Optionally, you can set the environment variable `BOOST_SONARQUBE_SONAR_BRANCH_NAME` to target the analysis to a specific SCM branch. 
When this value is not set, the analysis is targetted to `master` branch by default.

### Consider SonarLint plugin

If you want quick feedback from your IDE, and don't want to publish the results, an option is to use the SonarLint plugin that is available for both IntelliJ and Eclipse IDE's. It will give you feedback quickly that is very simialar to what the central SonarQube server will provide. See the SonarLint plugin pages for [IntelliJ](https://www.sonarlint.org/intellij/) or [Eclipse](https://www.sonarlint.org/eclipse/) for more details.

## References

- CAB Reference Application - [https://github.ford.com/PCFDev-CAB/cab-service-fordair](https://github.ford.com/PCFDev-CAB/cab-service-fordair)
- Jenkins Pipeline Guide - [https://github.ford.com/DevEnablement/ecoboost-pipeline/blob/master/README.md](https://github.ford.com/DevEnablement/ecoboost-pipeline/blob/master/README.md)
- GradleBoost Plugin - SonarQube Support - [https://github.ford.com/DevEnablement/gradle-boost-plugin#sonarqube-module](https://github.ford.com/DevEnablement/gradle-boost-plugin#sonarqube-module)
- SonarQube User Tokens - [https://docs.sonarqube.org/latest/user-guide/user-token/](https://docs.sonarqube.org/latest/user-guide/user-token/)
- Jenkins Credentials - [https://jenkins.io/doc/book/using/using-credentials/](https://jenkins.io/doc/book/using/using-credentials/)
