# ADFS configuration for frontend and backend integration.

This guide covers Angular Single page application (SPA) as frontend, and Spring boot application as backend.


The Angular frontend is protected with OAuth2 [implicit](../implicit), and Spring Boot backend is protected by [OAuth2 Java Web Token JWT](../spring-boot/resource-server). 

In order to integrate with the frontend, the backend must use the same resource URI as the frontend.

## 1. Frontend ADFS registration

Register frontend application as **website**.

- Login to ADFS Registration at [https://www.adfsreg.ford.com/](https://www.adfsreg.ford.com/).
- Register New App
- Add Website
  > The options of FORD Federated Users and Standard ADFS claims should be good for most of applications.
  
  > You can change "Resource URI (Web API Identifier)" value according to  your application name convention.

## 2. ADFS with frontend

[ADFS with Angular Development Guide](https://github.ford.com/WaMCOE/web-devguides/blob/master/adfs-with-angular/ADFS-Integration.md) details steps to protect the Angular UI with ADFS.

You can use Angular interceptor to attach the OAuth2 token to Authorization http header before calling backend API services. You should check if token is expired to avoid authentication failure, please refer to [checkLogin()](https://github.ford.com/WaMCOE/frf-jab/blob/master/src/app/oauth/authorization.guard.ts#L51).


## 3. ADFS with Spring Boot Application

You can generate Spring Boot application from [/d/c/s](https://dcs.ford.com/project-workflow/springboot) with EcoBoost template. When selecting "App-to-App Security (Server-Side)" option, the generated application has ADFS configuration setup already.  All you need is to update "audience-id" in the application.properties with the ADFS Resource URI of frontend, and change the "spring.security.oauth2.resourceserver.jwt.issuer-uri" property for different environment(DEV, QA or PROD).

If your application is not generated from /d/c/s with app-to-app security option, we recommend to generate a sample application and refer to the WebSecurityConfiguration.java and application.properties.

## Access backend API services from another application.

Any other applications can access your backend API services with [client-credentials](../spring-boot/client-credentials). 

The frontend Resource URI can only searched in the "WebSites" tab during creating Client & Secret from ADFS registration site. The default tab is "Web Services". Refer to User Guide at https://www.adfsreg.ford.com/ for creating client & Secret steps.

## Test backend APIs
You need to create a Client&Secret for testing backend APIs, and this token can be used for 42Crunch conformance scan also.