# CORS configuration for Spring Boot Application

For security reasons, browsers restrict cross-origin HTTP requests to the same domain as the initiated scripts. 

For example, the JavaScript code in a front-end application at https://localhost:9500 uses XMLHttpRequest to invoke a back-end service at https://localhost:8080.

Following the same-origin policy, the request from front-end to back-end is blocked because of different origins, unless the response from back-end include the right cross-origin resource sharing (CORS) headers.

This guide describes how to configure CORS in Spring Boot application.

You can enable CORS for individual controller class/method or for whole application.


## CORS Configuration in class/method level

You can add @CrossOrigin annotation to controller classes or methods.

### Add @CrossOrign to class level to enable CORS all API methods in this class.

For Example:
```java
...
@RestController
@RequestMapping(path = "/api/v1/admins")
@CrossOrigin(origins = {"https://localhost:9500"},
    allowedHeaders = { "Accept", "Authorization", "Content-Type"},
    methods = {RequestMethod.GET,RequestMethod.POST},
    allowCredentials = "true",
    originPatterns = "/api/**"
	)
public class AdminController {
...
```

### Add @CrossOrign to enable CORS for individual methods

For Example:
```java
...
	@CrossOrigin(origins = {"https://localhost:9500"},
    allowedHeaders = { "Accept", "Authorization", "Content-Type"},
    methods = {RequestMethod.GET,RequestMethod.POST},
    allowCredentials = "true",
    originPatterns = "/api/**"
	)
    @GetMapping(produces = {MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_PROBLEM_JSON_VALUE})
	public AdminsResponse getAdmins() {
...
```

For Spring Security, CORS needs to be processed first, before other authorization handlers.

```java
...
	public static class ResourceServerSecurityConfiguration extends WebSecurityConfigurerAdapter {
		@Override
		protected void configure(HttpSecurity http) throws Exception {
            http.cors().and()
...
```


## CORS Configuration in application level

You can create your own CorsFilter to enable CORS for all APIs in your application

For Example:
```java
...
	@Value("${allowed-origins:https://localhost:9500}")
	String allowedOrigins;

	@Bean
	public FilterRegistrationBean<CorsFilter> corsFilter() {

		List<String> allowedOriginList = Arrays.stream(allowedOrigins.split(",")).map(String::trim)
				.collect(Collectors.toList());
		UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
		CorsConfiguration config = new CorsConfiguration();
		config.setAllowCredentials(true);
		config.setAllowedOrigins(allowedOriginList);
		config.addAllowedHeader("Accept");
		config.addAllowedHeader("Authorization");
		config.addAllowedHeader("Content-Type");
		config.addAllowedMethod("GET");
		config.addAllowedMethod("POST");
		source.registerCorsConfiguration("/api/**", config);
		FilterRegistrationBean<CorsFilter> bean = new FilterRegistrationBean<>(new CorsFilter(source));
		bean.setOrder(Ordered.HIGHEST_PRECEDENCE);
		return bean;
	}
...
```


## Security Considerations
You should restrict the allowed origins, allowed HTTP methods and matched path pattern as specific as possible.

## Additional Resources

* CAB Reference App has CORS implmented per this guide. See [cab-service-fordair](https://github.ford.com/PCFDev-CAB/cab-service-fordair/blob/master/src/main/java/com/ford/cab/fordair/WebSecurityConfiguration.java) for details.

* See the [CORS support in Spring Framework](https://spring.io/blog/2015/06/08/cors-support-in-spring-framework) post from Spring for more information. 

* See [CORS Nightmare](https://github.ford.com/cyourman/CORSnightmare) document authored by Casey Yourman for details on troubleshooting and understanding CORS.


