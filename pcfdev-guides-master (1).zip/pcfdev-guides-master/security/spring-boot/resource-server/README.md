

### Resource Server

In OAuth 2.0, a *resource server* is an application/service that is on the receiving side of an HTTP request with an access token. *Resource servers* validate and authenticate the request using its access token. They grant access to resources based on rules and the request's token.

Following code changes are required for a Spring Boot 2.1+ MVC application to validate access tokens from a specific provider.  For a reactive service, see the [Gateway guide](../../../gateway) for implementation details.

[Resource Server Video](https://videosat.ford.com/#/videos/01a3788a-6a56-4e25-a4c0-120ca97b5c28)

###### build.gradle
```gradle
implementation 'org.springframework.boot:spring-boot-starter-oauth2-resource-server'
```

###### application.properties
Set *spring.security.oauth2.resourceserver.jwt.issuer-uri* property with the provider's issuer URI. Refer to the [Provider Issuer URIs](../../README.md#provider-issuer-uris) section for a list of popular Ford provider URIs.
```properties
# i.e. Ford ADFS4 (Production)
spring.security.oauth2.resourceserver.jwt.issuer-uri=https://corp.sts.ford.com/adfs/services/trust
```
Set a property named *audience-id* with the resource-uri or resource-id value that you received while onboarding in to ADFS4 or Azure-AD OAuth Servers 

```properties
audience-id=<RESOURCE-URI-OF-YOUR-RESOURCE-SERVER-AS-PER-ADFS-OR-AZURE_AD-ONBOARDING>
```

###### HttpSecurity

In your security `@Configuration` class, you must configure your *HttpSecurity* with `http.oauth2ResourceServer().jwt()`. To validate a JWT token's audience field and control the session management properly, we need to do a little more work.

```java
@Value("${audience-id}")
String audience;

@Autowired
JwtDecoder decoder;
```


```java
JwtDecoder newJwtDecoder = wrapJwtDecoderWithAudienceCheck(this.jwtDecoder, audience);

http
    ...
    .sessionManagement()
        .sessionCreationPolicy(SessionCreationPolicy.STATELESS)
        .and()
    .oauth2ResourceServer()
        .jwt()
            .decoder(newJwtDecoder)
```

###### Audience Check Helper
```java
static JwtDecoder wrapJwtDecoderWithAudienceCheck(JwtDecoder jwtDecoder, String audience) {
	return (token) -> {
		Jwt jwt = jwtDecoder.decode(token);
		if (jwt.containsClaim(AUD) && !jwt.getClaimAsStringList(AUD).contains(audience)) {
			throw new JwtValidationException("Audience field does not match: " + audience, Arrays.asList(new OAuth2Error("invalid_aud")));
		}
		return jwt;
	};
}
```


Refer to [WebSecurityConfiguration.java](src/main/java/com/ford/cloudnative/pcfdev/security/WebSecurityConfiguration.java#L38) for full implementation.

<br/>

### Authentication

Above changes will automatically validate an incoming JWT Bearer token's timestamp, issuer value, and audience field, otherwise return a `403 Forbidden` response. The Bearer token is converted to `JwtAuthenticationToken` authentication/principal object and associated with the current request. `JwtAuthenticationToken` can be injected in controller methods.

Default Bearer token converter (1) maps the **sub**ject claim field to the principal's name and (2) maps the **scope**/**scp** claim fields to the granted authority list with SCOPE_ prefix. You can override this standard mapping conversion with your own converter `jwt().jwtAuthenticationConverter(...)`.

> Refer to the [JWT Decoder](../../README.md#jwt-decoder) section on how to inspect JWT Bearer tokens and gain a better understanding of the values getting mapped.

<br/>

### Basic Authentication (optional)

For educational purposes, this project demonstrates how to configure an application with some endpoints protected by bearer tokens while others by basic authentication or no restrictions at all (public). Refer to [WebSecurityConfiguration.java](src/main/java/com/ford/cloudnative/pcfdev/security/WebSecurityConfiguration.java#L75) and [HelloController.java](src/main/java/com/ford/cloudnative/pcfdev/security/hello/HelloController.java#L38) for the sample reference code.

<br/>

### Testing

#### ADFS4 Bearer Token

Start the application using `./gradlew bootRun`.

This application uses ADFS4 QA for verifying Bearer tokens. The following snippet generates a valid ADFS4 QA token based on some test credentials.

```bash
export CLIENT_ID='d70a7ed4-52e3-41ff-b1d5-96a8bc3f1f6e'
export CLIENT_SECRET='BRYv55lFDaLpamZhS9AbZY4P4GlwZ-q2OfWjX7x-'
export RESOURCE='urn:ssotest_web'

curl -X POST https://corpqa.sts.ford.com/adfs/oauth2/token \
  -H 'Content-Type: application/x-www-form-urlencoded' \
  -d "grant_type=client_credentials&client_id=${CLIENT_ID}&client_secret=${CLIENT_SECRET}&resource=${RESOURCE}"
```

Using *access_token* value from the JSON response as the access token, you can make the following protected call

```bash
export ACCESS_TOKEN='eyJ0eXA....'

curl -X GET http://localhost:8080/api-token/hello \
  -H "Authorization: Bearer ${ACCESS_TOKEN}"
```

#### Azure AD Bearer Token

Start the application with `azuread` profile and proxy settings:

```bash
export JAVA_OPTS='-Dhttps.proxyHost=internet.ford.com -Dhttps.proxyPort=83 -Dhttps.nonProxyHosts="*.ford.com"'
./gradlew -Dspring.profiles.active=azuread bootRun
```

This application now uses Azure AD for verifying Bearer tokens. The following snippet generates a valid Azure token based on some test credentials.

```bash
export HTTP_PROXY="http://internet.ford.com:83" && export HTTPS_PROXY="http://internet.ford.com:83" && export http_proxy="http://internet.ford.com:83" && export https_proxy="http://internet.ford.com:83" && export no_proxy=“localhost,*.ford.com”
export CLIENT_ID='ac2746b8-40c2-4377-988f-f8883848af41'
export CLIENT_SECRET='0pB33?5m?RrMJmds:vuFmMcnxy_3cfMQ'

curl -X POST https://login.microsoftonline.com/c990bb7a-51f4-439b-bd36-9c07fb1041c0/oauth2/token \
  -H 'Content-Type: application/x-www-form-urlencoded' \
  -d "grant_type=client_credentials&client_id=${CLIENT_ID}&client_secret=${CLIENT_SECRET}&resource=ac2746b8-40c2-4377-988f-f8883848af41"
```

Using *access_token* value from the JSON response as the access token, you can make the following protected call

```bash
export ACCESS_TOKEN='eyJ0eXA....'

export HTTP_PROXY="" && export HTTPS_PROXY="" && export http_proxy="" && https_proxy="" && no_proxy=“”

curl -X GET http://localhost:8080/api-token/hello \
  -H "Authorization: Bearer ${ACCESS_TOKEN}"
```




<br/><br/>
[<< Return back to the main security topics page](../../)
