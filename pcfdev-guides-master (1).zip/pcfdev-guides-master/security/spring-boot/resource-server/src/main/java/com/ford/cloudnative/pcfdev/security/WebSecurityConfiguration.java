package com.ford.cloudnative.pcfdev.security;

import static org.springframework.security.oauth2.jwt.JwtClaimNames.AUD;

import java.util.Arrays;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.annotation.Order;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.oauth2.core.OAuth2Error;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.security.oauth2.jwt.JwtDecoder;
import org.springframework.security.oauth2.jwt.JwtValidationException;


@EnableGlobalMethodSecurity(prePostEnabled = true)
@EnableWebSecurity
public class WebSecurityConfiguration {

	/*****************************************************************************************************************
	 * Resource Server (handle incoming Bearer tokens)
	 *****************************************************************************************************************/
	
	@Configuration
	@Order(10)
	public static class ResourceServerSecurityConfiguration extends WebSecurityConfigurerAdapter {
		
		@Value("${audience-id}")
		String audience;
		
		@Autowired
		JwtDecoder jwtDecoder;
		
		@Override
		protected void configure(HttpSecurity http) throws Exception {
			JwtDecoder newJwtDecoder = wrapJwtDecoderWithAudienceCheck(this.jwtDecoder, audience);

			http
			.cors()
			.and()
			.antMatcher("/api-token/**")
			.authorizeRequests()
				.anyRequest().authenticated()
				.and()
			.sessionManagement()
				.sessionCreationPolicy(SessionCreationPolicy.STATELESS)
				.and()
			.oauth2ResourceServer()
				.jwt()
					.decoder(newJwtDecoder)
			;
		}
		
	}
	
	// helper
	static JwtDecoder wrapJwtDecoderWithAudienceCheck(JwtDecoder jwtDecoder, String audience) {
		return (token) -> {
			Jwt jwt = jwtDecoder.decode(token);
			if (jwt.containsClaim(AUD) && !jwt.getClaimAsStringList(AUD).contains(audience)) {
				throw new JwtValidationException("Audience field does not match: " + audience, Arrays.asList(new OAuth2Error("invalid_aud")));
			}
			return jwt;
		};
	}
	

	/*****************************************************************************************************************
	 * Other - Basic/Public
	 *****************************************************************************************************************/
	
	@Configuration
	@Order(30)
	public static class HttpSecurityConfiguration extends WebSecurityConfigurerAdapter {
	
		@Override
		protected void configure(HttpSecurity http) throws Exception {
			http
			.csrf()
				.disable()
			.authorizeRequests()
				.antMatchers("/api-public/**").permitAll()
				.antMatchers("/api-basic/**").authenticated()
				.anyRequest().denyAll()    
				.and()
			.sessionManagement()
				.sessionCreationPolicy(SessionCreationPolicy.STATELESS)
				.and()
			.httpBasic()
			;
		}
		
	}

}

