package com.ford.cloudnative.pcfdev.security.hello;

import java.util.HashMap;
import java.util.Map;

import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.oauth2.server.resource.authentication.JwtAuthenticationToken;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@CrossOrigin
@RestController
public class HelloController {

	// resource server endpoint which is protected by bearer token (Client-Credentials/Implicit flow)
	// refer to README.md for test instructions
	@GetMapping("/api-token/hello")
	public Map<String, String> helloBearerToken(JwtAuthenticationToken auth) {
		Map<String, String> body = new HashMap<>();
		body.put("name", auth.getName());
		body.put("accessToken", auth.getToken().getTokenValue());
		return body;
	}




	// public endpoint
	@GetMapping("/api-public/hello")
	public Map<String, String> helloPublic(Authentication auth) {
		Map<String, String> body = new HashMap<>();
		body.put("auth.name", (auth != null ? auth.getName() : null));
		return body;
	}

	// endpoint protected by Basic Authorization
	@GetMapping("/api-basic/hello")
	public Map<String, String> helloBasic(UsernamePasswordAuthenticationToken auth) {
		Map<String, String> body = new HashMap<>();
		body.put("name", auth.getName());
		body.put("principal.username", ((User)auth.getPrincipal()).getUsername());
		return body;
	}
}
