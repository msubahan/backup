package com.ford.cloudnative.pcfdev.security;

import static org.springframework.http.MediaType.TEXT_HTML;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpInputMessage;
import org.springframework.http.HttpOutputMessage;
import org.springframework.http.converter.AbstractHttpMessageConverter;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.http.converter.HttpMessageNotWritableException;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;

@SpringBootApplication
public class ResourceServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(ResourceServerApplication.class, args);
	}


	// helper class specific to this project which adds supports for converting Map objects (returned in controller class) to HTML for browsers
	@Configuration
	public static class WebConfigHtmlConverterHelper implements WebMvcConfigurer {
		@Autowired
		ObjectMapper mapper;
		
		@Override
	    public void configureMessageConverters(List<HttpMessageConverter<?>> converters) {
	    	ObjectWriter writer = mapper.writerWithDefaultPrettyPrinter();

	    	converters.add(new AbstractHttpMessageConverter<Map<?, ?>>(TEXT_HTML) {
				protected boolean supports(Class<?> clazz) {
					return Map.class.isAssignableFrom(clazz);
				}
				
				protected Map<?, ?> readInternal(Class<? extends Map<?, ?>> clazz, HttpInputMessage inputMessage) throws IOException, HttpMessageNotReadableException {
					return null;
				}

				protected void writeInternal(Map<?, ?> t, HttpOutputMessage outputMessage) throws IOException, HttpMessageNotWritableException {
					outputMessage.getBody().write(("<pre>" + writer.writeValueAsString(t)).getBytes());
				}
	        });
	    }
	}
}
