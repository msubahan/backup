package com.ford.cloudnative.pcfdev.security.hello;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.reactive.function.client.WebClient;

import static com.ford.cloudnative.pcfdev.security.hello.SecurityContextJwtAuthenticationTokenOverride.overrideJwtAuthenticationToken;

@RestController
public class HelloProxyController {

    @Autowired
    @Qualifier("client-adfs4")
    WebClient clientAdfs4WebClient;
    
    @Autowired
    @Qualifier("client-azure-ad")
    WebClient clientAzureAdWebClient;


    @GetMapping("/with-client-adfs4")
    public String client1() {
        //overrideJwtAuthenticationToken();
        return clientAdfs4WebClient.get()
                .uri("http://localhost:8080/api-token/hello")
                .retrieve()
                .bodyToMono(String.class)
                .block();
    }


    @GetMapping("/with-client-azure-ad")
    public String client2() {
        //overrideJwtAuthenticationToken();
        return clientAzureAdWebClient.get()
                .uri("http://localhost:8080/api-token/hello")
                .retrieve()
                .bodyToMono(String.class)
                .block();
    }
}
