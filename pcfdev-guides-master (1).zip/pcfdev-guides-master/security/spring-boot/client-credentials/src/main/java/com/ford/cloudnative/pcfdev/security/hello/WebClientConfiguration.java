package com.ford.cloudnative.pcfdev.security.hello;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.oauth2.client.ClientCredentialsOAuth2AuthorizedClientProvider;
import org.springframework.security.oauth2.client.OAuth2AuthorizedClientManager;
import org.springframework.security.oauth2.client.endpoint.DefaultClientCredentialsTokenResponseClient;
import org.springframework.security.oauth2.client.registration.ClientRegistrationRepository;
import org.springframework.security.oauth2.client.web.DefaultOAuth2AuthorizedClientManager;
import org.springframework.security.oauth2.client.web.OAuth2AuthorizedClientRepository;
import org.springframework.security.oauth2.client.web.reactive.function.client.ServletOAuth2AuthorizedClientExchangeFilterFunction;
import org.springframework.web.reactive.function.client.WebClient;

import java.util.function.Consumer;

@Configuration
public class WebClientConfiguration {
    @Autowired
    ClientRegistrationRepository clientRegistrationRepository;
	
    @Autowired
    OAuth2AuthorizedClientRepository authorizedClientRepository;

    @Bean
    @Qualifier("client-adfs4")
    WebClient clientAdfs4WebClient(@Value("${spring.security.oauth2.client.registration.client-adfs4.resource}") String resource) {
    	return WebClient.builder()
                .apply(oauth2Configuration("client-adfs4", resource))
                .build();
    }
    
    @Bean
    @Qualifier("client-azure-ad")
    WebClient clientAzureAdWebClient(@Value("${spring.security.oauth2.client.registration.client-azure-ad.resource}") String resource) {
    	return WebClient.builder()
                .apply(oauth2Configuration("client-azure-ad", resource))
                .build();
    }

    private Consumer<WebClient.Builder> oauth2Configuration(String clientRegistrationId, String resource) {

        OAuth2AuthorizedClientManager oAuth2ClientManager = getOAuth2AuthorizedClientManager(resource);

        ServletOAuth2AuthorizedClientExchangeFilterFunction oauth2 = new ServletOAuth2AuthorizedClientExchangeFilterFunction(oAuth2ClientManager);
        oauth2.setDefaultClientRegistrationId(clientRegistrationId);

        return oauth2.oauth2Configuration();
    }

    public OAuth2AuthorizedClientManager getOAuth2AuthorizedClientManager (String resource) {
        DefaultClientCredentialsTokenResponseClient clientCredentialsTokenResponseClient = new DefaultClientCredentialsTokenResponseClient();
        clientCredentialsTokenResponseClient.setRequestEntityConverter(new AdOAuth2ClientCredentialsGrantRequestEntityConverter(resource));

        ClientCredentialsOAuth2AuthorizedClientProvider ccAuthorizedClientProvider = new ClientCredentialsOAuth2AuthorizedClientProvider();
        ccAuthorizedClientProvider.setAccessTokenResponseClient(clientCredentialsTokenResponseClient);

        DefaultOAuth2AuthorizedClientManager authorizedClientManager = new DefaultOAuth2AuthorizedClientManager(
                clientRegistrationRepository, authorizedClientRepository
        );

        authorizedClientManager.setAuthorizedClientProvider(ccAuthorizedClientProvider);

        return authorizedClientManager;
    }
}
