package com.ford.cloudnative.pcfdev.security.hello;

import org.springframework.http.RequestEntity;
import org.springframework.security.oauth2.client.endpoint.OAuth2ClientCredentialsGrantRequest;
import org.springframework.security.oauth2.client.endpoint.OAuth2ClientCredentialsGrantRequestEntityConverter;
import org.springframework.util.MultiValueMap;

public class AdOAuth2ClientCredentialsGrantRequestEntityConverter extends OAuth2ClientCredentialsGrantRequestEntityConverter {
    final String RESOURCE = "resource";

    private final String resource;
    
    public AdOAuth2ClientCredentialsGrantRequestEntityConverter(String resource) {
        this.resource = resource;
    }

    @Override
    @SuppressWarnings("unchecked")
    public RequestEntity<?> convert(OAuth2ClientCredentialsGrantRequest clientCredentialsGrantRequest) {
        RequestEntity<?> requestEntity = super.convert(clientCredentialsGrantRequest);
    	
        MultiValueMap<String, String> formParameters = (MultiValueMap<String, String>)requestEntity.getBody();
        formParameters.add(RESOURCE, this.resource);;
    	
        return requestEntity;
    }
}
