package com.ford.cloudnative.pcfdev.security.hello;

import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.security.oauth2.server.resource.authentication.JwtAuthenticationToken;

import java.util.Map;
import java.util.stream.Collectors;

public class SecurityContextJwtAuthenticationTokenOverride {

    public static void overrideJwtAuthenticationToken() {
        SecurityContext securityContext = SecurityContextHolder.getContext();
        JwtAuthenticationToken principal = (JwtAuthenticationToken) securityContext.getAuthentication();
        if (principal.getName() != null) { return; }

        Jwt jwt = principal.getToken();
        Map<String, Object> claims = jwt.getClaims();
        Map<String, Object> newClaims = claims.entrySet().stream().collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue));
        newClaims.put("sub", claims.get("appid"));

        Jwt newJwt = new Jwt(jwt.getTokenValue(), jwt.getIssuedAt(), jwt.getExpiresAt(), jwt.getHeaders(), newClaims);
        JwtAuthenticationToken newPrincipal = new JwtAuthenticationToken(newJwt);
        securityContext.setAuthentication(newPrincipal);
    }
}
