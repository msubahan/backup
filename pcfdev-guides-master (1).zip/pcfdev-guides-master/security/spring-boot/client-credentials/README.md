## Client Credentials

Client Credentials grant type is used to obtain an access token using (the client's) credentials directly. As such, this can only be used where credentials can be securely stored (hidden from the public) such as in a **backend service** application. Backend services primarily use this grant type to obtain a access token about themselves and use it in service-to-service communications.

[Service Client Video](https://videosat.ford.com/#/videos/34d587d1-2f38-4d79-993e-d1594d66ec4b)
<br/>

### Implementation

Few workarounds are required to get client credentials to work with Spring Security and AD providers (i.e. ADFS4, Azure).

- AD providers accept an additional optional *resource* parameter that sets the audience (aud) field of the access token. Setting your token with a specific audience value is a recommended security practice. Since Spring Security does not a facilitate a way to do this through its properties, some extra custom code is required; i.e. [AdOAuth2ClientCredentialsGrantRequestEntityConverter.java](src/main/java/com/ford/cloudnative/pcfdev/security/hello/AdOAuth2ClientCredentialsGrantRequestEntityConverter.java), [WebClientConfiguration.java](src/main/java/com/ford/cloudnative/pcfdev/security/hello/WebClientConfiguration.java).


- Spring Security 5 out-of-the-box does not support client credentials without some additional dependency or  code. This sample project favors use of *WebClient* which is recommended by the Spring team.


- When calling a secured service from another secured service using WebClient and Client Credentials Grant Type, 
Spring Security inspects the incoming authentication token for principal name, which is not available in a 
machine-to-machine auth token. To overcome this issue, call the `overrideJwtAuthenticationToken` function in 
[SecurityContextJwtAuthenticationTokenOverride.java](./src/main/java/com/ford/cloudnative/pcfdev/security/hello/SecurityContextJwtAuthenticationTokenOverride.java)
before making the external API call using the WebClient (refer [HelloProxyController.java](./src/main/java/com/ford/cloudnative/pcfdev/security/hello/HelloProxyController.java)).
This overrides the security context authentication with subject field added to the Jwt token claims. 
In this example, the source API is not secured and hence this method call is not required.

###### build.gradle


```gradle
implementation 'org.springframework.boot:spring-boot-starter-security'
implementation 'org.springframework.security:spring-security-oauth2-client'
implementation 'org.springframework.boot:spring-boot-starter-oauth2-resource-server'
implementation 'org.springframework.boot:spring-boot-starter-webflux'
```

> NOTE:  *WebClient* is reactive and it is part of the webflux dependency.

###### application.properties

For every client, configure its credentials (i.e. id, secret), *resource* parameter, and provider issuer URI in the properties file. (Refer to the [Provider Issuer URIs](../../README.md#provider-issuer-uris) section for a list of popular Ford provider URIs.)

Below is the configuration for one of the clients defined in this project. We have given this Ford ADFS4 QA test client the name *client-adfs4*. The other one defined in [application.properties](src/main/resources/application.properties) is an Azure AD test client named *client-azure-ad*.


```properties
spring.security.oauth2.client.provider.client-adfs4.token-uri=https://corpqa.sts.ford.com/adfs/oauth2/token

spring.security.oauth2.client.registration.client-adfs4.client-authentication-method=POST
spring.security.oauth2.client.registration.client-adfs4.authorization-grant-type=client_credentials
spring.security.oauth2.client.registration.client-adfs4.client-id=d70a7ed4-52e3-41ff-b1d5-96a8bc3f1f6e
spring.security.oauth2.client.registration.client-adfs4.client-secret=BRYv55lFDaLpamZhS9AbZY4P4GlwZ-q2OfWjX7x-
spring.security.oauth2.client.registration.client-adfs4.resource=urn:ssotest_web
```

> NOTE: The resource parameter is a custom property and it will be flagged by IntelliJ &mdash; ignore this warning.

###### WebClient Configuration & Injection

Each client must have its own separate *WebClient* instance that is configured to its particular set of properties. Since each *WebClient* is thread-safe, we register each WebClient instance as a *@Bean* in [WebClientConfiguration.java](src/main/java/com/ford/cloudnative/pcfdev/security/hello/WebClientConfiguration.java) so that we can inject it easily in other parts of the code like so:

```$xslt
    @Autowired
    @Qualifier("client-adfs4")
    WebClient client1WebClient;

    @Autowired
    @Qualifier("client-azure-ad")
    WebClient client2ebClient;
```

> NOTE: we make use of *@Qualifier* to differentiate between different clients

<br/>

### Testing

#### ADFS4 Client Credentials

Run this application and the [resource-server sample project](../resource-server).

By visiting http://localhost:9999/with-client-adfs4 in your browser, this project obtains an access token using ADFS4 client credentials and consumes the ADFS4 -protected resource-server endpoint in the other project. 


#### Azure AD Client Credentials

Run this application and the [resource-server sample project](../resource-server) with the profile `azuread`.

By visiting http://localhost:9999/with-client-azure-ad in your browser, this project obtains an access token using Azure AD client credentials and consumes the Azure-AD-protected resource-server endpoint in the other project. 


<br/><br/>
[<< Return back to the main security topics page](../../)
