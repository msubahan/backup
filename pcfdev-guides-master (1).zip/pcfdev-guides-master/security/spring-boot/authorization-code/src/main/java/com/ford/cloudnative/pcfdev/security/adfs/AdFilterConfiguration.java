package com.ford.cloudnative.pcfdev.security.adfs;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.ProviderManager;
import org.springframework.security.oauth2.client.OAuth2AuthorizedClientService;
import org.springframework.security.oauth2.client.endpoint.DefaultAuthorizationCodeTokenResponseClient;
import org.springframework.security.oauth2.client.oidc.authentication.OidcAuthorizationCodeAuthenticationProvider;
import org.springframework.security.oauth2.client.oidc.userinfo.OidcUserRequest;
import org.springframework.security.oauth2.client.oidc.userinfo.OidcUserService;
import org.springframework.security.oauth2.client.registration.ClientRegistrationRepository;
import org.springframework.security.oauth2.client.userinfo.OAuth2UserService;
import org.springframework.security.oauth2.client.web.OAuth2LoginAuthenticationFilter;
import org.springframework.security.oauth2.core.oidc.user.OidcUser;

import javax.servlet.Filter;
import java.util.Collections;

@Configuration
@EnableConfigurationProperties
public class AdFilterConfiguration {
    @Autowired
    ClientRegistrationRepository clientRegistrationRepository;

    @Autowired
    OAuth2AuthorizedClientService authorizedClientService;

    @Bean(name = "ad-authorizationredirect-filter") // Filter performs redirect to the authorization endpoint to get authcode
    Filter adFilter() {
        AdOAuth2AuthorizationRequestRedirectFilter filter = new AdOAuth2AuthorizationRequestRedirectFilter(clientRegistrationRepository);
        return filter;
    }

    @Bean(name = "ad-authorizationcode-filter") // Receives the authcode to hand off for token exchange
    OAuth2LoginAuthenticationFilter codeProcessorFilter() {
        OAuth2LoginAuthenticationFilter filter = new OAuth2LoginAuthenticationFilter(clientRegistrationRepository, authorizedClientService, "/login/oauth2/code/*");
        filter.setAuthenticationManager(getProviderManager());
        return filter;
    }

    // Manager holds an array of authentication providers
    private AuthenticationManager getProviderManager() {
        ProviderManager authenticationManager = new ProviderManager(Collections.singletonList(getOidcAuthorizationCodeAuthenticationProvider()));
        return authenticationManager;
    }

    // Handles exchange of authorization code for tokens - Customized to remove authorization header
    private OidcAuthorizationCodeAuthenticationProvider getOidcAuthorizationCodeAuthenticationProvider() {
        DefaultAuthorizationCodeTokenResponseClient tokenResponseClient = new DefaultAuthorizationCodeTokenResponseClient();
        OAuth2UserService<OidcUserRequest, OidcUser> userService = new OidcUserService();
        return new OidcAuthorizationCodeAuthenticationProvider(tokenResponseClient, userService);
    }
}
