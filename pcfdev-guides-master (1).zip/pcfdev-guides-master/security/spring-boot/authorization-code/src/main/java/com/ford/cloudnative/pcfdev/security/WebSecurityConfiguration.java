package com.ford.cloudnative.pcfdev.security;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.annotation.Order;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.oauth2.client.registration.ClientRegistration;
import org.springframework.security.oauth2.client.registration.ClientRegistrationRepository;
import org.springframework.security.oauth2.client.registration.InMemoryClientRegistrationRepository;
import org.springframework.security.web.authentication.LoginUrlAuthenticationEntryPoint;
import org.springframework.security.web.authentication.www.BasicAuthenticationFilter;

import javax.servlet.Filter;
import java.util.Iterator;


@EnableGlobalMethodSecurity(prePostEnabled = true)
@EnableWebSecurity
public class WebSecurityConfiguration {

	/*****************************************************************************************************************
	 * Client Application (authorization-code flow with browser/mobile clients)
	 *****************************************************************************************************************/

	@Configuration
	@Order(20)
	public static class AuthorizationCodeSecurityConfiguration extends WebSecurityConfigurerAdapter {
		@Autowired
		ClientRegistrationRepository clientRegistrationRepository;

		@Autowired
		@Qualifier("ad-authorizationcode-filter")
		Filter authorizationFilter;

		@Override
		protected void configure(HttpSecurity http) throws Exception {
			Iterator iterator = ((InMemoryClientRegistrationRepository)clientRegistrationRepository).iterator();
			ClientRegistration registration = (ClientRegistration)iterator.next();
			String loginEntryPoint = "/oauth2/authorization/" + registration.getRegistrationId();

			String[] oauth2Paths = { "/login", "/oauth2/**", "/login/**" };
			http
					.csrf()
					.disable()
					.authorizeRequests()
						.antMatchers(oauth2Paths).permitAll()
						.antMatchers("/api-public/**").permitAll()
					.and()
					.authorizeRequests().anyRequest().authenticated()
					.and()
					.exceptionHandling()
					.authenticationEntryPoint(
							new LoginUrlAuthenticationEntryPoint(loginEntryPoint))
					.and()
					.addFilterBefore(authorizationFilter, BasicAuthenticationFilter.class)
			;
		}
		
	}

}

