package com.ford.cloudnative.pcfdev.security.hello;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.oauth2.client.OAuth2AuthorizedClient;
import org.springframework.security.oauth2.client.OAuth2AuthorizedClientService;
import org.springframework.security.oauth2.client.authentication.OAuth2AuthenticationToken;
import org.springframework.security.oauth2.core.oidc.user.DefaultOidcUser;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.Map;


@RestController
public class HelloController {

	@Autowired OAuth2AuthorizedClientService authorizedClientService;
	
	// endpoint protected by Authorization-Code grant
	@GetMapping("/api-code/hello")
	public Map<String, String> helloAuthorizationCode(OAuth2AuthenticationToken auth) {
		OAuth2AuthorizedClient client = authorizedClientService.loadAuthorizedClient(auth.getAuthorizedClientRegistrationId(), auth.getName());
		
		Map<String, String> body = new HashMap<>();
		body.put("name", auth.getName());
		body.put("upn", (String)auth.getPrincipal().getAttributes().get("upn"));
		body.put("clientRegistrationId", auth.getAuthorizedClientRegistrationId());
		body.put("accessToken", client.getAccessToken().getTokenValue());
		body.put("idToken", extraIdToken(auth));
		
		return body;
	}

	private String extraIdToken(OAuth2AuthenticationToken auth) {
		return auth.getPrincipal() instanceof DefaultOidcUser ? ((DefaultOidcUser)auth.getPrincipal()).getIdToken().getTokenValue() : null;
	}

	// public endpoint
	@GetMapping("/api-public/hello")
	public Map<String, String> helloPublic(Authentication auth) {
		Map<String, String> body = new HashMap<>();
		body.put("auth.name", (auth != null ? auth.getName() : null));
		return body;
	}
}
