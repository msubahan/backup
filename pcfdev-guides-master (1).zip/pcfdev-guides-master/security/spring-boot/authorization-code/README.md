

### Authorization-Code

Authorization-Code grant is suited for applications that (1) seek to access their end-users' resources and (2) can securely store credentials within its application. Server-side web apps fall under this category. Server-side web apps initiate authorization with the end-user where an authorization code will be returned. With the app's credentials, the code is swapped for an access token, id token, and refresh token. In some cases this grant can be used without a client-secret, with a client-secret that is no longer considered a secret, or using cryptography (PKCE) in clients that cannot secure credentials.

[OAuth 2.0 Security Best Current Practice](https://tools.ietf.org/html/draft-ietf-oauth-security-topics) has emerged recently with favoring authorization code flow with the PKCE extension over implicit flow. Given this is a newer recommendation draft, current adoption is low and tooling may not support this alternative. Dev Enablement will update this guide accordingly as its recommendations change. 

###### Provisioning

Recent updates to Spring Security allow provisioning without requiring a client secret.  Applications can be provisioned using the ADFS Self-Service tool.

If AzureAD is the OAuth Provider, a client secret is required by the OAuth Provider to exchange the authorization code for tokens.

[ADFS Self-Sevice Onboarding Tool](https://www.adfsreg.ford.com/)

[Video demo for ADFS Self-Service Onboarding](https://videosat.ford.com/#/videos/b139019f-5188-4bb4-a01c-2cc6ffdd9611)  

Following code changes are required to enable authorization-code flow with a specific provider:

###### build.gradle
```gradle
implementation 'org.springframework.boot:spring-boot-starter-oauth2-client'
```

###### application.properties
Set <em>spring.security.oauth2.client.*</em> properties with the provider's issuer URI and client registration info. Refer to the [Provider Issuer URIs](../../README.md#provider-issuer-uris) section for a list of popular Ford provider URIs. <em>e.g. Ford ADFS4 (QA)</em>
```properties
spring.security.oauth2.client.provider.my-provider.issuer-uri=https://corpqa.sts.ford.com/adfs/services/trust
spring.security.oauth2.client.registration.my-provider.client-id=urn:devenablementauthcodedevguide:clientid:web_authcode_grant:qa
spring.security.oauth2.client.registration.my-provider.scope=openid
spring.security.oauth2.client.registration.my-provider.client-authentication-method=form
resource: authcodegrantservice2:qa
```

> NOTE: *scope* property is a comma delimited list of scopes. *openid* should be included in the list, otherwise, issues may arise from lack of user information.

###### TLS Configuration

ADFS requires the redirect URI to be secured with TLS (HTTPS).  For that reason, local testing will require additional configuration to support HTTPS.  This configuration will cause issues with deployed applications so the configuration will need to be backed out or enabled through configuration profiles.

This repository contains a self-signed certificate and associated keystore.  See the [Certificate README](CERT-README.md) for additional details.

The keystore is stored under the resources folder and referenced from application properties:
```properties
server.port=8443

# HTTPS Configuration
server.ssl.key-store-type=PKCS12
server.ssl.key-store=classpath:keystore/keystore.p12
server.ssl.key-store-password=apstest
```

###### Custom Security Filter

The adfs package contains the custom filter which adds resource ID support required by Active Directory to get a token with a non-default audience.  The filter is added to the chain through the WebSecurityConfiguration class.
###### HttpSecurity Configuration

In your security `@Configuration` class, you must configure your `HttpSecurity` to enable OAuth 2.0 authorization-code login flow and permit the login endpoints.


```java
String[] oauth2Paths = { "/login", "/oauth2/**", "/login/**" };
http
    .csrf()
    .disable()
    .authorizeRequests()
        .antMatchers(oauth2Paths).permitAll()
        .antMatchers("/api-public/**").permitAll()
    .and()
    .authorizeRequests().anyRequest().authenticated()
    .and()
    .exceptionHandling()
    .authenticationEntryPoint(
        new LoginUrlAuthenticationEntryPoint(loginEntryPoint))
    .and()
    .addFilterBefore(authorizationFilter, BasicAuthenticationFilter.class)
;
```

Refer to [WebSecurityConfiguration.java](src/main/java/com/ford/cloudnative/pcfdev/security/WebSecurityConfiguration.java#L70) for full implementation.

<br/>

### Authentication

Above changes will automatically kick off the authorization 
code grant for users who are not already authenticated. Resultant token will be of type `OAuth2AuthenticationToken` which can be injected in a controller's method.

You can get access to the underlying access token as follows:

```java
@Autowired
OAuth2AuthorizedClientService authorizedClientService;
```


```java
// 'OAuth2AuthenticationToken auth' injected into controller method
String regId = auth.getAuthorizedClientRegistrationId();
OAuth2AuthorizedClient client = authorizedClientService.loadAuthorizedClient(regId, auth.getName());
String accessToken = client.getAccessToken().getTokenValue();
```

<br/>

### HTTP Session

Since authorization-code flow relies on the session registry to keep track of authentication status or user's *state* value between requests, the session registry must be consistent across multiple application instances. Refer to [Spring's HTTP Session Guide](https://docs.spring.io/spring-session/docs/current/reference/html5/) on how to configure your application's sessions to be backed by a database, cache, or some other shared (persistent) storage.

<br/>

### Testing

#### ADFS4 Authorization-Code Flow

Start the application using `./gradlew bootRun`.

The application uses ADFS4 DEV for authorization-code flow. Visit [https://localhost:8443/api-code/hello](http://localhost:8080/api-code/hello) to start the flow.

Note - The browser will identify the untrusted self-signed certificate which will need to be accepted

#### Azure AD Authorization-Code Flow

Start the application with `azuread` profile and proxy settings:

```bash
export JAVA_OPTS='-Dhttps.proxyHost=internet.ford.com -Dhttps.proxyPort=83 -Dhttps.nonProxyHosts="*.ford.com"'
./gradlew -Dspring.profiles.active=azuread bootRun
```

The application uses an Azure test tentant for authorization-code flow. Visit [http://localhost:8080/api-code/hello](http://localhost:8080/api-code/hello) to start the flow. You may or may not have access to this tentant.



<br/><br/>
[<< Return back to the main security topics page](../../)

### Additional Information

#### Consuming Downstream Service
This application is not configured to support consuming a downstream application using the user's access token.  Examining the user's JWT will reveal the following Audience attribute:  urn:microsoft:userinfo.  Spring Security doesn't support Microsoft's resource property.  Modification of this library would be required to change the authorization call.  As a work around, downstream calls can be conducted using Client Credentials grant.  Note that the token will not contain the user's identity but rather the application's identity. 

