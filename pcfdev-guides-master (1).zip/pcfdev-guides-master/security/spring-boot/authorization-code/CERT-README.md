# Certificates and HTTPS in SpringBoot and Angular

## Background
Currently Ford Security Engineering requires the redirect host to use HTTPS.  This is not a 
requirement for UAA.  UAA is good for learning but real intenally-hosted applications should use ADFS4 as the OAuth Provider.

This information was created for Mac.  Translate as needed.

## Warning 
You will need to generate certificates, add them to the configuration, and back them out before pushing the app.  Profiles can be used for the SpringBoot app but an Angular app may require manual removal.
Keep this in mind if a webhook is deploying the app to dev through Jenkins upon commiting changes to Github.

While you can add the cert to your truststore/keychain, if you lose control of your certificate by checking it into GitHub in a public repo, it opens your computer for attack by a hacker reusing the cert.

## Generating the keys and self-signed cert within a PKCS12 format keystore

See the command below for generating the keystore.  Note the names should be changed to match your application.
It will prompt for a keystore password and metadata.  


```
keytool -genkeypair -alias dce -keyalg RSA -keysize 2048 -storetype PKCS12 \
  -keystore src/main/resources/keystore/dceLocal.p12 -validity 365 -dname CN=localhost \
  -ext san=dns:localhost,ip:127.0.0.1 \
  -ext KeyUsage=digitalSignature,nonRepudiation,keyEncipherment,dataEncipherment,keyCertSign \
  -ext eku=serverAuth,clientAuth,codeSigning,timeStamping -startdate -1d
```

## Extracting the PEM format certificates


Extract the certificates (it will prompt for the keystore password):
```
$ openssl pkcs12 -in apstest.p12 -nodes -out key.pem
```

Verify the results (it should not return an error):

```
$ openssl x509 -noout -text -in key.pem
```

The contents will contain both the private key and the certificate.  You will need two files in the apps, the key.pem and the cert.pem.  Filenames are not important, you need to know which is which.  I recommend keeping the extension .pem, .crt is for DER encoded certs.
Make a copy of the file for the public certificate.


```$xslt
$ cp key.pem cert.pem
```

Edit each file and delete the extra contents.  key.pem should only contain the private key and cert.pem should only contain the public cert.  See examples below:

key.pem
```$xslt
-----BEGIN PRIVATE KEY-----
MIIEvgIBADANBgkqhkiG9w0BAQEFAASCBKgwggSkAgEAAoIBAQCKeCixhVIoIILb
...
OtkLT99DgiB+Xs2gG1TZ+sJAp1qV6W0fqFLc0OnpmdN650aWO0lWHtIJ+S5SZ/uf
hBr5Y+FAkv+zk05J+5CrH/Sv
-----END PRIVATE KEY-----
```

cert.pem
```$xslt
-----BEGIN CERTIFICATE-----
MIIDZzCCAk+gAwIBAgIEA2ufFjANBgkqhkiG9w0BAQsFADBkMQswCQYDVQQGEwJV
...
6Cov8Ok3NgBIxQw=
-----END CERTIFICATE-----
```

## Configure Tomcat for SSL in SpringBoot app
Copy the keystore file to src/main/resources.  In the example below I created a subdirectory called keystore.

application.properties
```$xslt
server.port=8443


# HTTPS Configuration
server.ssl.key-store-type=PKCS12
server.ssl.key-store=classpath:keystore/apstest.p12
server.ssl.key-store-password=apstest
server.ssl.key-alias=apstest
```

## Configuring Angular for HTTPS
Copy the two pem files to the project root and reference them in the angular.json file.

angular.json

```$xslt
{
  ...
  "projects": {
    "angularclient": {
      ...
      "architect": {
        ...
        "serve": {
          ...
          "options": {
            "sslKey": "key.pem",
            "sslCert": "cert.pem",
            ...
          },
```

Start the application:

```$xslt
$ ng serve --ssl
```
