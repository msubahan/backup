# Application Security - Authentication and Authorization

This guide covers authentication and authorization topics in application development. It focuses on security patterns around Ford-available security providers such as authentication with **Ford ADFS4** / **Azure AD** and authorization with **APS**.

> PCF's Single Sign-On (SSO) provider UAA is not recommended, and thus is not documented in this guide.


## Table of Contents
- [Authentication](#authentication)
    - [Application Architecture](#application-architecture)
        -[Single-Page Applicatations and Services](#single-page-applications-spa-and-services)
        -[Server-Side Web Applications](#server-side-web-apps)
    - [Spring Security and OAuth2](#spring-security--oauth-20)
- [Authorization](#authorization)
- [ADFS for Angular/Spring Boot Integration](../security/frontend-backend-integration)
- [Reference](#reference)
    - [Security Dev Guides and Videos](#dev-guides-and-videos)
    - [Additional Links](#links)
    - [JWT Decoder](#jwt-decoder)
    - [Provider Issuer URIs](#provider-issuer-uris)


## Authentication

The access token is the heart of OAuth2.  It represents an authenticated client and is used to access resources.  The OAuth2 grants and OIDC flows define how the token is acquired.  These are defined as:
- Client Credentials
- Implicit
- Authorization Code
- Resource Owner Password Credentials

The next section describes the recommended grants for popular application architectures.

### Application Architecture

| Application Architecture | Grant |
|--------------------------|-------|
|Machine service client | Client Credentials or Resource Owner Password Grant using generic ID  |
|SPA|ADFS v4 - Implicit Grant, ADFS v5 - Authorization Code Grant|
|Server-Side Web Application|Authorization Code Grant|
|Mobile Application|Authorization Code Grant with PKCE or Implicit Grant|
|Service/API|NA - Service receives and validates tokens|
 
#### Single-Page Applications (SPA) and Services

Recommended app architecture is single-page applications backed by services.  The client application is deployed independently of the backing service.  That backing service can be a single service or a collection of services.  When a collection of services is desired for reasons of independent deployment and scalability, a gateway pattern should be implemented (See Spring Cloud Gateway Dev Guide).  This model supports both human and machine clients.

Implicit Grant is used within the SPA to authenticate the user and obtain tokens required to consume the backing service.  The service is configured as a resource server.  Machine clients consume the resource using either client credentials (CC) grant or resource owner password credentials (ROPC) grant using generic IDs.  For simple authorization models, CC grant is sufficient.  If fine grained authorization is needed ROPC is beneficial as the token will include the generic ID identity eliminating the need for applications to maintain client IDs to generic IDs mappings.

ADFS v4 does not include a CORS filter so Authorization Code Grant isn’t an option at this time.  The REST call to exchange the authcode for tokens from the browser will fail due to browser enforced security.  Authcode grant is an option for ADFS v5. The benefit this grant is a refresh token for long running sessions though implementation is more complicated.

The diagram below describes this pattern.  In this case authentication is not shown between the gateway service and backing services/downstream services.  External downstream services will dictate authentication required.  Internal backing services could be configure without routes and implement container to container networking.  That would allow lighter weight security such as basic authentication otherwise CC grant should be used.

![Gateway_pattern](images/gatewaypattern.png)

[Click here to learn more on how to obtain an access token using Implicit grant type.](implicit/README.md)

[Click here to learn more on how to obtain an access token using Client Credentials grant type.](spring-boot/client-credentials)

[Click here to learn how to register a Single Page Application or Server Side Web Application in ADFS](https://videosat.ford.com/#/videos/b139019f-5188-4bb4-a01c-2cc6ffdd9611)


#### Server-Side Web Apps

Server-Side web applications are not recommended but are supported.  These applications are not stateless, every request must be accompanied by a session cookie.  This creates an issue with session management.  Scaled applications should externalize session storage to a cache such as REDIS.  If the application is hosted in multiple datacenters a clustered cache service is needed such as SQL Server.

Authorization Code Grant is used for these applications which relies on the user supplying the application an authorization code to log in. 

[Click here to learn more on how to obtain an access token using Authorization-Code grant type.](spring-boot/authorization-code)


### Spring Security & OAuth 2.0

There are multiple options to configuring OAuth 2.0 security in a Spring Boot 2.1+ application. Spring's [OAuth 2.0 Features Matrix](https://github.com/spring-projects/spring-security/wiki/OAuth-2.0-Features-Matrix) highlights these options while pointing out that the *Spring Security 5* dependecy option is the path way forward. While *Spring Security 5* has not yet reached feature parity with *Spring Security OAuth*, in this guide we will favor *Spring Security 5* over other choices whenever possible.

Existing applications that already rely on *Spring Security OAuth* can continue to do so. Bug/security fixes will be supported for the foreseeable future. App teams, however,  are recommended to migrate to *Spring Security 5*. 

> Spring Security 5 also supersedes Dev Enablement's ADFS4 library which is based on Spring Security OAuth


## Authorization

Application teams should use APS or Axiomatics PDP for authorization.  APS was developed in-house and now uses the Axiomatics engine behind the scenes.  APS is a central provider accessible on-prem or externally via API Connect.  Axiomatics PDP is deployed as a separate service into the application space.  The benefit with the PDP is support for very complicated policies.
Both tools implement the XACML standard which defines the following components:

| Acronym | Name | Comment |
|---------|------|---------|
| PEP | Policy Enforcement Point|Your application|
| PDP | Policy Decision Point | Application responding to authorization requests |
| PIP | Policy Information Point | Information sources such as FDS used to make access control decisions|
| PAP | Policy Administration Point | Tool used to manage access control policies|
| PRP | Policy Retrieval Point | Policy store |


[APS Client Example](https://github.ford.com/DevEnablement/pcfdev-guides/tree/master/aps)

<br/>

## Reference
### Dev Guides and Videos
| Type | Link |
| ---- | ---- |
| Dev Guide | [Implicit Grant](implicit/README.md) |
| Dev Guide | [Resource Server](spring-boot/resource-server)|
| Dev Guide | [Service Client](spring-boot/client-credentials)|
| Dev Guide | [Server-Side Web App](spring-boot/authorization-code)|
| Video | [Resource Server](https://videosat.ford.com/#/videos/01a3788a-6a56-4e25-a4c0-120ca97b5c28)|
| Video | [Service Client](https://videosat.ford.com/#/videos/34d587d1-2f38-4d79-993e-d1594d66ec4b)|
| Video | [Server-Side Web App](https://videosat.ford.com/#/videos/dff387d8-3b30-4dc6-8440-40564cc3a761)|
| Video | [Security Architecture](https://videosat.ford.com/#/videos/165e62b8-46b2-421d-a42a-3206545d4cc5)|
| Video | [ADFS Self Service Onboarding](https://videosat.ford.com/#/videos/b139019f-5188-4bb4-a01c-2cc6ffdd9611)|

### Links
<table>
  <tr><th>Link</th></tr>
    <tr>
    <td>[Security docs and videos](https://it2.spt.ford.com/sites/dev/Documents/Forms/Security.aspx)
    </td>
  </tr>
    <tr>
    <td>[CAB Reference Application Integrated with ADFS4](https://github.ford.com/PCFDev-CAB/cab-service-fordair)
    </td>
  </tr>
    <tr>
    <td>[JABGoat - vulnerable version of JAB demonstrating security issues](https://github.ford.com/SoftwareCraftsmanGuild/jabgoat)
    </td>
  </tr>
  <tr>
    <td>[SQL Injection video](https://videosat.ford.com/#/videos/2a4d7853-d2a3-432f-9b6b-e978d75bd3f3)
    </td>
  </tr>
</table>

### JWT Decoder

[Dev Enablement's JWT Decoder](https://dev-services.apps.pd01i.edc1.cf.ford.com/jwt-decoder) is made available to you to inspect your JWT tokens securely. Paste your JWT token and review its header & claims. 

> Avoid pasting your Ford security JWT tokens on third-party public vendors such as the popular site ~~[https://jwt.io]()~~ 

<br/>

### Provider Issuer URIs

<table>
<tr><th width="125">Name</th><th width="725">URI(s)</th></tr>

<tr valign="top"><td>Ford ADFS4</td><td>
https://corp.sts.ford.com/adfs/services/trust<br/>
<a href="https://corpqa.sts.ford.com/adfs/services/trust">https://corp<strong>qa</strong>.sts.ford.com/adfs/services/trust</a><br/>
<a href="https://corpdev.sts.ford.com/adfs/services/trust">https://corp<strong>dev</strong>.sts.ford.com/adfs/services/trust</a>
</td></tr>

<tr valign="top"><td>Azure AD</td><td>
https://sts.windows.net/<strong>&lt;tenant-id&gt;</strong>/
<br/><br/>
<em>i.e.</em><br/>
https://sts.windows.net/c990bb7a-51f4-439b-bd36-9c07fb1041c0/ &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; <em># azure.ford.com (FP)</em>
</td></tr>

</table>
