# Spring Cloud Config Server - Troubleshooting

The following tips will help you in troubleshooting your Config Server setup, both from the server side, as well as the 
client side. We strongly encourage you to look at both the [Config Server Setup Guide](./CONFIG_SERVER_SETUP.md), as 
well as this [client guide](./README.md). The guides have been followed many times, and have been proven provide a 
working solution when followed as prescribed.

## Verify Server Setup using PCF Apps Manager

After creation of a config server, you should use the PCF Apps Manager and use the "Manage" feature for your config 
server instance. After you click on your config server instance, you will see a Manage link in the upper right-hand 
corner of the screen.

![Mirror Server](./images/config-server-instance-screen.png)


<br/>
After you click the Manage link, you will see a screen that should have a "Config Server is online!" message, as well 
as the configuration info, and the Mirror Service info. This info should be enough to verify that the config server was 
setup properly. You can also use this to verify if the Commit hashcode matches the latest commit hash for your 
configuration Git repo.

![Mirror Server](./images/config-server-manage-screen.png)


<br/>
<br/>

## Verify Client Connection using Server logs

When a Spring Boot application that is a config client starts, there is some valuable information regarding config 
server connectivity that will appear in the log. The information will be logged as some of the first events when the 
application is started (or restarted). Looking at the screenshot below, you will notice that log statements exist for:
* Connectivity to a config server
* Connectivity to a config server with profile
* Confirmation of the profile (dev in this example)
* Confirmation of the specific property files that were retrieved

You can view you logs with Splunk (requires setup) or PCF Apps manager.


![Server Logs](./images/config-client-log-file.png)

<br/>
<br/>

## Use Actuator Info endpoint with custom Info Properties

Another option for verifying that your properties are retrieved from the sources you expect, is to leverage a 
combination of the Spring Boot Actuator info endpoints and creation of specific properties that the info endpoint will 
display. Any properties that you create with the prefix of `info.app.` will automatically be displayed when using the 
http://SERVER/actuator/info endpoint that is provided by the Spring Boot Actuator library. This library is included and 
configured by default when generating a new application using EcoBoost. 

Below is a screenshot of our sample app's actuator info endpoint. We can use properties in GitHub to verify that 
our client is indeed retrieving the values from the remote location. You can see we used the property 
`info.app.configclient.property.source` in all our property files, but only the one in GitHub had a value of 
"[GitHub] application-dev.properties". This is done so we can easily tell that the client is able to get configuration 
from GitHub through the Config Server.  

![Actuator Info](./images/actuator-info-screen.png)

<br/>

The property files used for this example are below (notice 2 are from GitHub, and one file is part of the application):
* Git Hub Dev profile - https://github.ford.com/DevEnablement/devenablement-configclientdemo-configrepo/blob/master/application-dev.properties
* Git Hub Dev no profile - https://github.ford.com/DevEnablement/devenablement-configclientdemo-configrepo/blob/master/application.properties
* Part of application - https://github.ford.com/DevEnablement/devenablement-service-configclientdemo/blob/master/src/main/resources/application.properties

<br/>
<br/>

## Debug using HTTP POST

The basic components are the Client app, Config Server, and Property Source.  When applications are not pulling 
configuration properly, verify the Config Server is getting the expected properties.  This can be done by sending REST 
requests directly to the config server.  Obtain the following items by using App Manager -> Config Server Client App 
-> Settings -> Reveal ENV VARS:

- p-config-server uri
- client_id
- client_secret
- access_token_uri

Send a POST to the access token uri using grant_type: client credentials, the client id, and client secret parameters 
urlencoded.  That will return a short lived access token which you will send in a GET request to the config server uri 
in the Authorization header (Authorization: Bearer [token]).  Append the name of the desired configuration file to the 
request:  
https://config-d9a17ec1-8d16-4dcb-94bb-d1a9c208e44b.apps.pp01i.edc1.cf.ford.com/configservertest-development.properties

If the config server is working, the client is not working, and the client log shows it's trying to get the 
configuration from localhost:8888, make sure the app is using the correct dependency (io.pivotal... NOT 
org.springframework.cloud...):
```
io.pivotal.spring.cloud:spring-cloud-services-starter-config-client
```
