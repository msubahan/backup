## Introduction of Spring Cloud Services 3.x

Beginning in 2Q 2020, a new Spring Cloud Services (version 3.x) tile was added to Ford's PCF environments. There will be 
a time period where both the new version as well as the old (2.x) version of the Spring Cloud Services will be 
available. We recommend teams immediately begin using the new version. This change introduces a change in name to the 
config server instance name that is to be used in the cf create-service script that is used when creating a new 
instance of the config server. If using the Apps Manager, the change is even more subtle, as there will now be 2 tiles 
for Config Server (and 2 for Service Registry well). Here is how you know if you are requesting a 2.x version instance 
or a 3.x version instance:

* The name of the service has changed from `p-config-server` for 2.x, and is now `p.config-server`. So the command to 
create a new instance will now look like below. Note that the additional arguments that are used to establish the GitHub 
repo are not impacted.
```cf create-service p.config-server standard my-sample-config-server```

* The Service name as it appears in the Marketplace in PCF Apps Manager has been renamed from “Config Server” for 2.x 
version to “Spring Cloud Config Server” for the new 3.x version.

The major change with the newer version of Config Server is the way in which the Config Server get property files from 
GitHub. This will impact the steps needed to make changes to properties in GitHub "refreshed" such they are available 
to the config server client applications. See the official vendor documentation 
at [https://docs.pivotal.io/spring-cloud-services/3-1/common/config-server/index.html](https://docs.pivotal.io/spring-cloud-services/3-1/common/config-server/index.html) 
as well as the [Config Server Refreshes page](CONFIG_SERVER_REFRESHES.md).