# Spring Cloud Config Server - Client Localhost Example

## Configure app to function as a Config Server in localhost

The instructions below assume that you are using EcoBoost to generate an application with Config Server support. The [Config Server sample project](https://github.ford.com/DevEnablement/devenablement-service-configclientdemo) can also be looked at as a reference.

This solution relies on a couple configuration settings that we need to take care of:
1. Edit the bootstrap.yml file such that the ```spring.cloud.config.server.bootstrap``` property is set to true. A setting of false will turn off use of config server, and only pull properties from local application.properties file.
```
spring.cloud.config.server.bootstrap: ${LOCAL_CLOUD_CONFIG_BOOTSTRAP:true}
```
2. Set and environment named ```LOCAL_CLOUD_CONFIG_DIR``` variable before running the application locally. Set this environment variable to point at a Git repo which contains an application.properties file. An example value if using this guides repo, which does contain a application.properties file in the root of the guide, on a windows machine would be ```C:\projects\GitHub\pcfdev-guides\config-client```
	* Both Eclipse (run configurations) and IntelliJ (edit configurations) provide the ability to set an environment variable. 
	* If running from command line using ```gradlew bootRun```, set the environment variable in your shell. i.e. in Windows use ```set LOCAL_CLOUD_CONFIG_DIR=C:\projects\GitHub\pcfdev-guides\config-client```


## Run Example Locally

1. Create a Git repo on your local machine, and ensure that it contains a file called application.properties (use the one in the root of this guide, just rename it by removing the '.gitfolder' extension). If you have GitHub access you could clone the [PCF DEV example config repo](https://github.ford.com/PCFDev-Reference/pcfdev-sample-config-repo), otherwise you will have to create a your own Git repo and that the application.properties file contains the following 3 properties:
```
devenablement.service.config.client.prop1=This [prop1] was served from the devenablement-sample-config-repo Git Repo
devenablement.service.config.client.prop3=This [prop3] was served from the devenablement-sample-config-repo Git Repo
devenablement.service.config.client.prop5=This [prop5] was served from the devenablement-sample-config-repo Git Repo (application.properties file)
```
2. Set the environment variable per the explanation in the Overview section above. The variable will point to the local Git repo you created in step 1. IF running from command prompt in windows:
```
set LOCAL_CLOUD_CONFIG_DIR=C:\projects\GitHub\pcfdev-guides\config-client
```
3. Run the application.
```
gradlew bootRun
```
4. Test using the API's displayed on the server's index page using your browser to hit [http://localhost:8080](http://localhost:8080).



## What's Happening in the Example?

* The running application is pulling properties from the application.properties in Git as well as those located in the project's local application.properties file. The properties in the Git file take precedence if the property is located in both files.
* The loading of properties occurs at server startup. To refresh property values that are updated in Git while the application is running requires the use of a refresh API. See the [Refreshing Properties](#refreshing-properties) section for more details.
* The 3 API's that are used to display property values can be used to demonstrate that "prop1" and "prop3" are pulled from Git file, while "prop2" is only located in the project's application.properties file. 
* Disabling the config server by editing the bootstrap.yml file setting ```
spring.cloud.config.server.bootstrap: ${LOCAL_CLOUD_CONFIG_BOOTSTRAP:false ``` will cause the perties to only be looked up in the local file, and Git will not be refernced. This change requires a server restart.

