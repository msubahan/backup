# Config Server Refreshes

This page will explain the Config Server architecture, and the process required to get a configuration change 
implemented and made available to your running application which is a Config Server client.

## Mirror Service in Spring Cloud Config Server

The Spring Cloud Config Server uses what is called a Mirror Service to provide a layer between the config server and the 
GitHub instance from where the property files are retrieved. This layer protects the config server and applications 
from any outages or downtime in GitHub. It also prevents config servers from sending too much traffic at GitHub. 
Previous to use of the Mirror Service, Application restarts, deploys, scaling, etc. all would normally cause a "pull" 
event against GitHub. When this is multiplied by all the applications in PCF that use GitHub a Config Server instance, 
the traffic and load on our GitHub server was substantial.

The picture below clearly shows that an application communicates with a config server, and that a config server 
communicates with a mirror server, and a mirror server communicates with GitHub. If GitHub goes down, config server's 
will still be able to pull the property files that are cached in the mirror server. The next section will describe the 
to applications that need to refresh their properties after a change is made in GitHub.

![Mirror Server](./images/config-server-refresh.png)

## Refreshing Properties

Now that we have a mirror service in place, the steps required to get a change to a property file in GitHub reflected in 
an application are as follows:

1. Edit the required property file that is stored in the GitHub repo which you config server was setup to use it's 
backing store for properties. Commit the change to the repo.
2. Refresh the Mirror Service 
   * Our preferred method is through use if the `"periodic": true` setting for the config server as discussed in 
   the next section.
   * Use one of the manual approaches documented at [https://docs.pivotal.io/spring-cloud-services/3-1/common/config-server/refreshing-properties.html]().
3. Refresh the application that is a client of a config server. A refresh can be achieved by:
   * Restarting the application always causes the properties to be loaded as part of app start sequence.
   * Restarting the application without downtime using the CF CLI [rolling restart feature](https://docs.cloudfoundry.org/devguide/deploy-apps/rolling-deploy.html#restart).
   * Use the Actuator API and the `@RefreshScope` annotation in your code that allow a refresh to be initiated via an 
   API call to the application. The details on the setup for this approach are in section later in this document. 


## Update your Config Server to use periodic Mirror refresh

In order for changes made to properties to be reflected in Mirror service, and thus to any client applications, some 
action has to occur to get the Mirror service to refresh. These were covered in the previous section. To avoid having 
to use these manual efforts we suggest using the `"periodic": true` setting in the creation script for a config server.
All EcoBoost generated applications that choose the "Config Server" option and Jenkins pipeline will be provided a 
script for creating a config server instance with this setting. You can refer to this [script](https://github.ford.com/DevEnablement/devenablement-service-configclientdemo/blob/master/pipeline/create-config-server.sh)
in our demo app as an example. 

When this setting is in place, the Mirror service will check the GitHub repo every 5 minutes and compare the last 
commit hashcode vs. the commit hashcode for the last update the mirror service received. If they are different, the 
mirror service will automatically retrieve the latest files from the GitHub repo.

If you already have a config server that does not use this setting, and you want to leverage this recommendation, you 
will need to create a new instance and replace your existing instance. See the "Migrating Spring Cloud Services 2.0.x 
or 1.5.x Service Instances" section of [Vendor Documentation](https://docs.pivotal.io/spring-cloud-services/3-1/common/config-server/managing-service-instances.html) 
to see a process where you can swap in a new config server instance. The instructions are for upgrading from an older 
version of config server, but can be followed for this scenario as well.


#### Using Actuator to refresh in a running application

Properties that are retrieved in a class that has the ``@RefreshScope`` annotation can be refreshed via an API. See 
the [RefreshDemoService.java](https://github.ford.com/DevEnablement/devenablement-service-configclientdemo/blob/master/src/main/java/com/ford/devenablement/configclientdemo/refresh/RefreshDemoService.java) 
class in our demo app as an example.
* To perform the refresh, you need execute a POST operation to the "/actuator/refresh" endpoint. This can be done via 
a curl command, or using a tool such as POSTMAN. The response from the request will report back which properties were 
updated.
* If multiple applications (or if a single app has more than 1 instance running) are bound to one config server, and 
you want to refresh the properties for all of the application instances in one step, you have to refresh them with 
"/actuator/bus-refresh" endpoint for any one of the applications bound to the config-server. This approach does require 
that all the applications are also bound to the same RabbitMQ instance. The "actuator/bus-refresh" endpoint is a 
Spring Cloud Bus endpoint which is used to broadcast state changes like configuration changes using RabbitMQ. 
Applications created using EcoBoost that choose the Config Server option are automatically provided with the service 
bus library (that connects with a Rabbit instance) which is needed to support this bus-refresh approach.
* Since the refresh API may be protected, you may need to authenticate the request. This example application is using 
basic auth, with user/password of "user" & "password". This password is configured 
in [application.properties](https://github.ford.com/DevEnablement/devenablement-service-configclientdemo/blob/master/src/main/resources/application.properties). We have enabled this 
bus-refresh endpoint in this same `application.properties` file using the `management.endpoints.web.exposure.include` 
property. 
* When using the EcoBoost provided WebSecurityConfiguration class, you will need to configure the request matchers to 
allow the actuator refresh and bus-refresh endpoints to pass through. See our Demo Application's 
[WebSecurityConfiguration.java](https://github.ford.com/DevEnablement/devenablement-service-configclientdemo/blob/master/src/main/java/com/ford/devenablement/configclientdemo/WebSecurityConfiguration.java) file for an example.  

When running this example application locally, you can hit the refresh endpoint using the following curl command:
```
curl -X POST --user user:configdemo http://localhost:8080/actuator/refresh
```
or if the app were running locally, and it had a Rabbit service running or if it is running in PCF with multiple app 
instances, the curl command would look like:

```
curl -X POST --user user:configdemo http://localhost:8080/actuator/bus-refresh
```
