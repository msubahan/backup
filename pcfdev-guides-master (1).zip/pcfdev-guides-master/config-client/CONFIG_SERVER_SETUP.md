# Setting up Config Server with GitHub backend
The following instructions detail how to configure a Config Server instance in PCF that will retrieve properties from a Ford GitHub repo. Instructions require use of Git bash shell when using Windows, or a Linux/iOS operating system.
After completing the steps, you will need to push a Spring Boot application that has the proper config server client code in place such that properties will be pulled from the GitHub repo. See the [Config Server Client Guide](../config-client) for an example application.

## Create RSA SSH keys
1.	Create an SSH key; you must use Git bash (or Linux/iOS)
    * when prompted to enter a file, enter a meaningful filename (i.e. configserver)
```
   $ ssh-keygen -t rsa -b 4096 -N '' -m pem
```
2.	Rename the newly created private key file. (i.e. configserver to configserver.key)
3.	You now have 2 files; configserver.key and configserver.pub. They are a private key and a public key respectively. Store these files somewhere safe!

## Configure a GitHub Repo with public key
1. Open GitHub and navigate to the repository that you want to configure as the backend for Config Server. 
    You can view our [Sample Config Server Repo](https://github.ford.com/DevEnablement/devenablement-sample-config-repo) as a reference model.
2.	In the repo, click on “Settings” tab.
3.	Now click on “Deploy Keys” sub-menu item.
4.	Click the “Add deploy key” button on the displayed page.
5.	Add a Title, ex: “config-server-key”
6.	Using Git command line, copy contents of your public key to clipboard
```
   $ clip < configserver.pub
```
or on a Mac
```
   $ pbcopy < configserver.pub
```
7.	Paste the clipboard contents into the “Key” input field in GitHub.
8.	Click the “Add key” to save the Deploy Key.

## Create a Config Server service instance in PCF

1.	Create a script file named create-config-server.sh and use the following text as the initial script: 

```
#!/bin/sh

# create config server instance in PCF using private key
# that pairs with public key that is configured in GitHub
PRIVATE_KEY=$(awk '{printf "%s\\n", $0}' configserver.key)
cf create-service p.config-server standard my-sample-config-server -c "$(cat <<EOF
{
   "git": {
       "uri": "git@github.ford.com:PCFDev-Reference/pcfdev-sample-config-repo.git",
       "privateKey": "$PRIVATE_KEY",
       "periodic": true
   }
}
EOF
)"
```

>Note: The above script creates a Spring Cloud Services (SCS) v3.x instance of Config Server service. Read more about [SCS 3.x here](./SPRING_CLOUD_SERVICES_3.X.md).

2.	Edit above script using you specific information. Text in script that is likely to change for you:
    * configserver.key – Use your RSA SSH private key file name
    * my-sample-config-server – Name of the Config Server Service in PCF
    * PCFDev-Reference – The name of your GitHub Organization
    * pcfdev-sample-config-repo.git – The name of your GitHub repo

3.	Login to PCF using CF CLI. Use [DevServices TAS (PCF) Version Information page](https://devservices.ford.com/version-information) for foundation specific CF login command.

4.	Execute the script to have the config server instance created. 
**NOTE:** The private key file needs to be in the same location as the script, at least when you run the script!
```
   $ ./create-config-server.sh
```

## Periodic Refresh of Mirror

You will notice that the create config server script example included a `"periodic": true` setting. This setting will 
cause the Mirror server to check the GitHub repo every 5 minutes to see whether a refresh is needed. See 
the [Config Server Refreshes page](./CONFIG_SERVER_REFRESHES.md) for more information on refreshes or see 
the [vendor documentation](https://docs.pivotal.io/spring-cloud-services/3-1/common/config-server/configuring-with-git.html).

## Enabling Service Instance Sharing in PCF
Sharing a service instance between spaces allows apps in different spaces to share databases, messaging queues, and other types of services including Config Server instances. Service instances can be shared into multiple spaces and across orgs. Instance sharing can be used to improve maintenance and lower hosting costs. 
The Dev Enablement team thinks that instance sharing of config server instances makes sense, especially in lower environments where you are likely to have all your non-prod properties hosted in the same GitHub repo.

In order to use instance sharing, we need to verify that it is enabled for our foundation. Using CF CLI from a command line, use the following command to verify that service instance sharing is enabled.
```
$ cf feature-flags
```
You can refer the Pivotal documentation at https://docs.cloudfoundry.org/devguide/services/sharing-instances.html to learn more about instance sharing, and for the CF CLI commands to utilize service instance sharing.
 
In addition to using CF CLI commands, you can also use PCF Apps Manager to share service instances. The below example is drafted with CAB as a reference application. A single Config Server service instance is shared between CAB-DEV and CAB-QA spaces with in a same PCF organization.

>**Note:** You can share service instances across spaces and organization but cannot share outside of a foundation (e.g, EDC1 or EDC2).

To achieve this:

1.	Open Apps Manager in desired TAS (PCF) foundation
2. Navigate to the source space where the Config Service service instance originally exists. In the example, it is CAB-DEV space .
3.	Select the "Config Server" instance, click on "Share service Instance" and select the targer org/space where you want to share the service. In the example, it is CAB-QA space. Cick on "Share".
4.	To verify, navigate to the target org/space and select "Services". Verify that "Config Server" service is available.
4.	Select the "Config Server" instance, select "Bind App" and select the app to bind to the service.

![Config Server instance sharing](images/service_instance_sharing.png)

If your app contains `refresh` actuator endpoint enabled, you can refresh the app using a CURL command.
```
$ curl -X POST --user user:configdemo https://cab-fordair-qa.apps.pp01i.edc1.cf.ford.com/actuator/refresh
```

>Note: Replace `cab-fordair-qa.apps.pp01i.edc1.cf.ford.com` with your application URL. Replace `user:configdemo` with your application's basic username:password, if protected using basic authentication or remove it, otherwise. 

The above command will refresh the properties cache in your application, provided the app code uses **RefreshScope** for the referrenced property. In CAB, you can browse this link to verify the refreshed properties https://cab-fordair-qa.apps.pp01i.edc1.cf.ford.com/actuator/info
