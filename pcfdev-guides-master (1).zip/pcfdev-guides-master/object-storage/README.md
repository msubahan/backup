## Spring Boot using Object Storage

This guide included Object Storage demo application details the use Ford's "Storage as a Service (StaaS) - Object Storage" offering from a Spring Boot application.

We will cover how to easily integrate with the StaaS provided from [Ford Cloud Portal (FCP)](https://www.cloudportal.ford.com/object-storage). The previous version of our guide detailed use of the Object Storage provided in the PCF Marketplace, which we are no longer recommending due to the fact that it is easier to integrate with the StaaS offering especially for applications in multiple data centers.

* To learn more about the StaaS offering, see the [StaaS training video](https://videosat.ford.com/#/playlist/16d03a18-262c-4194-9d84-713bb2858fdc/videos/?videoId=3668f522-5d82-4b8c-a13e-e3e0ee6e4d69).


### FCP StaaS provisioning details
To make this example work, we assume you provisioned Object Storage using FCP. FCP will send an email providing you with the following information:

- Funding Approver (LL5+)
- Status
- Size
- Namespace
- Access Key
- URL

The Funding Approver will also receive an email, and will provided with the following:

- Storage Domain Name
- Secret Access Key

> Note: The Ford StaaS offering does not create a bucket by default, which the PCF offering did do for you. In order to write objects to your Object Storage you will need to use the "Create a Bucket" endpoint that we show in the demo app to get a bucket created.

### Integration in your Application


#### Properties
Once you have the Object Storage details from FCP, you will need to make them available to your application. Our demo application stores this data in the application.properties file. We use 3 of the pieces of information that were provided from FCP, and store them in the following properties:
```
s3.endpoint=https://s3-object.ford.com:9021
s3.access-key=24107-cab-dev-ns-a1d29e77-user01
s3.secret-key=ENC(fjfj$%^fdg)
```
> Note: The secret key is indeed a secret and should be protected. Our demo application use encryption to protect this value. See the [Secrets Management Dev guide](https://devservices.ford.com/dev-guides?search=Secrets%20Management%20%26%20Jasypt) to understand our use of Jasypt to provide encryption of properties.

#### Required Library

In order to integrate with a remote Object Storage, we need to use the AWS Java open source library. WE have added the following to `build.gradle`:

```
implementation "com.amazonaws:aws-java-sdk:1.11.850"
```

#### Creating and using the AWS client

Your Spring Boot application will need to use a AWS client object to interact with Object Storage. See the [S3Configuration](https://github.ford.com/DevEnablement/pcfdev-guides/blob/master/object-storage/src/main/java/com/ford/devenablement/objectstoragedemo/S3Configuration.java) class in the demo application. This Config class will create a bean named S3Storage which will make the AWS client available to your application. In the demo application, the [S3Service](https://github.ford.com/DevEnablement/pcfdev-guides/blob/master/object-storage/src/main/java/com/ford/devenablement/objectstoragedemo/s3/S3Service.java) class shows how to autowire the S3Storage object and use it to make use of your object storage.

### Usage in Demo App

In order to see the Object storage in use, update the application.properties with your Object Storage details, run the application, and use the `/swagger-ui.html` endpoint to interact with the S3Controller which contains API's to expose Object Storage operations.



