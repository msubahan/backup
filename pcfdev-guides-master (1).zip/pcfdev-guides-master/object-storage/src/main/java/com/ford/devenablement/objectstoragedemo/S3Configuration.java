package com.ford.devenablement.objectstoragedemo;

import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.client.builder.AwsClientBuilder;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3ClientBuilder;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.regex.Matcher;
import java.util.regex.Pattern;


@Slf4j
@Configuration
public class S3Configuration {

    @Value("${s3.access-key}")
    private String accessKey;

    @Value("${s3.secret-key}")
    private String secretKey;

    @Value("${s3.bucket:}")
    private String bucket;

    @Value("${s3.endpoint}")
    private String endpoint;


    @Bean
    public S3Storage s3Storage() {
        log.error("TEST" + this.secretKey);
        AmazonS3 client = AmazonS3ClientBuilder.standard().withPathStyleAccessEnabled(true)
                .withForceGlobalBucketAccessEnabled(true)
                .withCredentials(new AWSStaticCredentialsProvider(new BasicAWSCredentials(accessKey, secretKey)))
                .withEndpointConfiguration(new AwsClientBuilder.EndpointConfiguration(endpointUrlWithNamespace(endpoint, accessKey), null))
                .build();

        return new S3Storage(client, bucket, endpoint);
    }

    protected String endpointUrlWithNamespace(String endpoint, String accessKey) {
        Matcher matcher = Pattern.compile("((.+?-){3}ns\\d\\d)-").matcher(accessKey);
        if (!matcher.find()) {
            return endpoint;
        }

        String namespace = matcher.group(1);
        String value = endpoint.contains("://s3-object") ? endpoint.replace("://", "://" + namespace + ".") : endpoint;
        return value;
    }

    @Data
    @AllArgsConstructor
    public static class S3Storage {
        private AmazonS3 client;
        private String bucket;
        private String endpoint;
    }

}
