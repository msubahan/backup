package com.ford.devenablement.objectstoragedemo.s3;

import com.amazonaws.services.s3.model.*;
import com.ford.devenablement.objectstoragedemo.S3Configuration.S3Storage;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

@Slf4j
@Service
public class S3Service {

    private S3Storage s3Storage;

    @Autowired
    public S3Service(S3Storage s3Storage) {
        this.s3Storage = s3Storage;
    }


    public List<String> getBucketList() {
        log.info("Started getting the bucket List");
        var buckets = s3Storage.getClient().listBuckets();
        var bucketNames = new ArrayList<String>();
        if (buckets != null) {
            for (Bucket bucket : buckets) {
                bucketNames.add(bucket.getName());
            }
        }
        return bucketNames;
    }


    public Bucket createBucket(String bucketName) {
        var bucket = s3Storage.getClient().createBucket(bucketName);
        log.info("Created a new Bucket, BucketName : " + bucket.getName());
        return bucket;
    }


    public void put(String key, InputStream inputStream, String contentType, String bucketName, boolean makePublic) {
        var meta = new ObjectMetadata();
        log.info("Started uploading the file");
        if (contentType != null) {
            meta.setContentType(contentType);
        }
        var putObjectRequest = new PutObjectRequest(bucketName, key, inputStream, meta);
        if (makePublic) {
            putObjectRequest.setCannedAcl(CannedAccessControlList.PublicRead);
        }

        s3Storage.getClient().putObject(putObjectRequest);
    }


    public List<S3ObjectSummary> getObjects(String bucketName) {
        var list = s3Storage.getClient().listObjects(bucketName);
        if (list.isTruncated()) {
            log.info("Truncated List");
        }
        return list.getObjectSummaries();
    }


    public S3Object getObject(String bucketName, String objectKey) {
        return s3Storage.getClient().getObject(new GetObjectRequest(bucketName, objectKey));
    }


    public void delete(String key) {
        var deleteObjectRequest = new DeleteObjectRequest(s3Storage.getBucket(), key);
        log.info("The Delete Object Key :" + key);
        s3Storage.getClient().deleteObject(deleteObjectRequest);
    }

    public String readFromS3(String bucketName, String key) {
        var s3object = s3Storage.getClient().getObject(new GetObjectRequest(bucketName, key));
        log.info("s3 Object Content , " + s3object.getObjectMetadata().getContentType());
        log.info("s3 Object Content Length" + s3object.getObjectMetadata().getContentLength());

        var contents = new StringBuilder();
        String line;
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(s3object.getObjectContent()))) {
            while ((line = reader.readLine()) != null) {
                contents.append(line);
            }
        } catch (IOException e) {
            throw new IllegalStateException("Can't read from Object", e);
        }
        return contents.toString();
    }

    public void getObjectList() {

        var objectListing = s3Storage.getClient().listObjects(new ListObjectsRequest().withBucketName("s3-bucket-user01"));
        for (S3ObjectSummary objectSummary : objectListing.getObjectSummaries()) {
            log.info(" - " + objectSummary.getKey() + "  " + "(size = " + objectSummary.getSize() + ")");
        }
    }

    public void addFile(InputStream inputStream, String fileName, String contentType, String bucketName) {
        this.put(fileName, inputStream, contentType, bucketName, false);

        try {
            inputStream.close();
        } catch (IOException e) {
            //Ignore but log
            log.trace("Cant close input stream", e);
        }

    }
}
