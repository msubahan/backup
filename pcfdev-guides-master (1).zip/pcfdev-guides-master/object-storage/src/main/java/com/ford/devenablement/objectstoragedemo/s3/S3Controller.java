package com.ford.devenablement.objectstoragedemo.s3;

import com.amazonaws.services.s3.model.Bucket;
import com.amazonaws.services.s3.model.S3Object;
import com.amazonaws.services.s3.model.S3ObjectSummary;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.io.InputStream;
import java.util.List;

@Slf4j
@RestController
@RequestMapping(path = "/api/v1/objectstorage")
public class S3Controller {

    private S3Service s3Service;

    @Autowired
    public S3Controller(S3Service s3Service) {
        this.s3Service = s3Service;
    }

    @ApiOperation(value = "Create a bucket")
    @PostMapping(value = "/buckets/{bucketname}")
    public ResponseEntity<String> createBucket(@PathVariable("bucketname") String bucketName) {
        log.info("Creating a new bucket,name=" + bucketName);
        Bucket bucket = s3Service.createBucket(bucketName);

        return ResponseEntity.ok(bucket.getName());
    }

    @ApiOperation(value = "List buckets in your object storage")
    @GetMapping(value = "/buckets")
    public ResponseEntity<List<String>> listBuckets() {
        var bucketNames = s3Service.getBucketList();
        return ResponseEntity.ok(bucketNames);
    }

    @ApiOperation(value = "Upload File")
    @PutMapping("/buckets/{bucketname}/files")
    public ResponseEntity<String> uploadFile(@RequestParam("file") MultipartFile file, @PathVariable("bucketname") String bucketName, HttpServletRequest request) {

        var fileName = "";
        try (InputStream inputStream = file.getInputStream()) {
            fileName = file.getOriginalFilename();
            var contentType = file.getContentType();
            s3Service.addFile(inputStream, fileName, contentType, bucketName);
        } catch (IOException e) {
            throw new IllegalStateException("Error streaming file upload", e);
        }

        return new ResponseEntity<>(fileName + " was created", HttpStatus.CREATED);
    }

    @ApiOperation(value = "List files in bucket")
    @GetMapping(value = "/buckets/{bucketname}/files")
    public ResponseEntity<List<S3ObjectSummary>> listFiles(@PathVariable("bucketname") String bucketName) {
        log.info("Lists all the files in the bucket,bucketname=" + bucketName);
        List<S3ObjectSummary> list = s3Service.getObjects(bucketName);

        ResponseEntity<List<S3ObjectSummary>> response = new ResponseEntity<List<S3ObjectSummary>>(list, HttpStatus.OK);
        return response;
    }


    @ApiOperation(value = "List file contents of a bucket")
    @GetMapping(value = "/buckets/{bucketname}/files/{filename}/contents")
    public ResponseEntity<String> getFileContents(@PathVariable("bucketname") String bucketName, @PathVariable("filename") String filename) {
        log.info("Reading contents of the file ,bucketname=" + bucketName + ", filename=" + filename);
        var fileContents = s3Service.readFromS3(bucketName, filename);
        return ResponseEntity.ok(fileContents);
    }

    @ApiOperation(value = "Get a file from ECS")
    @GetMapping(value = "/buckets/{bucketname}/files/{filename}/metadata")
    public ResponseEntity<S3Object> getFileInfo(@PathVariable("bucketname") String bucketName, @PathVariable("filename") String filename) {
        var object = s3Service.getObject(bucketName, filename);
        return ResponseEntity.ok(object);
    }

}
