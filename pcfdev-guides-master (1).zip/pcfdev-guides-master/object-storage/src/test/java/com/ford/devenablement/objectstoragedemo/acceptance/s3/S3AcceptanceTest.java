package com.ford.devenablement.objectstoragedemo.acceptance.s3;

import com.ford.cloudnative.base.test.acceptance.AcceptanceTestUtil;
import org.junit.Before;
import org.junit.Test;
import org.springframework.http.ResponseEntity;
import org.springframework.web.reactive.function.client.ClientResponse;
import org.springframework.web.reactive.function.client.WebClient;

import java.util.ArrayList;

import static com.ford.devenablement.objectstoragedemo.TestUtil.get;
import static org.assertj.core.api.Assertions.assertThat;

public class S3AcceptanceTest {

	WebClient webClient;

	@Before
	public void setup() {
		webClient = AcceptanceTestUtil.webClientBuilder().build();
	}

	@Test
	public void testGetHelloEndpoint() throws Exception {
		ClientResponse clientResponse = get(webClient, "/api/v1/objectstorage/buckets");
		var response = clientResponse.bodyToMono(ArrayList.class).block();
		assertThat(clientResponse.statusCode().is2xxSuccessful()).isTrue();
	}
}
