package com.ford.devenablement.objectstoragedemo.s3;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ford.cloudnative.base.app.web.exception.handler.ExceptionHandlerConfiguration;
import com.ford.devenablement.objectstoragedemo.TestUtil;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Import;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.ResultActions;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultHandlers;
import org.springframework.web.servlet.mvc.method.annotation.RequestMappingHandlerAdapter;

import java.util.Arrays;
import java.util.List;

import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@RunWith(SpringRunner.class)
@WebMvcTest(controllers = { S3Controller.class })
@Import(ExceptionHandlerConfiguration.class)
public class S3ControllerIntegrationTest {

	@Rule
	public ExpectedException exception = ExpectedException.none();

	@Autowired
	MockMvc mockMvc;

	@Autowired
	ObjectMapper objectMapper;

	@Autowired
	RequestMappingHandlerAdapter adapter;

	@MockBean
	private S3Service s3Service;

	/***********************************************************************************************
	 * ENDPOINT: GET /api/v1/hello
	 ***********************************************************************************************/

	@Test
	public void should_returnBucketList_forBucketsEndpoint() throws Exception {

		//Build an object
		List<String> buckets = Arrays.asList("bucket1", "bucket2");
		when(s3Service.getBucketList()).thenReturn(buckets);

		TestUtil.jsonGet(mockMvc, "/api/v1/objectstorage/buckets")
				.andExpect(status().isOk())
				.andExpect(content().contentType(MediaType.APPLICATION_JSON))
				// controller unit tests test completeness of response object; we only smoke test here that a JSON response is returned
				.andExpect(jsonPath("$[0]").value("bucket1"))
				.andExpect(jsonPath("$[1]").value("bucket2"));

		verify(s3Service).getBucketList();
	}


	//////////////////// Helper Methods

	ResultActions jsonGet(String url) throws Exception {
		return this.mockMvc.perform(MockMvcRequestBuilders.get(url))
				.andDo(MockMvcResultHandlers.print());
	}

	ResultActions jsonPost(String url, Object entity) throws Exception {
		return
			this.mockMvc.perform(MockMvcRequestBuilders
				.post(url)
				.contentType(MediaType.APPLICATION_JSON)
				.content(objectMapper.writeValueAsString(entity))
			)
			.andDo(MockMvcResultHandlers.print());
	}
}
