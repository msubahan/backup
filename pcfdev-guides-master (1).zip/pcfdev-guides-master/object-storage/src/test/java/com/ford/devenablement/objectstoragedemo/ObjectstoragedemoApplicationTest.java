package com.ford.devenablement.objectstoragedemo;

import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class ObjectstoragedemoApplicationTest {
	@Test
	public void contextLoads() {
	}
}