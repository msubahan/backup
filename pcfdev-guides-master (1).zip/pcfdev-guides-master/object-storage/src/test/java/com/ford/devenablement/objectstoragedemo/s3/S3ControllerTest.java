package com.ford.devenablement.objectstoragedemo.s3;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import java.util.Arrays;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class S3ControllerTest {

    S3Controller controller;

    @Mock
    private S3Service s3Service;

    @Before
    public void setup() {
        controller = new S3Controller(s3Service);
    }

    @Test
    public void testListBuckets() throws Exception {

        //Build an object
        List<String> buckets = Arrays.asList("bucket1", "bucket2");
        when(s3Service.getBucketList()).thenReturn(buckets);

        //Assert
        var bucketResponse = controller.listBuckets();
        var bucketListResponse = bucketResponse.getBody();
        assertThat(bucketListResponse).isNotEmpty();
        assertThat(bucketListResponse).contains("bucket1");
        assertThat(bucketListResponse).contains("bucket2");

    }


}
