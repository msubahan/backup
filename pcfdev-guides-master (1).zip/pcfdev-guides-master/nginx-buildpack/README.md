# NGINX Buildpack Guide

Angular applications are recommended to use nginx buildpack.

You need to include three files, [nginx.conf](https://github.ford.com/WaMCOE/frf-starter/blob/v11.0.0/nginx.conf), [mime.conf](https://github.ford.com/WaMCOE/frf-starter/blob/v11.0.0/mime.types) and [manifest.yml](https://github.ford.com/WaMCOE/frf-starter/blob/v11.0.0/manifest.yml).

This sample nginx.conf includes https redirect and health check endpoint.

You can generate [Angular Standard Setup offering](https://dcs.ford.com/project-workflow/angular), and publish to PCF.

To learn more about nginx buildpack, see the pivotal documentation at [https://docs.pivotal.io/application-service/2-12/buildpacks/nginx/index.html].

## Deploy to PCF

In order to deploy your applciation you can use a pipeline or deploy manually from your local machine using the CF CLI. See our [Getting Started page](https://devservices.ford.com/on-boarding) for instructions on getting the CF CLI, or any other of the critical tools for Cloud Native development.

Steps to deploy your app, using your CF CLI:

1. Login to the appropriate PCF Foundation. This is documented [here](https://github.ford.com/DevEnablement/pcfdev-guides/tree/master/base-service#cf-login-session), or you can use the [PCF Foundation Tool](https://devservices.ford.com/version-information) to get the necessary login command.

2. Follow instructions of this guide, including use of the [manifest.yml](https://github.ford.com/WaMCOE/frf-starter/blob/v11.0.0/manifest.yml) file as a template for setting the name or other characteristics of your application.

3. Run the `cf push` command from the command line in the folder where your project, and the `manifest.yml` file exist. This will cause your project to be uploaded and started in PCF using the nginx buildpack.

4. View log from cf push in order to determine the route (URL) for your application which is now running in PCF.
