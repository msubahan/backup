# Secrets Management

## Overview
This guide details a recommendation that was collaborated amongst the leaders in the Dev Enablement, Platform Enablement, and Ford Credit. We will be 
replacing the single option (previously based on Jasypt) for Java/Spring Boot applications, with a few options where teams will need to make a 
decision based on their situation/requirements. The scope of our recommendations are limited to the Java/Spring Boot stack, and guidance for 
other stacks should be sought elsewhere.

## What is Secrets Management
In the context of this guide, we consider Secrets Management to relate to how we handle data such as passwords, keys, etc. that are needed by the 
application but should not be exposed in plain text in the application code or configuration files. Our strategy will involve the use of 
encryption, or a service that will manage the secrets for us.


## Option 1 – CredHub

This option relies on the use of the CredHub service that is available in PCF. With this option you can store your secrets in a JSON string in a 
CredHub service, where it will only be made available to an application bound to the service running in PCF. The secret can be retrieved at runtime. 
See the [CredHub Secrets Demo App and README](https://github.ford.com/PE-Consulting/peconsulting-service-credhubsecrets) for implementation details.

Best option if:
* You are not using Config Server
* You do not have many secrets

Pros:
* Encryption not required
* Easy to create CredHub service

Cons:
* You need to synchronize the secrets when deploying app to dual data centers
* Multiple secrets in single JSON in CredHub not ideal
* CredHub only available from PCF; Desktop testing use case needs solution


## Option 2 – Config Server with Encryption

This option utilizes the very popular Config Server in PCF. The solution does require for the Config Server service instance to be created with a 
secret to seed the encryption algorithm. See the [Config Server Secrets Demo App and README](https://github.ford.com/PE-Consulting/peconsulting-service-configsecrets) for implementation details.

Best option if: 
* You have many secrets
* You are already using Config Server
* You want to use GitHub to store configuration

Pros:
* Secrets are encrypted
* Dual data center friendly; both data centers point to same GitHub repo

Cons:
* Config Server has some complexity; several moving pieces
* Need to use Config Server endpoint to encrypt secrets


## Option 3 – GCP Secrets Manager

More info coming soon. Initial details are that Spring Boot applications using Google Services will use Google Secrets Manager. Additional use 
cases such as storing non-Google service secrets will be explored.

## Password Management

To learn more about handling of passwords, and how to optimize your password update process, refer to the 
[Password Management Guide](../password-management/README.md)
