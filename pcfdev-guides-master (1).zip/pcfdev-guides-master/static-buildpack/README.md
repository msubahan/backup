# Static Buildpack Guide

> Note: Angular using staticfile_buildpack is deprecated, please refer to [nginx-buildpack](https://github.ford.com/DevEnablement/pcfdev-guides/tree/master/nginx-buildpack)

Candidates for the static buildpack include apps or content that require no backend code other than a webserver. The static buildpack in PCF provides a NGNIX webserver. Examples of staticfile apps are front-end Angular or JavaScript apps, static HTML content, and HTML/JavaScript forms.

> NOTE: The static buildpack is the recommended buildpack for Angular applications. The NGINX buildpack can be considered when more complex cases such as needing to customize the nginx.conf file.

The code in this guide contains a simple example for using the static buildpack in PCF.


The requirements are:
* Ford's PCF foundations, as of PCF 2.0 release in 2018, requires at least 128mb for the memory size
* The Staticfile is just that - static; Just leave it as is in the root folder of your static buildpack project.
* Add any static files (html, css, JavaScript, etc.) based on your requirements
* Edit (or remove) index.html per your requirements
* Edit manifest.yml, and edit the name of your static project
* login to cloud foundry using the [CF CLI](https://devservices.ford.com/on-boarding). See the [Foundation Information page](https://devservices.ford.com/version-information) for the proper cf login command using the CF CLI. 
* perform a cf push from root folder to leverage the manifest.yml settings and deploy your site to a NGINX webserver hosted in PCF.

To learn more about static buildpack, see the cloud foundry documentation at [https://docs.cloudfoundry.org/buildpacks/staticfile/index.html]().

## Deploy to PCF

In order to deploy your applciation you can use a pipeline or deploy manually from your local machine using the CF CLI. See our [Getting Started page](https://devservices.ford.com/on-boarding) for instructions on getting the CF CLI, or any other of the critical tools for Cloud Native development.

Steps to deploy your app, using your CF CLI:

1. Login to the appropriate PCF Foundation. This is documented [here](https://github.ford.com/DevEnablement/pcfdev-guides/tree/master/base-service#cf-login-session), or you can use the [PCF Foundation Tool](https://devservices.ford.com/version-information) to get the necessary login command.

2. Follow instructions of this guide, including use of the `manifest.yml` file as a template for setting the name or other characteristics of your application.

3. Run the `cf push` command from the command line in the folder where your project, and the `manifest.yml` file exist. This will cause your project to be uploaded and started in PCF using the static file buildpack.

4. View log from cf push in order to determine the route (URL) for your application which is now running in PCF.
