## Getting Started with GCP Cloud Functions 

This guide documents the onboarding process GCP Cloud Functions. 

Google Cloud Functions is a serverless execution environment for building and connecting cloud services. With Cloud Functions you write simple, single-purpose functions that are attached to events emitted from your cloud infrastructure and services.


## Prerequisites 

- [Request GCP Project](https://github.ford.com/gcp/prod-requests) 
    - As part of onboarding:
        - Request write access to Cloud Functions API and Cloud Storage API
        - Request Service Account creation
        - Set Up Service Account with Workload Identity Federation (WIF)
        - Set up "Serverless VPC Access User" for "service-SERVICE_PROJECT_NUMBER@gcf-admin-robot.iam.gserviceaccount.com" to "Host Project"
- [Install Google Cloud SDK](https://cloud.google.com/sdk/docs/install)
- [Install Terraform CLI](https://learn.hashicorp.com/tutorials/terraform/install-cli)


## Constraints

- Cannot deploy via GCP Console due to org policy
- [Cannot deploy via gcloud CLI due to limitations with WIF accounts](https://issuetracker.google.com/issues/187734550?pli=1)
- All egress traffic must route through a VPC connector.

## Deploying Via Terraform

- [Terraform Template](https://github.ford.com/gcp/tfm-cloud-functions)


## Calling Cloud Functions

Cloud Functions require a trigger, they can be invoked via HTTP or other Cloud Events. The type of trigger will need to be specified in the Terraform environment file. 

- HTTP triggers
- Event triggers
Referrences:
https://cloud.google.com/functions/docs/calling
https://registry.terraform.io/providers/hashicorp/google/latest/docs/resources/cloudfunctions_function#event_trigger



