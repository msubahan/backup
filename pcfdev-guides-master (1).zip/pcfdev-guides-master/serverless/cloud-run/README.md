## Getting Started with GCP Cloud Run 

This guide documents process to use GCP Cloud Run. 

1. Cloud Run is a fully-managed compute environment for deploying and scaling serverless HTTP containers without worrying about provisioning machines, configuring clusters, or autoscaling.
2. No vendor lock-in - Because Cloud Run takes standard OCI containers and implements the standard Knative Serving API, you can easily port over your applications to on-premises or any other cloud environment. 
3. Fast autoscaling - Microservices deployed in Cloud Run scale automatically based on the number of incoming requests, without you having to configure or manage a full-fledged Kubernetes cluster. Cloud Run scales to zero— that is, uses no resources—if there are no requests.
4. Split traffic - Cloud Run enables you to split traffic between multiple revisions, so you can perform gradual rollouts such as canary deployments or blue/green deployments.
5. Custom domains - You can set up custom domain mapping in Cloud Run and it will provision a TLS certificate for your domain. 
6. Automatic redundancy - Cloud Run offers automatic redundancy so you don’t have to worry about creating multiple instances for high availability


## Pre-Requisites

- [Request GCP Project](https://github.ford.com/gcp/prod-requests) 
    - As part of onboarding:
        - Request write access to Cloud Run API and Cloud Storage API
        - Request Service Account creation
        - Set Up Service Account with Workload Identity Federation (WIF)
        - Set up "Serverless VPC Access User" for "service-SERVICE_PROJECT_NUMBER@serverless-robot-prod.iam.gserviceaccount.com" to "Host Project"
- [Install Google Cloud SDK](https://cloud.google.com/sdk/docs/install)
- [Install Terraform CLI](https://learn.hashicorp.com/tutorials/terraform/install-cli)
- Knowledge on [Dockerfile](https://docs.docker.com/develop/develop-images/dockerfile_best-practices/)
- Build and Deploy Image into project registry.

## Constraints

- Cannot deploy via GCP Console due to org policy
- [Cannot deploy via gcloud CLI due to limitations with WIF accounts](https://issuetracker.google.com/issues/187734550?pli=1)
- All egress traffic must route through a VPC connector.



## To test the app locally

1. Add all the app supporting files and the Dockerfile to a new directory
2. switch to that directory
3. run docker build to create an image that is specific to your app. This command creates a new image based on the Dockerfile and call all your app related files in the current directory to it.
        `docker build . -t <unique_name_to_identify_your_app_image>`
    You can tag as `<repo>/<ProjectID>/<NEW IMAGE URL>`
4. To view all your images, run `docker images`
5. To test your app locally, run `docker run -p 8080:8080 <newly created image ID>`
    Where the port number 8080 would vary based on the port that your app uses
6. Now you have a image running as docker. you can switch to your browser https://localhost:8080 to validate your app
7. To push the same image to container registry,run `docker push <NEW_IMAGE_URL>`
where `NEW_IMAGE_URL` is `<repo>/<ProjectID>/<NEW IMAGE URL>`

**For more info, please refer the [Doc](https://cloud.google.com/run/docs/testing/local)**


## Deploying Via Terraform

- [Terraform Template](https://github.ford.com/gcp/tfm-cloud-run)

