# GitHub Migration – Application Team Guide to Migration AccuRev Depots to GitHub


## Table of Contents

- [Project Summary](#project-summary)
- [Document Objective](#document-objective)
- [Assumptions](#assumptions)
- [Audience](#audience)
- [Timing](#timing)
- [Constraints](#constraints)
- [Pre-conditions](#pre-conditions)
- [Post-conditions](#pre-conditions)
- [Application Team Run Book](#application-team-run-book)
  - [Application team responsibilities GitHub Installation and Access](#application-team-responsibilities-github-installation-and-access)
    - [GitHub Tools:](#github-tools)
    - [GitHub Installation](#github-installation)
    - [How to obtain the Ford GitHub access](#how-to-obtain-the-ford-github-access)
  - [Application team responsibilities Create GitHub Structure](#application-team-responsibilities-create-github-structure)
    - [Create a new organization](#create-a-new-organization)
    - [Create a GitHub Repository](#create-a-github-repository)
    - [Creating teams in GitHub](#creating-teams-in-github)
    - [Team Permission setup in repository](#team-permission-setup-in-repository)
    - [Inviting collaborators to a repository](#inviting-collaborators-to-a-repository)
    - [Set up branches for your Repository](#set-up-branches-for-your-repository)
    - [Protecting the master branch](#protecting-the-master-branch)
    - [Setting the default branch](#setting-the-default-branch)
    - [GitHub Training commands](#github-training-commands)
    - [Learning Git GitHub](#learning-git-github)
- [Code Migration from AccuRev to GitHub](#code-migration-from-accurev-to-github)
  - [Schedule the Assisted shadow session with DevTools team](#schedule-the-assisted-shadow-session-with-devtools-team)
  - [GitHub Flow Branching Model](#github-flow-branching-model)
    - [SDE Team suggested best Practice the GitHub Flow](#sde-team-suggested-best-practice-the-gitHub-flow)
  - [Push the code from AccuRev Prod stream to GitHub master branch](#push-the-code-from-accurev-prod-stream-to-gitHub-master-branch)
  - [Push the code similar like AccuRev stream structure to GitHub branch model](#push-the-code-similar-like-accurev-stream-structure-to-github-branch-model)   
   
### Project Summary
The AccuRev Depot Decommission project is the phase 1 initiative to decommission the on-premise instance of Micro Focus AccuRev. AccuRev is the current enterprise software configuration management platform in the IT department of Ford Motor Company. Usage of the platform will be scaled-down through two primary efforts: migrating content of AccuRev depots to the GitHub platform at Ford and purging decommissioned depots no longer needed by Ford application teams. The project will result in further enabling negotiation options for renewal or elimination of AccuRev vendor software maintenance and support. The project team will address elevated support and resource requirements for the GitHub administrative support team and the GitHub user community at Ford.<br />
Subsequent decommission of the Micro Focus AccuRev hosting infrastructure will be assessed upon completion of the project.
### Document Objective
This document provides guidance for application teams to follow this technical guide for GitHub setup, source code migration process & will continue to Integrate with CI/CD fulfills.
### Assumptions
Application team migrates their latest production code version from AccuRev stream model to a GitHub branch model, without previous stream history, comments, snapshots & revisions.
### Audience
<b>Roles:</b> <br />
The following roles are applicable to the depot decommission procedures


| Role  | Responsibilities |
| ------------- | ------------- |
| Project Sponsor  | Provide project directives, escalation authority, approvals, final acceptance of project deliverables  |
| Project Team Supervisor  | Provide project directives, approvals, and general project team management support  |
| Project Manager  | Manage project initiation, stakeholder expectations, process creation, artifact creation, scheduling of work and timing of delivery, costs, risk mitigation, issue management, and communications/reporting.  |
| Delivery Manager  | Manage technical aspects of the project, ensure on-time delivery and expected quality  |
| Migration Liaison  | Manage communications and relations amongst depot application teams, the GitHub administrator team, and the project team. Assist in defining processes and creating artifacts.  |
| AccuRev SME  | Provides customer consultation for AccuRev, assesses viability of AccuRev Depot migration, provides L3 AccuRev support, and assists in GitHub repository planning  |
| AccuRev Support  | Provides L1 and L2 AccuRev support for project related activity.  |
| GitHub Trainer  | Provides customer training for GitHub. May also provide training to the project team.  |
| GitHub SME  | Provides L3 GitHub support and repository planning.  |
| GitHub Support  | Provides L1 and L2 GitHub support for project related activity.  |
| uBuild SME  | Provide integration capabilities between uBuild and GitHub  |
| AccuRev Depot SPOC  | Single point of contact for application team representation, communication, and coordination of activities related to a single or multiple AccuRev depots owned by an AccuRev Depot Application Supervisor  |
| AccuRev Depot Application Owner  | pprove the migration of one or more owned AccuRev Depots to GitHub and/or the decommission of an owned AccuRev Depot  |
| Architect  | Provide planning, design, guidance, and approval of any required infrastructure changes  |
| GitHub Migration Consultant  | Provide 3rd party support or full service delivery for the migration of version content from AccuRev to GitHub  |
| GitHub Vendor  | Provide GitHub support beyond the means of Ford internal resources  |


### Timing

Xx – xx weeks duration, triggered by pre-conditions noted below

### Constraints
### Pre-conditions 
One of the following has occurred: <br />
• Application status should be “Active” in EAMS.  <br />
• Depot should be active.  <br />
• Promote all active changes from lower stream (QA, DEV) to PROD Stream before migration.  <br />
• Expect all application team members to do self-learning on the GitHub Developer Training.  <br />
October 26, 2020 Github Migration Guide for App Teams 6  <br />

### Post-conditions
• GitHub access has been provided to all team members.  <br />
• Setup is completed the GitHub Organization and repository to store their application code.  <br />
• Provided appropriate permission level: write, Read or Admin to repository. <br />
• Migrated the Production latest code version from AccuRev to GitHub. <br />
• Ready to Decom. AccuRev Depot. <br />

### Application Team Run Book

#### Application team responsibilities GitHub Installation and Access

#### GitHub Tools:

#### Tools:
| Tool  | Description |
| ------------- | ------------- |
| GitHub  | GitHub is a source code repository management tool, aka, a code hosting platform for version control and collaboration for development teams. It lets you and others work together on creating and reviewing code projects from anywhere.  |

#### Installation and Access:

| Tool  | Description |
| ------------- | ------------- |
| GitHub Access  | GitHub request details are available at: http://wiki.ford.com/display/SDE/GitHub  |
| GitHub Client  | Follow “Source Code Management” steps on following wiki: http://wiki.ford.com/display/SDE/Tools https://pages.github.ford.com/githubschool/GitHub-For-Developers-StudentManual/  |

##### GitHub Installation

##### Prerequisites:

As a GitHub developer you will need to install Git package on your local computer to perform normal GIT operation (clone, add, commit, push/pull, branch, etc.). <br />
To install, do the following: <br />
Administration level privileges are NOT required to install Git & Git-LFS <br /> 

##### Install Git (required):

* Navigate to \\ecc9010110.ecc1.ford.com\proj\adsdevpt\global\GitHub in Windows Explorer
* Double click on ‘Git-2.21.0-64-bit’ <br />
To Obtain the Git Client : https://wiki.ford.com/display/SDE/Where+to+obtain+the+Git+client

##### Installing git LFS (recommended)

GitHub limits the size of files allowed in repositories and will block a push to a repository if the files are larger than the 100>MB maximum file limit. <br />

###### You should use git LFS for files > 100mb

* Install git LFS (large file storage) from here: Git LFS
* Open git bash from the windows search, and type "git lfs install". Once this is done, git LFS is all set up <br />

###### Setup Git & Git-LFS https://wiki.ford.com/pages/viewpage.action?pageId=133105145

##### How to obtain the Ford GitHub access

Access requests are managed through IT’s Application Policy Services (APS) application. <br />
Request GitHub access using the below link. <br />
https://wiki.ford.com/display/SDE/How+to+request+GitHub+access. <br />
Here is a link to request GitHub access for proxy ID for CI/CD requirement. <br />
https://wiki.ford.com/display/SDE/How+to+request+GitHub+access+for+Proxy+Account. <br />

<b>Note:</b>: Create proxy id with mailbox and network access. Account Type: Generic ID, a non-person. Contacted the SILAS Admin for any proxy Id queries. <br />
https://wiki.ford.com/display/SDE/Create+a+Generic+CDSID+to+use+with+GitHub <br />
In order to add a CDSID to a GitHub repository (in a Team or as a Collaborator), the CDSID must successfully log into GitHub once. This will instantiate the CDSID and make it available in GitHub. <br />

#### Application team responsibilities Create GitHub Structure

#### Create a new organization.

Once you have access to GitHub, access the link https://github.ford.com/ and click on the "+" Icon on the top of the system and choose "New organization" to create one. <br />
A default "Organization" is created for your CDSID, you can keep private repositories in this space, or even share them with other users. <br />
Now you can create organization with your Team name. As an example. AccuRev2Git, DevTools <br />

![high-level architecture](diagrams/diagram1.JPG)

Next screen will allow you to add members for the organization. <br />

Add People to your newly created organization, you should give Owner permissions to a small group of people who will manage the organization account. Choose a role for the member <br />
https://docs.github.com/en/github/setting-up-and-managing-organizations-and-teams/permission-levels-for-an-organization <br />
You may skip the step if you don't want to add members right now. <br />

Next step after Creation organization, we'll create a Repository. <br />

#### Create a GitHub Repository

We'll create a Repository, under newly created Organization. For this step, access the Organization that you have access and then click “create a new repository” <br />

![high-level architecture](diagrams/diagram2.JPG)

In the below form, fill the information that is requested (in Repository name, it's recommended to fill with the acronym of your application). also is recommended to let your repository in <b>"Private"</b> and do initialize the <b>"README"</b> file<br />

![high-level architecture](diagrams/diagram3.JPG)

After click on <b>"Create repository"</b>, a screen like the one below will be displayed, and you are ready to go. Take note that HTTPS link, it will be used to clone this repository latter.<br />
<b>Note:</b> GitHub do both <b>HTTPS</b> and <b>SSH end points</b>, the Git- LFS supports only <b>HTTPS</b> endpoints.

#### Creating teams in GitHub

We've already created our Organization and repositories in our previous steps, so now it's turn to assign to create our teams.<br />
Go to Organization's home site, and click on the <b>Teams</b> tab

![high-level architecture](diagrams/diagram4.JPG)

Click on <b>"New team"</b> to create your first team. <br />
Again, as we are seeking for consistency with our existing AccuRev setup, we've chosen to create specific groups for each application. <br />
As an example, we'll create the Developers group for AccuRev2Git Application. We'll name this group <b>AccuRev2Git-Developers. </b>

![high-level architecture](diagrams/diagram5.JPG)

Click on <b>"Create team"</b> to complete this step <br />
<b>Adding members to team</b>
Now our group has been created, and we'll be listed as the only member (and therefore maintainer of the group)<br />
<b>Note:</b> Group maintainers will be able to add or remove other members. Carefully select this role based on job function.

![high-level architecture](diagrams/diagram6.JPG)

<b>Important:</b> In order to be available in the list, users must have requested access to github enterprise, access should have been approved, and they should have visited https://github.ford.com at least one, so that their user is generated on the GitHub database.<br />

Add as many users as you want, and you may repeat steps to create a new group for repository Leads. We'll call this one <b>AccuRev2Git-Leads</b> <br />

We're now done setting basic groups. <br />

Keep in mind the Organization Owner will still have this permission! <br />

Once our groups have been created, we can proceed to permission setup in our repository. <br />

#### Team Permission setup in repository

1. Start by going to your Application repository
2. Click on the Settings Tab <br />

![high-level architecture](diagrams/diagram7.JPG)

3. On Settings screen, click on Teams and Collaborators

![high-level architecture](diagrams/diagram8.JPG)

4. On the Collaborators Screen, click on the Add Team button, and add the teams we've created on previous steps.

![high-level architecture](diagrams/diagram9.JPG)

5. Change permissions for Developers and Lead groups to Write, and save settings

![high-level architecture](diagrams/diagram10.JPG)

#### Inviting collaborators to a repository

1. On GitHub, navigate to the main page of the repository.
2. Under your repository name, click Settings.<br />

![high-level architecture](diagrams/diagram11.JPG)

3. In the left sidebar, click Collaborators.
4. Under "Collaborators", start typing the collaborator's Ford cds-id.
5. Select the collaborator's username from the drop-down menu.
6. Click Add collaborator.
7. The user will receive an email inviting them to the repository. Once they accept your invitation, they will have collaborator access to your repository.

#### Set up branches for your Repository

Aligned with our current AccuRev set-up, we'll be setting up some base branches to match AccuRev Streams. Only difference will be that originally created master branch, will be kept, and considered the PROD branch of code. <br />
In order to create branch, go to your application repository, and click the Branch:master dropdown button.

![high-level architecture](diagrams/diagram12.JPG)

Type desired branch name and hit enter to create it. Base setup recommends creating <b>dev</b> and <b>qa</b> branches along with the existing <b>master</b> branch.

![high-level architecture](diagrams/diagram13.JPG)

Eventually new branches will be created as necessary for new features.

#### Protecting the master branch

You should protect the master branch to encourage code reviews before changes are merged and deployed. This will prevent work from being performed directly on master,<br />
If you're a repository owner or have admin permissions in a repository, you can customize branch protections in the repository and enforce certain workflows on master, <br />
https://docs.github.com/en/github/administering-a-repository/configuring-protected-branches

Under a specific repo, go to Settings.

![high-level architecture](diagrams/diagram14.JPG)

Navigate to the branches section (on the left). And then click on “Add rule”. </br>
Finally, enter in the target branch that you would like to protect and apply checks that must be completed before merges and changes to branches occur.<br />

#### Setting the default branch

Our default branch is named master is considered the base branch. If you have admin rights over a repository on your GitHub Enterprise, you can change the default branch on the repository.
1. On GitHub Enterprise, navigate to the main page of the repository.
2. Under your repository name, click Settings.
3. In the left menu, click Branches.
4. In the default branch sidebar, choose the new default branch.

![high-level architecture](diagrams/diagram15.JPG)

You can only switch between branches that already exist on your GitHub Enterprise.

#### GitHub Training commands

***Setup:*** <br />
<b>git config - -global user.name “firstname.lastname”</b> Set a name that is identifiable for credit when review version history. <br />
<b>git config - -global user.email “valid-email”</b> Set an email address that will be associated with each history make <br />

***Setup & Init:*** <br />
<b>git init </b> Initialize an existing directory as Git repository. <br />
<b>git clone [url] </b>Retrieve an entire repository from a hosted location via URL. <br />
<b>git pull [branch name](optional)</b> Pull any changes from the the remote repository to your local copy. <br />

***Stage & Snapshot:*** <br />
<b>git status </b> Show modified files in working directory, stated for your next commit. <br />
<b>git add . or git add [file] </b>Add the files as it looks now to your next commit (state).<br /> 
<b>git reset</b> Unstage a file while retaining the changes in work directory. <br />
<b>git diff</b> Diff of what is changed but not staged. <br />
<b>git diff - -staged </b> Diff of what is staged but not yet committed. <br />
<b>git commit -m “descriptive messages of changes” </b> Commit your staged content as new commit snapshot. <br />
<b>git push origin [branch name] </b> Push your changes to the repository either local or master branch. <br />
<b>git pull [branch name]</b> Pull any changes from the the remote repository to your local copy. <br />

***Branch & Merge:*** <br />
<b>git branch</b> List your branches. A *will appear next to the currently active branch. <br />
<b>git branch [branch-name] </b> Create a new branch at the current commit. <br />
<b>git checkout</b> Switch to another branch and check it out into your working directory. <br />
<b>git merge [branch name]</b> Merge the specified branch’s history into the current one. <br />
<b>git log</b> Show all commits in the current branch’s history


#### Learning Git GitHub

##### Training Resources

Here are some helpful links to learn git/github: <br />
* ###### [Learn Git](https://git-scm.com/book/en/v2 "Heading link")<br />
* ###### [Learn Github](https://guides.github.com/activities/hello-world/ "Heading link")<br />
* ###### [Github High Level Workflow](https://guides.github.com/introduction/flow/ "Heading link")<br />
* ###### [Atlassian Git/Github Tutorials](https://www.atlassian.com/git/tutorials "Heading link")<br />
* ###### [Atlassian Git Cheat Sheet](https://www.atlassian.com/git/tutorials/atlassian-git-cheatsheet "Heading link")<br />

<b>Google has been an invaluable resource to learning Git/GitHub. The user base is so large that you should be able to find anything you're looking for as long as you understand the GitHub terminology.</b>

### Code Migration from AccuRev to GitHub

#### Schedule the Assisted shadow session with DevTools team

Application team can schedule the assisted shadow sessions with DevTools team, after following the below instructions section, and subheadings sections for GitHub setup and project structure creation in GitHub,<br />


  - [Application team responsibilities GitHub Installation and Access](#application-team-responsibilities-github-installation-and-access)
  - [Application team responsibilities: Create GitHub Structure.](#github-structure.)
     
#### GitHub Flow Branching Model
As the name indicates, this model was designed by GitHub and provides an extremely simple and efficient organizational method to take code from development to production.
The GitHub Flow can be summarized in the following steps:
1. Create a branch from the repository.
2. Create, edit, rename, move, or delete files.
3. Send a pull request from your branch and select your reviewer(s) to kick off a discussion.
4. Once the pull request is approved, perform a <b>'Squash Merge'</b> and <b>add a comment</b>.
5. The merge is now performed to master.
6. Tidy up your branches using the delete button in the pull request or on the branches page. <br />
The basic principal behind the GitHub flow is to keep things as simple as possible. This is done by keeping changes as close to the master branch as possible, reducing the chances of frequent code merges and encouraging developers to always maintain production ready code.

#### SDE Team suggested best Practice the GitHub Flow

https://wiki.ford.com/display/SDE/SDE+Development+Best+Practice+using+the+GitHub+Flow <br />

#### Push the code from AccuRev Prod stream to GitHub master branch.

If there is already an existing project folder that you would like to push in git, follow the steps for New Project creation mentioned above and add the required files.
• Create Empty Repo.
• Clone Empty Repo.
• Copy your project files to locally cloned empty repo/folder.
• Add
• Commit
• Push your added project files
* <b>Create a Empty Repo:</b>

![high-level architecture](diagrams/diagram16.JPG)

* <b>Clone Empty Repo:</b> <br />
To get started, open a Git Bash tool then navigate to the new folder you will use as the GitHub Workspace folder on your local computer.<br />
> cd <New-Folder> <br />

Right Click and select Git Bash

![high-level architecture](diagrams/diagram17.JPG)

> git clone https://github.ford.com/AccuRev2Git/GitMigration.git <br />

the process will begin.

Git clone command will request to login to complete the clone process for the first. Please note that when you are prompted to enter your credentials when cloning a repo, you should enter your <b>CDSID in the username field and the value of the password is the personal access token.</b> <br />
https://wiki.ford.com/display/SDE/How+to+set+up+Personal+Access+Token+for+your+GitHub+profile <br />
<b>TIP:</b> If you have issue cloning run below commands to setup Proxy in GitBash

>export http_proxy=http://internet.ford.com:83 <br />
export https_proxy=http://internet.ford.com:83 <br />
export no_proxy="localhost, 127.0.0.1, .ford.com" <br />

![high-level architecture](diagrams/diagram18.JPG)

After finishing the cloning step, you Workspace folder should be like the image below.

![high-level architecture](diagrams/diagram19.JPG)

* <b>Migrating the Code from AccuRev to GitHub</b> <br />
As part of migrate your code directly from AccuRev Prod stream to GitHub master branch, expected from the application teams to promote all the active issue ID’s from lower environment streams (QA, DEV) to Prod Streams,
Then Run pop command on source PROD stream to Git workspace directly,
<b>accurev pop -O -R -v AccuRev_PROD -L C:\AccuRev\AccuRev2Git\GitMigration.</b>
Remove the “. accurev" folder in Git Workspace before check-in the files into repository.

* <b>Sending the Files to GitHub</b> <br />
cd Folder ( Navigate to the Git workspace) <br />
git add * (to add the files that will be pushed to the repository) <br />
git commit -m "Initial Commit - Migration from AccuRev to GitHub" <br />
The Last command will be the push command. Your Login and Authorization Token for GitHub will be requested. <br />
<b>git push -u origin master</b> <br />

![high-level architecture](diagrams/diagram20.JPG)

Finishing this last step, you can access your Git Repository to check if the code was already Pushed.

![high-level architecture](diagrams/diagram21.JPG)

#### Push the code similar like AccuRev stream structure to GitHub branch model
If application team decided to maintain the branch in GitHub similar like current AccuRev stream structure pattern like AccuRev_DEV – > GitHub Dev branch, AccuRev_QA -> GitHub QA branch, AccuRev_PROD -> Master branch. <br />
The default branch get reflects in GitHub is master is considered the base branch, So the first step to create a local dev branch and switch to the dev branch,
Follow the steps below,
1) Create a folder in application name <br />
<b>mkdir < appname ></b>
2) cd < appname > (should be the acronym of your application)
3) Create the local repo branch using below command and switch to branch, <br />
<b>git checkout -b Loadtest3_DEV</b>
4) After you switch to newly created branch to AccuRev_DEV in GitBash, we need to populate the code from AccuRev Dev Stream to the GitHub Workspace directly using below command,<br />
<b>accurev pop -O -R -v Loadtest3_DEV -L C:\AccuRev\workspaces\Loadtest3_DEV.</b>
5) After the populate the code completes, delete the “. accurev" folder in Git Workspace

![high-level architecture](diagrams/diagram22.JPG)

6) git add . (to add the files that will be pushed to the repository)
7) git commit -m "Initial Commit - Migration from AccuRev to GitHub"

![high-level architecture](diagrams/diagram23.JPG)

8) The last step is to the push the code to GitHub remote repository.
Your Login and Authorization Token for GitHub will be requested. <br />
<b>git push -u origin Loadtest3_DEV</b>

![high-level architecture](diagrams/diagram24.JPG)

![high-level architecture](diagrams/diagram25.JPG)









