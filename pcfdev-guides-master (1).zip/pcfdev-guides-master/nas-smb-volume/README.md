# SMB Volume Services (NAS)

This guide explains and demonstrates how to bind and mount a SMB protocol storage share to an application in PCF so that it can perform CREATE/READ/UPDATE/DELETE operations on the files in the storage share. WE also cover why SMB, setup details, and how to bind to SMB/NAS service in PCF from a Jenkins pipeline.
> NOTE: the sample projject has been moved to a seperate repo. see the [SMB Volume Serve Demo App](https://github.ford.com/DevEnablement/devenablement-service-smbvolume) for a working example of Spring Boot application using a SMB Volume service.

## Why SMB

We have switched from the original NFS based NAS mounts in PCF to SMB based for several reasons: 

* Adopting NFS in PCF has proven to be challenging. It is not possible to overcome the security challenges and performance issues (a result of trying to fix security issues) with NFS volume services in PCF. The two articles below describe these challenges.
  * https://www.cloudfoundry.org/blog/securing-cloud-foundry-volume-services-part-1/
  * https://www.cloudfoundry.org/blog/securing-cloud-foundry-volume-services-part-2/
* We have overcome the cons of using SMB by opting to direct all apps to request SMB protocol NAS storage with NTFS/Windows style security, which requires an AD/FIM security group to be created. All access control is now enforced via AD/FIM security groups.

## Prerequisites for SMB Volume Services in PCF
* Access to the PCF Org and Space that contains the application to which you want to bind the SMB share.
* An existing SMB protocol NAS share, requested from the [Ford Cloud Portal.](https://www.cloudportal.ford.com/storage) 
  * Instructions for requesting storage shares [can be found here.](https://azureford.sharepoint.com/sites/itoinfraservices/Storage%20Operating%20Model/Storage%20Service%20Operating%20Model.aspx)
* You will need the full server/share path - example: `//dc18101ad01.prod.f01.dc1.ford.com/q12345` <br>
This information can be found in the summary email sent from the Ford Cloud Portal after the storage is provisioned: <br> 
  * **Storage Hostname:** `dc18101ad01.prod.f01.dc1.ford.com` <br> 
  * **SMB Share Name:** `q12345`
* An existing Generic CDSID that has been added to the same AD/FIM security group that was used when provisioning the storage.
  * You can verify what security groups the Generic CDSID belongs to by visiting Ford's [Security Group Portal](https://iam.ford.com/IdentityManagement/aspx/users/AllPersons.aspx) and searching for the Generic CDSID name. (Note: Must use Internet Explorer)
* Verify you have the correct password for the Generic CDSID and that the password has not expired. Attempting to run the cf CLI commands using an incorrect password will add significant time to the mounting process.
  * You can test the Generic CDSID and password by attempting to log in to the [Ford Password Manager](https://www.changepassword.ford.com/). 
  * If you need to reset the password, you can use that same website to do so, however **BE AWARE** that you may be using this CDSID elsewhere in your codebase and changing the password may break this codebase until you update any configuration with the new password for the Generic CDSID.

## Warnings

* You may encounter issues if using an out of date version of the cf CLI. Info about the CF CLI and links to downloads are available in the [CF CLI Guide](https://github.ford.com/DevEnablement/pcfdev-guides/blob/master/cf-cli/README.md)
* Pay close attention to the syntax of the cf CLI commands. All backslashes `\` and forward slashes `/` must be typed exactly as they are documented. You must also pay attention to the quotation marks used in the cf CLI commands, as copying/pasting the commands can sometimes cause slight changes. There is a difference between `""` and `““`. The cf CLI commands should use `""`.
* A new application (such as the case when doing Blue/Green deploy) cannot immediately bind to the SMB volume service instance such as the case when the service binding is in a manifest file. The application needs to be pushed without starting, and then bind command can be issued with credentials. After the bind, the application can be started.
* Beginning with version 3.0 of the [Dev Enablement Jenkins Pipeline](https://github.ford.com/DevEnablement/pcfdev-guides/blob/master/pipeline-jenkins/README.md), the binding of the Volume Service instance can occur in a script that is executed after the app is pushed (in non-start mode), but before the app starts.

## Manual Volume Service creation an app binding instructions
* `SERVICE_NAME` should be the name you want to call the newly created SMB service in PCF
* `APP_NAME` should be the PCF app you wish to bind/mount the SMB service to
* `STORAGE_HOSTNAME` is the hostname of the NAS server - example: `dc18101ad01.prod.f01.dc1.ford.com`
* `SMB_SHARE_NAME` is the SMB share name - example: `q12345`
* `smb` is the name of the the SMB service offered in PCF and should not be changed
* `Existing` is the name of the service plan for the `smb` service and should not be changed
* `CDSID` is the name of your Generic CDSID
* `PASSWORD` is the password for your Generic CDSID
* `MOUNT_PATH` should be the directory where the application will read/write files to - example: `/var/proj/my-app/nas`
  * This directory path must always begin with `/var/proj`
  * If the full directory path does not exist, the `cf bind-service` command will automatically create the subdirectories
* `username` is a key-value identifier and should not be changed
* `password` is a key-value identifier and should not be changed
* `share` is a key-value identifier and should not be changed
* `mount` is a key-value identifier and should not be changed

### Manual Steps
> Note: These steps assume the application already exists and has already been deployed to PCF.

### 1. Run the `cf create-service` command to create a SMB volume service instance within the same PCF Space as your application.

* Syntax:<br>
```
cf create-service smb Existing SERVICE_NAME -c "{\"share\":\"//STORAGE_HOSTNAME/SMB_SHARE_NAME\"}"`
```
* Example:<br> 
```
cf create-service smb Existing my-smb-service -c "{\"share\":\"//dc18101ad01.prod.f01.dc1.ford.com/q12345\"}"
```
### 2. Run the `cf bind-service` command to bind and mount your newly created SMB volume service instance to your PCF application.

* Syntax:<br> 
```
cf bind-service APP_NAME SERVICE_NAME -c "{\"username\":\"CDSID\",\"password\":\"PASSWORD\",\"mount\":\"MOUNT_PATH\"}"
```
* Example:<br>
```
cf bind-service my-app my-smb-service -c "{\"username\":\"pcfprxid\",\"password\":\"GoFordBlue1\",\"mount\":\"/var/proj/my-app/nas\"}"
```
### 3. Run the `cf restage` command to restage your PCF application.
* Syntax:<br>
`cf restage APP_NAME`
* Example:<br>
`cf restage my-app`<br><br>

### IMPORTANT: If the restage fails, one of the `cf create-service` or `cf bind-service` commands was incorrect. You MUST unbind the application from the service using the `cf unbind-service` command (`cf unbind-service APP_NAME SERVICE_NAME`) before trying to run the first two commands again with the proper parameters/syntax.

### 4.) Once the restage is successful, run the `cf service` command to verify that the `smb` service was created and your PCF application was bound successfully.
* Syntax:<br>
`cf service SERVICE_NAME`
* Example:<br>
`cf service my-smb-service`<br><br>
You should see a "create succeeded" status for your `smb` service, and should see your APP_NAME under "bound apps" for that service.


## Using Dev Enablement Jenkins Pipeline with SMB Volume Services

In order to support use of the SMB Volume service in PCF as well as a Blue/Green deployment model, the Dev Enablement Jenkins pipeline was updated to support the creation of the Volume service as well as the binding of the app to the service via scripts that will be executed during pipeline execution.

The required setup using the Dev Enablement Jenkins pipeline is demonstrated in the [SMB Volume Serve Demo App](https://github.ford.com/DevEnablement/devenablement-service-smbvolume). We will refer to examples from this app frequently in the setup steps below.

Perform the following configuration of your pipeline to allow creation and/or binding to the SMB Volume service instance for your app during your Blue/Green deployments.

1. Add the credentials for the SMB Volume to the Jenkins credentials plugin. See [Pipeline Guide Credentials](https://github.ford.com/DevEnablement/pcfdev-guides/blob/master/pipeline-jenkins/README.md#jenkins-credentials) section for more details.  
2. Use the Cloud SMB Volume block in the `pipeline.configuration.groovy` file for your project. Update this configuration block using the [demo app example](https://github.ford.com/DevEnablement/devenablement-service-smbvolume/blob/master/pipeline/pipeline.configuration.groovy#L118) as a template.
3. Add the volume service creation command to the `pipeline.cf-services.sh` script. This script will create the service instance only if it has not yet been created, and it will use information that you populated in previous step. See  [pipeline.cf-services.sh](https://github.ford.com/DevEnablement/devenablement-service-smbvolume/blob/master/pipeline/pipeline.cf-services.sh#L17) for an example.
4. Add the required service to app binding command to the `pipeline.app-pre-start-script.sh` script. This will allow the binding to occur after the app has been pushed, but before it starts. It also support retrieving the required credentials from Jenkins and avoid s having to have the credentials in scripts files. See the demo app's [pipeline.app-pre-start-script.sh](https://github.ford.com/DevEnablement/devenablement-service-smbvolume/blob/master/pipeline/pipeline.app-pre-start-script.sh#L18) for a working example.
> NOTE: When using this approach to binding the app to the service, you can NOT have the binding in your manifest file.


## Password Management Requirements
* Once the SMB share has been mounted to an application, any time the Generic CDSID password is updated in Active Directory (i.e. via the [Ford Password Manager](https://www.changepassword.ford.com/)), then the application will fail to start the next time it is restaged or restarted. It is important to remember to un-bind and then re-bind the SMB volume service instance to the application with `cf bind-service` using the new credentials whenever the password is updated.

## Troubleshooting

- Most failures result in a `failed to mount volume` error in the app log, which can occur for many reasons. Therefore, it is important to double check the syntax of the cf CLI commands. The cf CLI does minimal syntax checking. A successfull `cf create-service` and `cf bind-service` command does not guarantee that it will actually bind and mount the volume.  Therefore, a syntax error will not be seen until the app is re-staged. 
- Make sure that the Generic CDSID that you are trying to use in the `cf bind-service` command is in the FIM/AD security group that was assigned to the NAS volume ('Read/Write Security' field in Ford Cloud Portal).
- App teams can now mount these volumes on a Windows PC for troubleshooting or fine-tuning permissions for individual files.  The Windows user will need to be added to the FIM/AD Security group.
- There are existing firewall rules that may block connectivity between PCF foundations and your NAS server (especially in PROD) and may cause the SMB binding to fail. You can check connectivity between a PCF foundation and your NAS server using DevEnablement's [WillItConnect app](https://devservices.ford.com/willitconnect). If you experience connectivity issues and believe they are related to the firewall, contact the PCF Ops team with details to open up the firewall rule.
