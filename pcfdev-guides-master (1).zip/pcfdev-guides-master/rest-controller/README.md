## REST Controller Guide

You can find many tutorials online about writing REST controllers in Spring Boot:
- [Pivotal - Building a RESTful Web Service](https://spring.io/guides/gs/rest-service/)
- [Baeldung - RESTful Web Services](http://www.baeldung.com/building-a-restful-web-service-with-spring-and-java-based-configuration)

In this guide, however, we will focus on how to write API-driven controllers for projects based on [Base Service](../base-service) or [Base Service (Multi-Project)](../base-service-multi). We will also touch upon the API response body format, use of *Lombok* library, and finally the different testing strategies you can use against your controller.

<br/>

### Controller Overview

This project has exactly one controller *HelloController* and it's defined as follows:

```
@RestController
@RequestMapping(path = "/api/v1/hello")
public class HelloController {

	@GetMapping
	public HelloResponse hello() { ... }

	@PostMapping
	public HelloResponse helloName(@RequestBody @Valid HelloRequest helloRequest) { ... }
}
```

One endpoint */api/v1/hello* is defined in the controller and it handles two HTTP verbs:
- One method handles *GET* requests and it returns a *HelloResponse* body response.
- One method handles *POST* requests. A **valid** *HelloRequest* post input is required and *HelloResponse* is returned.

Both *HelloRequest* and *HelloResponse* classes here are the API (request/response) models. In an API-driven service, you would first create the API models and then turnaround create the controller/endpoints that would implement these API models.

The remaining controller-related classes are three test classes which are covered later in this guide.

<br/>

### Project Files (Single Project Structure)

Lets now take a look where the API models, the main controller, and its test classes are defined in this project.

<pre>
└── src/
    ├── <em>main/java/com/ford/devenablement/rest/app</em>
    │   └── hello
    │       └── api
    │       |  ├── HelloRequest.java                                 <strong>&lt;== API Request/Response Models</strong>
    │       |  └── HelloResponse.java
    │       └── HelloController.java                                 <strong>&lt;== Main Controller</strong>
    │
    └── <em>test/java/com/ford/devenablement/rest/app</em>
        ├── acceptance/hello
        │   └── HelloAcceptanceTest.java                             <strong>&lt;== Acceptance Test</strong>
        │
        └── hello
            ├── HelloControllerIntegrationTest.java                  <strong>&lt;== Unit/Integration Tests</strong>
            └── HelloControllerTest.java
</pre>

In the **main** source folder, you will find a single feature named *hello*. Within the feature, you have the main controller class and sub-directory containing the API models only; i.e. *HelloRequest*, *HelloResponse*. API models are isolated into its own java package to promote decoupling and API-first design.
 
In the **test** source folder you find the various test classes (i.e. unit, integration, acceptance) that test the controller. The acceptance test being defined in a separate package from the other tests is only a matter of preference where grouping acceptance tests together is favored.

<br/>


### Project Files (Multi-Project Structure)

Alternatively if you are using a mult-project structure for you application, locations of files will slightly differ.

<pre>
├── api/
│   └── <em>src/main/java/com/ford/devenablement/rest/api</em>
│       └── hello
│          ├── HelloRequest.java                                     <strong>&lt;== API Request/Response Models</strong>
│          └── HelloResponse.java
│
└── application/
    ├── <em>src/main/java/com/ford/devenablement/rest/app</em>
    │   └── hello
    │       └── HelloController.java                                 <strong>&lt;== Main Controller</strong>
    │
    └── <em>src/test/java/com/ford/devenablement/rest/app</em>
        ├── acceptance/hello
        │   └── HelloAcceptanceTest.java                             <strong>&lt;== Acceptance Test</strong>
        │
        └── hello
            ├── HelloControllerIntegrationTest.java                  <strong>&lt;== Unit/Integration Tests</strong>
            └── HelloControllerTest.java
</pre>

As recommended by the [Multi-Project Structure](../base-service-multi) guideline, we find the expected top-level component directories *api* and *application* &mdash; each having its own source folders:
- **api** encapsulates the API models only; i.e. *HelloRequest*, *HelloResponse*. API models are isolated from the rest of the application to promote decoupling, API-first design, backwards compatibility, and allow for different components (e.g. *application*, *client*) to depend only on API models in *api* without worrying to pull in other additional logic.
- **application** encapsulates the main controller class in its *main* source folder. In its *test* source folder you find the various test classes (i.e. unit, integration, acceptance) that test the controller. The acceptance test being defined in a separate package from the other tests is only a matter of preference where grouping acceptance tests together is favored.

<br/>

### API Response Body

Lets now take a closer look at the API response of our */api/v1/hello* endpoint.<br/>
*NOTE: Spring can support different message formats (e.g. JSON, XML) and its conversion to/from our API models. In our examples we will use JSON format which is supported out-of-the-box by Spring Boot.*

You can POST your name to the */api/v1/hello* endpoint like so <a name="successmsg"></a>

```
POST /api/v1/hello HTTP/1.1
Content-Type: application/json

{
    "name": "Henry"
}
```

and in return you get a response with a customized greeting message with your name.

<pre>
HTTP/1.1 200 OK
Content-Type: application/json

{
    "<strong>result</strong>": {
        "greeting": "Hello Henry"
    },
    "error": null
}
</pre>

We can also take a look at what a Bad Request response looks like from the same endpoint (caused by not passing in the required *name* parameter): <a name="errormsg"></a>

<pre>
HTTP/1.1 400 Bad Request
Content-Type: application/json

{
    "result": null,
    "<strong>error</strong>": {
        "errorCode": null,
        "messages": [ "Validation failed for object='helloRequest'. Error count: 1" ],
        "dataErrors": [
            {
                "code": "NotNull",
                "name": "name",
                "value": null,
                "message": "may not be null"
            }
        ],
        "attributes": { ... }
    }
}
</pre>

You will notice that both JSON body responses have exactly two top-level JSON fields; *result* and *error*. Successful responses populate the *result* field while error responses populate *error*. The *result* field in some ways serves as a "wrapper" to the endpoint's successful response. The *error* structure allows for an error code, multiple messages, field validations, and flexible custom attributes. This shared top-level structure allows us to describe both successful and error responses with a single API response model. By having a single model, you could now easily deserialize the response irrespective of it HTTP status. *(Typically with error responses, you would have to manually deserialize the response against a different response model.)*

Let us build on this concept and assume that ALL responses will now adopt this shared top-level structure. The *result* structure for responses, as you would expect, should and would vary differently between endpoints. When it comes to the *error* structure, however, we recommend a single standardized and flexible error structure be used for all response APIs. <strong>Why?</strong> By having a fixed error structure for all API responses, it possible to generate a valid error response without having any knowledge about the context of the request. Spring framework can throw an error unrelated to the application and configured controller advices can ensure such errors are converted into the error structure we want.

<br/>

###### BaseBodyResponse

Returning back to our hello sample responses... both *hello* successful and error responses are described by the same API response model [HelloResponse.java](src/main/java/com/ford/devenablement/rest/hello/api/HelloResponse.java). Let's look at the exact implementation of *HelloResponse* and see how it programmatically handles *result* and *error* fields:

```java
public class HelloResponse extends BaseBodyResponse<HelloResponseResult> {

	@Data
	@Builder
	@NoArgsConstructor
	@AllArgsConstructor
	public static class HelloResponseResult {
		String greeting;
	}

}

```

We do not notice any *result* and *error* field definitions. That is because *HelloResponse* extends `BaseBodyResponse<T>` which is the class that defines both *result* and *error* fields. `BaseBodyResponse<T>` is part of the CloudNative Spring API library `com.ford.cloudnative:spring-base-api` and its actual definition can be found here [BaseBodyResponse.java](https://github.ford.com/PCFDev-InnerSource/spring-base-dependencies/blob/master/spring-base-api/src/main/java/com/ford/cloudnative/base/api/BaseBodyResponse.java). Looking at the `BaseBodyResponse<T>` class definition, the *result* is of generic type `T` while *error*'s exact type is  [BaseBodyError.java](https://github.ford.com/PCFDev-InnerSource/spring-base-dependencies/blob/master/spring-base-api/src/main/java/com/ford/cloudnative/base/api/BaseBodyError.java).

<br/>

###### Successful Responses

*HelloResponse* extends `BaseBodyResponse<HelloResponseResult>` which implies that the *result* structure is of type *HelloResponseResult*. *HelloResponseResult* defines all of the fields that *result* wraps or encapsulates. In our case, it is only *greeting* field. We also take notice that *HelloResponseResult* is annotated with *Lombok* annotation for couple reasons:
- We can avoid creating getters, setters, equals/hashCode, toString &mdash; handled by `@Data`.
- We can avoid creating a Builder class to help us build our *result* &mdash; `@Builder` takes care of that. We can create a *HelloResponseResult* object using `HelloResponseResult.builder()`.

The value of *Lombok* may not be transparent with couple fields. When the API model grows to several fields, however, the value of *Lombok* becomes very obvious.

Lets take a look at the example how you would create a complete successful message such as *HelloResponse*. You first would want to create the successful *result* object using Lombok's Builder class and then wrap the *result* object using `BaseBodyResponse.result(...)` or `HelloResponse.result(...)`.


```
@GetMapping
public HelloResponse hello() {
	HelloResponseResult result = HelloResponseResult.builder().greeting("Hello").build();

	return HelloResponse.result(result, HelloResponse.class);
}
```

<br/>

###### Error Responses

The goal is to return all errors into the expected top-level shared structured with the standardized error structure. To this possible, we first must ensure that the [Common Error Handling](../base-service#common-error-handling) feature is enabled so that internal Spring or any other thrown errors are automatically converted into the standard body and error format we want. *Common Error Handling* feature even handles hibernate field-level errors elegantly!

Any exception you throw will be converted into the standard error format one way or another. For generic exceptions thrown, the error response would be a single message matching the Exception's message and some attributes. Depending on the type of Exception class thrown, different top-level HTTP status codes will be used. For more control on the overall error response including the top-level HTTP status code, you have two options:
1. Throw a ```BaseBodyResponseException``` instance. ```BaseBodyResponseException``` gives you full control in populating the error structure and set the top-level HTTP status code. For example,<br/>  &nbsp; &nbsp; ```throw new BaseBodyResponseException(..., HttpStatus.SERVICE_UNAVAILABLE)```
2. Create a custom Exception class that extends ```BaseBodyResponseException```.  Throw the custom Exception class instead.


<br/>

### Testing

This project demonstrates different types of tests and use of frameworks.

- Unit Testing (JUnit/Mockito/AssertJ)
- Integration Testing (Spring MockMVC)
- Acceptance Testing (CloudNative Base Test Library)

Unit & Integration tests would be executed during gradle's normal build task ```gradlew build```.

Acceptance Tests would be executed using *Common-Build-Deploy*'s custom gradle task  ```gradlew acceptanceTests```. By default, acceptance test classes are differentiated from other test classes based on class naming convention (e.g. ends with *AcceptanceTest*) or if the class falls under a package named *acceptance*. The environment variable ```ACCEPTANCE_APP_BASE_URL``` configures the location of the service which acceptance tests are executed against.

<br/>


### API Security

> **Note:** The sample code in this guide does not use any security for the API endpoints. This section will cover what is generated from EcoBoost, which can also be viewed by looking at our reference application's [build.gradle](https://github.ford.com/PCFDev-CAB/cab-service-fordair/blob/master/build.gradle) or it's Web Security filter implemented in its [WebSecurtyConfiguration.java](https://github.ford.com/PCFDev-CAB/cab-service-fordair/blob/master/src/main/java/com/ford/cab/fordair/WebSecurityConfiguration.java) class.

The way in which we secure API's at Ford is through the use of OAuth2 as a way to insure authentication prior to allowing access to an API. Our [Security Guide](./security) focuses on security patterns around Ford-available security providers such as authentication with Ford ADFS4 / Azure AD and authorization with APS. 

While this guide focuses on building of REST controllers and not necessarily securing them, it is worth mentioning that applications generated using EcoBoost and opting for REST Controller functionality (either from the "Simple REST Controller" option or the "SQL Database + Flyway" option) will also contain Spring Security and a basic Web Security filter which will provide [Basic Auth](https://en.wikipedia.org/wiki/Basic_access_authentication) to any new API's that are added to the app. The filter will allow for bypassing of this security for the sample API's (Hello and/or Greeting). If the application generated picked the “App-to-App Security (Server-Side)” option, then Spring Security plus Spring Cloud OAuth2 libraries will be added, and the filter will also support OAuth2 token processing. Any new API’s added in this case will by default require OAuth2 authentication.




