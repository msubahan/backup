# Spring Cloud Gateway

## Purpose
Spring Cloud Gateway aims to provide a simple, yet effective way to route to APIs and provide cross cutting concerns to 
them such as: security, monitoring/metrics, and resiliency. [Click here to read further about Spring Cloud Gateway](https://spring.io/projects/spring-cloud-gateway). 
The Dev Enablement team opted for this product in part because of the fact that Netflix Zuul is going into maintenance mode.


## Usage
This guide provides access to a [sample gateway application](https://github.ford.com/PCFDev-CAB/cab-service-gateway#spring-cloud-gateway-application) 
that is implemented in our CAB reference application. This is available for you to either run locally or push to your own PCF org/space. 
This guide also provides step-by-step instructions to [create a new Spring Cloud Gateway service](#Create-a-new-spring-cloud-gateway-service) on your own.

Spring Cloud Gateway implementation in CAB:

![CAB Gateway Diagram](./cab_gateway_diagram.png)


>_**Note:**_ Gateway pattern shall be used to encapsulate downstream services with unified authentication process. 
Along with Container to Container networking feature, downstream services shall expect only trusted API calls coming in from Gateway service.
Refer to [**Container to Container networking guide**](../c2c_networking) for additional details.
>
>The sample gateway service referred here uses container to container networking feature. However, the downstream CAB FordAir service 
>also implements its own authentication process, as the service is accessible directly without gateway route. 
>For this reason, the ADFS token is passed from gateway to downstream service, when accessed through gateway route.

## Resources/Examples:
* [Create a new Spring Cloud Gateway Service](#Create-a-new-spring-cloud-gateway-service) by 
[generating a new EcoBoost app](https://dcs.ford.com/project-workflow/springboot) and turning it into a Reactive Gateway Service.
* [Reference CAB Gateway Service](https://github.ford.com/PCFDev-CAB/cab-service-gateway#spring-cloud-gateway-application) - Source
* Deployed CAB Gateway Service [EDC1](https://cab-gateway-dev.apps.pp01i.edc1.cf.ford.com) | [EDC2](https://cab-gateway-dev.apps.pp01i.edc2.cf.ford.com)
* [CAB Backend Service](https://cab-fordair-dev.apps.pp01i.edc1.cf.ford.com) (direct access w/o gateway) 

## Create a new Spring Cloud Gateway service

The following section describes the steps to create a new Spring Cloud Gateway service bootstrapping from EcoBoost generated Spring Boot application.

Refer to [CAB Gateway Service](https://github.ford.com/DevEnablement/cab-service-gateway) for a sample implementation of Spring Cloud Gateway service with all the features detailed below.

### Generate a new Spring Boot application

Create a basic EcoBoost app from [/dev/central/station](https://dcs.ford.com/project-workflow/springboot) with Jenkins Pipeline and JDK11 (recommended) options. 
Bootstrapping from EcoBoost generated Spring Boot application enables us to leverage the latest trusted open source libraries and built-in 
features offered by Dev Enablement team (such as Jenkins Pipeline, Gradle Boost, and ford cloud native libraries).

>_Note:_ _Service Registry option shall be selected if gateway is expected to route based on registry lookup. 
>Other options shall be selected as required but may need additional work to resolve compatibility issues, if any with reactive libraries._

### Dependencies

Add the following spring cloud gateway dependencies in [build.gradle](https://github.ford.com/PCFDev-CAB/cab-service-gateway/blob/master/build.gradle#L29)

```
implementation 'org.springframework.cloud:spring-cloud-starter-gateway'
implementation (org.springframework.cloud:spring-cloud-starter-contract-stub-runner) {
   exclude group: "org.springframework.boot", module: "spring-boot-starter-web"
}
```

Remove Spring Boot Starter Web and Cloud Native Ford dependencies as they are incompatible with 
reactive Spring Cloud Gateway libraries.

```
//implementation 'org.springframework.boot:spring-boot-starter-web'
//implementation 'com.ford.cloudnative:spring-boot-starter-ford:2.2.0'
```
Additionally, swagger and lombok related libraries shall be removed, if your gateway service does not use them.

```
//implementation 'io.springfox:springfox-swagger2:2.9.2'
//implementation 'io.springfox:springfox-swagger-ui:2.9.2'

//compileOnly 'org.projectlombok:lombok'
//annotationProcessor 'org.projectlombok:lombok'
//implementation 'com.google.guava:guava:28.1-jre'
```

### Run as a Reactive Web Application

By default, Spring Cloud Gateway is a reactive web application. This is enabled automatically by 
including the cloud gateway libraries in classpath.

If for some reason, a transitive dependency to Spring MVC is found in the classpath, manual over-riding may be required
by setting the below property in application.properties file.

`spring.main.web-application-type=reactive`

### Service Registry Configuration (if selected)

If service registry option is selected while generating an EcoBoost app, 
the below cloud service library by pivotal is added to the build class path. 
```
//service registry
implementation 'io.pivotal.spring.cloud:spring-cloud-services-starter-service-registry'
```

This library causes bean definition conflict with Spring Cloud Gateway. To resolve this, 
override bean definition by setting the below property in [application.properties](https://github.ford.com/PCFDev-CAB/cab-service-gateway/blob/master/src/main/resources/application.properties#L32) file.
```
spring.main.allow-bean-definition-overriding=true
```

If required, the registration of gateway application itself in the Service Registry can be disabled
by setting the below property in [application.properties](https://github.ford.com/PCFDev-CAB/cab-service-gateway/blob/master/src/main/resources/application.properties#L8) file.

```
eureka.client.register-with-eureka=false
```

### Routes Configuration

Define gateway routes to handle incoming requests and route them to downstream services 
by defining a bean of type RouteLocator.

>_Note: The usage of @EnableDiscoveryClient below is required only if Service Registry is being used._

```
@Configuration
@EnableWebFlux
@EnableDiscoveryClient
public class RouteConfiguration {

    @Bean
    public RouteLocator myRoutes(RouteLocatorBuilder builder) {
        return builder.routes()
            .route("route_id", p -> p
            .path("/url_pattern")               // replace /url_pattern with your value
                .filters(f -> f
                    .stripPrefix(1)             // to remove /url_pattern from downstream request, if needed
                )
                .uri("downstream_service_url")  // can be a http url or a load balanced service registry url.
            )
            .build();
    }

}
```

Refer to the sample gateway application for example code: [RouteConfiguration.java](https://github.ford.com/PCFDev-CAB/cab-service-gateway/blob/master/src/main/java/com/ford/cab/gateway/routes/RouteConfiguration.java)

Refer to [Pivotal Spring Cloud Gateway guide](https://cloud.spring.io/spring-cloud-gateway/single/spring-cloud-gateway.html) for additional predicates and filters.

### Advanced Configurations

#### Spring Security: App-to-App OAuth2 with JWT tokens

If securing the gateway routes with OAuth2, configure the reactive gateway application with reactive spring security and OAuth2 resource server libraries by following the below steps.

>Note: If App-to-App Security option is selected during the EcoBoost app generation, some of the below libraries are already included in the build path. 

1. Add OAuth2 libraries in [build.gradle](https://github.ford.com/PCFDev-CAB/cab-service-gateway/blob/master/build.gradle#L38)

```
//security
implementation 'org.springframework.boot:spring-boot-starter-security'
implementation 'org.springframework.boot:spring-boot-starter-oauth2-resource-server'
implementation 'org.springframework.boot:spring-boot-starter-oauth2-client'
```
2. Create a security configuration class and create a bean of type SecurityWebFilterChain with required permissions to the route. 
Refer to the sample gateway application for example code: [WebSecurityConfiguration.java](https://github.ford.com/PCFDev-CAB/cab-service-gateway/blob/master/src/main/java/com/ford/cab/gateway/WebSecurityConfiguration.java)

#### Gateway Actuator Endpoints

Spring Cloud Gateway actuator endpoints shall be turned on and exposed through web by setting the below properties in [application.properties](https://github.ford.com/PCFDev-CAB/cab-service-gateway/blob/master/src/main/resources/application.properties#L26)

```
# Enable and Expose Gateway Actuator Endpoint via HTTP
management.endpoint.gateway.enabled=true
management.endpoints.web.exposure.include=gateway
```
Gateway actuator endpoints shall be used to add, modify, delete and refresh route configurations.

Gateway actuator endpoints co-exists with spring boot actuator endpoints.

Refer to [Spring documentation](https://cloud.spring.io/spring-cloud-gateway/multi/multi__actuator_api.html) for available gateway actuator endpoints.

#### Sleuth Integration with Gateway Application

Gateway application seamlessly integrates with sleuth tracing. EcoBoost application already provides the 
[required library](https://github.ford.com/PCFDev-CAB/cab-service-gateway/blob/master/build.gradle#L35) in classpath. 
Trace IDs from Gateway to downstream services shall be seen in the access logs.

## Use Cases
Below are some use cases where API Gateway solution shall be considered:

 - **Unified authentication process for upstream clients** - Gateway service shall be used to implement a unified 
 authentication process and shall control access to the downstream services. It shall also pass the authentication token 
 to downstream services for further downstream authentication and/or authorization. Further, Gateway service shall 
 communicate to downstream services using [Container to Container networking](../c2c_networking) to make API access more secured. 
 
 - **Filter API Requests and Responses** - Gateway service shall be used to implement pre and/or post processing filters, 
 which allows request and response manipulation to/from downstream APIs.
 
 - **Fan-Out or Aggregate API Calls** - Gateway service shall be used to fan out calls or aggregate responses to/from 
 multiple APIs based on a single incoming request.
