

# Overview
This guide will provide an introduction of Spring Cloud Data Flow (SCDF) in PCF.<br>
It will outline steps to:
- Create a service instance of SCDF.
- Create and deploy a simple stream via the SCDF Dashboard.
- Create and deploy a task using the same SCDF Dashboard.

## What is SCDF?
Spring Cloud Data Flow is a toolkit for composing microservices into a stream or batch
pipeline.  The composible pipelines can be created, deployed, and managed via UI or REST APIs.

## Create a Dataflow service instance
This feature assumes that the dataflow service is available in the PCF marketplace.
1.  Create service instance using
```cf create-service```
>Example:  ```cf create-service p-dataflow standard my-dataflow-instance```

    This one service creation will actually create 3 services.
    name     service                 plan       bound apps   last operation       broker       upgrade available
    messaging-a6767142-f05f-4636-8032-6b62ec500162    p-dataflow-messaging    proxy                   create in progress   p-dataflow   
    my-dataflow-instance                              p-dataflow              standard                create in progress   p-dataflow   
    relational-a6767142-f05f-4636-8032-6b62ec500162   p-dataflow-relational   proxy                   create in progress   p-dataflow   

## View Dataflow Dashboard
1. Open the Dataflow dashboard from Apps Manager for the instance created above.

![](sdcf-manage-dataflow-dashboard.png)


## Add [Stream] Applications

There are two general types of applications than can be imported.
1.  Out-of-the-box pre-defined apps.
2.  Custom apps you have written.

### --Predefined method
For on-prem foundations use:<br>
```Import application coordinates from an HTTP URI location```<br>
Enter the following HTTP URI:<br> ```https://www.nexus.ford.com/repository/maven-central/org/springframework/cloud/stream/app/stream-applications-descriptor/2020.0.1/stream-applications-descriptor-2020.0.1.stream-apps-rabbit-maven```<br>

For off-prem foundations use:<br>
```Import application starters from dataflow.spring.io.```<br>
Select<br>
```Stream application starters for RabbitMQ/Maven```<br>
OR<br>
```Task application starters from Maven```<br>

### --Custom method
Use ```Import application coordinates from a properties file``` option to add application(s).
<hr>

## Add [Task] Applications
For on-prem foundations use:<br>
```Import application coordinates from an HTTP URI location```<br>
Enter the following HTTP URI:<br>```https://www.nexus.ford.com/repository/maven-central/org/springframework/cloud/task/app/spring-cloud-task-app-descriptor/Elston.SR3/spring-cloud-task-app-descriptor-Elston.SR3.task-apps-maven```

<hr>

## Create a sample [Stream]
1.  Click on ```Streams``` below Streams pulldown on left side of the dashboard.
2.  Click on ```Create stream(s)```
3.  In the ```Enter stream definition...``` box type: ```http | log```
4.  Click on bottom button [```Create streams(s)```]
5.  Enter ```Name``` and ```Description``` for the stream.
6.  Click on the newly created stream.
7.  Click on the [```Deploy Stream```] button.
8.  Enter values for Memory, CPU, Disk, Count.
9.  Click the [```Deploy Stream```] button.
     
## Create a sample [Task]
1.  Click on ```Tasks``` below ```Tasks / Jobs``` pulldown on left side of the dashboard.
2.  Click on [```Create Task```]
3.  In the ```Enter task definitions here...``` box type: ```timestamp```
4.  Click on the bottom button [```Create task```]
5.  Enter ```Name``` and ```Description``` for the task.
6.  Click on the newly created task.
7.  Click on [```Launch Task```] button.