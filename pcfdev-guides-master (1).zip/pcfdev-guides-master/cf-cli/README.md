# CF CLI Guide

The cf CLI is the official command line client used to access a Cloud Foundry foundation from a client machine. Commercial versions of Cloud Foundry, such as the PCF version Ford uses, all utilize the open source Cloud Foundry provided cf CLI. This guide will explain where to download the various versions of the CLI, and the differences between the versions being offered. We will also link out to all the vendor documentation so you can learn what you need to use the CLI.


## v6 or v7

The cf CLI v7 release was a major release, and first became available as a client to PCF version 2.10.x foundations. This means that v7 can only be used on PCF 2.10 and above, while foundations running at PCF version 2.9 and earlier require the use of v6 of the cf CLI. 

During the upgrade from PCF 2.9 to 2.10 that is occurring in 1Q 2021, there will be a brief period of time where the PRE-PROD PCF foundations will be a at version 2.10 and the PROD foundations will still be at version 2.9. This means users will need to be aware of the consequences of installing cf CLI v7.

#### Running/Installing both versions

Some people may require to have both installed, and use either one at any given time. In this situation you can consider the following approach:

* Download and install the v6 and v7 binaries into separate directories
* Write a scipt that updates your PATH so it points to the binary for the version of the CLI you need to run. The example below is a MacOS example only!

    ``
    export PATH=/path/to/your/v6-or-v7/binary/:$PATH 
    ``

#### What version of PCF is foundation XYZ running?

You can use the [Ford PCF Foundations](https://devservices.ford.com/version-information) tile that is part of the [Dev Services portal](http://devservices.ford.com). This tool contains a list of all the PCF foundations at Ford. Click on a Foundation in the list, and you will find a table of products and versions that make up the PCF platform. Simply look in the product table for the product named "cf" to determine what version of PCF that foundation is running.


## CLI Downloads

The links below will download the latest stable v6 and v7 versions of the CLI directly from the PCF vendor's website.

The installation instructions are also available externally. See the [c6 installation guide](https://github.com/cloudfoundry/cli/wiki/V6-CLI-Installation-Guide)
or the [v7 installation guide](https://github.com/cloudfoundry/cli/wiki/V7-CLI-Installation-Guide). 

#### v6 CLI Installers:
* [Windows 32 bit](https://cli.run.pivotal.io/stable?release=windows32&source=apps_man&version=v6)
* [Windows 64 bit](https://cli.run.pivotal.io/stable?release=windows64&source=apps_man&version=v6)
* [MacOS 64 bit](https://cli.run.pivotal.io/stable?release=macosx64&source=apps_man&version=v6)
* [Linux 32 bit (.deb)](https://cli.run.pivotal.io/stable?release=debian32&source=apps_man&version=v6)
* [Linux 64 bit (.deb)](https://cli.run.pivotal.io/stable?release=debian64&source=apps_man&version=v6)
* [Linux 32 bit (.rpm)](https://cli.run.pivotal.io/stable?release=redhat32&source=apps_man&version=v6)
* [Linux 64 bit (.rpm)](https://cli.run.pivotal.io/stable?release=redhat64&source=apps_man&version=v6)


#### v7 CLI Installers:
* [Windows 32 bit](https://cli.run.pivotal.io/stable?release=windows32&source=apps_man&version=v7)
* [Windows 64 bit](https://cli.run.pivotal.io/stable?release=windows64&source=apps_man&version=v7)
* [MacOS 64 bit](https://cli.run.pivotal.io/stable?release=macosx64&source=apps_man&version=v7)
* [Linux 32 bit (.deb)](https://cli.run.pivotal.io/stable?release=debian32&source=apps_man&version=v7)
* [Linux 64 bit (.deb)](https://cli.run.pivotal.io/stable?release=debian64&source=apps_man&version=v7)
* [Linux 32 bit (.rpm)](https://cli.run.pivotal.io/stable?release=redhat32&source=apps_man&version=v7)
* [Linux 64 bit (.rpm)](https://cli.run.pivotal.io/stable?release=redhat64&source=apps_man&version=v7)

### Jenkins Installation
Refer to [CF CLI custom tools installation](https://github.ford.com/DevEnablement/ecoboost-pipeline/blob/master/MIGRATE_TO_JENK8S.md#cf-cli) section for steps to install CF CLI in Jenkins. You can get the CF CLI 7.x installation definition from [SDE sharepoint page](https://jenkins-guide.apps.pd01.edc.caas.ford.com/ch05/1-custom-tool-collection.html#pcf-cf-cli-7-2-0), that pulls the binary from Ford Nexus repository (no proxies required). You can choose between whether you want to globally set the CF CLI path in Jenkins environment variable ([EcoBoost pipeline style](https://github.ford.com/DevEnablement/ecoboost-pipeline)) or you want to set the tool's home path in each individual pipeline (SDE installation step).

### Using CF CLI v7 with EcoBoost generated Apps and/or GradleBoost plugin
If your application uses GradleBoost plugin, upgrade the plugin version to `3.2.0` or above to be compatible with CF CLI v7 and backward. Read related release notes [here](https://github.ford.com/DevEnablement/gradle-boost-plugin/releases/tag/v3.2.0).

## CLI Plugins

There are a couple of CLI plugins that we recommend for those who use the Autoscaler service or the PCF Scheduler service. Both plugins allow
you maintain the settings for these services via code in manifest or pipeline scripts. The plugins can be downloaded from Ford Nexus in the [cf-cli-plugins folder](http://www.nexus.ford.com/#browse/browse:jenkins_tools:plugins%2Fcf-cli-plugins).

To learn about use of these specific plugins, refer to the following guides:
* [Autoscaler Service Guide](https://devservices.ford.com/dev-guides?search=PCF%20Autoscaler%20Service)
* [Scheduled Jobs Guide](https://devservices.ford.com/dev-guides?search=Scheduled%20Jobs)


## Additional Documentation

> Note: What we here at Ford still refer to as "PCF" is officially been renamed by the vendor to "Tanzu Application Service for VM’s", or TAS for short. Please note that you will see this new name used in the vendor documentation, while the "PCF" name continues to be used here at Ford. 

* Official GitHub repo - [https://github.com/cloudfoundry/cli/blob/master/README.md](https://github.com/cloudfoundry/cli/blob/master/README.md)
* Using the CF CLI Vendor Guide - [https://docs.pivotal.io/application-service/2-10/cf-cli/index.html](https://docs.pivotal.io/application-service/2-10/cf-cli/index.html)
* cf CLI v7 upgrade guide - [https://docs.cloudfoundry.org/cf-cli/v7.html](https://docs.cloudfoundry.org/cf-cli/v7.html)
* What's New in cf CLI v7 Blog Post - [https://www.cloudfoundry.org/blog/cloud-foundry-further-simplifies-modern-app-development-an-inside-look-at-the-new-cf-cli-v7/](https://www.cloudfoundry.org/blog/cloud-foundry-further-simplifies-modern-app-development-an-inside-look-at-the-new-cf-cli-v7/)
