# PCF Vanity URL Guide

### Update Existing Vanity URL with App-specific Configuration
If you're confused by any of the content on this page, please start by fully reading the [Vanity URL General page](README.md).


## High Level Steps
1. Implement a /health API endpoint in your application code
2. Submit Ford Cloud Portal request to create a WideIP URL (FCP Step #1)
3. Map a route for the WideIP URL to your PCF app
4. Test app functionality using WideIP URL & /health endpoint

<b>- - - - - - - Preparing for Cutover - - - - - - -</b>

5. Map a route for the Vanity URL to your PCF app (if not already done)
6. Submit Ford Cloud Portal request to DNS map your WideIP URL to your Vanity URL (FCP Step #2)
7. Understand how to control application traffic

## 1.) Implement a /health API endpoint in your application code
In order for traffic to be properly routed to your PCF application, you will need to expose a /health endpoint in your application. At a minimum, this /health endpoint needs to return a 200 response when queried, indicating that the application is healthy and able to receive traffic. Please note that this /health endpoint <b>must be implemented at the root of your application URL.</b> For example, a /health endpoint at "app_name.ford.com/actuator/health" <b>will NOT work.</b>

Implementing this /health endpoint can be accomplished in a number of ways, depending on your application architecture. Documentation has been provided for a number of common frameworks:
 - [Spring Boot](springboot_healthendpoint_implementation.md)
 - [Angular](angular_healthendpoint_implementation.md)
 - [WAS Liberty](CLOUD_TOLERANT.md)


If additional assistance is needed to configure a /health endpoint for your application, please submit a detailed post to the [DevEnablement Community Yammer forum.](https://www.yammer.com/ford.com/#/threads/inGroup?type=in_group&feedId=7970611200&view=all)

 Additional reading on API Health Monitoring [can be found here.](https://github.ford.com/Platform-Enablement/API-Style-Guide/wiki/API-Health-Monitoring)

#### <u>How can I test this is working correctly?</u>
Once you have implemented the /health endpoint in your application code and deployed the application to your PCF Org, you can test the proper functionality of your /health endpoint.

To do so, open your application from the PCF Apps Manager WebUI using the PCF-specific URL (Ex. app_name.apps.pp01.edc1.cf.ford.com). At the end of the URL, append "/health" and try to navigate to the new URL. If it resolves and you see a success message of some kind, your /health endpoint is functioning correctly.

If the page does not resolve or shows an unexpected message, your /health endpoint is not functioning correctly and you will need to address it.


## 2.) Submit Ford Cloud Portal request to create a WideIP URL (FCP Step #1)
PCF Vanity URL self-service in FCP is conducted in a 2-step process. The first step will create a new WideIP URL for use with your Vanity URL. This WideIP URL is utilized by the load balancer to allow for proper application traffic routing. (Note: WideIP URL name will be based off your existing Vanity URL name.)

#### <u>To submit the request (Org Managers only):</u>

a.) Navigate to the [Manage Vanity URL page in FCP](https://www.cloudportal.ford.com/pcf/vanityurl/manage)

b.) Select the option for "Configure WideIP/AppGSLB for Existing PCF Vanity URL"

c.) Select the next option for "Step 1: Create WideIP/AppGSLB URL"

d.) Select the desired environment, PCF Org name, and all application Foundations where this Vanity URL will be used

e.) Select the domain that corresponds to your Vanity URL

f.) Select your Vanity URL

![existing_Vanity_step1.png](existing_Vanity_Step1.png)
<br><br>

#### <u>What happens when I submit?</u>
If all the inputs are valid, the requester should see a confirmation that their request was successful. They will then receive an email confirmation, <b>which will also include their new WideIP URL.</b> This URL should be shared with the full team and kept handy during this process. The WideIP URL is just as important as your Vanity URL.


## 3.) Map a route for the WideIP URL to your PCF app
In order for the PCF platform to be able to route application traffic to your specific PCF app, a "route" must be configured in your PCF Org. Routes can be configured from either the cf CLI or from the PCF AppsManager WebUI.


#### <u>From the PCF AppsManager:</u>
a.) Select your PCF Org

b.) Select the applicable Space within your Org

c.) Select the desired application that requires a route

d.) Click on the "Routes" tab on the left-side pane

e.) Click the "Map a Route" button

![new_Vanity_map_route.png](DCOF_map_route_WideIP.PNG)
<br>

Information on mapping a route via the cf CLI [can be found here.](https://cli.cloudfoundry.org/en-US/v6/map-route.html)

## 4.) Test app functionality using WideIP URL & /health endpoint
At this point, you should have everything you need to test the functionality of your WideIP URL. Things to know:<b>
 - No DNS changes have been made yet; your Vanity URL is still pointing to your PCF application
 - You will conduct tests using only your WideIP URL, not your Vanity URL</b>

The full scope of the functionality testing is at the discretion of the application team, but at a minimum, it is recommended that you run a "curl -i" command via the CLI with your new WideIP-URL/health as an argument. If a 200 response is returned, this will confirm that your /health endpoint is working as expected.

![curl command with wideipurl](DCOF_test_WideIP_health.PNG)

Once confirmed, the final test will be navigating to your WideIP URL in a web browser and seeing if it resolves to your application correctly.

<br><br><br><br>
### - - - - - - - Preparing for Cutover - - - - - - -
As always, please take extra care when conducting cutovers of Production Vanity URLs.
<br><br><br><br><br><br>

## 5.) Map a route for the Vanity URL to your PCF app (if not already done)
In order for the PCF platform to be able to route application traffic to your specific PCF app, a "route" must be configured in your PCF Org. Routes can be configured from either the cf CLI or from the PCF AppsManager WebUI. (Note: this step may already be done if your Vanity URL was previously in use in this PCF Org.)
#### <u>From the PCF AppsManager:</u>
a.) Select your PCF Org

b.) Select the applicable Space within your Org

c.) Select the desired application that requires a route

d.) Click on the "Routes" tab on the left-side pane

e.) Click the "Map a Route" button

![map route](DCOF_map_route_Vanity.PNG)

<br>

Information on mapping a route via the cf CLI [can be found here.](https://cli.cloudfoundry.org/en-US/v6/map-route.html)

## 6.) Submit Ford Cloud Portal request to DNS map your WideIP URL to your Vanity URL (FCP Step #2)
PCF Vanity URL self-service in FCP is conducted in a 2-step process. The second step <b>will submit a DNS request to map your WideIP URL to your Vanity URL.</b> Once this DNS request is executed (within 24 hours), it will <u><b>immediately update your Vanity URL to point to your WideIP URL.</u></b>  

Therefore, it is crucial that your team completes Step #4 and confirms that the WideIP URL is resolving and that the /health endpoint is returning a 200 response before submitting this request in FCP.

#### <u>To submit the request (Org Managers only):</u>

a.) Navigate to the [Manage Vanity URL page in FCP](https://www.cloudportal.ford.com/pcf/vanityurl/manage)

b.) Select the option for "Configure WideIP/AppGSLB for Existing PCF Vanity URL"

c.) Select the next option for "Step 2: Submit DNS Move for Vanity URL"

d.) Select the desired environment, PCF Org name, and all application Foundations where this Vanity URL will be used

e.) Select the domain that corresponds to your Vanity URL

f.) Select your Vanity URL

g.) Lastly, select the WideIP URL that corresponds to your Vanity URL

![existing_Vanity_step2](existing_Vanity_Step2.png)

#### <u>What happens when I submit?</u>

If all the inputs are valid, the requester should see a confirmation that their request was successful. They will also receive a confirmation email of the DNS ticket. Please note that the DNS ticket may take up to 24 hours to execute.

If your receive an error related to the submission of the DNS ticket, please submit a [PCF Incident ticket via IT Connect.](https://www.itconnect.ford.com/dwp/app/#/itemprofile/1116)


## 7.) Understand how to control application traffic
The primary benefit of using an application-specific Vanity URL configuration is the automated failover of application traffic should your PCF application go down in one of the data centers.

But this configuration will also allow application teams to have more direct control over where their application traffic is flowing at any given time. This can be useful when undergoing app maintenance, conducting blue-green deployments, or testing/enacting disaster recovery (DR) procedures.

Controlling application traffic is simple enough: direct manipulation of the application via the PCF AppsManager WebUI will allow teams to determine where traffic will flow. For instance, if an application instance is stopped in EDC1, within 30 seconds, the F5 GSLB will recognize the application is down and will stop routing traffic to the PCF Foundation in EDC1, and instead route all traffic to the application in the PCF Foundation in EDC2. And vice versa if the application is stopped in EDC2.

As always, teams are highly encouraged to experiment with application traffic control in lower environments first to get a feel for the process before attempting any traffic control in Production.

![traffic_control_stop](traffic_control_stop.png)

![traffic_control_start](traffic_control_start.png)
