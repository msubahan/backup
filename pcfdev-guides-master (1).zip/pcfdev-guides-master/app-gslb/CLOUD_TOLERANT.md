# Implementation - WAS Liberty App


App Specific Load Balancer set up for cloud tolerant apps (a.k.a. Cloud Tolerant apps)


### Step 1

Set up a &quot;health&quot; check endpoint for your web app. You need to create a health check servlet which will return &quot;status: pass&quot; in json. Make sure the endpoint of your health servlet is having &#39;/&#39; as the context root. e.g., **xxx.ford.com/health.** No other entries should be there after &quot;.ford.com&quot; as context root except &quot;/&quot;.

In addition to the following health servlet implemetation, an alternative option to take the advantage of the health check API from Liberty Server. It is described at [MicroProfile Health](#microProfile-health).

>There are 3 options to make /health API URL without the applicaiton context root.
> * With MicroProfile Health, no context root change in your existing applicaiton is required. You need to update your application to Servlet 3.1.
> * Change your application context root to '/'. Any reference points to your application need to be updated without the applicaiton name in the URL.
> * Create a redirect web application with the context root of '/', and make /health in the redirect web application to call to your existing applicaiton health check.

#### Sample code for servlet:

```
public class HealthCheck extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
	    final PrintWriter out = resp.getWriter();
	    resp.setContentType("application/json");
	    out.println("{\"status\": \"pass\"}");
    }

}
```

#### Sample entry for web.xml:

```
<servlet>
    <servlet-name>Health</servlet-name>
    <servlet-class>com.ford.pd.egmt.inbound.bean.health.HealthCheck</servlet-class>
    <load-on-startup>1</load-on-startup>
</servlet>
<servlet-mapping>
    <servlet-name>Health</servlet-name>
    <url-pattern>/health</url-pattern>
</servlet-mapping>
```

#### Sample entry for web.xml for bypassing authentication:

```
<security-role>
    <role-name>UnauthenticatedUsers</role-name>
</security-role>
<security-constraint>
    <display-name>AllUnprotectedRequests</display-name>
    <web-resource-collection>
        <web-resource-name>AllUnprotectedRequests</web-resource-name>
        <url-pattern>/health</url-pattern>
        <http-method>GET</http-method>
    </web-resource-collection>
    <auth-constraint>
        <role-name>UnauthenticatedUsers</role-name>
    </auth-constraint>
</security-constraint>

```

#### Results

After doing this set up your normal vanity URL hit with /health should return you on browser as below:

```
{"status": "pass"}
```

> Skip the next section, and go to [Step 2](#step-2)

#### MicroProfile Health

Liberty Server implements the MicroProfile specification which includes a health check.

MicroProfile health provides the /health API to return the health status of your application. You can enable this feature by updating your server.xml.

```
    <featureManager>
        ...
        <feature>mpHealth-2.0</feature>
    </featureManager>
```
Your web application should have the Servlet feature enabled already.
Servlet 3.1 is the minimum version supported.

The default return value from /health is:
```
{
"checks": [],
"status": "UP"
}
```

You can customize your health check logic by implementing the [HealthCheck](https://download.eclipse.org/microprofile/microprofile-health-2.0/apidocs/) interface.
For more inforamtion about MicroProfile health, please refer to the [Liberty Guide](https://openliberty.io/guides/microprofile-health.html).
