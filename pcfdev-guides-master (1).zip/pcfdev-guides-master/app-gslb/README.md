# PCF On-Prem Vanity URL Guide

## General Overview

#### What is the purpose of this guide?
<p>
This guide serves as the definitive resource for all on-premise Vanity URL needs within PCF. With the release of the new Vanity URL tile in the Ford Cloud Portal, PCF application teams can now accomplish in a self-service capacity all on-prem Vanity URL tasks that previously required manual ticket submissions. The resources outlined in this guide will help application teams navigate these new automated processes, and ensure that they have everything they need to successfully configure a Vanity URL for use with their PCF application(s).

#### Who should use this guide?
 - New on-prem PCF application teams in need of a Vanity URL
 - Application teams conducting a DCOF Migration (non-PCF) to PCF
 - Existing on-prem PCF application teams who want to re-configure their existing Vanity URLs to be application-specific

#### What has changed with the Vanity URL configuration?
<p>
In the past, PCF applications pointed their Vanity URLs (alias) to a <i>shared</i> PCF foundation URL. The shared foundation URL distributed traffic to a data center based on the <i>PCF foundation's</i> availability, not the actual application's availability. As long as the PCF foundation is up, traffic will continue to be forwarded regardless of the application's status. In the event that an application is down, this would result in a 404 error for application users.

A Vanity URL configured as an application-specific URL is a dedicated URL that routes traffic to a PCF foundation based on the <i>application's</i> health. The URL is configured to intelligently monitor the application's health and only directs traffic to a PCF foundation if the application is up.

In terms of application team effort, the biggest change in the Vanity URL configuration is the requirement that your PCF application will need a /health API endpoint exposed in order for an application-specific Vanity URL to be configured. This /health endpoint is used to probe the health of your application before traffic is routed to it. You will find detailed instructions on how to implement this /health API endpoint farther into this guide.

#### What benefits does the application-specific Vanity URL configuration provide?
<p>

The primary benefit of this new configuration is that PCF applications will have automated traffic fail-over in the event of an app outage in one data center. In addition, this configuration gives application teams more direct control over where their application traffic will be sent at any given time. This can be extremely useful when undergoing app maintenance, conducting blue-green deployments, or testing/enacting disaster recovery (DR) procedures.

#### How does the application-specific Vanity URL configuration work?
<p>
Instead of being pointed to a shared foundation URL, application-specific Vanity URLs will point to a dedicated app-specific GSLB URL, <b>which going forward will be referred to as a <i>WideIP URL.</b></i>  As part of the Vanity URL self-service automation, this WideIP URL will be created for your PCF application(s) and a record for it will be added to the F5 Global Server Load Balancer (GSLB), which is managed by the LBaaS team at Ford. Utilizing this WideIP URL in conjunction with your PCF application's /health endpoint, the F5 GSLB will only route traffic to your PCF application if it receives a successful response from the /health endpoint. If a successful /health response is not received, the F5 GSLB will then probe the /health endpoint of your PCF application in another data center, and if a successful /health response is received here, it will route your application traffic to this data center instead.

Example:
 - Shared foundation URL: navigate.ford.com IN CNAME edcpd01i.cf.app.ford.com
 - App-specific URL: navigate.ford.com IN CNAME navigate.cf.app.ford.com (WideIP URL)

Below is a depiction of shared foundation URL vs. application-specific URL. Note with the shared foundation URL, traffic flows to a PCF foundation regardless of the application's health, whereas with an application-specific URL, the F5 GSLB detects that the application is down and stops forwarding traffic to it.

![found_vs_app](foundation_vs_app.png)

#### Is the application-specific configuration required for a Vanity URL?
<p>
Going forward, all new PCF Vanity URLs will need to use the application-specific configuration. An over-arching goal of the PCF Service Team is to continually try to put more control into the the hands of the PCF application teams, and application-specific Vanity URLs are in support of that goal.

For teams that already have an existing PCF Vanity URL that was configured using a shared foundation URL (almost every Vanity URL configured before June 2020 will be using a shared foundation URL), there is no hard requirement to migrate your Vanity URLs to an application-specific configuration, but it is <b>highly recommended</b> that you do so at your earliest convenience.

With that being said, if an application team requires support from the PCF Service Team in the future related to a Vanity URL with a shared foundation configuration, they will be asked to re-configure their Vanity URL with an application-specific configuration before the PCF Service Team will provide the needed support.


#### What is the process for configuring an application-specific Vanity URL?
Each use case will vary slightly, but at a high-level, the steps to configure an application-specific Vanity URL are:
1. Implement a /health API endpoint in your application code ([SpringBoot](springboot_healthendpoint_implementation.md) | [Angular](angular_healthendpoint_implementation.md) | [Cloud Tolerant](CLOUD_TOLERANT.md))
2. Submit a Ford Cloud Portal self-service request to create a WideIP URL
3. Map a route for the WideIP URL to your PCF app from the PCF WebUI
4. Test app functionality using WideIP URL & /health endpoint
5. Map a route for the Vanity URL to your PCF app from the PCF WebUI
6. Submit a 2nd Ford Cloud Portal self-service request to DNS map your WideIP URL to your Vanity URL
	- (Note: for new Vanity URL requests, this step is taken care of with your initial FCP request)

>Note: Mapping of Vanity URL to a SpringBoot microservice shall be automated during every blue-green deployment using the DevEnablement's pipeline offering 3.x. Refer to [pipeline guide](https://github.ford.com/DevEnablement/pcfdev-guides/tree/master/pipeline-jenkins) for details.

#### How do I get started?
There are detailed instructions for completing this process for each applicable use case:
 - [New PCF Vanity URL](New_Vanity_withPCF.md)
 - [DCoF Migration (Non-PCF) to PCF](DCOF_Migration_toPCF.md)
 - [Update Existing Vanity URL with App-specific Configuration](Existing_PCF_toAppGSLB.md)

#### What about traffic load balancing?
The use of the term "load balancing" in the context of PCF Vanity URLs is a bit of a misnomer, and the PCF team is moving away from associating them with one another. To be clear, <b>an application-specific Vanity URL will NOT evenly balance traffic load between two data centers.</b> In fact, application teams may see that their traffic load between two data centers is close to a 90/10 ratio. This is completely normal.

True traffic load balancing is not currently feasible for PCF Vanity URLs. The PCF Service Team will continually assess this feasibility, but at the current time this is not on our service roadmap.

#### My PCF application is only deployed to one foundation (single-sided). What does all this mean for me?
Admittedly, the benefits of an application-specific Vanity URL highlighted above mainly apply to PCF applications that are deployed in two PCF foundations (dual-sided). Despite this, single-sided PCF applications requesting a NEW Vanity URL will still be required to configure an application-specific Vanity URL. The rationale for this is two-fold:
1. The PCF Service Team is attempting to move away from shared foundation Vanity URLs altogether, and therefore will not create any new shared foundation Vanity URLs.
2. If in the future your PCF application will need to expand to a second foundation, having an application-specific Vanity URL already configured will make this expansion much easier, at which point you will be able to gain the benefits highlighted above.

For existing single-sided PCF applications that have a Vanity URL with a shared foundation configuration, the recommendation is still to migrate to an application-specific Vanity URL, however there are no immediate benefits to be gained by this and can therefore be considered a lower priority.

#### How is internal/external configuration managed with the WideIP URL?
The externality of your WideIP URL will match your Vanity URL. When creating a new Vanity URL, if you specify in your request that the Vanity URL needs to be externally exposed, your WideIP/AppGSLB URL that is generated will also be externally exposed. When creating a WideIP/AppGSLB URL for an existing Vanity URL, this will be configured based on the existing Vanity URL. For example, if the existing Vanity URL is configured for external access, the WideIP/AppGSLB URL will be generated with external access as well.

#### Where can I go to ask questions about this process?
Questions can be posed in the ["Cloud Foundry (PCF) - Infrastructure Community" Webex Teams space](https://www.webexteams.ford.com/space?r=vcnv).

<p>
<p>
