# Implementation - Spring Boot
## /health

Application-specific load balancing uses the application's health status as opposed to the foundation's health status to determine if the app is available.
Without this configuration, GSLB can route traffic to an application that is down so long as the foundation itself is up.
This configuration relies on the application providing the health check endpoint at the application's root without authentication:
```properties
https://[app url]/health
```

Spring Boot actuator provides a health check endpoint and it's enabled by default if you are using the below dependency in your application:
```
implementation 'org.springframework.boot:spring-boot-starter-actuator'
```
The actuator's health check endpoint is located at URN:
```properties
/actuator/health
```

There are couple of methods to meet the GSLB health check requirements:
1) Change the Actuator's health check path, OR
2) Add a filter to forward requests

Which method you choose depends on the application.  Existing applications may have dependencies connecting to /actuator/health for example.

### Change the Actuator endpoint path

While simple, this will have unintended consequences as it changes all actuator endpoints.  Changes will be needed in the security filter and security tests.

application.properties:
```properties
management.endpoints.web.base-path: /
```
### Create a forwarding filter

> Note: Choose this approach when you have other dependencies with `/actuator/**` endpoints.

Create the forwarding filter - [HealthCheckForwardingFilter](./src/main/java/com/ford/devenablement/appgslb/healthcheck/HealthCheckForwardingFilter.java):
```java
@Slf4j
public class HealthCheckForwardingFilter implements Filter {

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
        HttpServletRequest httpReq = (HttpServletRequest) request;

        if(httpReq.getRequestURI().equals("/health")) {
            RequestDispatcher dispatcher = request.getRequestDispatcher("/actuator/health");
            log.info("Forwarding health check to actuator");
            dispatcher.forward(request, response);
        } else {
            chain.doFilter(request,response);
        }
    }
}
```

Implement the filter - [HealthCheckFilterConfig](./src/main/java/com/ford/devenablement/appgslb/healthcheck/HealthCheckFilterConfig.java):
```java
@Configuration
public class HealthCheckFilterConfig {
    @Bean
    public FilterRegistrationBean<HealthCheckForwardingFilter> healthFilter() {
        FilterRegistrationBean<HealthCheckForwardingFilter> registrationBean
                = new FilterRegistrationBean<>();

        registrationBean.setFilter(new HealthCheckForwardingFilter());
        registrationBean.addUrlPatterns("/health");

        return registrationBean;
    }
}
```

### Security
In addition to the above steps, you will need to update your security configuration to allow access to the /health endpoint.  You should also add additional tests.

```
.antMatchers("/health").permitAll()
```
