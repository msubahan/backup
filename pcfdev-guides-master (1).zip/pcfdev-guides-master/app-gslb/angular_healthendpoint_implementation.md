# Angular using nginx_buildpack
When deploying  angular application to PCF with nginx_buildpack, you need to provide three files, [nginx.conf](https://github.ford.com/WaMCOE/frf-starter/blob/v11.0.0/nginx.conf), [mime.conf](https://github.ford.com/WaMCOE/frf-starter/blob/v11.0.0/mime.types) and [manifest.yml](https://github.ford.com/WaMCOE/frf-starter/blob/v11.0.0/manifest.yml).

The nginx.conf provides health check endpoint. If your angular application is running, it will return HTTP status code of 200 with {"status":"UP"}.

# (Deprecated) Angular using staticfile_buildpack 
> Note: Angular using staticfile_buildpack is deprecated. With [DCS](https://dcs.ford.com/project-workflow/angular) Standard Setup, you can generate a sample application as a reference to migrate your staticfile_buildpack based application. 

When the Vanity URL is pointing to an Angular application via staticfile_buildpack, an endpoint needs to be made available that responds to requests made to /health.
This request is satisfied by an update to the nginx.conf file.  Most applications will not be including this file already.
The change is simply to add the following location to the existing configuration:
```java
    location /health {
        default_type application/json;
        return 200 '{"status":"UP"}';
    }
```

To obtain the current default version of the nginx.conf file included in the buildpack, do the following:
- Use the CF CLI to SSH into the container in PREPROD
- locate the nginx.conf file
- Copy the contents - You can view by using the cat command:  cat /home/vcap/app/nginx/conf/nginx.conf

```java
cf ssh [appname]

find / -name "nginx.conf"
```

Currently the file is located here:
```java
/home/vcap/app/nginx/conf/nginx.conf
```

Below is a copy of the file after adding the health endpoint modification:
```java
worker_processes 1;
daemon off;

error_log /home/vcap/app/nginx/logs/error.log;
events { worker_connections 1024; }

http {
  charset utf-8;
  log_format cloudfoundry '$http_x_forwarded_for - $http_referer - [$time_local] "$request" $status $body_bytes_sent';
  access_log /home/vcap/app/nginx/logs/access.log cloudfoundry;
  default_type application/octet-stream;
  include mime.types;
  sendfile on;

  gzip on;
  gzip_disable "msie6";
  gzip_comp_level 6;
  gzip_min_length 1100;
  gzip_buffers 16 8k;
  gzip_proxied any;
  gunzip on;
  gzip_static always;
  gzip_types text/plain text/css text/js text/xml text/javascript application/javascript application/x-javascript application/json application/xml application/xml+rss;
  gzip_vary on;

  tcp_nopush on;
  keepalive_timeout 30;
  port_in_redirect off; # Ensure that redirects don't include the internal container PORT - 8080
  server_tokens off;

  server {
    listen 8080;
    server_name localhost;

    root /home/vcap/app/public;

    location / {
        index index.html index.htm Default.htm;
    }

    location /health {
        default_type application/json;
        return 200 '{"status":"UP"}';
    }

      location ~ /\. {
        deny all;
        return 404;
      }

  }
}
```

Include the nginx.conf file in your dist directory prior to pushing the app to PCF.
