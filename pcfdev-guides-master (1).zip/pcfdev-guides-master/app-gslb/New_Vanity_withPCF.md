# PCF Vanity URL Guide

### New PCF Vanity URL
If you're confused by any of the content on this page, please start by fully reading the [Vanity URL General page](README.md).


## High Level Steps
1. [Implement a /health API endpoint in your application code](#implement-a-/health-api-endpoint-in-your-application-code)
2. [Submit Ford Cloud Portal request for a new Vanity URL and WideIP URL](#submit-ford-cloud-portal-request-for-a-new-vanity-url-and-wideip-url)
3. [Map a route for the WideIP URL and Vanity URL to your PCF app](#map-a-route-for-the-wideip-url-and-vanity-url-to-your-pcf-app)
4. [Test app functionality using WideIP URL AND Vanity URL](#test-app-functionality-using-wideip-url-and-vanity-url)
5. [Understand how to control application traffic](#understand-how-to-control-application-traffic)


## 1.) Implement a /health API endpoint in your application code
In order for traffic to be properly routed to your PCF application, you will need to expose a /health endpoint in your application. At a minimum, this /health endpoint needs to return a 200 response when queried, indicating that the application is healthy and able to receive traffic. Please note that this /health endpoint <b>must be implemented at the root of your application URL.</b> For example, a /health endpoint at "app_name.ford.com/actuator/health" <b>will NOT work.</b>

Implementing this /health endpoint can be accomplished in a number of ways, depending on your application architecture. Documentation has been provided for a number of common frameworks:
 - [Spring Boot](springboot_healthendpoint_implementation.md)
 - [Angular](angular_healthendpoint_implementation.md)
 - [WAS Liberty](CLOUD_TOLERANT.md)


If additional assistance is needed to configure a /health endpoint for your application, please submit a detailed post to the [DevEnablement Community Yammer forum.](https://www.yammer.com/ford.com/#/threads/inGroup?type=in_group&feedId=7970611200&view=all)

 Additional reading on API Health Monitoring [can be found here.](https://github.ford.com/Platform-Enablement/API-Style-Guide/wiki/API-Health-Monitoring)

#### <u>How can I test this is working correctly?</u>
Once you have implemented the /health endpoint in your application code and deployed the application to your PCF Org, you can test the proper functionality of your /health endpoint.

To do so, open your application from the PCF Apps Manager WebUI using the PCF-specific URL (Ex. app_name.apps.pp01.edc1.cf.ford.com). At the end of the URL, append "/health" and try to navigate to the new URL. If it resolves and you see a success message of some kind, your /health endpoint is functioning correctly.

If the page does not resolve or shows an unexpected message, your /health endpoint is not functioning correctly and you will need to address it.


## 2.) Submit Ford Cloud Portal request for a new Vanity URL & WideIP URL
This will create a new WideIP URL for use with your Vanity URL. This WideIP URL is utilized by the load balancer to allow for proper application traffic routing. (Note: WideIP URL name will be based off your Vanity URL name.)

#### <u>To submit the request (Org Managers only):</u>

a.) Navigate to the [Create Vanity URL page in FCP](https://www.cloudportal.ford.com/vanity-url)

b.) Enter the AppID/ITMS# of your application
 - The portal will use this input to verify that your application has a valid GRC record; if one is not found, you will be asked to provide an ACR number on the next page

c.) Select the desired environment, PCF Org name, and all applicable Foundations where this Vanity URL will be used

d.) Once everything is correct, click "Next"

e.) If a valid GRC record was not found for your application, enter the ACR# for your application instead
 - If your application does not have an ACR# and does not yet have a valid GRC record, you can select the box for "I don't have a valid ACR number."
 - If selecting this option, you must attest that you have received LL6+ approval to request this new Vanity URL

f.) Enter the Certificate Owner CDSID (LL6+)

g.) Enter your desired core domain name, including "ford.com"

h.) From the preview list, select your desired full Vanity URL

i.) Make note of the WideIP URL that will also be created with this request (this will also be emailed to you when the request is submitted)

j.) Read and agree to the Terms of Use

k.) Click "Create"

![new_Vanity_FCP_first.png](New_Vanity_FCP_first.PNG)

![new_Vanity_FCP_second.png](New_Vanity_FCP_second.png)


<br><br>
#### <u>What happens when I submit?</u>
If all the inputs are valid, the requester should see a confirmation that their request was successful. They will then receive an email confirmation, <b>which will also include their new WideIP URL.</b> This URL should be shared with the full team and kept handy during this process. The WideIP URL is just as important as your Vanity URL.


## 3.) Map a route for the WideIP URL and Vanity URL to your PCF app
In order for the PCF platform to be able to route application traffic to your specific PCF app, a "route" must be configured in your PCF Org. Routes can be configured from either the cf CLI or from the PCF AppsManager WebUI.


#### <u>From the PCF AppsManager:</u>
a.) Select your PCF Org

b.) Select the applicable Space within your Org

c.) Select the desired application that requires a route

d.) Click on the "Routes" tab on the left-side pane

e.) Click the "Map a Route" button

<br>

![new_Vanity_map_route.png](DCOF_map_route_WideIP.PNG)
Mapping the WideIP URL

![new_Vanity_map_route2.png](DCOF_map_route_Vanity.PNG)
Mapping the Vanity URL

Information on mapping a route via the cf CLI [can be found here.](https://cli.cloudfoundry.org/en-US/v6/map-route.html)

## 4.) Test app functionality using WideIP URL AND Vanity URL
The full scope of the functionality testing is at the discretion of the application team, but at a minimum, it is recommended that you run a "curl -i" command via the CLI with your new WideIP-URL/health as an argument, as well as with your Vanity-URL/health as an argument. This will confirm that your /health endpoint is working as expected. Once confirmed, the final test will be navigating to your Vanity URL in a web browser and seeing if it resolves to your application correctly.

![new_Vanity_ma_route.png](DCOF_test_WideIP_health.PNG)


## 5.) Understand how to control application traffic
The primary benefit of using an application-specific Vanity URL configuration is the automated failover of application traffic should your PCF application go down in one of the data centers.

But this configuration will also allow application teams to have more direct control over where their application traffic is flowing at any given time. This can be useful when undergoing app maintenance, conducting blue-green deployments, or testing/enacting disaster recovery (DR) procedures.

Controlling application traffic is simple enough: direct manipulation of the application via the PCF AppsManager WebUI will allow teams to determine where traffic will flow. For instance, if an application instance is stopped in EDC1, within 30 seconds, the F5 GSLB will recognize the application is down and will stop routing traffic to the PCF Foundation in EDC1, and instead route all traffic to the application in the PCF Foundation in EDC2. And vice versa if the application is stopped in EDC2.

As always, teams are highly encouraged to experiment with application traffic control in lower environments first to get a feel for the process before attempting any traffic control in Production.

![traffic_control_stop](traffic_control_stop.png)

![traffic_control_start](traffic_control_start.png)
