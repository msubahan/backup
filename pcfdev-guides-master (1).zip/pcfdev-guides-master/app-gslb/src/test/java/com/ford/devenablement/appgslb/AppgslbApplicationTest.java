package com.ford.devenablement.appgslb;

import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class AppgslbApplicationTest {
	@Test
	public void contextLoads() {
	}
}