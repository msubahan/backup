package com.ford.devenablement.appgslb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AppgslbApplication {

	public static void main(String[] args) {
		SpringApplication.run(AppgslbApplication.class, args);
	}

}
