package com.ford.devenablement.appgslb.healthcheck;

import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class HealthCheckFilterConfig {
    @Bean
    public FilterRegistrationBean<HealthCheckForwardingFilter> healthFilter() {
        FilterRegistrationBean<HealthCheckForwardingFilter> registrationBean
                = new FilterRegistrationBean<>();

        registrationBean.setFilter(new HealthCheckForwardingFilter());
        registrationBean.addUrlPatterns("/health");

        return registrationBean;
    }
}
