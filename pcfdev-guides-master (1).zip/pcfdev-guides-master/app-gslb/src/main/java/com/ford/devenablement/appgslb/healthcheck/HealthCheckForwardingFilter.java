package com.ford.devenablement.appgslb.healthcheck;

import lombok.extern.slf4j.Slf4j;

import javax.servlet.*;
import javax.servlet.http.HttpServletRequest;
import java.io.IOException;

@Slf4j
public class HealthCheckForwardingFilter implements Filter {

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
        HttpServletRequest httpReq = (HttpServletRequest) request;

        if(httpReq.getRequestURI().equals("/health")) {
            RequestDispatcher dispatcher = request.getRequestDispatcher("/actuator/health");
            log.info("Forwarding health check to actuator");
            dispatcher.forward(request, response);
        } else {
            chain.doFilter(request,response);
        }
    }
}
