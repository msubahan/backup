# PCF On-Prem Vanity URL Guide

### DCoF Migration (Non-PCF) to PCF
If you're confused by any of the content on this page, please start by fully reading the [Vanity URL General page](https://github.ford.com/DevEnablement/pcfdev-guides/tree/master/app-gslb).

## New Cutover Process & Preparation
Previously, DCoF migrations to the PCF platform required a DNS ticket to be submitted by the PCF team and scheduled for a specific cutover date/time. Going forward, IT Connect tickets will no longer be required, and DCoF migration requests are available in a self-service capacity via the Ford Cloud Portal. In addition, app teams will now have <b>full control over their application traffic when conducting their migration cutover. </b>This means that initial traffic cutover is controlled by the app team, and if any issues arise when conducting the migration cutover, the app team will be able to easily and immediately revert the cutover and send application traffic back to their original infrastructure. This will not require an emergency DNS ticket or any direct support from the PCF or DNS teams. This functionality is made possible through the use of the NaaS Migration Tool, which you will learn more about below.

This is a major change from the previous DCoF migration process and may be concerning to some teams, so it is worth re-iterating: <b> If the steps below are followed correctly, the DNS tickets associated with your migration cutover (Step #8) will have <i>no immediate effects</i> on your application traffic. Using the NaaS Migration/Availability Tool, the application team will have full control over when the traffic cutover will actually take place.</b> This means that Step #8 can be completed at any time by the application team before the true cutover, and application teams can rest assured that the cutover will not occur until they initiate it via the NaaS Migration/Availability Tool. This same tool will allow application teams to revert their cutover immediately should any unforeseen issues arise.

Please ensure your team has read through and understands the steps outlined on this page fully before beginning implementation.

## High Level Steps
1. Request access to the NaaS Migration/Availability Tool
2. Implement a /health API endpoint in your application code
3. Submit Ford Cloud Portal request to create a WideIP URL (FCP Step #1)
4. Map a route for the WideIP URL to your PCF app
5. Test app functionality using WideIP URL & /health endpoint
6. Disable PCF pools and enable non-PCF pools in NaaS Migration/Availability Tool
7. Map a route for the Vanity URL to your PCF app
8. Submit Ford Cloud Portal request to DNS map your WideIP URL to your Vanity URL (FCP Step #2)
9. Use NaaS Migration/Availability Tool to cutover traffic from non-PCF infrastructure to PCF
10. Request PCF migration support (if needed)

## 1.) Request access to the NaaS Migration/Availability Tool
The [NaaS Migration/Availability Tool](https://nsg.app.ford.com/lbaas/availability/) is Network-as-a-Service team offering specifically designed for application migrations. Once access has been granted and your team has generated a WideIP URL for use with your Vanity URL (Step #3), you can search for that WideIP URL in the NaaS Migration/Availability Tool, and you will see all network pools associated with your Vanity URL/WideIP URL. Application teams should see 3 network pools: one for their legacy infrastructure, and two for their new DCoF infrastructure in EDC1 and EDC2.

The use of the tool is fairly straightforward: once a route has been created for your WideIP URL to your PCF app (Step #4) any pools set to "On" will receive application traffic and any pools set to "Off" will not receive traffic. Toggling the pools on or off will immediately switch application traffic to only route to the pools set to "On."

![screenshot of DCOF_request_access_NaaS.png](DCOF_request_access_NaaS.PNG)

#### <u>To request access to the NaaS Migration/Availability Tool:</u>
Follow these [NaaS access instructions](https://nsg.app.ford.com/docs/faq/access/) to request access to the NaaS Migration/Availability Tool
 - Note: Your team will need a FIM group in order to obtain access to this tool
 - For Step #5 at the link above, the service sub-type will be "NSG Tool Access"

#### <u>To learn more about using the NaaS Migration/Availability Tool:</u>
The NaaS team has created excellent documentation for using this tool, which is [available here.](https://nsg.app.ford.com/docs/load-balancing/tools/availability-service/)
 - Please note that the screenshots included in the above documentation only shows a network pool for EDC1; when application teams view their WideIP network pool configuration, it will show pools for both EDC1 and EDC2
 - Application teams can find additional helpful documentation pages on the left-hand sidebar of the NaaS documentation site, but please be aware that <b>not all of this information may apply to PCF migrations;</b> for instance, the NaaS instructions for submitting a DNS ticket will not apply to DCoF PCF migrations, as all DNS tickets will be created via the Ford Cloud Portal self-service forms (Step #8 below)

## 2.) Implement a /health API endpoint in your application code
In order for traffic to be properly routed to your PCF application, you will need to expose a /health endpoint in your application. At a minimum, this /health endpoint needs to return a 200 response when queried, indicating that the application is healthy and able to receive traffic. Please note that this /health endpoint <b>must be implemented at the root of your application URL.</b> For example, a /health endpoint at "app_name.ford.com/actuator/health" <b>will NOT work.</b>

Implementing this /health endpoint can be accomplished in a number of ways, depending on your application architecture. Documentation has been provided for a number of common frameworks:
 - [WAS Liberty](https://github.ford.com/DevEnablement/pcfdev-guides/blob/master/app-gslb/CLOUD_TOLERANT.md) (most common for DCoF migrations)
 - [Spring Boot](springboot_healthendpoint_implementation.md)
 - [Angular](angular_healthendpoint_implementation.md)



 If additional assistance is needed to configure a /health endpoint for your application, please submit a detailed post to the [DevEnablement Community Yammer forum.](https://www.yammer.com/ford.com/#/threads/inGroup?type=in_group&feedId=7970611200&view=all)

  Additional reading on API Health Monitoring [can be found here.](https://github.ford.com/Platform-Enablement/API-Style-Guide/wiki/API-Health-Monitoring)

#### <u>How can I test this is working correctly?</u>
Once you have implemented the /health endpoint in your application code and deployed the application to your PCF Org, you can test the proper functionality of your /health endpoint. To do so, open your application from the PCF Apps Manager WebUI using the PCF-specific URL (Ex. app_name.apps.pp01.edc1.cf.ford.com).

At the end of the URL, append "/health" and try to navigate to the new URL. If it returns a 200 OK response, your /health endpoint is functioning correctly.

If the page does not return a 200 OK response or shows an unexpected message, your /health endpoint is not functioning correctly and you will need to address it.


## 3.) Submit Ford Cloud Portal request to create a WideIP URL (FCP Step #1)
PCF Vanity URL self-service in FCP is conducted in a 2-step process. The first step will create a new WideIP URL for use with your Vanity URL. This WideIP URL is utilized by the F5 Global Server Load Balancer (GSLB) to allow for proper application traffic routing. (Note: WideIP URL name will be based off your existing Vanity URL name)

#### <u>To submit the request (Org Managers only):</u>

a.) Navigate to the [Manage Vanity URL page in FCP](https://www.cloudportal.ford.com/vanity-url/manage)

b.) Select the option for "DCoF Migration (Non-PCF) to PCF"

c.) Select the next option for "Step 1: Create WideIP/AppGSLB URL"

d.) Select the desired environment, PCF Org name, and all applicable Foundations where this Vanity URL will be used

e.) If your application is a WAS Liberty app that will be externally facing, select "Yes"; otherwise, select "No"

f.) Provide an ACR number (if available) and the CDSID of the LL6+ who is responsible for ownership of your Vanity URL

g.) Lastly, provide the full URL of your application's existing Vanity URL

![screenshot of DCOF_Vanity_Step1.png](DCOF_Vanity_Step1.PNG)
<br><br>
#### <u>What happens when I submit?</u>
If all the inputs are valid, the requester should see a confirmation that their request was successful. They will then receive an email confirmation, <b>which will also include their new WideIP URL.</b> This URL should be shared with the full team and kept handy during this process. The WideIP URL is just as important as your Vanity URL.

To test that the WideIP URL was created successfully, you can search for your WideIP URL using the NaaS Migration/Availability Tool, which should direct you to the network pool configuration page.


## 4.) Map a route for the WideIP URL to your PCF app
In order for the PCF platform to be able to route application traffic to your specific PCF app, a "route" must be configured in your PCF Org. Routes can be configured from the PCF AppsManager WebUI.

#### <u>From the PCF AppsManager:</u>
a.) Select your PCF Org

b.) Select the applicable Space within your Org

c.) Select the desired application that requires a route

d.) Click on the "Routes" tab on the left-side pane

e.) Click the "Map a Route" button

![add screenshot DCOF_map_route_WideIP.png](DCOF_map_route_WideIP.PNG)



<br>

Information on mapping a route via the cf CLI [can be found here.](https://cli.cloudfoundry.org/en-US/v6/map-route.html)

## 5.) Test app functionality using WideIP URL & /health endpoint
At this point, you should have everything you need to test the functionality of your WideIP URL. Things to know:<b>
 - No DNS changes have been made yet; your Vanity URL is still pointing to your legacy infrastructure
 - Any action in the NaaS Availabilty Tool will not affect Vanity URL traffic; there is no danger in affecting users
 - You will conduct tests using only your WideIP URL, not your Vanity URL</b>


 The full scope of the functionality testing is at the discretion of the application team, but at a minimum, it is recommended that you run a "curl -i" command via the CLI with your new WideIP-URL/health as an argument. If a 200 response is returned, this will confirm that your /health endpoint is working as expected.

 ![curl command with wideipurl](DCOF_test_WideIP_health.PNG)

 Once confirmed, the final test will be navigating to your WideIP URL in a web browser and seeing if it resolves to your application correctly.

Application teams can also experiment with toggling the NaaS Availablity Tool network pools on and off, and testing if their application resolves using their WideIP URL.

<br><br><br><br>
### - - - - - - - Preparing for Cutover - - - - - - -
As always, please take extra care when conducting cutovers of Production Vanity URLs.
<br><br><br><br><br><br>

## 6.) Disable PCF pools and enable non-PCF pools in NaaS Migration/Availability Tool
Before completing Step #8, which will submit a DNS request to map your WideIP URL to your Vanity URL, it is crucial to return to the NaaS Migration/Availability Tool to disable your PCF network pools and enable your legacy infrastructure network pools. By doing so, you can ensure that the DNS ticket associated with Step #8 will have no immediate effect on your Vanity URL traffic. <p>
<b>Failure to complete this step will cause application traffic to immediately begin flowing to PCF when the DNS tickets are implemented.</b>

![add screenshot DCOF_disable_PCF_pools.png](DCOF_disable_PCF_pools.PNG)

## 7.) Map a route for the Vanity URL to your PCF app

#### <u>From the PCF AppsManager:</u>
a.) Select your PCF Org

b.) Select the applicable Space within your Org

c.) Select the desired application that requires a route

d.) Click on the "Routes" tab on the left-side pane

e.) Click the "Map a Route" button

![DCOF_map_route_Vanity.png](DCOF_map_route_Vanity.PNG)

<br>

Information on mapping a route via the cf CLI [can be found here.](https://cli.cloudfoundry.org/en-US/v6/map-route.html)

## 8.) Submit Ford Cloud Portal request to DNS map your WideIP URL to your Vanity URL (FCP Step #2)
PCF Vanity URL self-service in FCP is conducted in a 2-step process. The second step <b>will submit a DNS request to map your WideIP URL to your Vanity URL.</b> Because you completed Step #6, this will have <u><b>no immediate effect on your Vanity URL traffic.</u></b>  

#### <u>To submit the request (Org Managers only):</u>

a.) Navigate to the [Manage Vanity URL page in FCP](https://www.cloudportal.ford.com/vanity-url/manage)

b.) Select the option for "DCoF Migration (Non-PCF) to PCF"

c.) Select the next option for "Step 2: Submit DNS Move for Vanity URL"

d.) Select the desired environment, PCF Org name, and all application Foundations where this Vanity URL will be used

e.) Select the domain that corresponds to your Vanity URL

f.) Select your Vanity URL

g.) Lastly, select the WideIP URL that corresponds to your Vanity URL

![DCOF_Vanity_Step2.png](DCOF_Vanity_Step2.png)

<br>

#### <u>What happens when I submit?</u>
If all the inputs are valid, the requester should see a confirmation that their request was successful. They will also receive a confirmation email of the DNS ticket. Please note that the DNS ticket may take up to 24 hours to execute.

If your receive an error related to the submission of the DNS ticket, please submit a [PCF Incident ticket via IT Connect.](https://www.itconnect.ford.com/dwp/app/#/itemprofile/1116)


## 9.) Use NaaS Migration/Availability Tool to cutover traffic from non-PCF infrastructure to PCF
<b>PLEASE NOTE: This step cannot be completed until the DNS request associated with Step #8 is implemented. The requester will receive an email when this DNS implementation is successful (usually within 24 hours).</b>

At the team's convenience, once the DNS tickets have been implemented, application teams can use the NaaS Migration/Availability Tool to toggle their PCF network pools on, and their legacy infrastructure network pools off. Once done, they should fully test their Vanity URLs and confirm that they are resolving. Teams should cross-reference their PCF application logs to ensure that Vanity URL traffic is now directing to PCF and not their legacy infrastructure.

Should any unforeseen issues arise, application teams can quickly and easily toggle their PCF network pools off, and their legacy infrastructure network pools back on, thus reverting their Vanity URL traffic back to their old infrastructure. Once they are ready to try again, they can repeat the process until no further issues arise.


![screenshot of DCOF_request_access_NaaS.png](DCOF_request_access_NaaS.PNG)


At this point, after testing their application satisfactorily, the DCoF migration can be considered complete.

## 10.) Request PCF migration support (if needed)
With this new Vanity URL cutover process, application teams should have all the tools they need to complete their cutover themselves. As such, <b>PCF Engineers will no longer join migration bridge calls in a "standby" capacity.</b> If any issues arise that require PCF support, application teams can submit a "Report PCF Related Incident" critical ticket in ITConnect. The SLA of this ticket is 15 minutes or less and an on-call PCF Engineer will be available to join your migration bridge call and provide support.

#### <u>To submit the request:</u>

a.) In ITConnect, search for the [Report PCF Related Incident](https://www.itconnect.ford.com/dwp/app/#/itemprofile/1116) ticket form

b.) Fill out all required fields

c.) Include in the 'Issue Summary' field that you require "migration bridge support"

d.) Ensure that the 'Urgency' field is "Critical"

e.) For improved response time, include the URL of your migration bridge meeting in the 'Additional Comments' field
