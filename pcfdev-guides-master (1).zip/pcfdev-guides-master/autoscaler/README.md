# Autoscale Automation Guide

## App Autoscaler Service

App Autoscaler is a marketplace service that automatically scales apps in your environment based on app performance metrics or a schedule. This controls the cost of running apps while maintaining app performance.

You can use App Autoscaler to do the following:
- Configure scaling rules that adjust app instance counts based on metrics thresholds such as memory, HTTP traffic, etc.
- Modify the maximum and minimum number of instances for an app, either manually or following a schedule

>Note: PER the [Vendor document on CPU scaling](https://community.pivotal.io/s/article/PCF-Autoscaler-Advisory-for-Scaling-Apps-Based-on-the-CPU-utilization?language=en_US), we strongly evourage teams to avoid scaling on CPU. The example code we have above uses CPU as an example only. 


## Autoscaler limitations

The App Autoscaler has a couple limitations that we will talk about, and offer solutions for in this guide.

#### Autoscaler configuration

The Autoscaler instance can only be configured manually using the Apps Manager or through the use of a manifest file 
which is read by the App Autoscaler CLI plugin. You will need to install this plugin wherever you currently have your 
CF CLI installed (both your developer machines as well as your CI server) in order to leverage the autoscaler manifest 
file. The benefit to this model is that automation can be used and consistent autoscaler rules can be kept in a manifest 
file which will be managed in your source code management system (GitHub) with the rest of your project artifacts.


#### Blue/Green deployments

When using a Blue/Green deployment model, any new versions of your application are deployed to PCF as a new application
and eventually swapped in to replace the previous version of your application. It is the fact that the push of your 
application is considered a new application (it gets a new PCF app guid) that causes an issue. The issue is that the 
previously established scaling rules are not applied to the new app that was just pushed. After the swap occurs 
(Blue becomes Green), and the newly pushed app becomes the current app, the scaling rules are lost. In this guide we 
offer a pattern on use of the App Autoscaler CLI plugin to apply the applications scaling rules to the new app using a 
manifest file. This allows these rules to be in place when the new app replaces the previous version of your app.

## The App Autoscaler Pattern for Blue/Green deployments

This section of the guide gives an example of how to ensure that your Autoscaler rules are maintained as you deliver new 
versions of your application to PCF using  Blue/Green deployment model. The code associated with this guide is a real 
example of using Autoscaler and the Dev Enablement pipeline (v3.0 or greater) which includes Blue/Green deployment support.

> NOTE: The working code example for this guide is located in its own repo at
> [https://github.ford.com/DevEnablement/devenablement-service-autoscaledemo](https://github.ford.com/DevEnablement/devenablement-service-autoscaledemo). 
>This allows the Dev Enablement team to deploy the solution to PCF to insure the code is always functioning as expected.

In this example application we are relying on:
* Jenkins server has had the App Autoscaler CLI plugin installed
* The file `autoscaler-manifest.yml` has been created with your autoscaler rules defined. 
* You are using the Dev Enablement Jenkins pipeline version 3.0 or greater as well as our GradleBoost Gradle plugin
version 3.0 or greater. 
* You are using the Post Deploy shell script file (`pipeline.app-post-start-script.sh`) that has the specific autoscaler 
CLI commands needed to register the autoscaler.
* You use the CF Services shell script file (`pipeline.cf-services.sh`) that defines the CF commands to create your 
services if they have not yet been created. This is useful for the first time you deploy your application that the 
required autoscaler service instance will in fact be created.


#### Contents of `pipeline.app-post-start-script.sh` 

This Dev Enablement Jenkins Pipeline supports the execution of commands that need to occur after an application has 
been deployed and started in PCF. In our case where we are in need of using the Autoscaler service, we can use this 
 file to perform 3 required actions needed for getting Autoscaler configured properly. These step all assume that the 
 Autoscaler CF plugin is installed.

1. Set the scaling limits to temporary values (such as 1 & 1). This only serves to avoid an error of having the default 
values (which are -1 & -1) causes when running the next step.
```
cf update-autoscaling-limits devenablement-autoscaledemo-dev-temp 1 1
```

2. Enable the autoscaler on the application that is being pushed.
```
cf enable-autoscaling devenablement-autoscaledemo-dev-temp
``` 

3. Use the manifest file to load the autoscaling rules into your applications autoscaler instance.
```
cf configure-autoscaling devenablement-autoscaledemo-dev-temp autoscaler-manifest.yml
```


## How to install the App Autoscaler CLI plugin

#### CF CLI Plugin Downloads

The CF CLI plugins, including the Autoscaler plugin, can be downloaded from the [cf-cli-plugins folder](http://www.nexus.ford.com/#browse/browse:jenkins_tools:plugins%2Fcf-cli-plugins) in Ford Nexus. Pick the appropriate plugin for your OS. Jenkins servers should use the Linux version.

#### Developer Workstation instructions

To install the App Autoscaler CLI plugin on your developer machine, follow [these instructions from Pivotal](https://docs.pivotal.io/application-service/2-10/appsman-services/autoscaler/using-autoscaler-cli.html).

#### Jenkins Server instructions

To install the App Autoscaler CLI plugin on your Jenkins server, follow these steps:

1. Follow Jenkins Custom Tools installation steps [https://github.ford.com/DevEnablement/ecoboost-pipeline/blob/master/MIGRATE_TO_JENK8S.md#installconfigure-custom-tools](https://github.ford.com/DevEnablement/ecoboost-pipeline/blob/master/MIGRATE_TO_JENK8S.md#installconfigure-custom-tools)

2. Add a new Custom Tool for CF AutoScaler Plugin using the script from the jenkins_custom_tool_for_cfautoscalerplugin.txt file in this guide. The provided script includes a reference to the actual plugin that has been made available in Ford's Nexus repository.
See screenshot below.
![Custom-Tool-Screenshot](./jenkins_custom_tool_for_cfautoscalerplugin.png)

3. Follow the custom tools installation steps to install the plugin.

4. You can verify successful installation by executing the shell command “cf plugins” in a free style Jenkins job. This will list the Autoscaler plugin in the list of installed plugins.

5. Finally, set an environment variable in Jenkins (Manage Jenkins -> Configure System -> Global Properties -> Environment Variables) for CF_PLUGIN_HOME pointing to ${JENKINS_HOME}, as shown below:
![CF plugin env var Screenshot](./cf_plugin_env_var.png)


## CF Push with Autoscale manifest locally

This guide includes a file called `deploy-app-withautoscale.sh` which can be used from your command line to execute 
a `cf push` of the demo application (that is also part of this guide), and then immediately use the required commands 
from the autoscaler plugin to configure the autoscaler in PCF based on rules defined in the `autoscaler-manifest.yml` 
file which is also provided in this guide. You must have installed the autoscaler plugin before running this script.
This approach assumes that you have the Autoscaler CLI installed locally.

Here are the steps from the shell script:

1. Create a Autoscaler service if necessary
```
if serviceMissing 'autoscaledemo-autoscaler' ; then
   cf create-service app-autoscaler standard autoscaledemo-autoscaler
fi
```

2. Using EcoBoost provided manifest creation functionality, create a "DEV" manifest file named manifest-generated.yml.
```
./gradlew -PcfManifestTarget=dev cfManifest
```

3. Push the App to PCF
```
cf push -f manifest-generated.yml
```

4. Set default scaling limits, enable the autoscaler, and then apply the autoscaler-manifest.yml rules.
>Note:  the autoscaler requires initial limits be established before enableing it, thus the first line below is required but is overridden by what is set in the autoscaler-manifest.yml
```
cf update-autoscaling-limits devenablement-autoscaledemo-dev 1 1
cf enable-autoscaling devenablement-autoscaledemo-dev
cf configure-autoscaling devenablement-autoscaledemo-dev autoscaler-manifest.yml
```


## Test Autoscaler behavior

This guide also includes a script (`run-autoscale-test.sh` for Mac and `run-autoscale-test.bat` for Windows) that will use JMeter to send some load to an API (/api/v1/hello/cpu) contained in this demo application that is included with this guide. When running this script you will be able to witness the Autoscaler in PCF scale your application up to 7 instances, and after load subsides, watch it sale back down to 1 instance. 
>Note: The API provided in thus demo application contains some code that will intentionally consume CPU cycles.

To use this script, you first must:
1. Install JMeter. See [JMeter site](https://jmeter.apache.org/) for all the details on using, installing, etc. this tool.
2. Deploy this application to PCF with autoscale rules in place. Ideally using the `deploy-app-withautoscale.sh` script we documented in previous section.
3. Edit the `jmeter-sendtraffic-for-autoscale.jmx` file, and update the "HTTPSampler.domain" property on line 32 such that it matches the domain of your application that you pushed in step 2.


## Autoscaler and Ford's Dual Foundation setup

The previous section mentioned that the autoscaling helps with controlling the cost of running applications. Applications that are deployed to PCF in both on-prem datacenters (EDC1 & EDC2) rely on the F5 GSLB (Global Server Load Balancer) to send traffic to your application in one of the two foundations. Unfortunately, the traffic to an application is not going to be evenly distributed across EDC1 & EDC2. In fact, it is likely that most of the traffic will get routed to 1 data center while the other one has much less load.

The use of the autoscaler can be an effective way to combat this issue by allowing the application in the data center that is receiving most of the traffic to automatically adjust and scale up to additional instances, while the same application in the other data center can scale down while it is not being used as much.

Example Issue:
1. Application "HelloWorld" is deployed to EDC1 and EDC2 because it has both HA (High Availability) and DR  (Disaster Recovery) requirements.
2. It is configured to use 5 instances in each data center, thus it is being billed for a total of 10 app instances.
3. Load balancer is currently sending 80% of traffic to EDC1 while only 20% is routed to EDC2.
4. The 5 instances are running at capacity in EDC1, while the 5 instances are too much capacity for current load.

Solution to above Issue:
1. Autoscaler is employed to the application in both EDC1 and EDC2.
2. Scaling rule allows for scaling from 2 to 5 instances based on HTTP throughput metrics.
3. Given example above where EDC1 is getting most of the traffic, Autoscaler maintains 5 application instances running to meet current demand.
4. Given example above where EDC2 is getting ittle traffic, Autoscaler runs only 2 application instances to meet current demand.
5. Net is there are 7 application instances running in order to meet demand, resulting in 30% reduction in cost of running this application.

> Note: See our [Application Specific Load Balancing Guide](https://github.ford.com/DevEnablement/pcfdev-guides/tree/master/app-gslb) to learn more about the GSLB and it's impact on applications in PCF.


## References

- Pivotal Autoscaler CLI documentation: [https://docs.run.pivotal.io/appsman-services/autoscaler/using-autoscaler-cli.html](https://docs.run.pivotal.io/appsman-services/autoscaler/using-autoscaler-cli.html).
- Pivotal Autoscaler Service documenation: [https://docs.pivotal.io/platform/application-service/2-8/appsman-services/autoscaler/about-app-autoscaler.html](https://docs.pivotal.io/platform/application-service/2-8/appsman-services/autoscaler/about-app-autoscaler.html)
- Avoid CPU Autoscaling: [https://community.pivotal.io/s/article/PCF-Autoscaler-Advisory-for-Scaling-Apps-Based-on-the-CPU-utilization?language=en_US](https://community.pivotal.io/s/article/PCF-Autoscaler-Advisory-for-Scaling-Apps-Based-on-the-CPU-utilization?language=en_US)

