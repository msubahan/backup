# Swagger Configuration for EcoBoost Spring Application

The Dev Enablement spring-boot-starter-ford with springfox libraries can generate API documentation from your Restful Controller classes. You
can simply generate a new Spring Boot project using [DCS](https://dcs.ford.com/project-workflow/springboot) to verify the recommended library versions and propertiy values. 

You need to select "App-to-App Security" with "Simple REST Controller" and/or "SQL Database + Flyway" EcoBoost Project options to generate security related attributes in swagger doc.



## Spring Boot Dependency
The libraries to support API documentaion generation:
```
com.ford.cloudnative:spring-boot-starter-ford:<version 3.0.0 or later>
io.springfox:springfox-boot-starter:3.0.0
```

## Basic Swagger Configuration

These swagger configurations are created during EcoBoost Spring project generation when you choose Swagger and/or Simple Rest Controller. 

```
# Configure Swagger
cn.app.swagger.enabled=true
cn.app.swagger.scan-packages=com.ford.dev.swaggerguide
cn.app.swagger.display.title=<app name>
cn.app.swagger.display.description=API Resources & Documentation
cn.app.swagger.display.contact-name=<cdsid>
cn.app.swagger.display.contact-email=<email>
cn.app.swagger.display.version=@gradle.properties.version@
```

## Customize the host, base-path and schemes

```
cn.app.swagger.apidoc.host=myhost
cn.app.swagger.apidoc.base-path=/mybasepath

# to test locally in Swagger UI, you can temporary comment property below
cn.app.swagger.apidoc.schemes=https
```

## Security Configuration
Spring-base-app will generate the security and securityDefinitions based on the following configurations.
> Before spring-boot-starter-ford version 3.0.0, the *scopes* property is a list, now it's a map.

```
#Security for ADFS 
cn.app.swagger.security.adfs.enabled=true
cn.app.swagger.security.adfs.env=qa

#Security for API Connect
cn.app.swagger.security.apic.enabled=true
cn.app.swagger.security.apic.token-url=https://apigtwdev.ford.com/myproject/sb/myapp/oauth2/token
cn.app.swagger.security.apic.scopes.oneford=oneforddesc

#Security for Azure AD
cn.app.swagger.security.azure-ad.enabled=true
cn.app.swagger.security.azure-ad.scopes.read=for read operations
cn.app.swagger.security.azure-ad.scopes.write=for write operations

#Security for Application-Id
cn.app.swagger.security.application-id.enabled=true

#Security for CAT token
cn.app.swagger.security.cat-auth-token.enabled=true
```

## Security in API method
> Before spring-boot-starter-ford version 3.0.0, all API definitions have a security attribute if any security is enabled, now there will be **no** security in API definitions unless they explicitly specified.

You have different ways to specify how to protect each API method in your application.

One way is to specify the API URL patterns for security. Make sure the pattern matching all the APIs that need security

For example, using ADFS protect APIs with /api in the path.
```
cn.app.swagger.security.adfs.paths=/api/**
```

Another option is to annotate the API method in your Restful controller code. It gives your opportunity to combine different types of security with *AND/OR*  logic.

For example
```java
	@ApiOperation(value = "Get all pets in store", notes = "Get all pets in store")
	@ApiOperationSecurity({ApiSecurityScheme.CAT_AUTH_TOKEN, ApiSecurityScheme.APPLICATION_ID}) // AND within
	@ApiOperationSecurity({ApiSecurityScheme.AZURE_AD, ApiSecurityScheme.APPLICATION_ID}) // OR across multiple @ApiOperationSecurity annotations
	@ApiResponses({
		@ApiResponse(code = 200, message = "OK", response = PetsResponse.class),
		@ApiResponse(code = 0 /*default*/, message = "All Errors", response = StandardErrorResponse.class)
	})
	@GetMapping
	public PetsResponse getAllPets() {
```


## HTTP Response Codes

In the controller class, add the annotations of @ApiResponses and @ApiResponse from io.swagger.annotations package to an API method to generate HTTP response code.

Starting from spring-boot-starter-ford version 3.0.0, you can define the default response code, so no need to list all error response codes any more. 

```
	@ApiResponse(code = 0 /*default*/, message = "All Errors", response = StandardErrorResponse.class)

```

Where *StandardErrorResponse* is in spring-boot-starter-ford.

## Bean Validation
With springfox-bean-validators, springfox can automatically generate Bean Validation definitions in the API documentation.

For example:
```
@Data
class RequestBody {
	@ApiModelProperty(dataType = "String" , example = "EcoBoost")
	@Size(min=1, max = 32, message
			= "name must be between 1 and 32 characters")
	@Pattern(regexp = "^.{1,32}$")
	private String name;
}
```

> Refer to [CAB](https://github.ford.com/PCFDev-CAB/cab-service-fordair) for how to use new features from spring-boot-starter-ford version 3.0.0 and 42Crunch.
