## Security Vulnerabilities

This guide is intended to define what is meant by Security Vulnerabilities, and define some standards, policies, 
and best practices team should follow in order to reduce their risk and potential exposure to vulnerabilities as they 
exist in open source software that is used in our applications.

### What is a Vulnerability

A vulnerability is a hole or a weakness in the application, which can be a design flaw or an implementation bug, 
that allows an attacker to cause harm to the stakeholders of an application. Stakeholders include the application 
owner, application users, and other entities that rely on the application.

In this guide we are going to focus on vulnerabilities that exist in Open Source libraries that we use in our 
applications. There are other dev guides that speak to vulnerabilities in the software we write (our code as opposed 
to open source code). See examples at:
* [OWASP Top Ten Security](https://devservices.ford.com/dev-guides?search=OWASP%20TOP%2010%20Security%20-%202020)
* [Ford Credit Security Solutions](https://devservices.ford.com/dev-guides?search=Ford%20Credit%20Security%20Solutions)

### CVE's

The Common Vulnerabilities and Exposures (CVE) system provides a reference-method for publicly known 
information-security vulnerabilities and exposures. The can be referenced in the 
[National Vulnerability Database](https://nvd.nist.gov/).

CVE Identifiers (also called "CVE names," "CVE numbers," "CVE-IDs," and "CVEs") are unique, common identifiers for 
publicly known information security vulnerabilities. Each CVE Identifier includes the following:
* CVE identifier number (i.e., "CVE-1999-0067").
* Indication of "entry" or "candidate" status.
* Brief description of the security vulnerability or exposure.
* Any pertinent references (i.e., vulnerability reports and advisories or OVAL-ID).
* CVE Identifiers are used by information security product/service vendors and researchers as a standard method for 
  identifying vulnerabilities and for cross-linking with other repositories that also use CVE Identifiers.

### CVE Detection

There are many SAST (static application security testing) tools that will identify CVE's in open source within our 
applications. Example in use at Ford include Checkmarx, Blackduck, and FOSSA, but others may also be in use. Dev 
Enablement is recommending the use of FOSSA, since it is required for License scanning and provides Security scanning 
at the same time as the license scan. This scanning can be integrated into a CI/CD pipeline to automate this analysis.

### How do I remediate a CVE

Once a CVE has been identified, the development team can remediate the CVE using one of the following options:
1. Remove use of the component
2. Upgrade the component to a newer version that does not have the CVE. In many cases the CVE details will identify a 
   version that does not have the CVE
   
After you have taken any of the actions above, you need to run the analysis again and validate the CVE is no longer 
present. Your ability to remediate in a timely manner greatly depends on your ability to quickly test that the changes 
made do not introduce errors. A robust automated test suite is a great way to do this validation.

A more detailed explanation of Security Issues in FOSSA can be found at this [SharePoint location](https://azureford.sharepoint.com/sites/SDE/FOSSA/FOSSA-SharePoint-Content/FOSSA%20Security%20Issues.pdf).


## Security Vulnerability Remediation Standard 

** *This section is under review, and pending approval from Cyber Security*. 

This remediation standard assumes the following:
* Team is using the FOSSA tool. Integration of FOSSA into a CI/CD pipeline is preferred but not required for this 
  process.
* Security Issue Scanning is enabled for the FOSSA project.
* The Security Policy named "High" is being used. This will raise a FOSSA Security Issue when "High" or "Critical" 
  CVE's are detected.
  

1. New applications, products, and API's cannot launch to production with FOSSA Security Issues from High or Critical 
   CVE's unless a deviation/exception is obtained.
2. Existing applications, products, API's must remediate FOSSA Security Issues from High or Critical CVE's within 45 
   days unless a deviation/exception is obtained.
   