package com.ford.devenablement.dbflyway.greeting;

import java.time.OffsetDateTime;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

 
@Service
public class GreetingService {

	private GreetingRepository greetingRepository;

	@Autowired
	public GreetingService(GreetingRepository greetingRepository) {
		this.greetingRepository = greetingRepository;
	}

	public Greeting create(Greeting newGreeting) {
		newGreeting.setCreated(OffsetDateTime.now());
		return this.greetingRepository.save(newGreeting);
	}

	public List<Greeting> getAllGreetings() {
		return this.greetingRepository.findAll();
	}

	public Optional<Greeting> getGreeting(Long id) {
		return this.greetingRepository.findById(id);
	}
		
	public Greeting update(Long id, Greeting updateGreeting) {
		Optional<Greeting> existingGreeting = getGreeting(id);
		if (!existingGreeting.isPresent()) {
			throw new IllegalStateException(String.format("Greeting record was not found using greeting ID [%s]", id));
		}

		updateGreeting.setId(id);
		updateGreeting.setCreated(existingGreeting.get().getCreated());
		Greeting persistedGreeting = greetingRepository.save(updateGreeting);
		return persistedGreeting;
    }
    
    public void delete(Long id) {
    	greetingRepository.deleteById(id);
    }
    
    public Boolean isExists(Long id) {
        return greetingRepository.existsById(id);
    }
	
}
