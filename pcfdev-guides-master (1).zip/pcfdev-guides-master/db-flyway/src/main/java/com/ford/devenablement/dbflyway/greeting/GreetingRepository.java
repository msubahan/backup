package com.ford.devenablement.dbflyway.greeting;

import org.springframework.data.repository.Repository;

import java.util.List;
import java.util.Optional;

public interface GreetingRepository extends Repository<Greeting, Long> {
	List<Greeting> findAll();

	Greeting save(Greeting greeting);

	Optional<Greeting> findById(Long id);
	
	boolean existsById(Long id);
	void deleteById(Long id);
}
