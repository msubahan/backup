INSERT INTO greeting (
  message,
  author_name,
  created
) VALUES('What''s Up?', 'Larry Smith', NOW());
INSERT INTO greeting (
  message,
  author_name,
  created
) VALUES('How''s it Going?', 'Bob Wilson', NOW());