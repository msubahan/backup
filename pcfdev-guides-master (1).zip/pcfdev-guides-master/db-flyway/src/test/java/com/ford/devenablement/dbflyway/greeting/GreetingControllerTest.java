package com.ford.devenablement.dbflyway.greeting;

import static java.lang.Boolean.FALSE;
import static java.lang.Boolean.TRUE;
import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.mockito.internal.verification.VerificationModeFactory.times;

import java.util.List;
import java.util.Optional;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.ford.devenablement.dbflyway.greeting.api.GreetingApi;
import com.ford.devenablement.dbflyway.greeting.api.GreetingRequest;
import com.ford.devenablement.dbflyway.greeting.api.GreetingResponse;
import com.ford.devenablement.dbflyway.greeting.api.GreetingsResponse;

@RunWith(MockitoJUnitRunner.class)
public class GreetingControllerTest {

	private static final Long GREETING_ID = 1L;
	private static final Long INVALID_GREETING_ID = 2L;

	private static final String MESSAGE = "Test Message";
	private static final String AUTHOR_NAME = "Test Author Name";

	// GreetingController controller;

	@Mock
	GreetingService greetingService;

	@Mock
	GreetingMapper greetingMapper;

	@InjectMocks
	GreetingController greetingController;

	@Test
	public void testGetGreeting() throws Exception {
		Greeting mockGreeting = mock(Greeting.class);
		when(greetingService.getGreeting(1L)).thenReturn(Optional.of(mockGreeting));
		GreetingApi mockGreetingApi = mock(GreetingApi.class);
		when(greetingMapper.fromGreeting(mockGreeting)).thenReturn(mockGreetingApi);

		ResponseEntity<GreetingResponse> response = greetingController.get(1L);

		assertThat(response.getStatusCode()).isEqualTo(HttpStatus.OK);
		assertThat(response.getBody().getError()).isNull();
		assertThat(response.getBody().getResult()).isNotNull();

		assertThat(response.getBody().getResult().getGreeting()).isEqualTo(mockGreetingApi);
	}

	@Test
	public void testGetGreetingsList() throws Exception {
		List<Greeting> mockGreetings = mock(List.class);
		when(greetingService.getAllGreetings()).thenReturn(mockGreetings);
		List<GreetingApi> mockListGreetingApi = mock(List.class);
		when(greetingMapper.fromGreetings(mockGreetings)).thenReturn(mockListGreetingApi);

		GreetingsResponse response = greetingController.list();

		assertThat(response.getError()).isNull();
		assertThat(response.getResult()).isNotNull();

		assertThat(response.getResult().getGreetings()).isEqualTo(mockListGreetingApi);
	}

	@Test
	public void testCreateGreeting() throws Exception {
		GreetingRequest greetingRequest = mock(GreetingRequest.class);
		Greeting mockGreeting = mock(Greeting.class);
		Greeting mockCreatedGreeting = mock(Greeting.class);
		GreetingApi mockCreatedGreetingApi = mock(GreetingApi.class);
		when(greetingMapper.toGreeting(greetingRequest)).thenReturn(mockGreeting);
		when(greetingMapper.fromGreeting(mockCreatedGreeting)).thenReturn(mockCreatedGreetingApi);
		when(greetingService.create(mockGreeting)).thenReturn(mockCreatedGreeting);

		ResponseEntity<GreetingResponse> response = greetingController.create(greetingRequest);

		assertThat(response.getStatusCode()).isEqualTo(HttpStatus.CREATED);
		assertThat(response.getBody().getError()).isNull();
		assertThat(response.getBody().getResult()).isNotNull();

		assertThat(response.getBody().getResult().getGreeting()).isEqualTo(mockCreatedGreetingApi);
	}

	@Test
	public void shouldReturnNotFoundIfGreetingDoesNotExistsForUpdate() {
		when(greetingService.isExists(INVALID_GREETING_ID)).thenReturn(FALSE);

		ResponseEntity<GreetingResponse> response = greetingController.update(INVALID_GREETING_ID,
				buildCreateGreetingRequest());
		assertThat(response.getStatusCode()).isEqualTo(HttpStatus.NOT_FOUND);
		verify(greetingService).isExists(Mockito.anyLong());
		verify(greetingService, times(0)).update(Mockito.anyLong(), Mockito.any());
	}

	@Test
	public void shouldUpdateGreetingIfExists() {
		GreetingApi mockGreetingApi = mock(GreetingApi.class);
		when(greetingService.isExists(GREETING_ID)).thenReturn(TRUE);
		when(greetingService.update(Mockito.eq(GREETING_ID), Mockito.any())).thenReturn(Greeting.builder().build());
		when(greetingMapper.toGreeting(Mockito.any())).thenReturn(mock(Greeting.class));
		when(greetingMapper.fromGreeting(Mockito.any())).thenReturn(mockGreetingApi);

		ResponseEntity<GreetingResponse> response = greetingController.update(GREETING_ID,
				buildCreateGreetingRequest());
		assertThat(response.getStatusCode()).isEqualTo(HttpStatus.ACCEPTED);
		assertThat(response.getBody().getResult().getGreeting()).isEqualTo(mockGreetingApi);
		verify(greetingService).isExists(Mockito.anyLong());
		verify(greetingService).update(Mockito.eq(GREETING_ID), Mockito.any());
	}

	@Test
	public void shouldReturnNotFoundIfGreetingDoesNotExistsForDelete() {
		when(greetingService.isExists(INVALID_GREETING_ID)).thenReturn(FALSE);

		ResponseEntity<HttpStatus> response = greetingController.delete(INVALID_GREETING_ID);
		assertThat(response.getStatusCode()).isEqualTo(HttpStatus.NOT_FOUND);
		verify(greetingService).isExists(Mockito.anyLong());
		verify(greetingService, times(0)).delete(Mockito.any());
	}

	@Test
	public void shouldDeleteGreetingIfExists() {
		when(greetingService.isExists(GREETING_ID)).thenReturn(TRUE);
		doNothing().when(greetingService).delete(GREETING_ID);

		ResponseEntity<HttpStatus> response = greetingController.delete(GREETING_ID);
		assertThat(response.getStatusCode()).isEqualTo(HttpStatus.ACCEPTED);
		verify(greetingService).isExists(GREETING_ID);
		verify(greetingService).delete(GREETING_ID);
	}

	private GreetingRequest buildCreateGreetingRequest() {
		return GreetingRequest.builder().message(MESSAGE).authorName(AUTHOR_NAME).build();
	}

}
