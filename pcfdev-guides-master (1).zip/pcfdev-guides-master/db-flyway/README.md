##  SQL Database + Flyway Guide

This guide demonstrates how to setup a project that usees a relational database and relies on Flyway to manage the DB schema. It shows how you to rely on the in-memory *H2* DB server for local development and testing. While H2 is uses for local development, you must use another relational database (MySQL, SQL Server, Oracle, PostgreSQL, etc.) for your deployed application. 

### Database drivers
In your EcoBoost generated application we have commented out the import of the MS SQL Server driver. If you are using SQL Server, simply uncomment the import. IF you are using MySQL in PCF, the database driver will be provided by the Java buildpack. If you are using some other database, you will have to add the necessary driver import to build.gradle.

There are notations specific to Azure SQL Server where appropriate and additional details about [Azure](#azure-sql-server) implementation at the end of this guide.
<br/>

### Flyway
We strongly suggest the use of Flyway as a tool for managing your relational schema. In fact, your schema (in the form of DDL statements) will be managed in your SCM tool (GitHub or AccuRev) along with all your other source code. This allows the changes to code or data model to be tracked, audited, and synced in a single location. 

Flyway has several different ways to actually execute your database migrations. We urge you to read [Flyway's official documentation](https://flywaydb.org/documentation/) to better understand all of its capabilities. The focus of this guide is on Spring Boot applications, and the use of Flyway's integration into Spring Boot such that migrations will be executed at deploy time using Flyway and our Spring Boot Starter Ford library. What this means is that all of the migrations will be executed at Spring Boot startup time. If the migration fails, your Spring Boot application will not start and you will be forced to address the catastrophic error. 

In addition to the documentation on this guide, Spring documents the topic of [database migrations on Spring Boot startup](https://docs.spring.io/spring-boot/docs/current/reference/html/howto-database-initialization.html#howto-execute-flyway-database-migrations-on-startup). This Spring document would be useful if you are not using our Spring Boot Starter Ford library.



### Implementation

In this guide, we have a implemented a feature package named [greeting](src/main/java/com/ford/devenablement/dbflyway/greeting) and inside we placed a *GreetingController.java* and all of its supporting Service, Repository, and JPA model classes. 

You will also find the (Flyway) SQL scripts that defines the DB schema and pre-populates data located in the [resources/db](src/main/resources/db) directory. The *db* folder is split into separate directories that target different DB vendors. The reason for this DB party is that we will use *H2* for the embedded in-memory database and a different DB vendor for our deployed applicatons in Cloud Foundry (e.g. MySQL, SQL Server). Different vendors may have slight differences in their SQL syntax and different set of SQL scripts may be required.

<br/>

### Build Script

Take a look at application's [build.gradle](build.gradle) for a complete list of dependencies. You will find these notable database-related dependencies:

```
org.springframework.boot:spring-boot-starter-data-jpa
org.flywaydb:flyway-core

com.h2database:h2
com.microsoft.sqlserver:mssql-jdbc

com.ford.cloudnative:spring-boot-starter-ford
```

The starter dependency handles the basic JPA and Spring database-related support. *Flyway* dependency will handle our database migrations and execution of SQL scripts. We rely on *H2* for the in-memory DB implementation. Lastly, we must pull in the JDBC database driver for the DB vendor that we will use in the deployed cloud &mdash; in this case it is SQL Server.

Finally we depend on the CloudNative Spring library to help us detect the DB vendor and configure Flyway to execute the SQL scripts from the correct vendor directory.

<br/>

### Flyway and SQL Server support
Flyway version 6.x was provided when moving to Spring Boot version 2.2.x. Unfortunately, this version of Flyway is not compatible with SQL Server 2014 databases. This older version of SQL Server is still in use at Ford. IF you are using SQL Server 2016 or greater, then use of Flyway 6.x is supported.

Teams using SQL Server 2014 and Spring Boot 2.2.x or 2.3.x will need to downgrade the verion of Flyway. The syntax for 
this in Gradle is:
```
implementation('org.flywaydb:flyway-core') {
	version {
		strictly '5.2.4'
	}
}
```

### Application Properties

We configure our *H2* embedded DB service and enable H2-console in [application.properties](src/main/resources/application.properties):

```
spring.datasource.url=jdbc:h2:mem:local;USER=sa;DB_CLOSE_DELAY=-1;DB_CLOSE_ON_EXIT=FALSE;MODE=MSSQLServer

spring.h2.console.enabled=true
spring.h2.console.path=/h2-console
```

With H2 console enabled, you can visit the H2 console [http://localhost:8080/h2-console](http://localhost:8080/h2-console) after running your application locally.

We must configure CloudNative Spring library to help us detect the DB vendor, configure our Flyway, and kick-off the Flyway migration during application start-up:

```
cn.app.datasource-populate.enabled=true
spring.flyway.locations=classpath:db/migration/{vendor}
spring.flyway.table=${spring.application.name}_schema_version
spring.flyway.baseline-on-migrate=true
spring.flyway.baseline-version=0
```

We also turn off other attempts by Spring or libraries to perform unnecessary and potentially similar conflicting DB migrations:

```
spring.flyway.enabled=false
spring.datasource.initialization-mode=never
spring.jpa.hibernate.ddl-auto=none
```

<br/>

### Configuring Datasources in the Cloud - with CUPS
 
For applications that include Dev Enablement's [Ford Spring Boot starter](https://github.ford.com/DevEnablement/spring-base-dependencies/tree/master/spring-base-app ) library as a dependency, when the application is deployed in the cloud environment, its PCF user-provided-services will be scanned for a *jdbcDbUrl* field and a DataSource will be configured for each JDBC DB URL field value found.

>NOTE: Generated EcoBoost projects include the Ford Spring Boot starter (i.e. com.ford.cloudnative:spring-boot-starter-ford)

>NOTE: If a DataSource is configured, then *spring.datasource.url* property in *application.properties* will be ignored.

<br/>

The following steps demonstrate how to configure your deployed application with a DataSource that points to a SQL Server:


1. Ensure both [Spring Base App](https://github.ford.com/DevEnablement/spring-base-dependencies/tree/master/spring-base-app) library and your database driver dependency are defined in *build.gradle*:
   
```
implementation 'com.ford.cloudnative:spring-boot-starter-ford'
implementation 'com.microsoft.sqlserver:mssql-jdbc'
``` 

For Azure SQL Server the following dependency is needed:

```
implementation 'com.microsoft.azure:adal4j'
```
2. Enable Spring Base App library's datasource-configure feature in *application.properties*:

```properties
cn.app.datasource-configure.enabled=true
```

3. Create a user-provided-service with the database JDBC URL for the datasource you need configured. Following is an example how to create a user-provided-service named *team-db* using *cf* cli command tool and bash: 

>NOTE: If multiple datasources are required, simply create additional user-provided-service instances for each additional database you will use. How to use multiple datasources in your app is outside the scope of this document.
	 
```
   cf cups team-db -p "$(cat <<EOF
   {
    "jdbcDbUrl": "jdbc:sqlserver://fcdb1591.md1q.ford.com:61435;databaseName=myDB;user=xxxxx;password=xxxxx" 
   }
   EOF
   )"
```

### Configuring Datasources in the Cloud - with Encryption

There is another approach for configuring datasources that relies on property files and encryption in order to manage connection strings that does not use CUPS as defined in previous section. Using this other technique will require us to store the datasource url and password in a property file, store the password in an encrypted format, and utilizing separate property files for each environment. See the [Secrets Management Guide](https://github.ford.com/DevEnablement/pcfdev-guides/tree/master/secrets-management) for more information on using the Jasypt library to encrypt/decrypt secrets in property files. See this [Properties with Spring Guide](https://www.baeldung.com/properties-with-spring#boot) from public internet for more information about property files and separate files per environment. Below is an example of a couple of the properties that you may expect to see in an `application-dev.properties` file to support by DEV environment integrating with an Oracle Database. This pattern is same as previous section, expect the final step for creation of a CUPS service.

```
# SQL Datasource. Password decrypted by Jasypt using password provided by CredHub
spring.datasource.url=jdbc:sqlserver://FCDB1591.MD1Q.FORD.COM:61435;databaseName=j2ee1;user=user02
spring.datasource.password=ENC(R2UWgoWrf32Kjt+kpS8sPFfHp7N/Xn55)
```

For Azure SQL Server:

>NOTE: Per the [Configuration guide for Azure SQL](https://azureford.sharepoint.com/sites/azure/ford%20azure%20how%20to%20guides%2Fhow%20to%20-%20configure%20and%20use%20azure%20sql%20server%20paas%20database.docx), 
       no local SQL Server accounts should be created or used.  Ford federates our internal CDSIDs with Azure
       so generic CDSIDs should be used instead of SQL server local proxy IDs.  This enforces company password managment policies are followed. 
       Credential strength and lifecycle are managed as any other Ford generic IDs.  Each team should configure two IDs to eliminate downtime 
       during password changes.  

```
   cf cups team-db -p "$(cat <<EOF
   {
    "jdbcDbUrl": "jdbc:sqlserver://[SERVERNAME].database.windows.net:1433;database=[DATABASE NAME];user=[CDSID]@ford.com;password=[PASSWORD];encrypt=true;trustServerCertificate=false;hostNameInCertificate=*.database.windows.net;loginTimeout=30;authentication=ActiveDirectoryPassword" 
   }
   EOF
   )"
```

You must create a user-provided-service in each PCF space the application will be deployed in. Creation of the user-provided-service is only required once prior to the app being pushed.

>NOTE: Different PCF space environments likely will use a different JDBC connection URLs to point to different environment instances (DEV, QA, PROD, etc.) of the DB.

4.  The newly created user-provided-service now needs to be bound/tied to the pushed app. One way to do this is to add the service name (i.e. *team-db*) under the *services* section in the *manifest.yml*.


``` 
  ....
  services:
  - team-db
```

5.  The Cloud Connectors dependency is needed to access the CUPS configuration

```
implementation 'org.springframework.boot:spring-boot-starter-cloud-connectors'

```

## Azure SQL Server

### Overview

This section discusses implementation of Azure SQL Databases in Cloud Native applications.  Much of the information 
contained here is summarized from the [Configuration guide for Azure SQL](https://azureford.sharepoint.com/sites/azure/ford%20azure%20how%20to%20guides%2Fhow%20to%20-%20configure%20and%20use%20azure%20sql%20server%20paas%20database.docx).



### Azure SQL Database Credentials

Per the [Configuration guide for Azure SQL](https://azureford.sharepoint.com/sites/azure/ford%20azure%20how%20to%20guides%2Fhow%20to%20-%20configure%20and%20use%20azure%20sql%20server%20paas%20database.docx), 
no local SQL Server accounts should be created or used.  Ford federates our internal CDSIDs with Azure
so generic CDSIDs should be used instead of SQL server local proxy IDs.  This enforces company password managment policies are followed. 
Credential strength and lifecycle are managed as any other Ford generic IDs.  Each team should configure two IDs to eliminate downtime 
during password changes.



### Database Creation
Cloud Engineering creates the database and associates the application team's generic IDs with access as part of iCSS 
(Infrastructure Customer Solution Service).  This process involves a Hosting Infrastructure Review (HIR process).

DB Admins are managed in Azure by the application team through a team member with Contributor access.  The list of contributors are 
identified during the HIR process.

### Azure DB Firewall

Cloud Operations will add access rules for PCF subnets and Ford VPN subnets.  Any additional requirements (developer computer using Public WIFI) can be added 
in the Azure Portal.

To allow additional IP addresses/ranges navigate as follows:

Azure Portal -> SQL servers -> [select your server] -> Firewalls and virtual networks



### Accessing the DB from the Ford Intranet
Local development using an externally hosted database poses a challenge as only HTTP traffic can pass through the outbound proxy.
Some options for connecting to the Azure SQL DB locally include:
<ul>
 <li>ZScaler Private Access</li>
 <li>Reverse VPN (See configuration guide)</li>
 <li>Public WIFI</li>
</ul>

Public WIFI works but is tedious.  ZScaler Private Access is available to all users, you just need to install the client application.  Access to database.windows.net has already been granted so once the client is installed, local connections to the database should work.  At this time the client is not available in the Ford software store but the client can be obtained online.

### Connection Strings

Access the recommended connection string from here:
Azure Portal -> SQL databases -> [your database] -> "Connection strings"

Select the JDBC tab and locate the connection string for "Active Directory password authentication".

See the example pasted below.  Note that the username must be a CDSID and include the @ford.com suffix.

```$xslt
jdbc:sqlserver://[SERVERNAME].database.windows.net:1433;database=[DATABASE NAME];user=[CDSID]@ford.com;password=[PASSWORD];encrypt=true;trustServerCertificate=false;hostNameInCertificate=*.database.windows.net;loginTimeout=30;authentication=ActiveDirectoryPassword
```
