# Git & GitHub Workflow Patterns

This Guide documents the various various Git workflows available to teams using GitHub to manage their source code. This list is not exhaustive. There are authoritative sites with detailed information just a google search away.

The focus of this discussion will be three Git workflows a project can use to manage changes:
1. GitHub Pull Requests
1. Git Flow
1. Commit to Master

Each style of workflow has its benefits and concerns that should be considered when choosing the project workflow.

## 1. GitHub Pull Requests
GitHub Pull Requests is for external contributions to the project and it is
being used for contributing to any of the Dev Enablement public repositories. 
The benefit to a project is that it allows external contributors to submit code changes and the development team can 
pull those changes into the repository using a well documented GitHub process. However, this is process intensive workflow not effective for daily development.

## 2. Git Flow
Git Flow uses branches to manage changes.

There are three types of branches in Git Flow:
1. `master` branch that is ready for release at any time.

1. `development` branch is the future features that have been accepted but not yet merged to `master` for release.

1. Feature branches are created for each change. The developer will branch from development (or some other feature branch) to create a new feature branch. This enables checking-in "work in progress" without impacting other developers, allows for partial features being developed by a number of stories, and only when completed will it be delivered.  A feature branch is accepted prior to merging to the `development` branch enabling selection and exclusion of features. Critical to Git Flow is the feature branch naming, and experience has shown using either the story identifier or a feature name and the story identifier to be very effective.

The Git Flow strengths are:
- `Master` branch can be released in a very short time.
- The selective choice of the changes that become part of the planned delivery.
- Handles development teams with high contention within the code base.
- Provides a process that can be defined quality gates like code reviews.
- Acceptance failures are resolved in the Feature branch and does not contaminate the `development` or `master` branch.

The downside:
- Accepting a code change there can be merge conflicts and
the person accepting the changes might be able to resolve those conflicts.  
- Project refactoring can cause complex merge conflicts.
- If not actively accepting changes the developer's knowledge of the change may diminish with the passage of time.
- Requires more Cloud Foundry Spaces.

Git Flow requires at least twice the cloud foundry resources since there is the development space and at least one acceptance
space.  However, practice has determined that a minimum of two acceptance spaces are needed if there is any measurable amount
of time and effort involved with building and deploying a feature branch for acceptance.
Git Flow demands that the build and deployment process are fully automated since to accept a Story requires:
1. Pull the feature branch from GitHub
1. Build the code
1. Deploy the code and initialize a clean Cloud Foundry Acceptance Space.
1. Validate the change.
1. if the change validates then merge the feature branch into the `development` branch
1. Destroy the Cloud Foundry Acceptance Space used for this Feature test.
1. Automated CI/CD should deploy the `development` branch.

If building and deploying the feature branch for acceptance is time consuming then more spaces might help:
1. First feature branch can be built and deployed for acceptance.
1. Second the feature branch can be in the process to build and deploy while the First feature branch is being validated.
1. After finished with the first feature branch then the Cloud Foundry Acceptance space can be destroyed and initialized 
for the next feature branch validation.

Experience has found that Git Flow if effective for projects in maintenance or controlled feature inclusion.

## 3. Commit to Master
This Git Workflow is as the name suggests commiting changes to the `master` branch.
The `master` branch contains all the code and may include code that has not be validated. 
Feature branch similar to Git Flow can be used for work in progress and should be short lived and eventually merged 
into the `master` branch.  These feature branches should be deleted when abandoned or merged to master.

CAB used the `Commit to Master` Git workflow because these factors:
1. CAB was decomposed into services to reduce the developer contention.
1. Developers were not likely to have merge conflicts and when merge conflicts occurred the developer was
able to determine the resolution prior to pushing to `master`.
1. CAB did not have an active acceptance cycle and stories where delivered that might not be verified for a few days.
1. CAB accepted the risks that `master` might not be ready for release until the stories are verified.  However, if a
release was needed then a commit could be chosen as the point when all the stories had been verified without cherry picking.

Basic workflow:
1. Developer pulls from master to their local workspace.
1. Developer create the changes needed for the story.
1. Developer validate the changes in their local workspaces as much as possible.
1. Developer pushes the change to the GitHub repository and if there are conflicts then the push is rejected and the 
developer can rebase from master and resolve the conflicts.

Down sides:
- Acceptance failures are part of the `master` branch and `master` is not
in a state to be released until that failure is corrected.  
- Acceptance might not be as clear cut.
    For example story A creates a REST endpoint with canned response. 
    Then story B replaces
    the canned response with actual data. The Acceptance for Story A might fail because story B has also been delivered, the
    acceptance would have to look at the other stories that have been delivered for the same feature and make a determination
    if story A should be accepted.

# Conclusion
Both `Commit to master` and `Git Flow` use the same standard Git commands. It is the process of the workflow that determines how the Git commands are used.

Decision Points (Git Flow vs. Commit to Master):
1. Are developers pairing?
    * yes - use either since pairing provides code reviews.
    * no - use 'Git Flow' and add a code review step in the process of acceptance.
1. High acceptance failure rate?
    * yes - use 'Git Flow' since failures can be isolated to the feature branch and not contaminate the `master` branch. Also get to the root cause of the failures and improve the process, tools or training.
    * no - use either.
1. High contention between developer teams in the code base?
    * yes - use 'Git Flow' or re-architect to minimize the contention.
    * no - use either.
1. Limited cloud foundry spaces?
    * yes - use 'Commit to Master' since only need a single Development space
    * no - use either but 'Git Flow' will need at least 2 spaces.
1. Do you need to selectively choose changes that will be released?
    * yes - use `Git Flow`
    * no - use either.
