# GitHub Flow Process

This Guide documents the GitHub Flow process, which is the process in use internally by the Dev Enablement team. Teams are free to choose the workflow that best meets their needs. There are numerous sites documenting [Git Workflows](https://www.google.com/search?q=Git+Workflows), so I encourage you to do your research and find the best fit for yout team.


## Our Choice: GitHub Flow

The Dev Enablement team is currently using a workflow called "GitHub Flow". The core idea behind the GitHub Flow is that all feature/bug fix/etc. development should take place in a dedicated branch instead of the master branch. This encapsulation makes it easy for multiple developers to work on a particular feature without disturbing the main codebase. It also means the master branch should never contain broken code, which is a huge advantage for continuous integration environments.

Encapsulating feature development also makes it possible to leverage pull requests, which are a way to initiate discussions around a branch. They give other developers the opportunity to sign off on a feature before it gets integrated into the master branch. Pull requests also provide a mechanism for you to seek feedback or suggestions from your colleagues.

__*Note:*__ For an explanation of the process that the community can use in order to contribute changes (i.e. innersource) to our Dev Enablement repositories, see our [Innersource Process](./InnersourceProcess.md) document.


## GitHub Flow Steps
Assuming you are using a Git Client, and you have repo that is a clone of a GitHub repo, the following steps can be used to make changes to your application in accordance with the GitHub Flow process:

1. **Start with the latest code** that is in your Master branch
```
git checkout master
git fetch origin 
git reset --hard origin/master
```

2. **Create a new branch**
```
git checkout -b my-new-feature
```

3. **Make changes** (Add, Update, Delete source code files) and commit them to local git
```
git status
git add .
git commit -m "some meaningful comment"
```

4. **Push the changes** and new Feature branch to GitHub
```
git push -u origin my-new-feature
```

5. Use GitHub UI to **open a new pull request** on your recently pushed pull request. This is done by selecting your branch, and clicking the "New Pull Request" button. 

6. **Review the changes**. During this step, 1 or more poeple from your team can provide feedback regarding the pull request directly in the GitHub UI. We in Dev Enablement use this as our code review that we require for all our changes.

6. **Squash & Merge** the Pull Request. This option is alos availble in the GitHub UI. This step results in the 1 or more commits that were made to the feature branch, now being combined into a single commit that will be added to the master branch. Your code has now been reviewed and merged into master, and can now be deployed!

>**Note:** Many teams, including ours, has a Jenkins pipeline that will automatically deploy changes to the master branch to our Dev Environment. This means that the "Squash and Merge" step will automatically cause all the code in Master to be built and deployed. Our pipeline is also engineered such that commits to feature branches are automaiclly built and tested in Jenkins, but not deployed until they are meged into master. See our [Jenkins Pipeline guide](/pipeline-jenkins/README.md) for more details.   


## References

- [Git Cheat Sheet](https://github.github.com/training-kit/downloads/github-git-cheat-sheet.pdf)
- [GitHub Flow](https://guides.github.com/introduction/flow/)
- [Atlassian's Git Feature Branch Workflow](https://www.atlassian.com/git/tutorials/comparing-workflows/feature-branch-workflow)
