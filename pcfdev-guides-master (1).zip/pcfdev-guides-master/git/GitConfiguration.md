# Git Client & GitHub Configuration

This document details how to configure your local git client as well as your GitHub account such that you can effectively use Ford's GitHub to manage your project's source code.

## Configure the Git Client
These commands will setup some default values needed by the git client. They will result in the settings being stored in your user home's `.gitconfig` file.
Execute the following commands (after swapping in your name and email address) using your workstation's command line (mac command line or Git BASH in windows).

```
git config --global user.name "Your Name"
git config --global user.email cdsid@ford.com
git config --global http.proxy http://internet.ford.com:83
git config --global https.proxy https://internet.ford.com:83
git config --global color.ui true
```

## Verify GitHub Access

1. Go to Ford's GitHub at [https://github.ford.com/](https://github.ford.com/)
2. If you do not have access, follow the instructions [here](http://wiki.ford.com/display/SDE/Get+Started+in+GitHub) for registering for access.


## Create an SSH key for client access to GitHub



1. Using command line, search for existence of existing public key
```
ls ~/.ssh
```

2. if “id_rsa.pub” is displayed, skip the “Generate new SSH key” step

3. Generate a new SSH key using following command

```
ssh-keygen -t rsa -b 4096 -C "yourcds@ford.com"
```

Note:
- When prompted to enter a file, just press Enter
- The passphrase can be empty. For our purposes, tssh-keygen -t rsa -b 4096 -C "sgovin37@ford.com"hat is acceptable.


4. Add the SSH key to the ssh-agent by executing the following 2 commands from the command line.

```
eval "$(ssh-agent -s)"
ssh-add ~/.ssh/id_rsa
```

5. Copy he public key to the clipboard so it can be pasted into GitHub in the next section
- on windows/git bash
```
clip < ~/.ssh/id_rsa.pub
```
- on mac/unix
```
pbcopy < ~/.ssh/id_rsa.pub
```

## Add the public key to GitHub

1. Open the “SSH and GPG keys” settings page for your profile at [https://github.ford.com/settings/keys](https://github.ford.com/settings/keys).

2. Click the “New SSH key” button

3. Add a title into the Title field. i.e. "My Laptop SSH key"

4. Paste the public key you added to clipboard in previous section, into the Key text field.

5. Click the Green “Add SSH key” button to save the SSH key.


## Verify your SSH key

Go back to your Git client (command line), and test your SSH access to GitHub.

1. Verify in Git Bash using following command. You should get a message that includes your CDS ID. i.e. such as _"Hi thall6! You've successfully authenticated, but GitHub does not provide shell access."_

```
ssh –T git@github.ford.com
```


2. You can further verify by cloning a repo from GitHub. An example clone command for our publicly available CAB Reference App is below:
```
git clone git@github.ford.com:PCFDev-CAB/cab-service-fordair.git
```
