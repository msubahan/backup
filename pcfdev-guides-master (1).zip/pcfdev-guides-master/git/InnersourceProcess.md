# Dev Enablement Innersource strategy with GitHub

This document will explain how members of the Ford community can participate in [innersource](https://resources.github.com/whitepapers/introduction-to-innersource/) software development with respect to the numerous software repositories that are maintained by the Dev Enablement team. This will allow great idea's as well as implementations to be contributed to our repositories directly by members of the community follow the processes documented below.

## Contribute by Creating an Issue
Issues can be used for enhancements requests and reporting bugs in the case that you can not provide an implementation.
1. From any public repo in the DevEnablement GitHub organization, click on the 'Issues' tab.
1. On the 'Issues' tab click "New Issue"
1. The title should start with "Enhancement - " or "Bug - " followed by a short description, like: "Enhancement - create the RPM Module"
1. Use the 'Write' and 'Preview' tabs to create the issue, for example:
    ```
    It would be ideal if there was a RPM(Read Programmer's Mind) module.
    This module would do what the programmer intended versus the actual logic in the code.
    ```
1. Monitor your email for updates or periodically check the Issue to respond to any questions.

## Contribute by Submitting a Pull Request
If you have a proposed correction then submit a pull request to the master branch by following these steps:
1. Fork Master Branch from any public repo in the DevEnablement GitHub organization
1. **Make sure to keep forked repo within Ford GitHub**
1. Create new branch on your forked repo
1. Make all changes against your new branch on your repo
1. Add unit tests for new functionality or bug fixes
1. Run tests and make sure they pass
1. Commit changes to your branch
1. On GitHub, [open a pull request (PR)](https://help.github.com/articles/creating-a-pull-request-from-a-fork/) from your branch to the master branch of this repo
    - Add PR comment in the following format:
    ```
	  Problem Solved: (N/A if none)
    Feature Added: (N/A if none)
	  Summary of Changes:
   ```
   - **note** - *PRs that do not include an adequate comment will be rejected.*
1. Monitor your email for updates or periodically check the opened PR to respond to any questions.
1. For future PRs, make sure to [sync with upstream](https://help.github.com/articles/syncing-a-fork/) <br /> OR it might be easier to delete fork repo and repeat this process from the beginning.

## Approval Process
**This is the approval process followed by the Dev Enablement Team. 
Teams looking for a Git issues and pull request approval process can follow this or develop their own. 
We are following an Agile process and are using a Backlog to manage all work within the Dev Enablement team.**

1. During pre-IPM grooming, anchor looks at new issues and open pull requests and either adds a story to the backlog to review OR they reject the Issue/PR

1. Assuming a story was added to the Dev Enablement Backlog, the story added to the backlog will have:
	- A link to Issue/PR
  	- For a PR:
    	- determine if requires pair or can be reviewed and merged solo
    	- Add 'Under Review' label to PR in GitHub
  	- Can reject an Issue/PR if does not have comments or does not seem valuable
  
1. Once in the backlog, the team will follow normal procedure to pick up the story

1. When reviewing the Issue/PR on GitHub, the team has two options:
	- Close the Issue with comments OR Reject PR with comments
    - Approve (add comments as needed)
    - Do not use the Request Changes functionality
   
1. For PR, Squash and Merge the PR

1. If reviewer later rejects the PR, make a comment in the Tracker story and close the story