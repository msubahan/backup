# Git Guides

### General Git documentation

- [Request GitHub Access](http://x.ford.com/dev-github) - Access to Ford GitHub requires registration (this is a link to the SDE team wiki)

- [Git Configuration](./GitConfiguration.md) - Instructions for initial Setup of your Git client with your Ford GitHub account.

- [Innersource Process](./InnersourceProcess.md) - Process by which the community can contribute code or idea's to the Dev Enablement team's public repo's.


### Git/GitHub Workflow options

- [GitHub Flow Workflow](./GitHubFlow.md) - Details the Git Workflow that Dev Enablement team uses for their day to day work. Feature branch based, where code is added to master from pull requests in GitHub.

- [Gitflow Workflow](./GitFlow.md) - Details a common branching strategy used by many teams where features are add to a devleopment branch prior to going to master.

>**Note:** Both of the Workflow's above are supported by our [Jenkins pipeline] offering. Our pipeline will can be configured such that deployments only occur when a specific branch is used. It is configured such that commits to feature branches are built and tested, but not deployed.
