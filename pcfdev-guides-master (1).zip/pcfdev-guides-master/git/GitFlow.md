## Gitflow Branching approach

The below branching structure is recommended for application teams that need to manage a multi-branch GitHub repository for their project. 
The recommended structure can be suitable for most of the project teams and can be scaled for additional environments/branches as per the needs.

![Multi-branch Structure](./img/multi-branch-structure.PNG)

where,
 
|||
|-------|-------|
|![](./img/env_light.PNG)|Denotes a lower environment in a branch that builds the code, performs quality checks, publishes the built artifact to Nexus (if enabled) and deploys the project.|
|![](./img/env_dark.PNG)|Denotes a higher environment in the same branch that can skip the build and quality check steps, and can download the latest published artifact for the branch from Nexus (if enabled) to deploy the project.|

In order to perform CI/CD to different environments, project teams can use the pipeline template [Jenkinsfile_N](/pipeline-jenkins/README.md#3-update-jenkinsfile_n) and customize it as required.


#### Further Reading

The Gitflow apporach is also documented on the Atlassian site at [https://www.atlassian.com/git/tutorials/comparing-workflows/gitflow-workflow](https://www.atlassian.com/git/tutorials/comparing-workflows/gitflow-workflow).
