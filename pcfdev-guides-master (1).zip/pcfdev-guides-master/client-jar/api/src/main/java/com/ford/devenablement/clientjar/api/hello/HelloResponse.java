package com.ford.devenablement.clientjar.api.hello;

import com.ford.cloudnative.base.api.BaseBodyResponse;
import com.ford.devenablement.clientjar.api.hello.HelloResponse.HelloResponseResult;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

public class HelloResponse extends BaseBodyResponse<HelloResponseResult> {

	@Data
	@Builder
	@NoArgsConstructor
	@AllArgsConstructor
	public static class HelloResponseResult {
		String greeting;
	}

}
