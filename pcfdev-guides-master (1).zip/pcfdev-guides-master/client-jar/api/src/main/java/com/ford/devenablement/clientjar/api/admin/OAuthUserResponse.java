package com.ford.devenablement.clientjar.api.admin;

import java.util.Collection;

import com.ford.cloudnative.base.api.BaseBodyResponse;
import com.ford.devenablement.clientjar.api.admin.OAuthUserResponse.OAuthUserResponseResult;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.Singular;

public class OAuthUserResponse extends BaseBodyResponse<OAuthUserResponseResult> {

	@Data
	@NoArgsConstructor
	@AllArgsConstructor
	@Builder
	public static class OAuthUserResponseResult {
		String clientId;
		Collection<String> scopes;
	}

}
