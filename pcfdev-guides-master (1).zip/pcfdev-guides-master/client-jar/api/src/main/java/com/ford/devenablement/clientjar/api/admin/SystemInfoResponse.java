package com.ford.devenablement.clientjar.api.admin;

import com.ford.cloudnative.base.api.BaseBodyResponse;
import com.ford.devenablement.clientjar.api.admin.SystemInfoResponse.SystemInfoResponseResult;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

public class SystemInfoResponse extends BaseBodyResponse<SystemInfoResponseResult> {

	@Data
	@NoArgsConstructor
	@AllArgsConstructor
	@Builder
	public static class SystemInfoResponseResult {
		String javaVersion;
	}

}
