package com.ford.devenablement.clientjar.app.admin;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.Arrays;
import java.util.HashSet;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.security.oauth2.provider.OAuth2Authentication;
import org.springframework.security.oauth2.provider.OAuth2Request;

import com.ford.devenablement.clientjar.api.admin.OAuthUserResponse;
import com.ford.devenablement.clientjar.api.admin.OAuthUserResponse.OAuthUserResponseResult;
import com.ford.devenablement.clientjar.api.admin.SystemInfoResponse;
import com.ford.devenablement.clientjar.api.admin.SystemInfoResponse.SystemInfoResponseResult;

@RunWith(MockitoJUnitRunner.class)
public class AdminControllerTest {

	AdminController adminController;

	@Before
	public void setup() {
		adminController = new AdminController();
	}

	@Test
	public void testMe() throws Exception {
		OAuth2Authentication authentication = mock(OAuth2Authentication.class);
		OAuth2Request oauth2Request = new OAuth2Request(null, "CLIENT-ID", null, false, new HashSet<>(Arrays.asList("SCOPE-1")), null, null, null, null);
		when(authentication.getOAuth2Request()).thenReturn(oauth2Request);

		OAuthUserResponse response = adminController.me(authentication);

		assertThat(response.getError()).isNull();

		OAuthUserResponseResult result = response.getResult();
		assertThat(result).isNotNull();
		assertThat(result.getClientId()).contains("CLIENT-ID");
		assertThat(result.getScopes()).contains("SCOPE-1");
	}

	@Test
	public void testSystemInfo() throws Exception {
		SystemInfoResponse response = adminController.systemInfo();

		assertThat(response.getError()).isNull();

		SystemInfoResponseResult result = response.getResult();
		assertThat(result).isNotNull();
		assertThat(result.getJavaVersion()).isEqualTo(System.getProperty("java.version"));
	}
}
