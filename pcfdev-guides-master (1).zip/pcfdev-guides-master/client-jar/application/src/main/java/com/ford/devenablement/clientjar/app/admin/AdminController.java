package com.ford.devenablement.clientjar.app.admin;

import org.springframework.http.MediaType;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.security.oauth2.provider.OAuth2Authentication;
import org.springframework.security.oauth2.provider.OAuth2Request;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ford.devenablement.clientjar.api.admin.OAuthUserResponse;
import com.ford.devenablement.clientjar.api.admin.OAuthUserResponse.OAuthUserResponseResult;
import com.ford.devenablement.clientjar.api.admin.SystemInfoResponse;
import com.ford.devenablement.clientjar.api.admin.SystemInfoResponse.SystemInfoResponseResult;

import io.swagger.annotations.ApiOperation;

@RestController
@RequestMapping(path = "/api/v1/admin", produces = MediaType.APPLICATION_JSON_VALUE)
public class AdminController {
	
	@ApiOperation(value = "Get Current Authenticated User Info (OAuth2 Protected)", notes = "Returns user-protected info")
    @GetMapping(value = "/me")
	public OAuthUserResponse me(Authentication authentication) {
    	OAuth2Request oAuth2Request = ((OAuth2Authentication)authentication).getOAuth2Request();
		
    	OAuthUserResponseResult result = OAuthUserResponseResult.builder()
    			.clientId(oAuth2Request.getClientId())
    			.scopes(oAuth2Request.getScope())
    			.build();
    	
		return OAuthUserResponse.result(result, OAuthUserResponse.class);
	}
    
    @ApiOperation(value = "Get System Info")
    @PreAuthorize("#oauth2.hasScope('pcfdev-services.application-profiles')")
    @GetMapping(value = "/system")
	public SystemInfoResponse systemInfo() {
    	SystemInfoResponseResult result = SystemInfoResponseResult.builder()
    			.javaVersion(System.getProperty("java.version"))
    			.build();
    	
		return SystemInfoResponse.result(result, SystemInfoResponse.class);
	}

}
