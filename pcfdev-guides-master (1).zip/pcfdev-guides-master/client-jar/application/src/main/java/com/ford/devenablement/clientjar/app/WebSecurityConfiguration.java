package com.ford.devenablement.clientjar.app;

import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.oauth2.config.annotation.web.configuration.EnableResourceServer;
import org.springframework.security.oauth2.config.annotation.web.configuration.ResourceServerConfigurerAdapter;
import org.springframework.security.oauth2.config.annotation.web.configurers.ResourceServerSecurityConfigurer;

@EnableResourceServer
@EnableWebSecurity
@EnableGlobalMethodSecurity(prePostEnabled = true)
public class WebSecurityConfiguration {

	@Configuration
	public static class OAuth2SecurityConfiguration extends ResourceServerConfigurerAdapter {
		@Override
		public void configure(ResourceServerSecurityConfigurer resources) throws Exception {
			resources.resourceId("pcfdev-services");
		}

		@Override
		public void configure(HttpSecurity http) throws Exception {
			http
			.requestMatcher( request -> {
				return request.getServletPath().startsWith("/api/");
			})
			.csrf()
				.disable()
			.authorizeRequests()
				.antMatchers("/api/v1/hello/**").permitAll()
				.anyRequest().access("#oauth2.isClient() and #oauth2.hasScope('pcfdev-services.access')");
		}
	}

	@Configuration
	public static class HttpSecurityConfiguration extends WebSecurityConfigurerAdapter {
		@Override
		protected void configure(HttpSecurity http) throws Exception {
			http
			.csrf()
				.disable()
			.authorizeRequests()
				.antMatchers("/swagger-ui.html", "/swagger-resources/**", "/webjars/**", "/v2/api-docs").permitAll()
				.anyRequest().authenticated()
				.and()
			.httpBasic();
		}
	}

}
