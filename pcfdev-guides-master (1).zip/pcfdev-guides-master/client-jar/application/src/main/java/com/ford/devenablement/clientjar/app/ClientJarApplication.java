package com.ford.devenablement.clientjar.app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Import;

import com.ford.cloudnative.base.app.workaround.ResolveUserInfoRestTemplateFactoryConfiguration;

@SpringBootApplication
@Import({ResolveUserInfoRestTemplateFactoryConfiguration.class})
public class ClientJarApplication {

	public static void main(String[] args) {
		SpringApplication.run(ClientJarApplication.class, args);
	}

}
