package com.ford.devenablement.clientjar.client.admin;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;

import com.ford.cloudnative.base.client.error.ThrowFeignResponseExceptionConfiguration;
import com.ford.cloudnative.base.client.oauth2.OAuth2ClientCredentialsFeignConfiguration;
import com.ford.devenablement.clientjar.api.admin.OAuthUserResponse;
import com.ford.devenablement.clientjar.api.admin.SystemInfoResponse;

@FeignClient(name = "pcfdev-service-client-jar", path = "/api/v1/admin", configuration = { OAuth2ClientCredentialsFeignConfiguration.class, ThrowFeignResponseExceptionConfiguration.class })
public interface AdminClient {

	@GetMapping(value = "/me")
	public ResponseEntity<OAuthUserResponse> me();

	@GetMapping(value = "/system")
	public ResponseEntity<SystemInfoResponse> systemInfo();

}
