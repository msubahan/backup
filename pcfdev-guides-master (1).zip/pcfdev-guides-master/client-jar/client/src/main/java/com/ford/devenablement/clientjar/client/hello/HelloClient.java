package com.ford.devenablement.clientjar.client.hello;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import com.ford.cloudnative.base.client.error.ThrowFeignResponseExceptionConfiguration;
import com.ford.devenablement.clientjar.api.hello.HelloRequest;
import com.ford.devenablement.clientjar.api.hello.HelloResponse;

@FeignClient(name = "pcfdev-service-client-jar", path="/api/v1/hello", configuration = {ThrowFeignResponseExceptionConfiguration.class})
public interface HelloClient {
	
	@GetMapping
	public ResponseEntity<HelloResponse> hello();

	@PostMapping
	public ResponseEntity<HelloResponse> helloName(HelloRequest helloRequest);
	
}
