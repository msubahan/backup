##  Service Client Jar Guide

This guide demonstrates how to generate a client jar that consumes your service using Feign. Feign is a declarative web service client and it makes writing REST clients easier. All you have to do is create an interface and annotate it with `@FeignClient`. Refer to [Spring's Feign Documentation](https://cloud.spring.io/spring-cloud-netflix/multi/multi_spring-cloud-feign.html) to learn more.

In addition to generating a jar, this guide will show you how to publish and consume this client jar. It will also demonostrate how to configure credentials required during client calls.

##### Why would you want to generate a client jar?

There are various options to consume a service. Often you find teams using Spring's *RestTemplate* class to directly consume a service. This would require teams to find the service's API definition and craft/copy the API model classes into their application. If teams are crafting API models by hand, then it would be prone to errors. Furthermore, in a micro-services architecture, when you have a common service (e.g. authentication, config) that is consumed by a lot of your other services, the API models for the common service will be duplicated across many services breaking the *DRY* (don't repeat yourself) principle and the task of syncing/updating the API models would be tedious.

An alternative option would be a published client jar that is capable of consuming your service. This client jar would encapsulate the API models and all of the logic to consume your service &mdash; removing the burden on the application caller. Consuming applications would only have to pull in the client jar as a dependency and they would have at their disposal all of the service's functionality via simple client-jar interfaces. As long as the service adheres to backwards compatibility, the application caller can still rely on older client-jars to consume the service. When the service updates and the application caller requires access to the new updates, then all that is required by the application caller is to update the client-jar version only.

You may ask then why do we not find a lot of teams generating client jars? One main reason is because it is not easy to generate and maintain client jars. The overhead of keeping client jars in sync with the API models and published may not be worth the efforts spent. This is now no longer the case with *Feign* and our *Multi-Project Structure* setup.

<br/>

### Implementation

As recommended by the [Multi-Project Structure](../base-service-multi) guideline, we divide the project into multiple components. Generating a client for your service would be a separate concern and thus we would dedicate a separate *client* component to handle the generation of the client.

<pre>
api/
application/
<strong>client/</strong>
</pre>

Because `client/` is its own component, it has its own source folder structure. Inside its source folder structure you would only find simple Java interface classes annotated with `@FeignClient` &mdash; more on this later.

<br/>

### Build Script

Take a look at the client [build.gradle](client/build.gradle) for a complete list of dependencies. You will find these notable dependencies:

<table>
<tr>
  <td nowrap>org.springframework.cloud:spring-cloud-starter-openfeign</td>
  <td>Pulls in Feign &mdash; declarative client developed by Netflix</td>
</tr>
<tr>
  <td>project(':api')</td>
  <td>Pulls in the <em>api</em> component as a dependency</td>
</tr>
<tr><td>com.ford.cloudnative:spring-base-client</td>
<td>CloudNative Spring dependencies to help us configure Feign clients further; e.g. credentials, exception handling</td>
</tr>
</table>
    
The project relies on [Common-Build-Deploy](https://github.ford.com/PCFDev-Reference/template-common-build-deploy) scripts for building the projects. The module `publish` was included as part of configuring the *client* build script which will handle the publishing of our client jar. Every time the service project gets built and published, both the *application* and *client* components would we built and published. A client jar, therefore, would be generated for each time the *application* gets built &mdash; both marked with the same version.

<br/>

### Feign Interfaces

In this guide project, we have two controllers [HelloController](application/src/main/java/com/ford/devenablement/clientjar/app/hello/HelloController.java) and [AdminController](application/src/main/java/com/ford/devenablement/clientjar/app/admin/AdminController.java). Each controller defines endpoint(s) which this service implements and exposes. The goal is write a client jar that knows how to consume these endpoints.

The client jar relies on Feign to drive client generation. Feign is a declarative client which means is that you only need to describe the API endpoint (input/output) and Feign will take care of the rest for you. With Feign, you describe API endpoints using simple Java interfaces annotated with `@FeignClient`.

Similarly, it is expected that in Spring MVC controller classes you describe API endpoints; namely with individual controller methods annotated with one of the `@*Mapping` annotations that describe the input/output thru their method signatures.

Because of this correlation, it is becomes very easy to come up with the `@FeignClient` interface. You would create a `@FeignClient` interface and copy the controller method signatures into it and make the following changes (if necessary):

- Remove any request parameters other than the API request model.
- Remove all annotations on the method or request parameter expect for the `@*Mapping` annotation.
- *Recommended:* wrap the return result with `ResponseEntity` (if not done so already).

For example, *HelloController* is defined as:

```java
@RestController
@RequestMapping(path = "/api/v1/hello")
public class HelloController {

	@ApiOperation(value = "Hello Message", notes = "Returns a hello greeting")
	@GetMapping
	public HelloResponse hello() { ... }

	@ApiOperation(value = "Customized Hello Message", notes = "Returns hello greeting with your name")
	@PostMapping
	public HelloResponse helloName(@RequestBody @Valid HelloRequest helloRequest) { ... }

}
```

Therefore the Feign client equivalent should look like this:

```java
@FeignClient(name = "devenablement-service-client-jar", path="/api/v1/hello", configuration = {ThrowFeignResponseExceptionConfiguration.class})
public interface HelloClient {
	
	@GetMapping
	public ResponseEntity<HelloResponse> hello();

	@PostMapping
	public ResponseEntity<HelloResponse> helloName(HelloRequest helloRequest);
	
}
```

Notice how all we needed to do is copy the controller methods, strip out the annotations, and wrap the result with `ResponseEntity`.

As for the `@FeignClient` annotation, its defined with properties and values. *name* should the application's service name, *path* matches the controller's endpoint path, and the *configuration* customizes how the Feign client behaves. Particular, *ThrowFeignResponseExceptionConfiguration* configuration class will throw the a `FeignResponseException` class (which encapsulates the response body) in the event a non-200 OK response is encountered.

Similarly, you can easily generate the Feign client for *AdminController* using the same approach. *AdminClient* `@FeignClient`, however, is annotated with *OAuth2ClientCredentialsFeignConfiguration* configuration class also because OAuth2 credentials is required to consume the *AdminController* endpoints. By adding *OAuth2ClientCredentialsFeignConfiguration* configuration class, Feign client will automatically obtain a valid OAuth2 token based on credentials defined by the `cn.client.feign.[feign-client-name].oauth2.*` properties.

<br/>

### Consume Service (using client jar)

The application consuming the service must first pull in the published client jar as a dependency. Typically the dependency name would be in the format [service_name]-client. *NOTE: This project's service name is client-jar*.

```
implementation 'com.ford.devenablement:client-jar-client'
```

Once the published client jar is pulled in, we would have access to the `@FeignClient` interfaces. We need to generate concrete feign client implementations base off these interfaces for us to directly use. You have two options here:

##### Option 1 - Creating Feign Clients Manually

You can generate Feign clients from the interfaces using `Feign.builder()` as described here in [Spring's Feign Documentation section](https://cloud.spring.io/spring-cloud-netflix/multi/multi_spring-cloud-feign.html#_creating_feign_clients_manually). With Feign builder, you have full control to configure your Feign client's encoder, decoder, URL, credentials and more.

##### Option 2 - Let Spring Handle it for you

You annotate your application caller with `@EnableFeignClients` which signals Spring to handle the generation and registration of your `@FeignClient`s. You access Feign client implementations via `@Autowired` as described by the Spring documentation [found here](https://cloud.spring.io/spring-cloud-netflix/multi/multi_spring-cloud-feign.html#netflix-feign-starter). NOTE: In our `@FeignClient` interface examples, we only annotated the *name* attribute and not *url*. We assume that both the service and appliation caller are registered with the same service registry (i.e. Eureka server) and we would fallback on Feign's Eureka support to lookup the service by name and configure the Feign client's URL.

<br/>

NOTE: If your Feign client is configured with the *OAuth2ClientCredentialsFeignConfiguration* configuration class, then you must define OAuth2 credentials via `cn.client.feign.[fiegn-client-name].oauth2.*` properties.
