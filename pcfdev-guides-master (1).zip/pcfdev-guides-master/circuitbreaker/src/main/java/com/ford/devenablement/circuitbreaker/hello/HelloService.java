package com.ford.devenablement.circuitbreaker.hello;

import io.github.resilience4j.circuitbreaker.CircuitBreaker;
import io.github.resilience4j.retry.Retry;
import io.github.resilience4j.retry.RetryConfig;
import io.vavr.control.Try;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.net.URI;
import java.util.function.Supplier;

@Slf4j
@Service
public class HelloService {

    private static final String LOCAL_URI = "http://localhost:8089/api/v1/hello";
    private static final String REMOTE_URI = "https://devenablement-hello-intermittent-error-dev.apps.pp01i.edc1.cf.ford.com/api/v1/hello";

    private final RestTemplate restTemplate;

    private final CircuitBreaker circuitBreaker;

    @Autowired
    public HelloService(RestTemplate restTemplate, CircuitBreaker circuitBreaker) {
        this.restTemplate = restTemplate;
        this.circuitBreaker = circuitBreaker;
    }


    public String remoteCall() {

        log.warn("Attempt to make a remote call");
        var uri = URI.create(REMOTE_URI);

        var restReponse = restTemplate.getForObject(uri, String.class);

        return restReponse;

    }


    public String remoteCallFallback() {
        log.warn("We had to give a fallback response");
        return "this is a fallback response";
    }


    public String remoteServiceCallWithCircuitBreaker() {
        log.warn("Circuit Breaker status --> " + circuitBreaker.getState());

        Supplier<String> fetchHelloResponse = () -> this.remoteCall();

        // it will prevent all calls to original fetchTargetPicture in case of UserService failure
        fetchHelloResponse = CircuitBreaker.decorateSupplier(circuitBreaker, fetchHelloResponse);

        //Setup a retry
        var retryConfig = RetryConfig.custom().maxAttempts(2).build();
        var retry = Retry.of("this", retryConfig);
        fetchHelloResponse = Retry.decorateSupplier(retry, fetchHelloResponse);

        // Attempt call with CB and Retry in place; and a fallback in place
        return Try.ofSupplier(fetchHelloResponse).recover(throwable -> this.remoteCallFallback()).get();
    }

}
