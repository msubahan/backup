package com.ford.devenablement.circuitbreaker.hello;

import com.ford.devenablement.circuitbreaker.hello.api.HelloResponse;
import com.ford.devenablement.circuitbreaker.hello.api.HelloResponse.HelloResponseResult;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@Slf4j
@RestController
@RequestMapping(path = "/api/v1/hello")
public class HelloController {

    private HelloService helloService;


    @Autowired
    public HelloController(HelloService helloService) {
        this.helloService = helloService;
    }


    @ApiOperation(value = "Hello Message", notes = "Returns a hello greeting using remote service")
    @GetMapping
    public HelloResponse hello() {

        var remoteHelloResponse = helloService.remoteServiceCallWithCircuitBreaker();

        var result = HelloResponseResult.builder().greeting(remoteHelloResponse).build();

        return HelloResponse.result(result, HelloResponse.class);
    }


}
