package com.ford.devenablement.circuitbreaker;

import io.github.resilience4j.circuitbreaker.CircuitBreaker;
import io.github.resilience4j.circuitbreaker.CircuitBreakerConfig;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import java.io.IOException;
import java.time.Duration;
import java.util.concurrent.TimeoutException;

@Component
public class ApplicationConfiguration {


    @Bean
    public RestTemplate rest(RestTemplateBuilder builder) {
        return builder.build();
    }


    /**
     * This example configuration should be altered to meet your specific needs. Please read the Resilience4J class
     * documentation to understand the settings shown below.
     * <p>
     * This configuration defined below will:
     * - open a circuit once failure exceed 15% rate and will hold in the open state for 1 second
     * - will evaluate at least 4 requests before determining if circuit breaker belongs in closed state
     * - only record failure when encountering RestClientException, IOException, or TimeoutException
     * - ignore Illegal State Exceptions
     */
    @Bean
    public CircuitBreakerConfig circuitBreakerConfig() {
        return CircuitBreakerConfig.custom()
                .failureRateThreshold(15)
                .waitDurationInOpenState(Duration.ofSeconds(1))
                .ringBufferSizeInClosedState(4)
                .recordExceptions(RestClientException.class, IOException.class, TimeoutException.class)
                .ignoreExceptions(IllegalStateException.class)
                .build();
    }


    @Bean
    public CircuitBreaker circuitBreaker(CircuitBreakerConfig circuitBreakerConfig) {
        return CircuitBreaker.of("default", circuitBreakerConfig);
    }

}
