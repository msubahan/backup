package com.ford.devenablement.circuitbreaker.hello;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ford.cloudnative.base.app.web.exception.handler.ExceptionHandlerConfiguration;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Import;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.ResultActions;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultHandlers;
import org.springframework.web.servlet.mvc.method.annotation.RequestMappingHandlerAdapter;

import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@RunWith(SpringRunner.class)
@WebMvcTest(controllers = {HelloController.class})
@Import(ExceptionHandlerConfiguration.class)
public class HelloControllerIntegrationTest {

    @Rule
    public ExpectedException exception = ExpectedException.none();

    @Autowired
    MockMvc mockMvc;

    @Autowired
    ObjectMapper objectMapper;

    @MockBean
    private HelloService helloService;

    @Autowired
    RequestMappingHandlerAdapter adapter;

    /***********************************************************************************************
     * ENDPOINT: GET /api/v1/hello
     ***********************************************************************************************/

    @Test
    public void should_return200ReponseWithFieldsPopulated_forHelloGreetingsEndpoint() throws Exception {

        when(helloService.remoteServiceCallWithCircuitBreaker()).thenReturn("this is a fallback response");

        jsonGet("/api/v1/hello")
                .andExpect(status().isOk())
                // controller unit tests test completeness of response object; we only smoke test here that a JSON response is returned
                .andExpect(jsonPath("$.result.greeting").value("this is a fallback response"));

        verify(helloService).remoteServiceCallWithCircuitBreaker();

    }


    //////////////////// Helper Methods

    ResultActions jsonGet(String url) throws Exception {
        return this.mockMvc.perform(MockMvcRequestBuilders.get(url))
                .andDo(MockMvcResultHandlers.print());
    }

    ResultActions jsonPost(String url, Object entity) throws Exception {
        return
                this.mockMvc.perform(MockMvcRequestBuilders
                        .post(url)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(entity))
                )
                        .andDo(MockMvcResultHandlers.print());
    }
}