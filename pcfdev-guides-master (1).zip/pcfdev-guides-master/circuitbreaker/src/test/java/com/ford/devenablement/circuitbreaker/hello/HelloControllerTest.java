package com.ford.devenablement.circuitbreaker.hello;

import com.ford.devenablement.circuitbreaker.hello.api.HelloResponse;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class HelloControllerTest {

    HelloController helloController;

    @Mock
    private HelloService helloService;


    @Before
    public void setup() {
        helloController = new HelloController(helloService);
    }

    @Test
    public void testHello() throws Exception {

        String EXPECTED_RESPONSE = "this is a fallback response";

        when(helloService.remoteServiceCallWithCircuitBreaker()).thenReturn(EXPECTED_RESPONSE);

        HelloResponse response = helloController.hello();

        assertThat(response.getError()).isNull();
        assertThat(response.getResult()).isNotNull();

        String greeting = response.getResult().getGreeting();
        assertThat(greeting).isEqualTo(EXPECTED_RESPONSE);
    }
}
