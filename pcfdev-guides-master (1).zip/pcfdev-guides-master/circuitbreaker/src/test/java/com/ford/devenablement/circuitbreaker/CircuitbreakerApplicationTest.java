package com.ford.devenablement.circuitbreaker;


import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class CircuitbreakerApplicationTest {
    @Test
    public void contextLoads() {
    }
}