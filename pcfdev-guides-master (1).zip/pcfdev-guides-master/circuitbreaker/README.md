# Circuit Breaker using Resilience4j library

## Purpose
This app is demonstration of the ability to use the Resilience4J library as a Circuit Breaker and Retry library for the purpose of added resiliency to distributed systems. 

The fact that Netflix Hystrix is going into maintenance mode has necessitated the need to seek other offerings, and the Resilience4J library came [recommended by Pivotal](https://spring.io/blog/2019/01/23/spring-cloud-greenwich-release-is-now-available#replacements).

The Resilience4J library has some very useful documentation. See [https://resilience4j.readme.io/docs/getting-started](https://resilience4j.readme.io/docs/getting-started) for a deep understanding of all their features, since this guide focuses on the use of only thier CircuitBreaker capability.

For additional understanding of the Circuit Breaker pattern, see the following resources:
* [Martin Fowler Circuit Breaker blog](https://martinfowler.com/bliki/CircuitBreaker.html)
* [Microservices.io site](https://microservices.io/patterns/reliability/circuit-breaker.html)
* [Tech Blog](https://techblog.constantcontact.com/software-development/circuit-breakers-and-microservices/) with details on Circuit Breaker States

> **Note:** This guide requires JDK Java 11 or higher. See our [Java 11 guide](https://github.ford.com/DevEnablement/pcfdev-guides/blob/v1.0/migrations/Java-11.md#workstation-setup) for details on Java 11 and how to get it on your workstation.

## Usage
If running locally, hit http://localhost:8080/api/v1/hello which will in turn call a remote service. This remote service call is wrapped with Circuit Breaker and Retry logic provided by the Resilience4J library. 
The remote call may need to be altered in order to get failures to occur. I have created an app that allows failure rates to be configured. See https://github.ford.com/thall6/devenablement-service-hello-intermittent-error.

## Setup
The following steps were needed after creating a brand new Spring Boot App using using the EcoBoost SpringBoot app generator in [/dev.central/station/](http://dcs.ford.com). The base app included only a simple REST controller. 
1. Add resilience4j Spring Boot 2 library to build.gradle. This will pull in the Circuit Breaker, Retry, Rate Limiter, and other libraries from the Resilience4J suite.`
   ```implementation 'io.github.resilience4j:resilience4j-spring-boot2:0.17.0'```
> Note: The version reference above was the version available when this guide was authored. See [Maven Central](https://mvnrepository.com/artifact/io.github.resilience4j/resilience4j-spring-boot2) to understand what versions are currently available.
2. Created an ApplicationConfiguration class to create beans for RestTemplate, CircuitBreakerConfig, and CircuitBreaker. These beans will be autowired into the appropriate controller and or service classes in the application.
3. Add circuit breaker logic to a service in order to protect calls to a remote service that may fail. See the ```HelloService.java``` class for an example of wrapping Retry and Circuit Breaker logic around an external REST call.

## Implementation Notes

Take note of the CircuitBreakerConfig bean that is created in ```ApplicationConfiguration.java```. This bean configures the way the CircuitBreaker will behave; for example the failure rate threshold is set to 15, which means that if the failure rate goes above 15% the circuit will be opened. You should read the class documentation (it is well written) in the Resilience4J source for ```CircuitBreakerConfig.java``` to better understand the various configurable settings. Your IDE should let you look at source, or view the latest release source in the [Resilience4J GitHub](https://github.com/resilience4j/resilience4j/blob/master/resilience4j-circuitbreaker/src/main/java/io/github/resilience4j/circuitbreaker/CircuitBreakerConfig.java). 

After understanding the ways to configure a Circuit Breaker, you may need to have multiple circuit breaker configurations due to the need to handle failures differently for some service calls. Our example code does not demonstrate this, but assumes you will be able to configure to meet your application requirements.
