CONFIGURATION = [

    cfSpaces: [
        [
            apiEndpoint: 'https://api.sys.pp01.edc1.cf.ford.com',
            org: 'DevEn.Ford.NA',
            space: 'CAB-DEV',
            credentialsId: 'PCF-DevEn-Dev', // Jenkins credentials ID
            // apps: ['cab-fordair-dev', 'cab-gateway-dev', 'cab-fordair-dev-java11'], // will start/stop only the apps specified here.
            apps: ['*'], //"*"" will start/stop all the apps in the space.
            sleepTimeInSeconds: 300, //sleep time in seconds. The program will sleep for this time after the start/stop is issued and before a check is perfomed to see if the application has started/stopped. 
        ],
        [   apiEndpoint: 'https://api.sys-pcf02v2.cf.ford.com',
            org: 'DevEn.Ford.NA',
            space: 'CAB-DEV',
            credentialsId: 'PCF-DevEn-Dev',
            credentialsId: 'PCF-DevEn-Dev', // Jenkins credentials ID
            apps: ['*'], //"*"" will start/stop all the apps in the space.
            sleepTimeInSeconds: 240, //sleep time in seconds. The program will sleep for this time after the start/stop is issued and before a check is perfomed to see if the application has started/stopped. 
        ]
    ]
]