## Jenkins Application Instance Scheduler

The Jenkins scripts provided in this guide are meant to allow a team to manage the stopping and starting of application instances in PCF that are not required to be run outside of normal team working hours. This allows resources, such as application instances running in our cloud environments, to be shut down thus reducing the hours these applications are 
being billed for.
The scripts are largely configurable to meet any team's schedule. The guide below will detail just how to do this configuration.


### Jenkins "pipeline as code" with GitHub Orgs 
The Jenkins scripts provided in this guide are based on Jenkins [Pipeline as Code](https://jenkins.io/doc/book/pipeline-as-code/) recommendations. *Pipeline as Code* consists of two parts:
 - Projects must contain a *pipeline script* file (e.g. `Jenkinsfile`) in their repository's root directory.
 - A **GitHub Organization** item in Jenkins setup to scan your GitHub organization's repositories for the *pipeline script* file.

> NOTE: While you can create a Jenkins pipeline based off your *pipeline script* file (e.g. `Jenkinsfile`) alone, **GitHub Organization** Jenkins item eliminates the manual process by detecting branches and repositories, respectively, and further creates appropriate folders with jobs in Jenkins automatically.

> 


### Jenkins Scripts

Our solution involves the use of a couple Jenkins scripts, the [Jenkinsfile_ScheduleStartApp](./Jenkinsfile_ScheduleStartApp) script and the [Jenkinsfile_ScheduleStopApp](./Jenkinsfile_ScheduleStopApp) script. The behavior of the scripts will be managed from the [pipeline.configuration.groovy](../pipeline.configuration.groovy) file. If you are familiar with the Dev Enablement team's [Jenkins Pipeline](../pipeline-jenkins) offering, you will be familiar with this pattern of using a configuration file.

The Start and Stop scripts handles the scheduling of downtime and uptime of applications in one or more CF spaces. The scripts contain the following steps:

- `Pipeline Setup` step: prepares the environment and workspace.
- `forEachCfSpace` step: stops/starts the application using application name(s) configured in the `pipeline.configuration.groovy` file.



### How to Configurare the Start/Stop behavior

Teams can choose to modify `Jenkinsfile_StartApp` and `Jenkinsfile_StopApp` directly but most of the scripts behavior should be tweaked via the [pipeline.configuration.groovy](./pipeline.configuration.groovy) file. 

Here are the fields and details to help you understand how to configure your use of the scripts. You can see the [pipeline.configuration.groovy](./pipeline.configuration.groovy) file in this guide to see actual values that could be used.
- apiEndpoint - URL for the PCF Foundation where your apps are running
- org - PCF Organization name where your apps are running
- space - PCF Space name where your apps are running
- credentialsId - Jenkins credential key for getting the PCF local account id and password needed to login to PCF for starting/stopping apps.
- apps - list of apps to start/stop; can use '*' to denote all apps in the Org/Space.
- sleepTimeInSeconds - time to wait before the script verifies if start/top command worked. This needs to be a value long enough to allow the start or stop action to complete.


### Configure the Start and Stop schedule

The start and stop of the apps can be scheduled by using the Jenkins configure page, where you will enter CRON schedule syntax into the schedule field under the Build Triggers section. Jenkins has a help page that will help you understand the required CRON syntax.
