# PCF Dev - FTP Client Example

***NOTE:*** Use of FTP is prohibited unless an exception has been granted to your team. This is due to security concerns with FTP. If requiring to transfer files, SFTP should be used. See [this post](https://www.ssh.com/ssh/ftp/server) for more details on the risks of using regular FTP.

This project demonstrates how to use the Ford Standard FTP client library in a Spring application. It's focus is to demonstrate how to read files into memory, and in the spirit of a cloud native application, it reads them into memory via a stream as opposed to relying on the local file system to store the files.

The sample code assumes that:
- you have a FTP Server running on localhost
- FTP server accepts an "anonymous" login without a password
- there are at least the following files in the home directory
    - text-example.txt
    - image-example.png 

The hostname, id, and password can be changed via the application.properties file. The file names can be changed via local variables defined in the service class.
  
The example code does use an API to expose the results, but this is not necessary. Simply examine the [FtpClientService](../ftp/src/main/java/com/ford/cloudnative/devenablement/ftpclient/details/FtpClientService.java) class to really understand the use of the library.

This example code does align with the overall application architecture patterns of our templates and our reference applications. It also demonstrates JUnit testing patterns as well.
