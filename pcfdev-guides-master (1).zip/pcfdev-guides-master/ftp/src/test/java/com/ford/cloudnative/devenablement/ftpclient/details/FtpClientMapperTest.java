package com.ford.cloudnative.devenablement.ftpclient.details;

import com.ford.cloudnative.devenablement.ftpclient.details.api.FtpDetailsApi;
import com.ford.cloudnative.devenablement.ftpclient.details.FtpClientMapper;

import org.junit.Before;
import org.junit.Test;

import static org.assertj.core.api.Assertions.assertThat;

public class FtpClientMapperTest {

    private static final String TEST_DIR_LIST = "file1.txt;file2.txt;";
    private static final String TEST_FILE_CONTENTS = "This is test data";

    FtpClientMapper mapper;


    @Before
    public void setup() {
        mapper = new FtpClientMapper();
    }


    @Test
    public void shouldConvertSingleFlightApiToFlight() throws Exception {

        FtpClientLocationDetails details = FtpClientLocationDetails.builder()
                .ftpReadFileContents(TEST_FILE_CONTENTS)
                .ftpRemoteDirectoryListing(TEST_DIR_LIST)
                .build();

        FtpDetailsApi apiObject = mapper.from(details);
        assertThat(apiObject).isNotNull();
        assertThat(apiObject.getFtpRemoteDirectoryListing()).isEqualTo(TEST_DIR_LIST);
        assertThat(apiObject.getTextFileContents()).isEqualTo(TEST_FILE_CONTENTS);
    }


}
