package com.ford.cloudnative.devenablement.ftpclient.details;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ford.cloudnative.base.app.web.exception.handler.ExceptionHandlerConfiguration;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Import;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.ResultActions;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.JsonPathResultMatchers;
import org.springframework.test.web.servlet.result.MockMvcResultHandlers;

import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@RunWith(SpringRunner.class)
@WebMvcTest(controllers = {FtpClientController.class, FtpClientMapper.class})
@Import(ExceptionHandlerConfiguration.class)
public class FtpClientControllerIntegrationTest {

    private static final String TEST_DIR_LIST = "file1.txt;file2.txt;";
    private static final String TEST_FILE_CONTENTS = "This is test data";

    @Rule
    public ExpectedException exception = ExpectedException.none();

    @Autowired
    MockMvc mockMvc;

    @Autowired
    ObjectMapper objectMapper;

    @MockBean
    private FtpClientService service;


    @Test
    public void shouldReturnFtpDetails() throws Exception {

        FtpClientLocationDetails details = FtpClientLocationDetails.builder()
                .ftpReadFileContents(TEST_FILE_CONTENTS)
                .ftpRemoteDirectoryListing(TEST_DIR_LIST)
                .build();

        when(service.getFtpClientLocationDetails()).thenReturn(details);

        jsonGet("/api/v1/ftpresults")
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                // controller unit tests test completeness of response object; we only smoke test here that a JSON response is returned
                .andExpect(jsonPath("$.result.ftpDetails.ftpRemoteDirectoryListing").value(TEST_DIR_LIST))
                .andExpect(jsonPath("$.result.ftpDetails.textFileContents").value(TEST_FILE_CONTENTS));

        verify(service).getFtpClientLocationDetails();
    }


    private ResultActions jsonGet(String url) throws Exception {
        return
                this.mockMvc.perform(MockMvcRequestBuilders
                        .get(url)
                        .contentType(MediaType.APPLICATION_JSON)
                )
                        .andDo(MockMvcResultHandlers.print());
    }


    private ResultActions jsonPost(String url, Object entity) throws Exception {
        return
                this.mockMvc.perform(MockMvcRequestBuilders
                        .post(url)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(entity))
                )
                        .andDo(MockMvcResultHandlers.print());
    }


    private static JsonPathResultMatchers dataError(String name) {
        return jsonPath(String.format("$.error.dataErrors[?(@.name == '%s')]", name));
    }

    private static JsonPathResultMatchers dataErrorWithCode(String name, String code) {
        return jsonPath(String.format("$.error.dataErrors[?(@.name == '%s' && @.code == '%s')]", name, code));
    }

    private static JsonPathResultMatchers dataErrorWithMessage(String name, String message) {
        return jsonPath(String.format("$.error.dataErrors[?(@.name == '%s' && @.message == '%s')]", name, message));
    }
}
