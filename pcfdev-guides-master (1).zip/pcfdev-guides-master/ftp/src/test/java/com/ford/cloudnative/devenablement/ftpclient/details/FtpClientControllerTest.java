package com.ford.cloudnative.devenablement.ftpclient.details;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Matchers.anyLong;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.time.OffsetDateTime;
import java.util.Optional;

import com.ford.cloudnative.devenablement.ftpclient.details.FtpClientController;
import com.ford.cloudnative.devenablement.ftpclient.details.FtpClientMapper;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.ford.cloudnative.base.api.BaseBodyResponse;
import com.ford.cloudnative.devenablement.ftpclient.details.api.FtpDetailsApi;
import com.ford.cloudnative.devenablement.ftpclient.details.api.FtpDetailsResponse;

@RunWith(MockitoJUnitRunner.class)
public class FtpClientControllerTest {

    private static final String TEST_DIR_LIST = "file1.txt;file2.txt;";
    private static final String TEST_FILE_CONTENTS = "This is test data";


    FtpClientController controller;

    @Mock
    private FtpClientService ftpService;


    @Before
    public void setup() {
        controller = new FtpClientController(ftpService, new FtpClientMapper());
    }

    @Test
    public void shouldReturnFlight() throws Exception {

        FtpClientLocationDetails details = FtpClientLocationDetails.builder()
                .ftpReadFileContents(TEST_FILE_CONTENTS)
                .ftpRemoteDirectoryListing(TEST_DIR_LIST)
                .build();


        when(ftpService.getFtpClientLocationDetails()).thenReturn(details);

        //Assert
        ResponseEntity<BaseBodyResponse<FtpDetailsResponse>> flightResponse = controller.getFtpDetails();
        FtpDetailsApi flightApi = flightResponse.getBody().getResult().getFtpDetails();
        assertThat(flightApi.getTextFileContents()).isEqualTo(TEST_FILE_CONTENTS);
        assertThat(flightApi.getFtpRemoteDirectoryListing()).isEqualTo(TEST_DIR_LIST);

        verify(ftpService).getFtpClientLocationDetails();

    }


}
