package com.ford.cloudnative.devenablement.ftpclient;

import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class FtpClientExampleApplicationTest {
	@Test
	public void contextLoads() {
	}
}