package com.ford.cloudnative.devenablement.ftpclient;


import com.ford.cloudnative.base.app.web.exception.handler.ExceptionHandlerConfiguration;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.context.annotation.Import;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;

import java.util.List;

import static org.springframework.boot.test.context.SpringBootTest.WebEnvironment.RANDOM_PORT;


@RunWith(SpringRunner.class)
@AutoConfigureMockMvc
@SpringBootTest(webEnvironment = RANDOM_PORT)
@Import(ExceptionHandlerConfiguration.class)
public class ActuatorsSecurityTest {

    @Autowired
    private TestRestTemplate restTemplate;

    @Autowired
    MockMvc mockMvc;


    /***********************************************************************************************
     * ENDPOINTS: Actuator
     ***********************************************************************************************/

    @Test
    public void should_allowActuatorInfoEndpoint_withoutAuthentication() {
        TestUtil.assertAccessGet(restTemplate, "/actuator/info");
    }

    @Test
    public void should_allowActuatorHealthEndpoint_withoutAuthentication() {
        TestUtil.assertAccessGet(restTemplate, "/actuator/health");
    }

    @Test
    public void should_notAllowSensitiveActuatorEndpoints_withoutAuthentication() {
        List<String> sensitiveActuatorEndpoints = TestUtil.getSensitiveActuatorEndpoints();
        for (String sensitiveEndpoint : sensitiveActuatorEndpoints) {
            TestUtil.assertNoAccessGet(restTemplate, sensitiveEndpoint);
        }
    }

    @Test
    public void should_notAllowSensitiveActuatorEndpoints_withInValidAuthentication() {
        ResponseEntity<?> entity = restTemplate.withBasicAuth("INCORRECT", "CREDENTIALS").getForEntity("/actuator/env", String.class);
        TestUtil.assertNoAccess(entity);
    }
}
