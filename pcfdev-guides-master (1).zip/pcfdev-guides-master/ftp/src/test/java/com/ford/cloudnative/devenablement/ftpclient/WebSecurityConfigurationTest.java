package com.ford.cloudnative.devenablement.ftpclient;

import com.ford.cloudnative.base.app.web.exception.handler.ExceptionHandlerConfiguration;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.context.annotation.Import;
import org.springframework.test.context.junit4.SpringRunner;

import static org.springframework.boot.test.context.SpringBootTest.WebEnvironment.RANDOM_PORT;


@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = RANDOM_PORT)
@Import(ExceptionHandlerConfiguration.class)
public class WebSecurityConfigurationTest {

    @Autowired
    private TestRestTemplate restTemplate;


    /***********************************************************************************************
     * ENDPOINTS: Swagger
     ***********************************************************************************************/

    @Test
    public void should_allowSwaggerEndpoints_withoutAuthentication() {
        TestUtil.assertAccessGet(restTemplate, "/swagger-ui.html");
        TestUtil.assertAccessGet(restTemplate, "/v2/api-docs");
    }

    /***********************************************************************************************
     * ENDPOINTS: Other
     ***********************************************************************************************/

    @Test
    public void should_notAllowOtherEndpoints_withoutAuthentication() {
        TestUtil.assertNoAccessGet(restTemplate, "/other-does-not-exist");
    }

    /***********************************************************************************************
     * ENDPOINTS: details feature
     ***********************************************************************************************/

    @Test
    public void should_allowGetFtpResultsApi_withoutAuthentication() {
        TestUtil.assertAccessGet(restTemplate, "/api/v1/ftpresults");
    }
}
