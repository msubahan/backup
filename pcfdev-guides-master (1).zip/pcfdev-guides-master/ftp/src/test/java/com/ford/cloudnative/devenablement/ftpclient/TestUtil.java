package com.ford.cloudnative.devenablement.ftpclient;

import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.ArrayList;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

public class TestUtil {


    public static ResponseEntity<?> get(TestRestTemplate restTemplate, String urlPath) {
        return restTemplate.getForEntity(urlPath, String.class);
    }

    public static ResponseEntity<?> post(TestRestTemplate restTemplate, String urlPath, Object post) {
        return restTemplate.postForEntity(urlPath, post, post.getClass());
    }

    public static void assertAccess(ResponseEntity<?> entity) {
        assertThat(entity.getStatusCode()).isNotIn(HttpStatus.UNAUTHORIZED, HttpStatus.FORBIDDEN, HttpStatus.NOT_FOUND, HttpStatus.METHOD_NOT_ALLOWED);
    }

    public static void assertNoAccess(ResponseEntity<?> entity) {
        assertThat(entity.getStatusCode()).isIn(HttpStatus.UNAUTHORIZED, HttpStatus.FORBIDDEN, HttpStatus.NOT_FOUND);
    }

    public static void assertAccessGet(TestRestTemplate restTemplate, String url) {
        ResponseEntity<?> entity = TestUtil.get(restTemplate, url);
        assertAccess(entity);
    }

    public static void assertNoAccessGet(TestRestTemplate restTemplate, String url) {
        ResponseEntity<?> entity = TestUtil.get(restTemplate, url);
        assertNoAccess(entity);
    }

    public static void assertAccessPost(TestRestTemplate restTemplate, String url, Object requestObject) {
        ResponseEntity<?> entity = TestUtil.post(restTemplate, url, requestObject);
        assertAccess(entity);
    }

    public static List<String> getSensitiveActuatorEndpoints() {
        List<String> endpoints = new ArrayList<>();
        endpoints.add("/actuator/actuator");
        endpoints.add("/actuator/auditevents");
        endpoints.add("/actuator/autoconfig");
        endpoints.add("/actuator/beans");
        endpoints.add("/actuator/configprops");
        endpoints.add("/actuator/dump");
        endpoints.add("/actuator/env");
        endpoints.add("/actuator/flyway");
        endpoints.add("/actuator/loggers");
        endpoints.add("/actuator/liquibase");
        endpoints.add("/actuator/metrics");
        endpoints.add("/actuator/mappings");
        endpoints.add("/actuator/shutdown");
        endpoints.add("/actuator/trace");
        return endpoints;
    }
}
