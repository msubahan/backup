package com.ford.cloudnative.devenablement.ftpclient.details;

import com.ford.cloudnative.devenablement.ftpclient.details.api.FtpDetailsApi;
import com.ford.cloudnative.devenablement.ftpclient.details.api.FtpDetailsResponse;

import org.springframework.stereotype.Component;

@Component
public class FtpClientMapper {

    public FtpDetailsApi from(FtpClientLocationDetails ftpDetails) {
        return FtpDetailsApi.builder()
                .ftpRemoteDirectoryListing(ftpDetails.getFtpRemoteDirectoryListing())
                .textFileContents(ftpDetails.getFtpReadFileContents())
                .build();
    }

}
