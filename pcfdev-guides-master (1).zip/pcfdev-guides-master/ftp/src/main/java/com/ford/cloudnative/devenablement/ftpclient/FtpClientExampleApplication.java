package com.ford.cloudnative.devenablement.ftpclient;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FtpClientExampleApplication {

    public static void main(String[] args) {
        SpringApplication.run(FtpClientExampleApplication.class, args);
    }

}