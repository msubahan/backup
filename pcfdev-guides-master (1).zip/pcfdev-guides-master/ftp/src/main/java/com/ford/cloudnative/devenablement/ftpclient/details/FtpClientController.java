package com.ford.cloudnative.devenablement.ftpclient.details;

import java.util.ArrayList;
import java.util.List;

import com.ford.cloudnative.devenablement.ftpclient.details.api.FtpDetailsResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ford.cloudnative.base.api.BaseBodyResponse;
import com.ford.cloudnative.devenablement.ftpclient.details.api.FtpDetailsApi;

import io.swagger.annotations.ApiOperation;

@RestController
@RequestMapping(path = "/api/v1/ftpresults")
public class FtpClientController {
    private FtpClientService service;
    private FtpClientMapper mapper;

    @Autowired
    public FtpClientController(FtpClientService service, FtpClientMapper mapper) {
        this.service = service;
        this.mapper = mapper;
    }


    @ApiOperation(value = "FTP Details", notes = "FTP Details")
    @GetMapping
    public ResponseEntity<BaseBodyResponse<FtpDetailsResponse>> getFtpDetails() {
        FtpClientLocationDetails details = service.getFtpClientLocationDetails();

        FtpDetailsResponse response = FtpDetailsResponse.builder()
                .ftpDetails(mapper.from(details))
                .build();

        return ResponseEntity.ok(BaseBodyResponse.result(response));
    }
}
