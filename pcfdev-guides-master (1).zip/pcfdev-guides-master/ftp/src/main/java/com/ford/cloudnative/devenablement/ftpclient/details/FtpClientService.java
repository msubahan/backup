package com.ford.cloudnative.devenablement.ftpclient.details;

import com.jscape.inet.ftp.Ftp;
import com.jscape.inet.ftp.FtpException;
import com.jscape.inet.ftp.FtpFile;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.Enumeration;

@Service
public class FtpClientService {

    @Value("${ftpclient.app.ftp.connection.host}")
    private String ftpHost;

    @Value("${ftpclient.app.ftp.connection.user}")
    private String ftpUser;

    @Value("${ftpclient.app.ftp.connection.password}")
    private String ftpPassword;

    //Filenames that I want to look for on my FTP Server
    private static final String FTP_FILE_TEXT = "text-example.txt";
    private static final String FTP_FILE_BINARY = "image-example.png";


    public FtpClientLocationDetails getFtpClientLocationDetails() {
        Ftp ftp = null;

        // create an ByteArrayOutputStream to store data
        ByteArrayOutputStream bout = new ByteArrayOutputStream();

        String folderContents = "";
        String textFileContents = "";

        try {
            ftp = new Ftp(ftpHost, ftpUser, ftpPassword);
            ftp.connect();

            // get directory listing and write to String for later use
            Enumeration listing = ftp.getDirListing();
            StringBuilder folderContentsBuilder = new StringBuilder();
            while (listing.hasMoreElements()) {
                FtpFile file = (FtpFile) listing.nextElement();
                folderContentsBuilder.append(file.getFilename());
                folderContentsBuilder.append(";");
            }
            folderContents = folderContentsBuilder.toString();

            //Download a text file and store in a stream
            ftp.download(bout, FTP_FILE_TEXT);
            byte[] bytes = bout.toByteArray();
            bout.reset();
            textFileContents = new String(bytes);

            // download image file and store in stream
            bout = new ByteArrayOutputStream();
            ftp.download(bout, FTP_FILE_BINARY);

            //Get the bytes for the binary file
            bout.toByteArray();
            bout.close();

            ftp.disconnect();

        } catch (FtpException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (null != ftp) {
                ftp.disconnect();
            }
        }

        FtpClientLocationDetails results =
                FtpClientLocationDetails.builder()
                        .ftpReadFileContents(textFileContents)
                        .ftpRemoteDirectoryListing(folderContents)
                        .build();

        return results;
    }

}
