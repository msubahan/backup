package com.ford.devenablement.mqguide;

import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.net.URL;

@Slf4j
@SpringBootApplication
public class MqGuideApplication {
    public final static String QNAME = "PSHUB.S4HANA.FROMHUB.MQT1";

    public static void main(String[] args) throws Exception {

        //******** FORD ****************
        URL trustStoreResource = MqGuideApplication.class.getResource("/keystore.jks");
        String path = trustStoreResource.toURI().getPath();
        log.warn("jks path" + path);
        log.warn("javax.net.ssl.keyStore", path);
        log.warn("javax.net.ssl.keyStorePassword", "<<keyStorePassword>>");

        SpringApplication.run(MqGuideApplication.class, args);

    }

}
