package com.ford.devenablement.mqguide.hellomessage;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@Slf4j
@RestController
@RequestMapping(path = "/mq")
public class SendMessageController {

    private SendMessageService sendMessageService;

    @Autowired
    public SendMessageController(SendMessageService sendMessageService) {
        this.sendMessageService = sendMessageService;
    }

    @GetMapping(path = "/sendMessage")
    public ResponseEntity<String> sendMessage(@RequestParam(required = false) String msg) {

        String msgValue = "Hello World!";
        if (!StringUtils.isEmpty(msg)) {
            msgValue = msg;
        }

        sendMessageService.sendHelloMessage(msgValue);

        return ResponseEntity.ok("message sent");
    }
}
