package com.ford.devenablement.mqguide.hellomessage;

import com.ford.devenablement.mqguide.MqGuideApplication;
import lombok.extern.slf4j.Slf4j;
import org.springframework.jms.annotation.JmsListener;
import org.springframework.stereotype.Component;

@Slf4j
@Component
public class MessageListener {

    @JmsListener(destination = MqGuideApplication.QNAME)
    public void receiveMessage(String message) {
        log.warn("Received message is: " + message);
    }
}
