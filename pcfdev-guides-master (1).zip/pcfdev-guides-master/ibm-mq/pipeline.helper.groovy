// JENKINS PIPELINE HELPER FILE

def _config, _configCf

// read configuration from external file
def readConfigFile(envKey = 'DEV') {
    evaluate readFile('pipeline.configuration.groovy')
    _config = CONFIGURATION
    _configCf = _config.cfEnvironments?.getAt("${envKey}") ?: [:]
}

// configure environment relating to third-party integrations
def configureThirdPartyIntegrations() {
    // configure nexus w/ credentials
    if (property('integrations.thirdParty.nexus.enabled')) {
        _withCredentials(property('integrations.thirdParty.nexus.credentialsId')) { user, password ->
            env.BOOST_PUBLISH_TEAM_REPO_USER = user;
            env.BOOST_PUBLISH_TEAM_REPO_PASS = password;
            env.BOOST_PUBLISH_TEAM_REPO_URL = property('integrations.thirdParty.nexus.repoUrl');
        }
    }

    // configure sonarqube w/ credentials
    if (property('integrations.thirdParty.sonarQube.enabled')) {
        _withCredentials(property('integrations.thirdParty.sonarQube.credentialsId')) { user, password ->
            env.BOOST_SONARQUBE_SONAR_LOGIN = password;
            env.BOOST_SONARQUBE_SONAR_PROJECTKEY = property('integrations.thirdParty.sonarQube.projectKey');
        }
    }

    // configure fossa w/ credentials
    if (property('integrations.thirdParty.fossa.enabled')) {
        _withCredentials(property('integrations.thirdParty.fossa.credentialsId')) { user, password ->
            env.FOSSA_API_KEY = password;
            env.FOSSA_PROJECT_NAME = property('integrations.thirdParty.fossa.projectName');
            env.FOSSA_TEAM_NAME = property('integrations.thirdParty.fossa.teamName');
            env.FOSSA_POLICY_NAME = property('integrations.thirdParty.fossa.policyName');
        }
    }
}

// configure environment relating to cloud-service integrations
def configureCloudServiceIntegrations() {
    // configure jasypt password in credhub
    if (propertyCf('integrations.cloud.credhub_secretzero.enabled')) {
        env.CREDHUB_ENABLED = true
        _withCredentials(propertyCf('integrations.cloud.credhub_secretzero.credentialsId')) { user, password ->
            env.SECRET_ZERO = password;
        }
    }

    // configure cloud config server
    if (propertyCf('integrations.cloud.config_server.enabled')) {
        env.CONFIGSERVER_ENABLED = true
        if (propertyCf('integrations.cloud.config_server.configured')) {
            env.CONFIGSERVER_CONFIGURED = true
            _withCredentials(propertyCf('integrations.cloud.config_server.credentialsId')) { user, password ->
                env.GITHUB_SSH_KEY = password
                env.GITHUB_CONFIG_REPO_URL = propertyCf('integrations.cloud.config_server.repoSSHUrl')
            }
        }
    }

}

// re/load environment configurations using global, specific cf environment, and specific cf space values
def loadEnvironmentConfigurations(spaceKey = null) {
    def setEnvs = { envMap -> for (def e in envMap) env."${e.key}" = e.value }
    env.cfManifestFile = 'manifest-generated.yml'
    setEnvs _config.env
    setEnvs _configCf.env
    if (spaceKey) {
        setEnvs _configCf.spaces?.getAt(spaceKey)?.env
        cfLogin spaceKey
    }
}

// perform an action for CF space
def stageForEachCfSpace(caption, closure) {
    for (def spaceKey in _configCf.spaces?.keySet()) {
        stage(String.format(caption, spaceKey)) {
            loadEnvironmentConfigurations spaceKey
            closure spaceKey
        }
    }
}

// login and cache cf session
def cfLogin(spaceKey) {
    env.CF_HOME = "${env.WORKSPACE}/cf-sessions/cf-${spaceKey}"

    if (!fileExists(env.CF_HOME)) {
        def spaceInfo = _configCf.spaces[spaceKey]
        _withCredentials(spaceInfo.credentialsId) { user, password ->
            sh """ mkdir -p "${env.CF_HOME}"; cf login -a "${spaceInfo.apiEndpoint}" -o "${spaceInfo.org}" -s "${spaceInfo.space}" -u "${user}" -p "${password}" """
        }
    }
}

// retrieve value for single or nested property from configuration (i.e. pipeline.configuration.groovy)
def property(name, value = _config, defaultValue = null) {
    name.tokenize('.').each { value = value?.get(it) }
    value ?: defaultValue
}

// retrieve value for single or nested CF property from configuration (i.e. pipeline.configuration.groovy)
def propertyCf(name, defaultValue = null) {
    property(name, _configCf, defaultValue)
}

// credentials wrapper helper
def _withCredentials(credentialsId, closure) {
    if (!credentialsId) return
    withCredentials([[$class: 'UsernamePasswordMultiBinding', credentialsId: credentialsId, usernameVariable: '_user_', passwordVariable: '_password_']]) {
        closure _user_, _password_
    }
}

def canPublish() {
    if (!property('integrations.thirdParty.nexus.enabled')) { return false }
    if (propertyCf('integrations.thirdParty.nexus.downloadMyLatestArtifact'))  { return false }
    return true
}

def canDownloadMyLatestArtifact() {
    if (!property('integrations.thirdParty.nexus.enabled')) { return false }
    if (!propertyCf('integrations.thirdParty.nexus.downloadMyLatestArtifact')) { return false }
    return true
}

// finalize
def cleanUp() {
    dir("${env.WORKSPACE}/cf-sessions") { deleteDir() }
}

// executes Checkmarx analysis
def runCheckmarx() {
    step([$class: 'CxScanBuilder', comment: 'Scan Triggered by Jenkins Pipeline', credentialsId: property('integrations.thirdParty.checkmarx.credentialsId'), excludeFolders: '', excludeOpenSourceFolders: '',
          exclusionsSetting: 'global', failBuildOnNewResults: true, failBuildOnNewSeverity: 'HIGH', filterPattern: '''!**/_cvs/**/*,     !**/.svn/**/*,     !**/.hg/**/*,     !**/.git/**/*,
                  !**/.bzr/**/*,    !**/bin/**/*,    !**/obj/**/*,    !**/backup/**/*,     !**/.idea/**/*,    !**/*.DS_Store,    !**/*.ipr,    !**/*.iws,
                  !**/*.bak,    !**/*.tmp,    !**/*.aac,    !**/*.aif,     !**/*.iff,    !**/*.m3u,    !**/*.mid,    !**/*.mp3,
                  !**/*.mpa,    !**/*.ra,    !**/*.wav,    !**/*.wma,     !**/*.3g2,    !**/*.3gp,    !**/*.asf,    !**/*.asx,
                  !**/*.avi,    !**/*.flv,    !**/*.mov,    !**/*.mp4,     !**/*.mpg,    !**/*.rm,    !**/*.swf,    !**/*.vob,
                  !**/*.wmv,    !**/*.bmp,    !**/*.gif,    !**/*.jpg,     !**/*.png,    !**/*.psd,    !**/*.tif,    !**/*.swf,
                  !**/*.jar,    !**/*.zip,    !**/*.rar,    !**/*.exe,     !**/*.dll,    !**/*.pdb,    !**/*.7z,    !**/*.gz,
                  !**/*.tar.gz,    !**/*.tar,    !**/*.gz,    !**/*.ahtm,     !**/*.ahtml,    !**/*.fhtml,    !**/*.hdm,    !**/*.hdml,
                  !**/*.hsql,    !**/*.ht,    !**/*.hta,    !**/*.htc,     !**/*.htd,    !**/*.war,    !**/*.ear,    !**/*.htmls,
                  !**/*.ihtml,    !**/*.mht,    !**/*.mhtm,    !**/*.mhtml,     !**/*.ssi,    !**/*.stm,    !**/*.stml,    !**/*.ttml,
                  !**/*.txn,    !**/*.xhtm,    !**/*.xhtml,    !**/*.class,     !**/*.iml,    !Checkmarx/Reports/*.*''',
          fullScanCycle: 10, teamPath: property('integrations.thirdParty.checkmarx.teamPath'), includeOpenSourceFolders: '', osaArchiveIncludePatterns: '*.jar', osaEnabled: true,
          vulnerabilityThresholdEnabled:true, osaHighThreshold:0, osaMediumThreshold:10, osaInstallBeforeScan: false, password: '',
          preset: '36', projectName: property('integrations.thirdParty.checkmarx.projectName'), sastEnabled: true, serverUrl: property('integrations.thirdParty.checkmarx.serverUrl'),
          sourceEncoding: '1', username: '', vulnerabilityThresholdResult: 'FAILURE', waitForResultsEnabled: true]
    )
}

// Versioning
def printVersionNumber() {
    sh '''
    set +x
    echo "\n*******************************************************************************"
    echo "***                                                                         ***"
    echo "***    DEV ENABLEMENT TEAM - JENKINS PIPELINE OFFERING - VERSION: 2.3.0     ***"
    echo "***                                                                         ***"
    echo "*******************************************************************************\n"
    '''
}

return this;