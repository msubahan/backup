# AutoSys Guide

This guide documents the steps required to have a job created in AutoSys that will securely call an endpoint in a PCF application.


## What is AutoSys

AutoSys is an automated job control system for scheduling, monitoring, and reporting. It is a centralized tool that executes jobs to be run on remote systems. It is Ford's standard and supported job scheduling tool. It recently added support for HTTP calls to remote systems, making it an option for running workloads in web applications such as those running in PCF (both on-prem as well as Azure).


## Jobs as API Endpoints

Once configured, AutoSys will initiate a request to an API endpoint (REST endpoints are a great option) of your choosing. 
Some of the considerations for this API endpoint:
* It must respond to HTTP GET method
* Security, while not required, is strongly encouraged. Securing your endpoint requires OAuth2, and requires you to configure AutoSys to hold a client ID and client secret to allow for secure communication using the  __client_credentials__ OAuth2 Grant Type.
* If the job is long running, it would be wise to process the job asynchronously. Long running HTTP requests have the potential for timing-out and causing AutoSys to falsely reflect an error. In this case you are using AutoSys to merely trigger the job, and would need to rely on other means to monitor or report status of the job.

Our referance application, [CAB](https://github.ford.com/PCFDev-CAB), has an example API endpoint  __/api/v1/flightjobs__ that works with AutoSys. See the Spring REST Controller class [FlightJobController](https://github.ford.com/PCFDev-CAB/cab-service-fordair/blob/master/src/main/java/com/ford/cab/fordair/flight/FlightJobController.java) to see a real working example.


## Configuring a job in the AutoSys Server

The example below details how we successfully configured Autosys to run a job (accessible via an endpoint) in PCF for the CAB application in our DEV environment (DEV space in a Pre-Prod foundation).

This sample job is configured to run once a day, Monday thru Friday, at 13:30 UTC. To see additional schedule options avalble, see the [Autosys JIL Guide](https://autosys.ford.com/jil_guide.html?ID=customer6).

### Required steps to configure your Job in AutoSys server:

* __Step 1__ : Write a JIL File (Job Information Language)

	_Below is the JIL that we used for the __/api/v1/flightjobs__ API endpoint in CAB_

    ```
    insert_job: 24107_pcf_cab_dev_create_flights_pojo   job_type: POJO
    machine: webdev
    owner: asysagtd
    permission:
    date_conditions: 1
    days_of_week: mo,tu,we,th,fr
    start_times: "13:30"
    description: "Create Flights by Accessing CAB's Job API"
    alarm_if_fail: 1
    alarm_if_terminated: 1
    timezone: UTC+00\:00
    group: cab_developers
    application: 24107_CAB
    method_name: authenticateAndSubmitGet
    class_name: com.ca.http.ApplicationWorkflow
    j2ee_parameter: String=file\:///app/CA/data/asysagtd/24107_cabdev/i.txt
    j2ee_parameter: String=file\:///app/CA/data/asysagtd/24107_cabdev/t.txt
    j2ee_parameter: String=file\:///app/CA/data/asysagtd/24107_cabdev/p.txt
    j2ee_parameter: String=https\://fd-usr-sso.login.sys-pcf01v2.cf.ford.com/oauth/token
    j2ee_parameter: String="grant_type&#61;client_credentials,resource&#61;cab2-flight-server.resource"
    j2ee_parameter: String=Content-Type\:application/x-www-form-urlencoded
    j2ee_parameter: String=https\://cab2-flight-server-dev.apps-pcf01v2i.cf.ford.com/api/v1/flightjobs
    j2ee_parameter: String=$.access_token
    j2ee_parameter: String=/app/CA/data/logs/24107_cabdev/24107_pcf_cabdev_create_flights_pojo.tkn
    ```
    If you have any questions on how to write a JIL file, or the correctness of your JIL, please contact an AutoSys team member to assist you. Below we have provided some descriptions for some common JIL Parameters that may assist you in composing it.  FYI - The values for each parameter, in JIL, is case-sensitive

    * `insert_job` : The Pattern maintained is *ITMSNUMBER_pcf_<APP_NAME><ENVIRONTMENT_NAME>_<JOBDESCRIPTION>_pojo* 
    * `machine` : *webdev / webqas / webprd* (according to the Environment)
    * `owner` : *asysagtd / asysagtq / asysagt* (according to the Environment)
    * `days_of_week` : First two letters of the Day (in lower case)
    * `start_times`: Should be in 24 hours Format
    * `description`: Any Description about the Job
    * `timezone` : Any Timezone with Appropriate offset. Here in our usecase, we have followed UTC.
    * `group` : The pattern is *<APP_NAME>_DEVELOPERS*
    * `application` : The Pattern is *<ITMS_NUMBER>_<APP_NAME>*
    * `j2ee_parameter` : 
        * For all the Path-related Params, ensure that you maintain the folder name in this Pattern ITMS_<APPNAME><ENVIRONEMNT_NAME> In our Job, you can see us mentioning that as, __24107_cabdev__   

        * Ensure you mention appropriate OAuth Token Endpoint
            * In our usecase we have used: `String=https\://fd-usr-sso.login.sys-pcf01v2.cf.ford.com/oauth/token`
        
        * Ensure you mention appropriate Grant types & Resource Name
            * In our usecase we have used:
               
                `String="grant_type&#61;client_credentials,resource&#61;cab2-flight-server.resource"`
               
        * Ensure that you mention appropriate API Endpoint of your App that needs to be triggered by the AutoSys Server
            * In our usecase we have used : `String=https\://cab2-flight-server-dev.apps-pcf01v2i.cf.ford.com/api/v1/flightjobs`


    

* __Step 2__ : Raise a IT Connect Ticket by clicking [here](https://www.itconnect.ford.com/ux/rest/share/OJSXG33VOJRWKSLEHUYTAMRQEZZGK43POVZGGZKUPFYGKPKTIJPVAUSPIZEUYRJGORSW4YLOOREWIPJQGAYDAMBQGAYDAMBQGAYDAMJGMNXW45DFPB2FI6LQMU6UGQKUIFGE6R27JBHU2RI=)
    * The Service Type should be `Job Scheduling`
    * The Service Sub-Type should be `Job Definition`
    * The Customer Machine should be AutoSys's Gateway server. Below are the servers name that should be used accordingly
     	
		* DEV - ito14153.hosts.cloud.ford.com 
		* QAS - ito14151.hosts.cloud.ford.com 
		* PRD - ito14149.hosts.cloud.ford.com
	
    * Ensure that the JIL is Attached in the Ticket

* __Step 3__ : Send the OAuth Keys to the AutoSys contact (if your API endpoint is Protected with OAuth)
    * Once the ticket is Approved by the Product Manager, AutoSys team will reach the Appropriate person
    * The Client-Id / Client-Secret needs to be eMailed to the AutoSys team. 
        * *Ensure that the eMail sent to them is Encrypted*


## Additional Resources & Support for AutoSys

1. Ford Autosys Site - [https://autosys.ford.com/](https://autosys.ford.com/)
1. Ford Autosys JIL Guide - [https://autosys.ford.com/jil_guide.html?ID=customer6](https://autosys.ford.com/jil_guide.html?ID=customer6)
1. Self-Service through Autosys Workload Command Center (WCC) for DEV, QAS & PRD.  The onboarding instructions are locate at this URL [https://autosysdev.ford.com/wcc.html?ID=customer1](https://autosysdev.ford.com/wcc.html?ID=customer1).
1. Open a service request and incident tickets via IT Connect for the Autosys operations team at [https://www.itconnect.ford.com/dwp/app/#/search/catalog/autosys](https://www.itconnect.ford.com/dwp/app/#/search/catalog/autosys).
1. Send escalations via email to this address [cssched1@ford.com](mailto:cssched1@ford.com)   
1. For escalations via messenger:  OPEN, SYSTEMS (O.)


