# Actuator Guide

This guide explains some of the considerations teams should be aware of when using the Spring Boot Actuators in their application. The Spring Boot actuators offer great features, which is why we include them by default when generating Spring Boot applications using the EcoBoost generator in [DCS](http://dcs.ford.com). 

This guide will not cover what is already documented in several other locations. If you need to learn about Spring Boot Actuators, please refer to the some of the following resources, or search the internet on the topic.
* [https://docs.spring.io/spring-boot/docs/current/reference/html/production-ready-features.html](https://docs.spring.io/spring-boot/docs/current/reference/html/production-ready-features.html)

* [https://docs.spring.io/spring-boot/docs/current/actuator-api/html/](https://docs.spring.io/spring-boot/docs/current/actuator-api/html/)

* [https://stackabuse.com/monitoring-with-spring-boot-actuator/](https://stackabuse.com/monitoring-with-spring-boot-actuator/)

* [https://www.baeldung.com/spring-boot-actuators](https://www.baeldung.com/spring-boot-actuators)


## Security Issues considerations with Spring Boot Actuators

The main purpose of this guide is for teams to understand the responsibilities around security when using Spring Boot Actuators. Only 2 of the actuators are considered non-sensitive, and can be exposed without authentication. The non-sensitive actuators are ```health``` and ```info```. All the other endpoints should be considered sensitive.

The current version of Spring Boot, which is Spring Boot 2.2.x at the time of this writing, disables the sensitive endpoints by default. Teams using older versions of Spring must verify and test to insure that these sensitive endpoints are indeed protected. 

**Teams that have enabled and unsecured sensitive actuator endpoints have these options:**
1. Disable the endpoints
2. Configure authentication and authorization on the sensitive endpoints
3. Upgrade to the latest version of Spring Boot

See the links in the other resources section below for assistance on the 3 recommendations detailed above.

If you have a requirement to enable any of the sensitive endpoints, you **MUST** insure that they are secured, and that access is limited to only the individuals that should have access. The [https://stackabuse.com/monitoring-with-spring-boot-actuator/](https://stackabuse.com/monitoring-with-spring-boot-actuator/) site reference above has information on how to add authorization to the endpoints. 


## Verification using JUnit

A preferred approach is to continually test that the sensitive actuator endpoints are not exposed without authentication or authorization. Our reference application, CAB Ford Air, is a Spring Boot app that uses JUnit to implement both unit tests as well as JUnit acceptance tests (tests run against the real deployed app during Blue/Green deploy). If the endpoints ever become unauthenticated, the tests will fail. If you are using a CI/CD pipeline, your build will break and prevent deployment of unsecure code.
See the links to these tests below:
* Unit test Example - [ActuatorsSecurityTest.java](https://github.ford.com/PCFDev-CAB/cab-service-fordair/blob/master/src/test/java/com/ford/cab/fordair/ActuatorsSecurityTest.java)
* Acceptance test Example - [ActuatorsAcceptanceTest.java](https://github.ford.com/PCFDev-CAB/cab-service-fordair/blob/master/src/test/java/com/ford/cab/fordair/acceptance/ActuatorsAcceptanceTest.java)


## Other Resources

* [Spring Boot Supported Versions](https://github.com/spring-projects/spring-boot/wiki/Supported-Versions)

* [Spring Boot & EcoBoost Migration Guides](https://github.ford.com/DevEnablement/pcfdev-guides/tree/master/migrations)

* Disabling & Enabling Actuator Endpoints Depends on the version of Spring Boot:
  * Customizing Endpoints - [Spring Boot 1.4.x](https://docs.spring.io/spring-boot/docs/1.4.x/reference/html/production-ready-endpoints.html#production-ready-customizing-endpoints)
  * Customizing Endpoints - [Spring Boot 1.5.x](https://docs.spring.io/spring-boot/docs/1.5.x/reference/html/production-ready-endpoints.html#production-ready-customizing-endpoints)
  * Customizing Endpoints - [Spring Boot 2.0.x](https://docs.spring.io/spring-boot/docs/2.0.x/reference/html/production-ready-endpoints.html#production-ready-endpoints-enabling-endpoints)
  * Customizing Endpoints - [Spring Boot 2.1.x](https://docs.spring.io/spring-boot/docs/2.1.x/reference/html/production-ready-endpoints.html#production-ready-endpoints-enabling-endpoints)
  * Customizing Endpoints - [Spring Boot 2.2.x](https://docs.spring.io/spring-boot/docs/2.2.x/reference/html/production-ready-features.html#production-ready-endpoints-enabling-endpoints)
