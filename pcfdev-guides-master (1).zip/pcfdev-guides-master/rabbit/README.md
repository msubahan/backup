# Rabbit MQ Dev Guide


## Overview

RabbitMQ is a messaging broker; i.e. an intermediary for messaging. It gives your applications a common platform to 
send and receive messages, and your messages a safe place to live until received.

Messaging enables software applications to connect and scale. Applications can connect to each other, as components of 
a larger application, or to user devices and data. Messaging is asynchronous, decoupling applications by separating sending and receiving data.

Common messaging patterns include publish/subscribe, asynchronous processing, or work queues. All these are possible 
using Rabbit MQ.

## Rabbit connectivity in Spring Boot

The samples applications (both a producer app & a consumer app) referred to in this guide demonstrate the required 
objects needed to connect, publish, and listen to a specific queue in a RabbitMQ instance. The code will work locally assuming there is a Rabbit Server running on your localhost, and will also work in PCF if you bind the applications to a Rabbit instance in your PCF Org/Space.

## Rabbit in PCF

>Note: Rabbit MQ running in PCF is only available to applications running in PCF, and thus cannot be used for 
> messaging between applications outside of PCF. Efforts are in progress to get Rabbit MQ made available off PCF to allow more robust app to app enterprise messaging at Ford.

### Recommended Plan in PCF 

Rabbit MQ is a popular service offering available to PCF applications via the PCF Marketplace. Their currently are 2 
offerings for Rabbit, with the RabbitMQ On-Demand being the recommended option for those needing to use RabbitMQ.

* RabbitMQ - This is the legacy offering that provides shared instances of Rabbit that may expose your application to 
  noisy neighbor issues. Users of this service also run the risk of downtime during platform patches/upgrades.
* RabbitMQ On-Demand - This is the preferred offering, and instances of this service provide isolated RabbitMQ node(s) 
  on demand. The following plans are available:
    * single-node-3.7
    * three-node-3.7
    * three-node-xl
>_**Note:**_ The 3 Node offerings are required for those that have HA (high availability) requirements. The single node is
> more appropriate for DEV workloads where HA is not important.

>_**Note:**_ The single node instance is good enough for development environments.
 

### Migration to new Rabbit On-Demand plan

Beginning in 2020, an effort has been made to get teams to migrate from the use of the legacy shared instance Rabbit 
service instances. This has been encouraged because of the performance and availability concerns outlined in a previous 
section. The remainder of this section will cover the options and patterns for migrating to the On-Demand service 
offering.

#### If your application can incur downtime

1. Stop you application, after insuring your queue(s) are empty
2. Rename your current instance, thus freeing up the name to be used in the new instance
3. Create a new instance of one of the On-Demand RabbitMQ plans, using the original name of your Rabbit instance
4. Start your app
5. If you are using the EcoBoost pipeline, consider editing the `pipeline.cf-services.sh` file that is used to auto 
   create service instances when deploying to a new environment.

#### If you need to avoid downtime

_*TBD*_



### Rabbit and the PCF Autoscaler

The PCF Autoscaler has the ability to monitor a queue that is in a RabbitMQ instance. If an application is bound to 
both a RabbitMQ instance and an Autoscaler instance, the Autoscaler can monitor the depth of a specific queue and 
cause the Application to scale up or down based on thresholds that you define. 

As an example, you could scale up when a queue has more than 50 messages, and scale down instances when the number of 
messages in the queue dips below 5. This allows the Work Queues pattern to optimize the number of workers (or app 
instances) that are concurrently pulling messages and acting on them, thus reducing the elapsed time it will take to 
complete the processing of messages. See the Autoscaler guide for more details regarding the Autoscaler and use of the Autoscaler CF CLI plugin use.   


## Common Patterns

#### Service Bus with Config Server

A common reason many teams are first introduced to Rabbit MQ is because of the [Spring Cloud Bus library](https://cloud.spring.io/spring-cloud-bus/reference/html/). Spring Cloud Bus links the nodes of a distributed system with a lightweight message broker. This broker can then be used to broadcast state changes (such as configuration changes) or other management instructions. A key idea is that the bus is like a distributed actuator for a Spring Boot application that is scaled out. It is common to use the Rabbit Service Bus to support this messaging. See the [Config Server Refreshes](https://github.ford.com/DevEnablement/pcfdev-guides/blob/master/config-client/CONFIG_SERVER_REFRESHES.md#using-actuator-to-refresh-in-a-running-application) document for more details.

#### Work Queues

This pattern uses a Queue in Rabbit that will be used to distribute time-consuming tasks among multiple workers. See 
the Rabbit and the PCF Autoscaler section above for an example of using a Work Queues pattern in conjunction with the 
Autoscaler.

See the Rabbit site's [Work Queues tutorial for Spring](https://www.rabbitmq.com/tutorials/tutorial-two-spring-amqp.html)  for more details.

We have two sample Spring Boot applications that demonstrate the Work Queues pattern. One serves as a Message Producer, 
and the other serves as a Message Consumer, with the consumer demo also storing the message in a database after the message 
is consumed. The projects show how to define the require configuration for the queue and exchange, as well as the code for producing and/or consuming a message.
See the sample projects at:
* [devenablement-service-rabbitproducer](https://github.ford.com/DevEnablement/devenablement-service-rabbitproducer)
* [devenablement-service-rabbitconsumer](https://github.ford.com/DevEnablement/devenablement-service-rabbitconsumer)

#### Pub/Sub

This pattern is used when we need to deliver a message to multiple consumers. This pattern is known as 
"publish/subscribe".

See the [Pub/Sub tutorial for Spring](https://www.rabbitmq.com/tutorials/tutorial-three-spring-amqp.html) for more 
details.


## Blue/Green Deployments & Rabbit MQ

#### Blue/Green Explained

Teams that use the EcoBoost pipeline offering enjoy a Blue/Green deployment model out of the box. This model works by 
deploying a new version of your application to PCF and have it available on a "temp" route so that it can be tested 
while the current version of your application is still services traffic from customers.

#### Rabbit Queues Concern during Blue/Green

![Blue Green Deploy](blue-green-image.png)

When the code is deployed, the new version will bind to the same backing services that the current version of the app 
is bound to. This means that our "temp" or "Green" app is using the same rabbit instance (and maybe databases, REDIS, etc.) as the 
current version of the app. If the app is using the "Work Queue" pattern, the risk is that both the new version of our 
app (on the "temp" route) and the current version of our app could be pulling messages from our queue. In many situations 
this is not a desired behavior. The intent of this new version of the project being on a temp route is to test it (such as 
from a CI server like Jenkins) safely without performing actual transactions in the system such as pulling items from a 
queue. 

#### Proposed Solution

A solution that the Dev Enablement team has successfully implemented and is demonstrated in our consumer reference app:
* Have the queue listener disabled by default so that when "Green" starts and it does not receive messages from the queue.
* After new application is tested, the pipeline will move it to active by switching the route so that "actual" route 
  is now pointing to the newly deployed app ("Green" becomes "Blue"). After this route switch, the application needs to 
  then enable the queue listener. This enabling can be done via the use of an environment variable setting and using the 
  use of the rolling restart feature supported by the CF CLI.
  
To see the an implementation of this pattern, refer to the [reference message consumer app](https://github.ford.com/DevEnablement/devenablement-service-rabbitconsumer). The README.md in this repo explains the pattern that is implmented in this repo.
  

## Anti-Patterns

#### 1. Message Producer & Consumer in the same Application/Microservice

It is a bad practice to have the application that publishes messages to a queue (a producer) also be the same 
application that reads messages from the same queue (the consumer). This has some potentially bad consequences:
* You can not scale producing and consuming independently. In many cases producing messages is much faster than the 
  work the consumer may need to do once the message is received. Independent applications allow for independent 
  scaling rules. 
* Locked queue connection since both producer and consumer share the same connection.



## Running Rabbit locally (dev machine)

You have a few options for running Rabbit on your local machine. The most popular options are to do a native install 
for your operating system or to run a Docker image assuming you have Docker installed.

If installing native to your OS, Rabbit MQ requires installation of [Erlang](https://www.erlang.org/downloads). 

See the Rabbit MQ [downloads](https://www.rabbitmq.com/download.html) page for instructions and required binaries.


## Testing with RabbitMQ-Mock

In an environment, such as Jenkins, where no RabbitMQ instance is available, you can use the [RabbitMQ-Mock](https://github.com/fridujo/rabbitmq-mock) to perform integration testing.

Spring Boot application can add this dependency to the build.gradle

``` gradle
testImplementation 'com.github.fridujo:rabbitmq-mock:1.1.1'
```

and provide a mocked RabbitMQ ConnectionFactory Bean for the environment based on Spring profile.

For example:

```java
@Configuration
@Profile("norabbit")
@Primary
public class MockRabbitConnectionFactory {
    @Bean
    ConnectionFactory connectionFactory() {
        return new CachingConnectionFactory(new MockConnectionFactory());
    }
}
```

See [Reference Message Consumer App  test case](https://github.ford.com/DevEnablement/devenablement-service-rabbitconsumer/blob/master/src/test/java/com/ford/devenablement/rabbitconsumer/greeting/HelloMessageConsumerTest.java) for details.

## References

* Rabbit Vendor Site - [https://www.rabbitmq.com/features.html](https://www.rabbitmq.com/features.html)
* Rabbit MQ Tutorials - [https://www.rabbitmq.com/getstarted.html](https://www.rabbitmq.com/getstarted.html)
* Reference App - Message Producer App - [https://github.ford.com/DevEnablement/devenablement-service-rabbitproducer](https://github.ford.com/DevEnablement/devenablement-service-rabbitproducer)
* Reference App - Message Consumer App - [https://github.ford.com/DevEnablement/devenablement-service-rabbitconsumer](https://github.ford.com/DevEnablement/devenablement-service-rabbitconsumer)
* Autoscaler Dev Guide - [https://devservices.ford.com/dev-guides?search=PCF%20Autoscaler%20Service](https://devservices.ford.com/dev-guides?search=PCF%20Autoscaler%20Service)

