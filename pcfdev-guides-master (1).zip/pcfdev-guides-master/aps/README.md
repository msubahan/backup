# APS Guide

This Guide Demonstrates how to integrate the DEV Enablement team's APS client library in order to use Ford's APS authorization solution from your Spring Boot application.

## What is APS

Application Policy Services (APS) is Ford Motor Company's application access control services infrastructure. APS provides a centralized, policy-driven, role-based access control solution that is used by Ford applications for access control and application audits. Visit the [APS SharePoint Site](http://x.ford.com/aps) for a detailed overview of APS.

## Prerequisites

Application must be onboarded to AZURE AD and generate the credentials and scope in order to consume the secured APS-APIs. For detailed information on on-boarding process, Please refer this [link](https://azureford.sharepoint.com/sites/AccessMgmt/authz/AuthZ%20Services/AMA%20Authorization%20Services%20-%20API%20Security%20-%20Overview.aspx). For any queries, please send an email to APSAUTH@ford.com

# Implementation

### Dependencies

Dependencies required in your [build.gradle](./build.gradle)

```
implementation 'com.ford.it.fjf:aps-spring-client:1.2'

```

### Enabling APS Spring Client Library

Configurations to enable APS Spring Client library are placed in [application.properties](./src/main/resources/application.properties)

***Important:*** Redis is on the classpath per the lib, it can be disabled from autoconfiguration if the application doesn't require cache

````aidl
spring.autoconfigure.exclude=org.springframework.boot.autoconfigure.data.redis.RedisAutoConfiguration
````

#### Basic Configurations

```
# Refer the sample application.properties for more details
application-name=<ENTER_APP_NAME_AS_PER_APS>
aps-url=<ENTER_THE_HOST_URL_RESOURCE_AND_ROLE_SERVICE>
pdp-base-url=<ENTER_THE_HOST_URL_FOR_PDP>
pdp-dls-base-url=<ENTER_THE_HOST_URL_FOR_PDP_DLS>
mdp-base-url=<ENTER_THE_HOST_URL_FOR_MDP>

```
#### Proxy

By default, APS Spring Client uses a proxy to connect to the APS services. If the application is hosted in public cloud(Azure), the proxy setup is not necessary and causes errors if it has been set up. `enable-aps-proxy` property is used to configure that. 

If it is set to **false**, the HTTP calls to APS services do not go via proxy.

If it is not set or set to **true**, the HTTP calls to APS services go via proxy.

````aidl 
enable-aps-proxy=false
````


#### Authentication

The following properties are mandatory and must be configured with the AZURE AD credentials of the application.

```
auth-client-id=<Add Client ID here>
auth-client-secret=<Add Client Secret here>
auth-scope=<Add Auth Scope here>
auth-mdp-scope=<Add MDP Auth Scope here>
auth-url=https://login.microsoftonline.com/xxxxxxx-xxxx-xxx/oauth2/v2.0/token
api-gateway-clientId=<Add API Gateway Client ID here>

```

#### Application using Client-Credentials Authentication

In this authentication grant type, security context can hold only the client ID but not the subject id/ user.
The framework expects the **client-ids** property to contain a machine-client mapping between the client ids and their corresponding generic ids. The APS library will retrieve the client id from the security context and pull the corresponding generic id from the map.

````
client-ids={<CLIENT_ID>:<GENERIC_ID>}

# sample entry for client-ids
# client-ids={'4176b352-f89d-9734-58c5-30148e7262ad':'deven2'}
# client-ids={'23u6b352-f89d-9734-58c5-30148e7262e5':'deven1','4176b352-f89d-9734-58c5-30148e7262ad':'deven2'}

````

### Spring Boot Configuration 

The required services in APS Spring Client can be loaded into the application context by adding the EnableAPSService annotation to the main class.
```
@SpringBootApplication
@EnableApsService
public class ApsclientApplication {
	public static void main(String[] args) {
		SpringApplication.run(ApsclientApplication.class, args);
	}
}
```

#### Method Level Authorization for the Application

On top of the API Method in your [Controller](./src/main/java/com/ford/devenablement/aps/hello/HelloController.java), used `@PreAuthorize` annotation as shown below.

<ins>Note</ins> : The Pattern within `@PreAuthorize` annotation is : `'APS_APP_NAME:RESOURCE_NAME' , 'ACTION_NAME' `. In this example it is `'CABAPS:Bookings', 'read'`

```
@RestController
@RequestMapping(path = "/api/v1/hello")
public class HelloController {

   @Autowired
    private HelloService helloService;

    @PreAuthorize("@authorizeService.isAuthorized('CABAPS:Bookings','read')")
    @ApiOperation(value = "Hello Message", notes = "Returns a hello greeting")
    @GetMapping
    public HelloResponse getHelloMessage(){

        String message = "Hello ! We have validated that you are authorized by APS to access this resource";
        HelloResponse.HelloResponseResult result = HelloResponse.HelloResponseResult.builder().greeting(message).build();

        return HelloResponse.result(result, HelloResponse.class);
    }
  }

```

#### Invoking Authorize service directly

For scenarios that dictate the use of general means of authorization inside the application, the isAuthorized method from the AuthorizeService can be called directly. This method returns a boolean where true means **PERMIT** and false means **DENY**.

````
@RestController
@RequestMapping(path = "/api/v1/hello")
public class HelloController {

    @Autowired
    private AuthorizeService authorizeService;
    
    @ApiOperation(value = "Hello Message", notes = "Returns a hello greeting")
    @GetMapping(path="/pdp")
    public HelloResponse getHelloMessageByInvokingPDPService() throws ApsClientException {
        if(authorizeService.isAuthorized("CABAPS:Bookings","read")) {
            String message = "Hello ! We have validated that you are authorized by APS to access this resource";
            HelloResponse.HelloResponseResult result = HelloResponse.HelloResponseResult.builder().greeting(message).build();
            return HelloResponse.result(result, HelloResponse.class);
        } else {
            throw new AccessDeniedException("access is denied");
        }

    }
}

````

#### Multi-Decision Point for the *user* of the current application

Multi-Decision Point (MDP) service is the authorization service that evaluates user access requests against authorization policies and provides decisions for all the resources of a given application.

```
@RestController
@RequestMapping(path = "/api/v1/hello")
public class HelloController {

   @Autowired
    private HelloService helloService;

    @ApiOperation(value = "MDP", notes = "Multi Decision point for the current user")
    @GetMapping(path = "/mdp")
    public MdpResponse getAllDecisions() throws ApsClientException {
        return helloService.getDecisions();
    }

}
```
Sample code to consume MdpService is available in [HelloService.java](./src/main/java/com/ford/devenablement/aps/hello/HelloService.java)


#### Note for SPAs

The MDP service is used to retrieve all decisions for the current user. It is the ideal use case for SPAs to leverage and can be used to improve the performance of the application by fetching all the decisions in one call. This can be achieved by sending the subject-ID / User-ID and setting the DecisionType as `DecisionType.ALL`. Application team can expose the MDP service call as an endpoint which can be consumed by the SPA and the pages can be rendered based on the decisions received.

#### Data Level Security for the user

To access DLS and Resource from APS, add the below property in the application.properties.

```
aps-url=<ENTER_THE_HOST_URL_FOR_APS_DLS>
```

There are two DLS functionalities available in `ApsDlsService` :-

1. **Role Assignment** - This is used to retrieve the role related data (including the data attributes and values they have access for) when the user is known.
2. **User DLS** - This is used to retrieve the user data (a list of users) when the role related data is known.



A sample controller method to get all roles for the current user is shown below. This is a use case for **Role Assignment**

```
@RestController
@RequestMapping(path = "/api/v1/dls")
public class DlsController {

    @Autowired
    private DlsService dlsService;

    @ApiOperation(value = "RoleAssignment", notes = "Returns roles for the current user")
    @GetMapping
    public HelloResponse getRoles() throws ApsClientException {

        String message = "Hello ! We have validated that you are authorized by APS to access this resource - ";
        message += dlsService.getRolesForCurrentUser().stream().map(Object::toString)
                .collect(Collectors.joining(" , "));
        HelloResponse.HelloResponseResult result = HelloResponse.HelloResponseResult.builder().greeting(message).build();
        return HelloResponse.result(result, HelloResponse.class);
    }
}
```

A sample controller method to get all users associated with the **Booking Viewer** role is shown below. This is a use case for **User DLS**

```
@RestController
@RequestMapping(path = "/api/v1/dls")
public class DlsController {

    @Autowired
    private DlsService dlsService;

    @ApiOperation(value = "UserDLS", notes = "Returns roles for the current user")
    @GetMapping("/users")
    public HelloResponse getUsers() throws ApsClientException {

        String message = "Hello ! We have validated that you are authorized by APS to access this resource. The following users have the Booking Viewer role in CABAPS - ";
        message += dlsService.getUsersForBookingViewerRole();
        HelloResponse.HelloResponseResult result = HelloResponse.HelloResponseResult.builder().greeting(message).build();
        return HelloResponse.result(result, HelloResponse.class);
    }
}
```

Sample code to consume APS DLS Service is available in [DlsService.java](./src/main/java/com/ford/devenablement/aps/dls/DlsService.java).

The [getRolesForCurrentUser](./src/main/java/com/ford/devenablement/aps/dls/DlsService.java#L29) method uses the **Role Assignment** functionality.

The [getUsersForBookingViewerRole](./src/main/java/com/ford/devenablement/aps/dls/DlsService.java#L45) method uses the **User DLS** functionality.

More details on the request and response structures and usage can be found in the [Wiki](https://github.ford.com/JCOE/aps-spring-client/wiki/APS%E2%80%AFDLS%E2%80%AFService%E2%80%AF)

#### Enable APS Caching

The APS Spring Client can be used either without a cache or with a Redis Cache. It can be a service instance in PCF or a hosted Redis outside PCF. Other caches, including in-memory caches are not supported as of the current release, but will be worked on in the future.

Refer the Framework wiki page for more details on configuring [APS Caching](https://github.ford.com/JCOE/aps-spring-client/wiki/Configuring-the-framework#aps-caching)


## APS Onboarding Process

### Application Pre-registration

The first step is to pre-register your application using the APS teams [pre-registration form](https://it2.spt.ford.com/sites/AccessMgmt/APSPreregistrationList/Lists/APS%20Preregistration%20List).

You will need to provided information such as: Application Acronym, Application Name, ITMS number, Business Owner, and Administrators.


### Requirement Gathering with Business Analyst

An APS business analyst will contact the application team to gather the requirements, and make sure the APS is appropriate for the application authorization.

### Request the APS EDU environment setup

The analyst will give your detailed steps to submit the APS EDU environment setup for your application through the [ITConnect request system](https://www.itconnect.ford.com/ux/myitapp/#/catalog/category?type=SBE&id=234).

Start the application support request, search and select:

13864-Application Policy Services - APS,SPS,MCS(APS)

Application Environment: EDU
Add two administrator's CDS ids in Detailed Description of the request.

After environment is setup, APS business analyst will guide the administrator how to setup the roles and how to use the APS Access Management. 

### Request the APS Production environment setup

Following the same process as APS EDU environment setup, submit a new request for the APS Production environment setup for your application. 

*This GUIDE project was generated by [**Spring EcoBoost**](http://x.ford.com/spring-ecoboost)*

