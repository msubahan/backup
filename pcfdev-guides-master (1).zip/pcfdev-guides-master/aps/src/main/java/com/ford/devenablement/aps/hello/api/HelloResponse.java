package com.ford.devenablement.aps.hello.api;


import com.ford.cloudnative.base.api.BaseBodyResponse;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

public class HelloResponse extends BaseBodyResponse<HelloResponse.HelloResponseResult> {

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class HelloResponseResult {
        String greeting;
    }

}