package com.ford.devenablement.aps.hello;

import com.ford.aps.core.exception.ApsClientException;
import com.ford.aps.core.mdp.MdpResponse;
import com.ford.aps.spring.service.ApsPdpService;
import com.ford.aps.spring.service.AuthorizeService;
import com.ford.devenablement.aps.hello.api.HelloResponse;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.context.request.WebRequest;


@RestController
@RequestMapping(path = "/api/v1/hello")
public class HelloController {



    @Autowired
    private HelloService helloService;

    @Autowired
    private AuthorizeService authorizeService;

    @PreAuthorize("@authorizeService.isAuthorized('CABAPS:Bookings','read')")
    @ApiOperation(value = "Hello Message", notes = "Returns a hello greeting")
    @GetMapping
    public HelloResponse getHelloMessage(){

        String message = "Hello ! We have validated that you are authorized by APS to access this resource";
        HelloResponse.HelloResponseResult result = HelloResponse.HelloResponseResult.builder().greeting(message).build();

        return HelloResponse.result(result, HelloResponse.class);
    }

    @ApiOperation(value = "Hello Message", notes = "Returns a hello greeting")
    @GetMapping(path="/pdp")
    public HelloResponse getHelloMessageByInvokingPDPService() throws ApsClientException {
        if(authorizeService.isAuthorized("CABAPS:Bookings","read")) {
            String message = "Hello ! We have validated that you are authorized by APS to access this resource";
            HelloResponse.HelloResponseResult result = HelloResponse.HelloResponseResult.builder().greeting(message).build();
            return HelloResponse.result(result, HelloResponse.class);
        } else {
            throw new AccessDeniedException("access is denied");
        }

    }

    @PreAuthorize("@authorizeService.isAuthorized('CABAPS:Bookings','update')")
    @ApiOperation(value = "Hello Message", notes = "Returns a hello greeting")
    @GetMapping(path = "/not")
    public HelloResponse thisShouldCauseNotAuthorized() {
        HelloResponse.HelloResponseResult result = HelloResponse.HelloResponseResult.builder().greeting("Hello !! You are Authorized to access").build();
        return HelloResponse.result(result, HelloResponse.class);
    }

    @ApiOperation(value = "MDP", notes = "Multi Decision point for the current user")
    @GetMapping(path = "/mdp")
    public MdpResponse getAllDecisions() throws ApsClientException {
        return helloService.getDecisions();
    }

    @ExceptionHandler({AccessDeniedException.class})
    public ResponseEntity<Object> handleAccessDeniedException(Exception ex, WebRequest request) {
        if (ex.getMessage().toLowerCase().indexOf("access is denied") > -1) {
            return new ResponseEntity<Object>("Hello !! You are not Authorized by APS to access the Resource", new HttpHeaders(), HttpStatus.UNAUTHORIZED);
        }
        return new ResponseEntity<Object>(ex.getMessage(), new HttpHeaders(), HttpStatus.INTERNAL_SERVER_ERROR);
    }
}