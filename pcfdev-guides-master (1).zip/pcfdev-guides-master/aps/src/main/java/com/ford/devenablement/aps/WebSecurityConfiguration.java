package com.ford.devenablement.aps;

import org.springframework.beans.factory.ObjectProvider;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.actuate.autoconfigure.security.servlet.EndpointRequest;
import org.springframework.boot.autoconfigure.security.SecurityProperties;
import org.springframework.boot.autoconfigure.security.servlet.UserDetailsServiceAutoConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.annotation.Order;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.oauth2.core.OAuth2Error;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.security.oauth2.jwt.JwtDecoder;
import org.springframework.security.oauth2.jwt.JwtValidationException;
import org.springframework.security.provisioning.InMemoryUserDetailsManager;

import java.util.Arrays;

import static org.springframework.security.oauth2.jwt.JwtClaimNames.AUD;


@EnableWebSecurity
@EnableGlobalMethodSecurity(prePostEnabled = true)
public class WebSecurityConfiguration {

    @Configuration
    @Order(10)
    public static class ResourceServerSecurityConfiguration extends WebSecurityConfigurerAdapter {

        @Value("${audience-id}")
        String audience;

        @Autowired
        JwtDecoder jwtDecoder;

        @Override
        protected void configure(HttpSecurity http) throws Exception {
            JwtDecoder newJwtDecoder = wrapJwtDecoderWithAudienceCheck(this.jwtDecoder, audience);

            http
                    .antMatcher("/api/**")
                    .csrf()
                    .disable()
                    .authorizeRequests()
                    .antMatchers("/api/v1/hello/**").authenticated()
                    .anyRequest().authenticated()
                    .and()
                    .sessionManagement()
                    .sessionCreationPolicy(SessionCreationPolicy.STATELESS)
                    .and()
                    .oauth2ResourceServer()
                    .jwt()
                    .decoder(newJwtDecoder)
            ;
        }

    }

    // helper
    static JwtDecoder wrapJwtDecoderWithAudienceCheck(JwtDecoder jwtDecoder, String audience) {
        return (token) -> {
            System.out.println("Logging for audience->" + audience);
            String[] audienceIdList = audience.split(",");
            Jwt jwt = jwtDecoder.decode(token);
            if (jwt.containsClaim(AUD) && doesNotContainEitherAudienceId(audienceIdList, jwt)) {
                throw new JwtValidationException("Audience field does not match: " + audience,
                        Arrays.asList(new OAuth2Error("invalid_aud")));
            }
            return jwt;
        };
    }

    private static boolean doesNotContainEitherAudienceId(String[] audienceIdList, Jwt jwt) {
        return Arrays.stream(audienceIdList).filter(audienceId -> {
            return jwt.getClaimAsStringList(AUD).contains(audienceId);
        }).count() == 0;
    }

    /*****************************************************************************************************************
     * Other - Basic/Public
     *****************************************************************************************************************/

    @Configuration
    @Order(30)

    public static class HttpSecurityConfiguration extends WebSecurityConfigurerAdapter {

        @Override
        protected void configure(HttpSecurity http) throws Exception {
            http
                    .csrf()
                    .disable()
                    .authorizeRequests()
                    .antMatchers("/").permitAll()
                    .antMatchers("/csrf").permitAll()
                    .antMatchers("/swagger-ui.html", "/swagger-resources/**", "/webjars/**", "/v2/api-docs").permitAll()
                    .requestMatchers(EndpointRequest.to("info", "health")).permitAll() // actuator
                    .anyRequest().authenticated()
                    .and()
                    .sessionManagement()
                    .sessionCreationPolicy(SessionCreationPolicy.STATELESS)
                    .and()
                    .httpBasic()
            ;
        }
    }

    @Bean
    public InMemoryUserDetailsManager inMemoryUserDetailsManager(
            SecurityProperties properties, ObjectProvider<PasswordEncoder> passwordEncoder) {

        return new UserDetailsServiceAutoConfiguration().inMemoryUserDetailsManager(properties, passwordEncoder);
    }

}
