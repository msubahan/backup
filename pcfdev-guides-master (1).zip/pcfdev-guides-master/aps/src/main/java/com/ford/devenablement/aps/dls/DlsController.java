package com.ford.devenablement.aps.dls;

import com.ford.aps.core.exception.ApsClientException;
import com.ford.devenablement.aps.hello.api.HelloResponse;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.stream.Collectors;

@RestController
@RequestMapping(path = "/api/v1/dls")
public class DlsController {

    @Autowired
    private DlsService dlsService;

    @ApiOperation(value = "RoleAssignment", notes = "Returns roles for the current user")
    @GetMapping("/roles")
    public HelloResponse getRoles() throws ApsClientException {

        String message = "Hello ! We have validated that you are authorized by APS to access this resource. You have the following roles in CABAPS - ";
        message += dlsService.getRolesForCurrentUser().stream().map(Object::toString)
                .collect(Collectors.joining(" , "));
        HelloResponse.HelloResponseResult result = HelloResponse.HelloResponseResult.builder().greeting(message).build();
        return HelloResponse.result(result, HelloResponse.class);
    }
    @ApiOperation(value = "UserDLS", notes = "Returns roles for the current user")
    @GetMapping("/users")
    public HelloResponse getUsers() throws ApsClientException {

        String message = "Hello ! We have validated that you are authorized by APS to access this resource. The following users have the Booking Viewer role in CABAPS - ";
        message += dlsService.getUsersForBookingViewerRole();
        HelloResponse.HelloResponseResult result = HelloResponse.HelloResponseResult.builder().greeting(message).build();
        return HelloResponse.result(result, HelloResponse.class);
    }
}
