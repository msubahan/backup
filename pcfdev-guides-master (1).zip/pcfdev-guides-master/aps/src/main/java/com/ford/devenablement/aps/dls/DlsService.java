package com.ford.devenablement.aps.dls;

import com.ford.aps.core.dls.RoleAssignmentResponse;
import com.ford.aps.core.exception.ApsClientException;
import com.ford.aps.core.mdp.DecisionType;
import com.ford.aps.core.mdp.MdpResponse;
import com.ford.aps.spring.api.RoleAssignmentDlsRequest;
import com.ford.aps.spring.api.UserDlsRequest;
import com.ford.aps.spring.service.ApsDlsService;
import com.ford.aps.spring.service.ApsMdpService;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
@RequiredArgsConstructor
public class DlsService {

    private final ApsDlsService apsDlsService;


    @Value("#{${client-ids:{null:null}}}")
    private Map<String, String> clientIds;

    public List<String> getRolesForCurrentUser() throws ApsClientException {

        RoleAssignmentDlsRequest roleAssignmentDlsRequest = new RoleAssignmentDlsRequest();
        roleAssignmentDlsRequest.setUserName(getUserName());

        List<String> roles = new ArrayList<>();

        RoleAssignmentResponse roleAssignmentResponse = apsDlsService.getRoleAssignments(roleAssignmentDlsRequest);
        roleAssignmentResponse.getRoleAssignments().stream().forEach(
                roleAssignment -> {
                    roles.add(roleAssignment.getRoleName());
                }
        );
        return roles;
    }

    public List<String> getUsersForBookingViewerRole() throws ApsClientException{
        UserDlsRequest userDlsRequest = new UserDlsRequest();
        userDlsRequest.setRoles(Collections.singletonList("Booking Viewer"));
        return apsDlsService.retrieveUserDlsData(userDlsRequest).getUsers();
    }

    private String getUserName() {
        String userName = null;
        Optional<Object> user = Optional.ofNullable(SecurityContextHolder.getContext().getAuthentication().getPrincipal());
        Object availableUser = user.get();
        Jwt availableUserJwt = (Jwt) availableUser;
        String clientId = Optional.ofNullable(availableUserJwt.getClaims()).isPresent() ?
                (String) availableUserJwt.getClaims().getOrDefault("appid", "")
                : null;
        if (Optional.ofNullable(clientIds).isPresent()) {
            userName = clientIds.getOrDefault(clientId, null);
        }
        return userName;
    }
}
