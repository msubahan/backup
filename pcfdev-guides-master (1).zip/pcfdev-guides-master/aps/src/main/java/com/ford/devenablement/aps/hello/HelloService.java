package com.ford.devenablement.aps.hello;

import com.ford.aps.core.exception.ApsClientException;
import com.ford.aps.core.mdp.DecisionType;
import com.ford.aps.core.mdp.MdpResponse;
import com.ford.aps.spring.service.ApsMdpService;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.stereotype.Service;

import java.util.Map;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class HelloService {

    private final ApsMdpService apsMdpService;

    @Value("#{${client-ids:{null:null}}}")
    private Map<String, String> clientIds;

    public MdpResponse getDecisions() throws ApsClientException {
        MdpResponse response = apsMdpService.getDecisionsFor(getUserName(), DecisionType.ALL);
        return response;
    }

    private String getUserName() {
        String userName = null;
        Optional<Object> user = Optional.ofNullable(SecurityContextHolder.getContext().getAuthentication().getPrincipal());
        Object availableUser = user.get();
        Jwt availableUserJwt = (Jwt) availableUser;
        String clientId = Optional.ofNullable(availableUserJwt.getClaims()).isPresent() ?
                (String) availableUserJwt.getClaims().getOrDefault("appid", "")
                : null;
        if (Optional.ofNullable(clientIds).isPresent()) {
            userName = clientIds.getOrDefault(clientId, null);
        }
        return userName;
    }

}
