package com.ford.devenablement.aps;

import com.ford.aps.spring.configuration.EnableApsService;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
@EnableApsService
public class ApsClientApplication {
	public static void main(String[] args) {
		SpringApplication.run(ApsClientApplication.class, args);
	}
}
