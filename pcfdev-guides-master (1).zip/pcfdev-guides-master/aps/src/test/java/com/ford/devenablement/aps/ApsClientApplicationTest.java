package com.ford.devenablement.aps;

import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class ApsClientApplicationTest {
	@Test
	public void contextLoads() {
	}
}