## Dev Guides

This repo is a collection of examples demonstrating specific capabilities, recommendations, starter projects, high-level solutions, integrations, and more. It covers examples that are not already provided by Pivotal unless additional special configuration is required to get them implemented in Ford environments.

**Note:** You can generate projects based on our guide examples using [Spring EcoBoost](http://x.ford.com/spring-ecoboost).

#### Find a Guide

You can look at the folders in this repo, or alternatively you can use our [Dev Guides UI](https://dev-services.apps.pd01i.edc1.cf.ford.com/dev-guides) in our Dev Services app which will allo you to easily search/filter our growing list of guides.


#### Other Examples

Did not find a guide that covers a specific topic? Try visiting [Spring Guides](https://spring.io/guides) and [Spring Boot Samples Repo](https://github.com/spring-projects/spring-boot/tree/master/spring-boot-tests/spring-boot-smoke-tests) for additional examples maintained by Pivotal. 

In addition to the Spring.io site maintained by pivotal, the [https://www.baeldung.com/](https://www.baeldung.com/) site offers a wealth of documentation and guides that are useful for the Cloud Native/Spring Boot developer.

#### Further Assistance
Feel free to reach out to us on the Dev Enablement [discussion forum](https://go.ford/devhub) for suggestions, feedback, or any questions.
