# PCF Hosted Redirector

## Description

From time to time an application team needs to map a vanity URL or previous application route to another location.
This guide demonstrates a simple redirect page hosted using an NGINX webserver, which is made avaiable when using the static buildpack in PCF.
To learn more about the static buildpack see our [static buildpack guide](../static-buildpack/README.md).

## Directory Structure

```
.
├── dist
│   ├── Staticfile
│   └── index.html
└── manifest.yml
```

## Index.html

Change the URL in the redirect function.

```java
<html>
	<head>
		<title>Redirector</title>
		<script>
			function redirect() {
				document.location="https://www.google.com";
			}
		</script>
	</head>
	<body onload="redirect()">
	<H3>Redirecting...</H3>
	</body>
</html>
```

## Manifest.yml
Change the application name as appropriate.  Note it pushes the content of the dist directory. 

```yaml
applications:
- name: googleredirecter
  path: dist/
  memory: 128M
  buildpacks:
  - staticfile_buildpack
  instances: 1
```

## Routes
The routes to be redirected will need to be mapped to the application.  A vanity URL can be requested using FCP if needed.

To create the route, use the following command:
cf create-route [SPACE] [DOMAIN] --hostname [HOSTNAME]

For example, if the vanity URL is: myapp.ford.com and the space name is myspace, it would be created as follows:
```
cf create-route myspace ford.com --hostname myapp
```
The route can then be mapped to the app using the App Manager GUI or from the command line.

cf map-route [APPNAME] [DOMAIN] -- hostname [HOSTNAME]

```
cf map-route mypcfapp ford.com --hostname myapp
```

You can easily unmap and delete these routes as well:

cf unmap-route [APPNAME] [DOMAIN] --hostname [HOSTNAME]
cf delete-route [DOMAIN] --hostname [HOSTNAME]

For example:

```
cf unmap-route mypcfapp ford.com --hostname myapp
cf delete-route ford.com --hostname myapp
```

PCF Operations will manage the certificate associated with the vanity URL in PCF. 
