## Ford Answers

![Ford Answers Icon](ford-answers-logo.png)


### What is Ford Answers?

Ford Answers is a tool that allows Software Developers to access a centralized knowledge base of Questions and Answers.

The tool was selected because of its similarity to Stack Overflow, which is a tool and process we are trying to 
emulate for our software development community.


### Why Ford Answers?

There are many collaboration tools that are in use today at Ford; Yammer, WebEx Teams, Slack, etc. This causes our 
collaboration that is Questions and Answers to become fragmented, difficult to find, and difficult to determine the 
value (is correct or not). The goals of Ford Answers is to centralize just the Questions & Answers part of what occurs
in collaboration channels, and to organize, structure, and curate the data so that it becomes easier to search, find, 
and trust. 


### Where is Ford Answers

To access Ford Answers, please visit [https://www.eesewiki.ford.com/questions](https://www.eesewiki.ford.com/questions). 
We encourage you to search for answers prior to asking a question.

If you want to drill down into Questions & Answers at a "Topic" level, visit 
https://www.eesewiki.ford.com/questions/topics. You can click on a specific topic to get a view into the Q&A that 
occurs at this more contextualize view. As an example, to learn more about PCF I would visit the 
"pivotal-cloud-foundry" topic page at https://www.eesewiki.ford.com/questions/topics/318570549/pivotal-cloud-foundry


### How to use Ford Answers

To see a wiki page on best practices and requesting login access, please visit the 
[Ford Answers How To Page](https://www.eesewiki.ford.com/pages/viewpage.action?pageId=330203305). 

> _**Note:**_ Login is required to Ask Questions, vote on answers, etc. Login is _**not**_ required to simply search 
> and read Questions and Answers.


### What Should I Put in Ford Answers (and what should I not)

##### Good Fits
  * Simple Questions that you think have simple answer.
    * Where do I go to request GitHub access?
    * Are applications running in PCF accessible from outside the Ford network?

##### Bad Fits
  * Opinionated Questions
    * Is Java the best programming language?
    * Is the Gitflow or GitHub Flow better as a git pattern? 
    * What application architecture should I use for my new dealer system?
    
  * Troublshooting conversations
    * I have the following stack trace, help me find root cause
    * Is GitHub Down?
