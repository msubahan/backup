# PCF Dev - SFTP Client Example

This project demonstrates how to use the Ford Standard SFTP client library in a Spring application. It's focus is to demonstrate what libraries are in use at Ford for SFTP, and how to use a cloud native apporach to file processing; that is we show how to read file content into memory via a stream as opposed to relying on the local file system to store the files.

The sample code assumes that:
- You have a SFTP Server running on localhost
- SFTP server accepts an login without a username as `tester` and password as `password`
- And there is a file in the home directory with the name `testfile.txt`

The hostname, id, and password can be changed via the application.properties file. The file names can be changed via local variables defined in the service class.
  
The example code does use an API to expose the results, but this is not necessary. Simply examine the [FetchService](src/main/java/com/ford/devenablement/sftp/fetch/FetchService.java) class to really understand the use of the library.

This project, like all the other guides, was built using [Spring EcoBoost](http://x.ford.com/spring-ecoboost), and thus adheres to the Application Architecture for API driven cloud native applications that EcoBoost provides.

