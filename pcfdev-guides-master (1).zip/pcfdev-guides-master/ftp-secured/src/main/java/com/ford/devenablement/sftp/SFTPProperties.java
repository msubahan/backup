package com.ford.devenablement.sftp;

import lombok.Data;

@Data
public class SFTPProperties {
    private String host;
    private String user;
    private String password;
    private Integer port;

}
