package com.ford.devenablement.sftp.fetch.api;

import com.ford.cloudnative.base.api.BaseBodyResponse;
import com.ford.devenablement.sftp.fetch.api.FetchResponse.FetchResponseResult;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

public class FetchResponse extends BaseBodyResponse<FetchResponseResult> {

	@Data
	@Builder
	@NoArgsConstructor
	@AllArgsConstructor
	public static class FetchResponseResult {
		String fileContents;
	}

}
