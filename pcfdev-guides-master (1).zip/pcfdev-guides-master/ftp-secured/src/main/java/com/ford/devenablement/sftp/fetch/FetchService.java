package com.ford.devenablement.sftp.fetch;

import com.ford.devenablement.sftp.SFTPProperties;
import com.jcraft.jsch.*;
import org.apache.commons.io.IOUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.nio.charset.StandardCharsets;

@Service
public class FetchService {
    public static final String FTP_FILE_NAME = "testfile.txt";
    public static final String CHANNEL_TYPE = "sftp";

    private SFTPProperties sftpProperties;


    @Autowired
    public FetchService(SFTPProperties sftpProperties) {
        this.sftpProperties = sftpProperties;
    }


    public String getContentsFromFile() {

        ChannelSftp channelSftp = getSFTPChannel();
        String fileContents = "";

        try {
            fileContents = IOUtils.toString(channelSftp.get(FTP_FILE_NAME), StandardCharsets.UTF_8.name());
        } catch (SftpException ex) {
            throw new IllegalStateException("Cannot get file from SFTP Channel", ex);
        } catch (IOException ioex) {
            throw new IllegalStateException("Cannot read the file from Input Stream", ioex);
        } finally {
            quietlyDisconnect(channelSftp);
        }

        return fileContents;
    }

    private ChannelSftp getSFTPChannel() {

        Session session = getSession();
        Channel channel = null;
        try {
            channel = session.openChannel(CHANNEL_TYPE);
            channel.connect();
        } catch (JSchException ex) {
            quietlyDisconnect(channel);
            throw new IllegalStateException("Cannot connect to SFTP Channel", ex);
        }

        return (ChannelSftp) channel;
    }


    private Session getSession() {

        Session session = null;
        try {
            JSch jSch = new JSch();
            session = jSch.getSession(sftpProperties.getUser(), sftpProperties.getHost(), sftpProperties.getPort());
            session.setPassword(sftpProperties.getPassword());
            session.setConfig("StrictHostKeyChecking", "no");
            session.connect();
        } catch (JSchException ex) {
            quietlyDisconnect(session);
            throw new IllegalStateException("Cannot create session to SFTP Server", ex);
        }

        return session;
    }


    private void quietlyDisconnect(Channel channel) {
        try {
            if (null != channel) {
                channel.disconnect();
            }

            quietlyDisconnect(channel.getSession());

        } catch (Throwable e) {
            //quiet methods ignore exceptions!
        }
    }

    private void quietlyDisconnect(Session session) {
        try {
            if (null != session) {
                session.disconnect();
            }
        } catch (Throwable e) {
            //quiet methods ignore exceptions!
        }
    }


}
