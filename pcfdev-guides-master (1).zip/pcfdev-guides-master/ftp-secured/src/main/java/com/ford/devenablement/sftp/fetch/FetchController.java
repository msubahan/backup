package com.ford.devenablement.sftp.fetch;


import com.ford.devenablement.sftp.fetch.api.FetchResponse;
import com.ford.devenablement.sftp.fetch.api.FetchResponse.FetchResponseResult;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping(path = "/api/v1/fetch")
public class FetchController {

    private FetchService fetchService;

    @Autowired
    public FetchController(FetchService fetchService) {
        this.fetchService = fetchService;
    }

    @GetMapping
    public ResponseEntity<FetchResponse> getFileContents() {
        String fileContents = fetchService.getContentsFromFile();
        FetchResponseResult result = FetchResponseResult.builder().fileContents(fileContents).build();

        return ResponseEntity.ok(FetchResponse.result(result, FetchResponse.class));
    }

}
