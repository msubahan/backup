package com.ford.devenablement.sftp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SFTPApplication {

	public static void main(String[] args) {
		SpringApplication.run(SFTPApplication.class, args);
	}

}
