### Table of Contents

- [Overview](#overview)
  - [Purpose](#purpose)
  - [Project Files](#project-files)
- [Core Features](#core-features)
  - [Gradle Boost Plugin](#gradle-boost-plugin)
  - [Lombok](#lombok)
- [Recommended Web Features](#recommended-web-features)
  - [API Documentation (Swagger)](#api-documentation-swagger)
  - [Monitoring (Actuator)](#monitoring-actuator)
  - [Distributed Tracing (Sleuth)](#distributed-tracing-sleuth)
  - [X-Application-Info response header](#x-application-info-response-header)
  - [X-Request-Info response header](#x-request-info-response-header)
  - [Common Error Handling](#common-error-handling)
  - [Testing](#testing)
- [Other Recommendations](#other-recommendations)
  - [Single GitHub Repo](#single-github-repo)
- [Build and Deploy](#build-and-deploy)
  - [Build Project Requirements](#build-project-requirements)
  - [Deploy to Cloud Foundry](#deploy-to-cloud-foundry)

<br/>

# Overview

### Purpose

This project serves as a recommended barebones starter project for other services. In fact, all [Dev Enablement Dev Guides](https://devservices.ford.com/dev-guides) and [Spring EcoBoost](https://dcs.ford.com/project-workflow/springboot) generated projects are built on top of this base project. It benefits developers and guide readers to get acquainted with this project and all of its structure, features, and guidelines.

<br/>

### Project Files

As a barebones project, you will find very few files.

##### Gradle Files

At first glance, you will notice that the project is a Gradle Project with the typical files and directory structure:
- `build.gradle` script file that defines the project and its tasks
- `gradle` directory that contains the Gradle Wrapper files
- `src` directory that contains the application codebase

##### src Directory

This directory encapsulates the main Spring Boot application codebase.
- `src/main/java` production codebase contains one main application class [BaseServiceApplication.java](src/main/java/com/ford/devenablement/baseservice/BaseServiceApplication.java) and one minimal security configuration class [WebSecurityConfiguration.java](src/main/java/com/ford/devenablement/baseservice/WebSecurityConfiguration.java).
- `src/test/java` codebase contains the corresponding security test classes.
- `src/main/resources` hosts the [application.properties](src/main/resources/application.properties) file that contains the properties that activate and configure the individual features described in the [Recommended Web Features](#recommended-web-features) section.

##### cf Directory

- `cf`[directory](cf) contains the Cloud Foundry manifest template and a settings file to tweak the template per environment.

##### Git Files

In the event this project is stored in a git repository on GitHub, this project includes sensible .gitignore and .gitattributes setting files.

<br/>

# Core Features

This section describes the project structure and use of dependencies that should be common to all projects.

### Gradle Boost Plugin

[Gradle Boost Plugin](https://github.ford.com/PCFDev-InnerSource/gradle-boost-plugin) is a Gradle plugin of reusable and useful Gradle tasks and configuration. Projects rely on the plugin to reduce common Gradle boilerplate and simplify the process of configuring different aspects of the project's build configuration. Notable plugin features include:

- Automatic Incremental Versioning support
- Manifest Generation (per environment)
- Simplifying Publishing & SonarQube configurations
- Generating a Dependency Report (TM compliance)
- Setting Build Properties (set actuator info)
- Setting Jar Manifest Info
- Configuring popular Ford Nexus Repos

In addition to the Gradle capability, teams that use [Gradle Boost Plugin](https://github.ford.com/PCFDev-InnerSource/gradle-boost-plugin) can also take advantage of the [PCF Dev jenkins pipelines](../pipeline-jenkins).  Out-of-the-box these Jenkins pipelines can support blue-green multi-foundation deployments, Nexus publishing, and SonarQube metrics.


<br/>

### Lombok

Lombok is a very useful Java annotation library that allows developers to code faster and avoid errors by generating boilerplate code on their behalf. Lombok can automatically generate constructors, getters, setters, toString, equals and hashCode methods. You create a class with fields and add one or more Lombok annotations (e.g. ```@Data```). That's it &mdash; Lombok will take care the rest for you! Lombok in fact can do a lot more for you with these [other annotations](http://projectlombok.org/features/). Notably it can also automatically generate a Builder class for your simple POJO objects with its ```@Builder``` annotation.

To enable Lombok, we add the following dependencies to your `build.gradle` file:
```
compileOnly 'org.projectlombok:lombok'
annotationProcessor 'org.projectlombok:lombok'
testAnnotationProcessor 'org.projectlombok:lombok'
```
Note that the versions are not specified, as they are provided by the Spring Boot pom file. When you update Spring Boot, you will get potentially new versions of Lombok.

A downside to Lombok is that it requires a one-time setup to get your favorite IDE to recognize and process its annotations. Fortunately they are simple steps:

##### Eclipse Setup

Before installing in Eclipse, you will want to download the approriate lombok jar file. In order to determine what lombok version to download, look at the Spring Boot dependecny list at [https://docs.spring.io/spring-boot/docs/2.2.7.RELEASE/reference/html/appendix-dependency-versions.html#dependency-versions](https://docs.spring.io/spring-boot/docs/2.2.7.RELEASE/reference/html/appendix-dependency-versions.html#dependency-versions) and look up the lombok component. You will need to change the version number in this URL to align withthe Spring Boot version you are using. After you know what version of lombok you need, you can download it from Ford Nexus. Here is an example URL for the 1.18.12 version of lombok: [http://www.nexus.ford.com/repository/external-proxy-group/org/projectlombok/lombok/1.18.12/lombok-1.18.12.jar](http://www.nexus.ford.com/repository/external-proxy-group/org/projectlombok/lombok/1.18.12/lombok-1.18.12.jar). After this download process, you can now follow these [Eclipse instructions](https://projectlombok.org/setup/eclipse).

##### IntelliJ Setup

Follow the following [IntelliJ instructions](https://projectlombok.org/setup/intellij). You must also enable annotation processing. Navigate to *File > Other Settings > Default Settings*. Search for *annotation*. Check the *Enable annotation processing* option. Click OK. Restart IntelliJ.

<br/>

# Recommended Web Features

This section goes into a discussion of individual features and how they were enabled or demonstrated in the project. One of the goals of this base project is to enable production-ready features with little to no noise added to the codebase. This is made possible by Spring Boot's support for auto-configuration and the [Ford Spring Boot starter](https://github.ford.com/DevEnablement/spring-base-dependencies/tree/master/spring-base-app) library. Most of the features below are enabled in the project by only modifying *build.gradle* and/or *application.properties*.

<br/>

### API Documentation (Swagger)

Swagger can automatically generate API documentation based off your controllers. It also offers a built-in interactive UI tool *(/swagger-ui.html)* that can test your service's endpoints. You can learn more about Spring and Swagger in this [Baeldung Tutorial](http://www.baeldung.com/swagger-2-documentation-for-spring-rest-api). We configure Swagger using properties found in *application.properties*.

<table>
<tr><td valign="top" width="200">build.gradle</td>
<td width="500"><em>
io.springfox:springfox-swagger2<br/>
io.springfox:springfox-swagger-ui<br/>
com.ford.cloudnative:spring-boot-starter-ford
</em></td></tr>
<tr><td valign="top" width="200">application.properties</td><td width="500"><em>cn.app.swagger.enabled=true<br/>cn.app.swagger.*</em></td></tr>
</table>

<br/>

### Monitoring (Actuator)

Your application can expose useful system and operational data thru Spring's Actuator endpoints. By default, Actuator will only publicly expose */acutator/info* and */acutator/health* endpoints. Actuator could be configured to expose additional data endpoints such metrics, configprops, heapdump, threadsdump, sessions, and more.  Refer to Spring's [Acutator Documentation](https://docs.spring.io/spring-boot/docs/current/reference/html/production-ready-endpoints.html) to learn more about Actuator and its capabilities.

<table>
<tr><td valign="top" width="200">build.gradle</td><td width="500"><em>org.springframework.boot:spring-boot-starter-actuator</em></td></tr>
</table>
<br/>


### Distributed Tracing (Sleuth)

Tracing allows us to track a single request's hops thru micro-services and more easily troubleshoot issues. Your project can rely on Spring Sleuth to provide tracing support. The request's sleuth trace id could be exposed by the *X-Request-Info* response header (see below).

<table>
<tr><td valign="top" width="200">build.gradle</td><td width="500"><em>org.springframework.cloud:spring-cloud-starter-sleuth</em></td></tr>
</table>

<br/>

### X-Application-Info response header

*X-Application-Info* response header exposes the application name and version.

```X-Application-Info: name=devenablement-service-base-service; version=build-1-g20e05b23d;```

When it comes to troubleshooting a client's request, this header helps teams more quickly identity the application and exact snapshot of the codebase which the issue occurred in. By enabling this feature, *X-Application-Info* header will be returned in ALL responses.

<table>
<tr><td valign="top" width="200">build.gradle</td><td width="500"><em>com.ford.cloudnative:spring-boot-starter-ford</em></td></tr>
<tr><td valign="top" width="200">application.properties</td><td width="500"><em>cn.app.application-info-header.enabled=true</em></td></tr>
</table>

<br/>


### X-Request-Info response header

*X-Request-Info* response header exposes request-related data points such as timestamp, execution time, and (sleuth trace) reference Id.

```X-Request-Info: timestamp=1521639564; execution=4; referenceId=6da72fd8a3534535;```

This header's information can be used for both metrics reports and troubleshooting a specific client's request. By enabling this feature, *X-Request-Info* header will be returned in ALL responses.

<table>
<tr><td valign="top" width="200">build.gradle</td><td width="500"><em>com.ford.cloudnative:spring-boot-starter-ford</em></td></tr>
<tr><td valign="top" width="200">application.properties</td><td width="500"><em>cn.app.request-info-header.enabled=true</em></td></tr>
</table>

<br/>


### Common Error Handling

Do not have specific error response requirements yet? Start off by adopting the CloudNative API's standard and flexible error structure. The error structure supports an error code, one or more error messages, field-level validations, and extensible attributes -- all optional fields. Enabling this feature will automatically handle the conversion of internal and thrown application errors into the standard error structure. This feature even handles hibernate field-level errors elegantly.<br/>

Refer to the [Rest Controller Guide](../rest-controller) to learn more about the standard body and error responses.

<table>
<tr><td valign="top" width="200">build.gradle</td><td width="500"><em>com.ford.cloudnative:spring-boot-starter-ford</em></td></tr>
<tr><td valign="top" width="200">application.properties</td><td width="500"><em>cn.app.exception-handler.enabled=true</em></td></tr>
</table>

<br/>

### Testing
Every Ecoboost app is generated with unit tests and acceptance tests, these tests use the WebClient and WebTestClient.

For more information on using our pattern with acceptance tests, see the [Jenkins Pipeline DevGuide](https://github.ford.com/DevEnablement/pcfdev-guides/tree/master/pipeline-jenkins).

See these resources for more information on using WebClient and WebTestClient:

* [https://docs.spring.io/spring/docs/current/spring-framework-reference/pdf/testing-webtestclient.pdf](https://docs.spring.io/spring/docs/current/spring-framework-reference/pdf/testing-webtestclient.pdf)
* [https://www.baeldung.com/spring-5-webclient](https://www.baeldung.com/spring-5-webclient)


# Other Recommendations

### Single GitHub Repo

Each service project should have its own GitHub repo. Single-service repos allows for smaller codebases, easier troubleshooting, reduced build times, independent deployments, and decreased risk of code collisions. Repo name should follow the naming convention ```[TEAM NAME]-service-[SERVICE NAME]```.


<br/>

# Build and Deploy

### Build Project Requirements

We currently recommend Java 11 for your new Spring Boot applications, but at this time only *JDK 8* is required to build and run new EcoBoost projects on your machine in a terminal window. None of the sample code or other constructs in a new application use any of the new Java features introduced in Java 9 or above, but that may change in the future as Java 8 will go out of support in 2020.

To build and run the application on Windows Command Prompt...
```
gradlew build
gradlew bootRun
```

To build and run in Windows Git Bash Or Mac 
```
./gradlew build
./gradlew bootRun
```

To build and run the projects in Eclipse or IntelliJ you must also perform additional instructions as described in the [Lombok](#lombok) section.


<br/>


### Deploy to Cloud Foundry

To deploy your service to Cloud Foundry, you must have access to a Cloud Foundry space with permissions to *push* an application. You also need to install the *cf* cli tool.

#### CF Login Session

Before you get started with *cf*, you must first login into the CF space in which you will deploy this application. Going forward this tutorial will be based on Pre-Prod EDC1 CF space and the plans it offers.  **Windows users must run the following command in Command Prompt and NOT in Git Bash. Going forward all other remaining commands should be executed in Git Bash.**

```
cf login -a https://api.sys.pp01.edc1.cf.ford.com -o [INSERT-ORG-NAME] -s [INSERT-SPACE-NAME] -sso
```

>Note: Our [Dev Services portal](https://devservices.ford.com) contains a nice utility for providing the appropriate CF login command for each of the PCF foundations at Ford. See the [PCF Foundation Information tool](https://devservices.ford.com/version-information).


#### CF Push Application

Before you push the application, you must first build the application and generate a manifest file. The application's manifest file is used while pushing the application by the cf tool and it defines settings such as hostname, number of instances, services, environment variables and more.  The manifest file settings may differ per environment. For this reason, the project relies on a [manifest template](cf/manifest-template.yml) file, [manifest settings](cf/manifest-template-settings.json) file, and Gradle Boost Plugin's ```cfManifest``` task to drive the generation of the manifest file for a particular environment. 


>NOTE: You will need to take note of the manifest file that is generated as it may contain bindings to services that you have yet to create in PCF. These bindings are configured as the result of some of the options available when you configured your project with EcoBoost. For instance, selecting the "External Configuration" option will result in an application needing to bind to a config server as well as a rabbit instance. A ```cf push``` using the generated manifest in this case will result in an error indicating "Could not find service...". Our [Jenkins offering](https://github.ford.com/DevEnablement/pcfdev-guides/tree/master/pipeline-jenkins) provides a script to auto-create these dependent services prior to first push to PCF.

Change directory to this project's root directory and run the following commands.

If using Git Bash (or linux/unix/mac/etc.):
```
./gradlew build

export cfManifestTarget=dev-edc1

./gradlew cfManifest

cf push -f manifest-generated.yml
```

If using Windows CMD prompt:
```
gradlew build

set cfManifestTarget=dev-edc1

gradlew cfManifest

cf push -f manifest-generated.yml
```


>NOTE: While pushing the application to CF, if you encounter an error relating to host name is already in use, then you must use a different name. Teams share domains across different spaces and conflicts can arise. To use a different domain name, you can pass an additional argument to cf push; e.g. *cf push -f manifest.yml --hostname different-service-name*.

Your application should be deployed now. Look at the log output in your terminal from pushing your app, it should contain your app's host name. Using your browser, you can navigate to *http://[app-host-name]/actuator/info* to view your application's info or *http://[app-host-name]/actuator/health* to view the applications status in a simple "UP or DOWN" JSON response.
