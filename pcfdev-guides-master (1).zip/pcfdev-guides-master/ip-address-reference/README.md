# IP Address Reference Guide

Below you can find a list of the IP ranges for all foundations. IP addresses are often required for whitelisting access for firewall or external access situations.

You can also consider using our [Willitconnect tool]( https://devservices.ford.com/willitconnect ) for determining  outbound access from a PCF Foundation.

### US-EDC1-NAT
|NAT Device   | us-edc1-preprod   | us-edc1-Prod    |
|-------------|-------------------|------------------|
|Firewall     | 19.13.208.192/28	| 19.13.208.208/28 |


### US-EDC2-NAT
|NAT Device   | us-edc2-preprod| us-edc2-prod|
|-------------|-------------------|------------------|
|Firewall     | 19.69.208.192/28	| 19.69.208.208/28 |


### US-Azure East
| NAT Gateway | us-east-preprod | us-east-prod |
|---------|------|---------|
| Shared Diego | 52.224.184.69, 20.42.31.38, 52.188.216.41, 20.185.210.90, 20.62.190.72/29(SUBNET) |52.191.232.136, 52.224.203.109, 52.188.136.149, 52.188.136.191, 52.234.169.216/29|
| VSDN Isolated |52.224.185.247, 52.147.221.82, 52.152.199.144, 52.191.91.225 | 52.191.239.146, 52.142.23.107, 52.142.16.41, 52.151.225.169 |
| VSDN Token Iso | 52.224.201.253 | 52.191.233.177 |
| Khafka Isolated | 104.45.173.254 | 52.190.25.156 |
| MTLS Segment | 20.62.149.104/29 | 52.226.0.176/29 |


### US-Azure West
| NAT Gateway | us-west-preprod | us-west-prod |
|---------|------|---------|
| Shared Diego | 13.91.150.78, 13.83.96.180, 13.86.250.34, 13.86.251.86 | 13.91.151.223, 13.83.70.222, 13.87.216.17, 13.86.250.171 |
| VSDN Isolated | 20.189.140.126 | 13.91.148.242, 13.86.252.84, 13.86.251.49, 13.86.184.159 |
| VSDN Token Iso | 20.189.137.14 | 13.83.240.21 |
| Khafka Isolated | 20.189.136.181 | 13.83.245.16 |
| MTLS Segment | 52.250.198.128/29 | 13.73.57.128/29 |


### US-AWS-West
|NAT Gateway   | us-west2-Pre-Prod| ~~us-west2-Prod~~|
|-------------|----------------|----------------|
|AZ-2a| 52.25.230.92   | ~~54.186.205.188~~ |
|AZ-2b| 54.214.169.93  | ~~44.225.31.198~~ |
|AZ-2c| 44.231.220.200 | ~~34.210.128.102~~ |


### China-Azure North
| NAT Gateway | cn-north-preprod | cn-north-prod |
|---------|------|---------|
| Shared Diego | 40.73.41.85, 40.73.43.135, 40.73.45.149, 40.73.45.181 | 40.73.41.133, 40.73.45.95, 40.73.45.97, 40.73.45.133 |
| VSDN Isolated | 40.73.41.101, 40.73.45.183, 40.73.45.184, 40.73.45.185 | 40.73.41.106, 40.73.42.191, 40.73.43.100, 40.73.43.128 |
| VSDN Token Iso | 40.73.41.87 | 40.73.41.51 |
| Khafka Isolated | 40.73.40.35 | 40.73.41.121|
| MTLS Segment | N/A (Decomm'ed) | 40.73.8.176/29 |


### China-Azure East
| NAT Gateway | cn-east-preprod | cn-east-prod |
|---------|------|---------|
| Shared Diego | 40.73.106.78, 40.73.122.202, 40.73.109.56, 40.73.122.207 | 40.73.106.112, 40.73.110.247, 40.73.122.196, 40.73.122.179 |
| VSDN Isolated | 40.73.106.76, 40.73.122.222, 40.73.122.223, 40.73.120.119 | 40.73.106.133, 40.73.122.217, 40.73.122.210, 40.73.109.132 |
| VSDN Token Iso | 40.73.106.68 | 40.73.108.91|
| Khafka Isolated | 40.73.104.240 | 40.73.107.160 |
| MTLS Segment | 40.73.91.224/29 | 40.73.93.0/29 |


### CN-SH8-NAT
|NAT Device   | cn-sh8_Preprod    | cn-sh8_prod|
|-------------|-------------------|------------------|
|Firewall     | 19.205.18.16/28		| 19.205.18.32/28		 |


### CN-KS1-NAT
|NAT Device   | cn-ks1_preprod    | cn-ks1_prod|
|-------------|-------------------|------------------|
|Firewall     | 19.205.146.16/28		| 19.205.146.32/28	 |


### US-GCP-Central
| us-central1_preprod | us-central1_uatext | us-central1_prodint | us-central1_prodext |
|---------------------|--------------------|---------------------|---------------------|
|    10.1.52.0/22     |    10.1.68.0/22    |    10.1.20.0/22     |    10.1.36.0/22     |
> NOTE: For any traffic outside of GCP or the Ford intranet, the outbound IPs will be seen as the [external proxy IPs](https://azureford.sharepoint.com/sites/ExtranetCoreServices/sitepages/http%20configuration.aspx).
