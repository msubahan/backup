# JAB 7.0 Setup Guide

    NOTE: This document is meant for applications that are currently using the JAB7 architecture and have new team members that
          need to setup JAB7 on their local environment.
          For any new applications the frontend Angular architecture that JAB7 demonstrates is recommended, but it is not recommended
          that any new applications start with the JAB7 Backend architecture that includes FordJPA framework.
## Table of Contents

- [Getting Started](#getting-started)
  - [What is the Java Adventure Builder (JAB)?](#what-is-the-java-adventure-builder-jab)
  - [Should I use Eclipse or RSA?](#should-i-use-eclipse-or-rsa)
  - [How do I get support?](#how-do-i-get-support)
- [Prerequisites](#prerequisites)
- [Download the JAB Distribution and Extract Project](#download-the-jab-distribution-and-extract-project)
- [Import JAB Project](#import-jab-project)
- [Run JUnit Tests](#run-junit-tests)
- [Generate Eclipse Metadata for JAB Gradle Projects](#generate-eclipse-metadata-for-jab-gradle-projects)
- [Completing Your Eclipse Setup](#completing-your-eclipse-setup)
- [Setting up the JAB Liberty Server](#setting-up-the-jab-liberty-server)
- [Create a New Liberty Server Instance](#create-a-new-liberty-server-instance)
- [Add the JAB EAR to the JabServer Websphere Liberty Server Instance](#add-the-jab-ear-to-the-jabserver-websphere-liberty-server-instance)
- [Setting Up Default Realm Credentials (this may not be necessary](#setting-up-default-realm-credentials-this-may-not-be-necessary)
- [Run JAB on Localhost](#run-jab-on-localhost)
- [Finish Setup](#finish-setup)
- [Configure Traditional WAS Server for JAB](#configure-traditional-was-server-for-jab)


 
### Getting Started

#### What is the Java Adventure Builder (JAB)?

Drawing on 15-years of collaboration with globally dispersed Ford Java software engineers, the JCOE has implemented the JCOE Adventure Builder (JAB) as a​​ JEE Reference Application. JAB is a functionally light but architecturally rich application that:

* reveals end-to-end use of standards-based APIs <br /> 
* demonstrates a versatile user interface developed by the Web and Mobile CoE (WaMCoE) <br />
* models an adaptable application architecture <br />
* expresses an enterprise Unified Pattern Language <br />
* demonstrates JCOE’s clean coding practices <br />
* integrates with FJF frameworks <br />
* reflects variation in responsive web design depending on JAB version <br />
* demonstrates integration of Web service providers and consumers <br />
* encourages use of advanced JUnit 4 testing techniques with technology-specific frameworks based on FordTestCore <br />​

The JCOE encourages software engineers to import the appropriate version of JAB (depending on your application needs) into Eclipse and explore the source code. Either JAB 6 or JAB 7 can be used as a reference for new or existing applications. 

#### Should I use Eclipse or intellij?

The short answer? <b>Eclipse</b>, using the minimal configuration and JCOE preferences template.

###### Eclipse Advantages <br />
* <b>Localhost Server</b> - WAS Liberty is a lightweight, high-performance server optimized for localhost testing. <br />
* <b>IDE Plug-ins</b> - Several Eclipse plug-ins are available and certified for use at Ford such as ObjectAid for creating class diagrams. <br />
* <b>Performance and Features</b> - The Eclipse Foundation continues to provide a new version each June with improved performance and additional features. <br />
 

#### How do I get support?
 Question about JAB, Need to notify us of a bug, have issues or new feature request Join and post your question in
 * [/d/c/s Community Channel](https://www.webexteams.ford.com/space?r=fz8y "DCS group")
 * [Dev Community](https://web.yammer.com/main/groups/eyJfdHlwZSI6Ikdyb3VwIiwiaWQiOiI3OTcwNjExMjAwIn0/all "DEV Community" )

<b>Note:</b>  The discussions are regularly monitored by DevEnablement architects and other Ford Java SDAs familiar with the application

### Prerequisites

* [Software Engineering Workstation Setup](https://github.ford.com/DevEnablement/pcfdev-guides/blob/master/jab7-setup/installing-jee-dev-software-dist/README.md "Install Software Distribution")
    
* Launch the Eclipse IDE with the "Ford Eclipse <version>" shortcut <br />
<b>Note:</b> Gradle "inherits" the JDK used for launching Eclipse. It is important to launch Eclipse with an Open JDK to ensure Gradle imports the project correctly later in the guide.
    
* Select Open JDK as the default installed JRE

![high-level architecture](diagrams/diagram1.JPG)


### Download the JAB Distribution and Extract Project

* Clone JAB 7.0 project from [Here](https://github.ford.com/JCOE/jab7 "JAB link").​​

   You should have a directory and file structure like this: 

    C:\Projects\git\Jab7\
````
    distribution
    FADAF
    gradle
    Jab7Angular
    Jab7Business
    Jab7EAR
    Jab7REST
    Jab7Server
    Jab7Test
    setup_dependencies
    .fossa.yml
    .gitignore
    .jshintrc
    .npmrc
    build.gradle
    gradle.properties
    gradlew
    gradlew.bat
    Gruntfile.js
    package.json
    README.md
    settings.gradle
````
<b>Note:</b>  Although JAB 7.0 can be clone into any directory, the recommendation ensures effective future support.

### Import JAB Project

1. Start Eclipse and create a new workspace called <b>C:\Projects\Workspace\JAB_7</b>  Eclipse should now start and you should see no projects in the Enterprise Explorer window. 
2. If the Gradle views are not visible in Eclipse, select them from <b>Window > Show View > Other… > Gradle > Gradle Tasks​.</b>
3. Select <b>File > Import > Gradle > Gradle Project</b>. The <b>Import Gradle Project - Welcome</b> dialog will now be displayed.<br />
<b>​​Note:</b> The option to import a Gradle project will not be present if the Buildship plug-in for Eclipse is not installed/properly configured.
4. Click <b>[Next >]</b>. The <b>Import Gradle Project - Import Gradle Project</b> dialog will now be displayed.
5. Set the <b>Project root directory</b> entry field to the directory JAB 7.0.
6. Click <b>[Next >]</b>. The <b>Import Gradle Project - Import Options</b> dialog will now be displayed.
![high-level architecture](diagrams/diagram7.JPG)
7. Select the <b>Gradle Wrapper.</b><br /> 
• JAB 7 has been set up with the required Gradle wrapper properties needed to use the TSL approved version of Gradle.  
• See the <b>C:\Projects\Git\jab7\gradle\wrapper\gradle-wrapper.properties</b> file for an example of how this is configured.  
• It is beyond the scope of this wiki to provide a detailed description of this Gradle feature.  
8. Leave all other entry fields in this dialog blank. Click <b>[Next]</b>. 
9. Review the import configuration to verify that JAB project structure is as expected (see following for example).  If all is OK, click <b>[Finish]</b>.

![high-level architecture](diagrams/diagram2.JPG)

     NOTE: If you run into an error during the import, ensure the Oracle JDK is selected as the default JRE and also set as the VM which is running your IDE.


Generate JPA Metamodel Class Sources

In the following steps we'll first generate the JPA Metamodel classes required by the Jab7Business project, then add those generated classes to that project.  After the generate process is complete, metamodel generated sources will be contained in the <b>Jab7Business\.apt_generated</b> directory.  That source directory now needs to be added to the JabBusiness project:

1. From the <b>Gradle Tasks</b> tab, select <b>Jab7Business > metamodel</b>  and double click on <b>generateMetamodel.</b>
2. In the <b>Enterprise Explorer</b> tab, right click on the <b>Jab7Business > Refresh.</b> 
3. From the <b>Enterprise Explorer</b> tab, right click on the <b>Jab7Business</b>, and select <b>Properties</b> ><b> Java Build Path.</b>
4. Click on the <b>Source</b> tab.
5. Click on the <b>Add Folder</b>... button.
6. Check the <b>.apt_generated</b> folder and click <b>[OK]</b> to add that source folder to the project.
7. Close the Add Folder dialog.
8. Click <b>[OK]</b> to save the new source directory to the project.  All projects should now build properly with no errors.<br />
​<b>Note:</b> You will see an XML error in the Jab7Server project, but that is OK.

### Run JUnit Tests

All JAB unit tests are conveniently located in one project: the <b>Jab7Test proj​ect</b>. To run the full suite of tests:

• From the <b>Enterprise Explorer</b> tab, <br />
1. Right click <b>Jab7Test</b>, <br />
2. Select <b>Run As </b>> <br />
3. Select <b>JUnit Test</b> <br />

<b>All test should run GREEN.</b> If you have failed tests, STOP and review prior steps. Ensure metamodel classes were generated <b>and</b> .apt folder (from JAB7Business) is checked as a source directory. Finally, refresh all projects.

### Generate Eclipse Metadata for JAB Gradle Projects
In this section we will set up the appropriate project facets for JAB's enterprise and web applications:  

1. In the Gradle Tasks tab, expand the <b>JAB7</b> entry, then expand the <b>ide</b> entry.
2. Left click on the <b>eclipse</b> entry in the <b>ide</b> list, then CTRL-Left Click on the <b>eclipseWtp</b> entry.
3. Right click on the <b>eclipse</b> entry and chose the <b>Run Gradle Tasks</b> option to run those tasks one after the other.
4. In the Project Explorer tab, select all the projects, right click on one of the projects and select <b>Gradle > Refresh Gradle Project.</b>

### Completing Your Eclipse Setup

In Eclipse, as an optional step, you can set up an XML Catalog entry for PropertyGroup.dtd to get rid of the Eclipse warning messages for various Property Manager files in JAB.  For example, to remove warnings such as the following:  "The file cannot be validated as the XML definition <b>"C:\Projects\Accurev\JCOE_JAB_7_DIST\Jab7Business\src\main\resources\dev\PropertyGroup.dtd </b>(The system cannot find the file specified.)" that is specified as describing the syntax of the file cannot be located... ". 

To do that, in Eclipse: 

1. Select <b>Window > Preferences > XML > XML Catalog > Add ... </b>
2. Click the <b>Workspace</b> button and navigate/specify <b>Jab7Business/src/main/resources/PropertyGroup.dtd</b>
3. Click <b>OK</b>
4. In the <b>Key</b>: entry field enter: <b>PropertyGroup.dtd</b>
5. Click <b>OK</b> 
6. Right click on the Jab7Business project and select the <b>Validate</b> option 

### Setting up the JAB Liberty Server 
The configuration for the JAB 7.0 Liberty Server in the Jab7Server project has already been set up.  Initially you will see an error in the Jab7Server project, but that will be fixed and cleared up when JAB is deployed.  

* Follow [setup-liberty-server](https://github.ford.com/DevEnablement/pcfdev-guides/blob/master/jab7-setup/setup-liberty-server/README.md) steps to set up the Liberty Server runtime.
* Install [liberty feature](https://github.ford.com/DevEnablement/pcfdev-guides/blob/master/jab7-setup/install-liberty-feature/README.md) for the Liberty server

### Create a New Liberty Server Instance

1. Select <b>File > New > Other > Server > Server</b> and click <b>[Next]</b>.  The New Server dialog will be displayed.
2. Select <b>Websphere Application Server Liberty</b> from the listbox.  Keep defaults.  Click <b>[Next]</b>.  The New Server > Liberty Server dialog will be displayed with the Liberty Server dropdown set to Jab7Server.  If the dropdown is not set to Jab7Server then open the list and select the Jab7Server option.  The Server configuration listbox will contain the configuration from the Jab7Server directory under the Jab7Server project as follows: 
![high-level architecture](diagrams/diagram3.JPG)
3. Click [Finish].
### Add the JAB EAR to the JabServer Websphere Liberty Server Instance

1. In the Server tab, right click on the <b>Websphere Application Server Liberty at localhost</b> entry, and select the <b>Add and Remove...</b> option.
2. Chose the <b>Jab7EAR</b> selection from the <b>Available</b>: listbox and click <b>[Add]</b> to move choice to the <b>Configured:</b> listbox.
![high-level architecture](diagrams/diagram4.JPG)
3. Click <b>[Finish]</b>.

### Setting Up Default Realm Credentials (this may not be necessary)
1. Edit the file <b>C:\Projects\Accurev\JCOE_JAB_7_DIST\Jab7Server\servers\Jab7Server\configDropins\overrides\security.xml.</b>  
2. Add your credentials (as documented in the file) and save.
3. From the Jab7Server project: 
  * Run the <b>uninstall_security_feature.cmd</b> command script by double clicking on the file in Eclipse
This script will uninstall Ford localhost security and prepare your project to install the Ford localhost security (next step). There is no harm in running this script if the Ford security feateu has not already been installed. 

* Run the <b>install_security_feature.cmd</b> script by double clicking on the file
This will install the Ford localhost security feature as necessary.  The feature is actually installed in two places, i.e., in the Jab7Sever project and in the global Liberty user area.  At the time of this writing, installing to both locations is required.  

### Run JAB on Localhost
1. Right click on the Liberty Server instance and select "<b>Clean</b>..." then "<b>Publish</b>" (sometimes this step is not necessary, and sometimes the server will throw a file_not_found exception)
2. Start the server in Debug mode to enable Hot Code Replace. Liberty should launch with your EAR in significantly less time compared to WAS Classic/Traditional.  If you are not able to start the JAB EAR then right click on the Liberty server in the server view and click <b>clean</b>.
3. The application can be accessed by navigating to <b>http://localhost:11000/Jab7Angular/​​</b> in Chrome. In some cases you'll be prompted with the following screen:
![high-level architecture](diagrams/diagram5.JPG)
If authentication fails when using your own login credentials, ensure that the security.xml file is updated according to the above instructions.
4. Enter as Agent to verify that the application is configured as expected.
5. You will see booking page like below.
![high-level architecture](diagrams/diagram6.JPG)


### Finish Setup
Finish the JAB 7 setup but selecting all the projects in the Enterpris Explorer window, <b>right click, Validate</b>.  This should clean up the errors in the Jab7Server project. 









