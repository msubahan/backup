# Install Liberty Features


#### Install Additional Features into Liberty Server:

##### Prerequisites:

* This assumes that you have already added a Liberty Server to your Eclipse workspace
 

Ford's Liberty Installation comes with a default set of "features", all of which add certain functionality to the application server -- Servet 3.0, for example, creates servlets; jsf-2.0 adds jsp pages; and jndi-4.0 adds database connectivity. Some applications would like to add additional features to their servers -- for example, JCA (for IMS connections) or Jax-RS for Restful services.  There is a two-step process to add these features.

1. Features must be installed before they can be used. In order to install a feature, open a view called "Runtime Explorer" in Eclipse (Window -> Show View -> Other, then under Server -> "Runtime Explorer".
2. Right click on the Liberty server and choose "Install Additional Content". 
![high-level architecture](diagrams/diagram.jpg)
3. Search for the description of the features -- for example, "Java Connector Architecture" to install jca-1.6 feature.
* Be extremely sure to choose features that are compatible with the version of Java Enterprise Edition you have -- for example, JCA 1.6 is compatible with EE6 but JCA 1.7 is not. List of compatible features can be found at http://www.oracle.com/technetwork/java/javaee/tech/javaee6technologies-1955512.html.<br />
* Additionally, application teams are responsible for ensuring technology they are installing to the team's liberty server has been vetted and approved from a TSL perspective.
Alternatively, one could install a feature from a local archive (.esa file, for example) by selecting "Add Archive..."
Click "Install" to add the feature to your server and click Next.
In server.xml, inside the <featureManager> element, add the acronym for the installed feature, like this:
        <featureManager>
  <feature>jca-1.6</feature>
...

​If your server instance was running when starting, restart the server for changes to take effect.

