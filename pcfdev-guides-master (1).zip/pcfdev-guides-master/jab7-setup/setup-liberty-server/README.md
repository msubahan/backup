# Adding a New Liberty Server Runtime Environment in Eclipse


#### To add a new Liberty Server Runtime to your existing Eclipse environment, perform the following steps:

Select <b>Window > Preferences > Server > Runtime Environment</b>

1. Click <b>[Add…]</b> to add a new runtime environment<br />
![high-level architecture](diagrams/diagram1.jpg)
2. Select <b>IBM Liberty Runtime</b><br />
![high-level architecture](diagrams/diagram2.jpg)
3. Uncheck the Create a new local server checkbox<br />
4. Click <b>Next</b><br />
5. On the Liberty Runtime Environment dialog : <br />
 Select Choose an <b>existing installation</b> and enter <b>c:\ford\liberty\wlp-base-20.0.0.4\wlp</b>.  20.0.0.4 is the Liberty Runtime currently supported by the jab7.  This version will likely change in the future as necessary and appropriate, so the screen shot provided (with 20.0.0.4 referenced) should just be used as an example.   <br />
![high-level architecture](diagrams/diagram3.jpg)
6. Configure JRE (Currently JAB7 support OpenJDK 8) <br />
7. Click <b>Advanced options</b> and  click <b>New</b> and select JAB7Server <br />
![high-level architecture](diagrams/diagram4.jpg)
8. Select <b>jab7Server</b> and click <b>OK</b>. <br />
![high-level architecture](diagrams/diagram5.jpg)
9. Click <b>Finish</b>
10. Click <b>OK</b>
