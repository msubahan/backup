# ​​​​​​​​​Installing Appropriate JEE Development Software Distributions


#### For EE development, developers should download the latest version of Liberty and OpenJDK from Nexus:
    
#### https://www.nexus.ford.com/#browse/browse:was_engineering_private_release_repository:liberty
    
#### They should then place those tools in the corresponding places within the c:\ford directory structure detailed below.



Follow the instructions below to establish and mirror the workstation environment.  Adhering to this exact setup makes it easier for Dev Enablement to help developers with any environment issues they might encounter. 

1. For the all-in-one software distributions package, download the ​ford.zip directory. Unzip the contents into C:\ford\. See below for how your folder structure should look upon completing.  See the bottom of the page for individual links.
Your <b>C:\ford</b> directory should now contain several subdirectories.  In each subdirectory there is a zip file corresponding to each DEST recommended distribution, e.g., <b>C:\ford\liberty\liberty.zip</b> is the complete Liberty Server 20.0.0.4 distribution.  Follow the instructions below to extract these distributions to your workstation to locations recommended by the DEST.  Where recommended, keep the version numbers as part of your workstation distribution directory names.  That way when new releases or updates come along, you can easily update your distributions as appropriate and as necessary.​<br />
    
        Note: Also VERY IMPORTANT: Regardless of what method you use to unzip the required distritutions, make sure that the 
        distribtions are unzipped to the directories we recommend.  Our documentation and sample scripts are geared to 
        reference these locations. Each item below specifies the directories you need.

At the end of the extract steps below, you should have the following directory structure.  Subsequent documentation assumes that you have this structure in place: 

   c:\ford<br />
    |-- eclipse<br />
    |  -- -- [oxygen](https://www.eclipse.org/getting_started/)<br />
    |-- gradle<br />
    |  -- -- [Gradle-4.1.zip](https://www.nexus.ford.com/#browse/search=keyword%3Dgradle:6681a6b40d0abaec45c97d9834c0568f)(This is the version packaged with Ford.zip)<br />
    |-- jdk<br />
    |  -- -- adoptOpenJDK<br />
    |     -- -- -- [JDK](https://www.nexus.ford.com/#browse/browse:was_engineering_private_release_repository:liberty%2FOpenJDK8U-jdk_x64_windows_openj9_8u252b09_openj9-0.20.0.zip) <br />
    |-- liberty<br />
    | -- -- [liberty](https://www.nexus.ford.com/#browse/browse:was_engineering_private_release_repository:liberty%2Fwlp-base-all-20.0.0.4.jar)<br />
    
2.    Unzip <b>C:\ford\liberty\liberty.zip</b> to <b>C:\ford\liberty</b><br />
        Your <b>C:\ford\liberty\ directory </b>should now contain the latest Libery Server distribution from the Dev Enablement Team.
        <b>Note:</b>  Only the Liberty features required to run JAB 6 and JAB 7 are contained in the provided distribution.  To install other features, please see this link.   
3.    Unzip <b>C:\ford\jdk\ibm\jdk8u252-b09\jdk8u252-b09.zip</b> to <b>C:\ford\jdk\ibm</b>
4.    Unzip <b>C:\ford\gradle\4.1\4.1.zip to C:\ford\gradle\gradle-4.1</b><br />
        Your <b>C:\ford\gradle\gradle-4.1</b> directory should now contain this distribution.  To complete the Gradle installation:
        In File Explorer <b>right-click</b> on the <b>This PC</b> (or the <b>Computer</b>) icon, then click <b>Properties -> Advanced System Settings -> Environmental Variables.</b>
        Under <b>System Variables</b> select <b>Path</b>, then click <b>Edit</b>. Add an entry for <b>C:\ford\gradle\gradle-4.1\bin.</b> Click <b>OK</b> to save
5.    Unzip <b>eclipse.zip</b> to <b>C:\ford\eclipse</b>
        This distribution contains Eclipse Oxygen with all the plugins needed to configure and run Liberty  In addition, the distribution contains various development plugins, e.g., Findbugs, used to improve code quality and to profile your application during development.
        Shortcuts called "Eclipse Oxygen" these are packaged in the oxygen directory, with proper startup parameters for different app servers.  <br />
