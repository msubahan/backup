# Logging

It is critical that teams configure app logging levels appropriately. Apps that generate outsized log streams can negatively impact Ford's cloud platform logging systems and even **bring down the logging system for all apps**. With rare exception, **apps should not run at `DEBUG`, `TRACE`, or similarly verbose log levels when deployed to PCF.** Using verbose logging for short durations to troubleshoot a specific issue is appropriate, but app teams must return logging level to `INFO` or lower after the issue is resolved. The PCF platform aggregates all app logs together, and as a consequence, a single app generating an outsized log stream can disrupt the logging for all other applications on the platform.

## Background

Applications running on cloud platforms should "[treat logs as event streams](https://12factor.net/logs)." Instead of writing to logfiles, each running process should write its event stream, unbuffered, to stdout. During local development, the developer will view this stream in the foreground of their terminal to observe the app’s behavior.

In staging or production deploys, each process’ stream will be captured by the cloud platform, collated together with all other streams from the app, and routed to one or more final destinations for viewing and long-term archival.

The logging system of the PCF platform can become saturated and fail if many apps are configured with highly verbose log levels. This has happened in the past, so please do not recreate this problem by leaving your app configured with `DEBUG` or `TRACE` level logging when deployed to PCF.

## Java / Spring Boot Apps

The focus f this guide is on Java, with preference given to Spring Boot. The examples assume that Java applications will use slf4j with the [Logback](http://logback.qos.ch/index.html) implementation for logging.

### 2021 CVE's related to Log4J

As mentioned above, Spring Boot uses Logback as it's default logging library, and not Log4J. Those that override the logging implementation should be aware of the Critical CVE's that were identifed in Log4J. See the [Log4J Vulerability FAQ page](https://azureford.sharepoint.com/sites/SDE/SitePages/Log4J-FAQ.aspx) for more information. 

### Log Level Hierarchy

The logging levels have a order of precedence or a hierarchy. Below are the Logback log levels in order:
* TRACE
* DEBUG
* INFO
* WARN
* ERROR

Using the code example below, where we have 5 Java log statements, the actual log statements that result in the data being written to log depends on the current log level that is set for the application. If you have your application logging level set to: 
- TRACE - then all 5 of the log statements will be actually written to log.
- DEBUG - then all except the TRACE log statement will be actually written to log.
- INFO - then only the INFO, WARN, and ERROR log statements will be actually written to log.
- WARN - then only the WARN and ERROR log statements will be actually written to log.
- ERROR - then only the ERROR log statements will be actually written to log.

```
log.trace("This is TRACE level logging");
log.debug("This is DEBUG level logging");
log.info("This is INFO level logging");
log.warn("This is WARN level logging");
log.error("This is ERROR level logging");
```


## Logger Setup in code

There are a couple of options available for setting up logging in your Spring Boot application. 

1. Setup logger using Lombok - Applications generated using the EcoBoost generator in DCS automatically come with the open source Lombok library. You can simply use the ```@Slf4j``` annotation on a class, which will establish a local static variable named ```log``` that can be used in the class for logging. You can see an example of this approach in our [CAB reference application](https://github.ford.com/PCFDev-CAB/cab-service-fordair/blob/master/src/main/java/com/ford/cab/fordair/flight/FlightService.java).

2. Manually configure a logger instance for any class that requires logging - Logger can be declared as the first field (top of code) in a class.

```java
private static final Logger logger = Logger.getLogger(MyClassName.class);
```


## Logger Level Setting at application

As we mentioned, it is critical to pick the appropriate log level for you application. The Dev Enablement team prefers to set the logging levels via a manifest file that is used to deploy the application to PCF. See our CAB reference application [manifest template example](https://github.ford.com/PCFDev-CAB/cab-service-fordair/blob/master/cf/manifest-template.yml).

Our example above is just one way to set logging levels. There are many options and a Google search will yield many results. A couple good resouces include:
* Baeldung site at [https://www.baeldung.com/spring-boot-logging](https://www.baeldung.com/spring-boot-logging).
* Spring.io Docs at [https://docs.spring.io/spring-boot/docs/2.3.3.RELEASE/reference/html/spring-boot-features.html#boot-features-logging](https://docs.spring.io/spring-boot/docs/2.3.3.RELEASE/reference/html/spring-boot-features.html#boot-features-logging)




## Best Practice

- Use clear key-value pairs<BR>
Splunk has powerful features to extract fields from logging messages for searching. In order to conform to
the Splunk expectation the syntax should follow:
key1=value1, key2="value with spaces", key3={"json": "data"}

- Logging messages must be readable<BR>
The logging messages should be a human readable format.  It should provide enough details and 
data to understand the processing steps of an issue.  Might not provide enough data to resolve the issue
but ideally provides enough information to reproduce the issue.

- Error Message Ids<BR>
For Error Messages consider creating and managing an Error Message Id as part of the logging message for use by
automated tools and notifications.

    For example from Oracle:
    ```
    [ORA-00018] Unable to create session for user=exampleUser

    ```

    Additional information on the error code (for example: ORA-00018) can be in a knowledge base for the application.

- Use developer-friendly formats<BR>
Log information in developer-friendly formats like JavaScript Object Notation (JSON) or XML 
that are considered human and
machine readable.
This will simplify logging the data for a HTTP/S request BUT some of the data might need to be masked
to hide sensitive data.


- Avoid multi-line events<BR>
Splunk will generate lots of segments, can affect indexing and searching, and order might not be maintained.
Consider seperate logging messages instead. 


## Logging Level Examples & Best Practices


### Error Logging
An issue has occurred and should be investigated immediately, processing has failed.

Typically, Error logging will be from the exception catch block
```java
catch (IOException ioex) {
    logger.error("Unable to read {}", fileName, ioex);
}
```

NOTE: Slf4j by design will find the exception in the parameters and print the stack trace.


### Warn Logging
An issue has occurred and processing is able to continue, however repeated warnings of the same issue
might warrant investigation.

Warn logging should be used for unexpected flow, automatic recovery (ex. retry, circuit breaker), Missing cache data.

```java
logger.warn("GET url={} returned status={}, will try another service", url, responseStatus);
```

If there is an exception it should be added to the paramters for the warn() method.
```java
catch (IOException ioex) {    
logger.warn("Unexpected failure calling url={}, will try another service", url, ioex);
}
```

### Info Logging

Info logging should be at critical points in the processing for business transaction or information for
issue reproduction.

Avoid logging that does not add value like entry and exit of methods, that is a code smell. The code should
be simplified so that there is very little to no branching.

```java
logger.info("Credit card payment: creditCard={} amount={} transactionId={}", 
    maskAllButLast4(request.getCreditCard()), request.getAmount(), request.getTransactionId());
```

Because of the 'Splunk' billing model 'INFO' level logging should be use sparingly and
add value for issue resolution reproduction. 
The important question is "does this info message add value since it is going to cost money for each request that is processed"

Do not have info messages like `logger.info("here");`... it does not add value. The logging message will have
the timestamp and might have the location in the code but the message should include useful information besides the word "here"

### Debug Logging
Used by developers to determine processing and issue resolution.
In a production environment 'DEBUG' and 'TRACE' level logging is expected to be disabled.
'DEBUG' and/or 'TRACE' level logging could be enabled in production but its not sustainable and could
impact application performance.
 
```java
logger.debug("POST {} with body={}", url, maskOut(request));
``` 

### Trace logging
​Lower level, more verbose developer information with more details and used liberally​.

Best practice is to use Debug level logging for only the critical information that effects processing
and a Trace level logging for the complete data.

```java
logger.debug("Request from {} transactionId={} action={}", sourceIp, request.getTransactionId(), request.getAction());
logger.trace("Request from {} body={}", sourceIp, maskOut(request));
```

Pairing the logging allows for Debug level logging to provide enough information to resolve issue and enabling Trace
level logging provides more data that might aid in issue resolution.

Notice that the request is still masked out to protect sensitive information even though its Trace level logging and should not be enabled in production.

## Guidelines for logging sensitive / private data
- Credit card numbers must be encrypted or masked showing at most the last 4 digits
- Credit card security code cannot be logged
- Social Security Number (SSN) must be encrypted or masked showing at most the last 4 digits.
- Passwords must be masked in a standard response not based on length of the password.
    
  For Example:
  ```
  "ThisIsMyPassword" would be masked as "****"
  "123" would be masked as "****"
  ```

Known Regional Restrictions

- For China ‘lat-long’ (location) data.
- For EU(France) GUID (if opted out).
 
As other regional restrictions get identified, we need to comply. 
These guidelines/rules may vary from country to country.​
