# Secrets Management

Effective secrets management is important to protect against both external and insider threats.
DevEnablement provides solutions for secrets management but that doesn't cover the full topic.

Common secrets to protect include:
- Service Credentials
- Acceptance Test Credentials
- PKI/Private Keys/Keystore Passwords
- Generic IDs
- API Keys

Common secrets management concerns include:
- Default Passwords
- Basic Authentication
- Pipeline Scripts and Helpers
- Git Credential Exposure
- Credential Sharing

## Default Passwords and Basic Authentication
All application secrets need to be encrypted, plain text credentials are a violation of ISP.
Spring Security includes a default password that is generated at startup and logged via startup output for each instance.
This is mitigated by not supporting basic authentication in production.

Applications should not manage passwords or user accounts.
At Ford we remove that responsibility by externalizing authentication to ADFS, Azure AD, FDS, IBM CI, etc...

## Application Password Management
- Jenkins Credential Manager is used to secure secrets used by the pipeline.
- Credhub is used to secure the decryption key used to decrypt other encrypted secrets
- Do not check code and configuration files into Git that include credentials
- Do not share private keys between applications

## Secrets Management Recommendations
- [Application](https://github.ford.com/DevEnablement/pcfdev-guides/tree/master/secrets-management)
- [Pipeline](https://github.ford.com/DevEnablement/pcfdev-guides/tree/master/pipeline-jenkins#Acceptance-Testing)

[Home](README.md)
