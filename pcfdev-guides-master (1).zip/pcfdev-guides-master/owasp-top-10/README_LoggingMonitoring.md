# Insufficient Logging and Monitoring

Some logging is external to the application such as authentication.  This section applies to logging in the application's control.
## Concern



* Hackers go undetected while attempting to compromise a system
* Insufficient data available to respond once detected

Application-level hacking involves requests and fuzzing.
Fuzzing involves sending in malicious data to exploit insufficient validation.  Validation code should log invalid requests along with the authenticated principal.
Requests involving authorization failures should be logged in the same manner.

App teams should implement Splunk to collect logs and monitoring Splunk for security events.
If needed, the app should generate notifications when certain conditions are met.

Cyber Security Center (CSC) has access to the Splunk logs for responding to incidents but they are not monitoring Splunk and the data is not fed to QRADAR.
Application teams need to notify CSC of incidents to initiate the process.


## References
* [Logging dev guide](https://github.ford.com/DevEnablement/pcfdev-guides/tree/master/logging)
* Splunk – Splunk access can be obtained using [Ford Cloud Portal](https://www.cloudportal.ford.com/)

[Home](README.md)
