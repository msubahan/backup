

# Authentication and Authorization

Authentication is the process of identifying the user while authorization is the process of ensuring access is limited to allowed resources.

## Authentication
Authentication is externalized from the application.  Users authenticate to identity providers made available through federation.
This removes many attack vectors from the developers responsiblity.
Developers don't have to deal with:
- Adding/Removing users
- Password resets
- Locked accounts
- Invalid login attempts

Common authentication methods used at Ford are:
- OAuth2/OIDC
- MTLS
- SAML
- Kerberos

With OAuth2 and OIDC, bearer tokens are used to represent authenticated users.  For APIs supporting human and machine clients, these tokens are passed on every request.
For traditional web applications, session cookies are included on requests which are backed by tokens collected during the login process.
A big concern with bearer tokens is that whoever holds it while it is valid can use it.  Its important to secure the token from compromise.

Mutual TLS requires clients to authenticate by passing a client certificate in the TLS handshake.
In PCF, the handshake is performed outside the application.  In CaaS the application can negotiate the process.
A concern with certificates is they are long-lived credentials.  While they can be included in revokation lists if compromised, applications may not be performing this check.

### Authentication Concerns
Developers need to insure a few things in the authentication space.

- Clients must authenticate to access the application over secure channels
    - Implement HSTS header and channel security in the security configuration file
- All entry points require authentication with few exceptions
    - Swagger
    - Health Check
- OAuth2/OIDC
    - Tokens are transmitted over secure channels
    - Tokens are validated (signature, audience, expiration, and issue time)
    - Token includes an attribute limiting it's use to a particular application
    - Session cookies are only transmitted over secure channels
    - Tokens should have minimum TTL balanced with user experience
    - Developers should use reputable security libraries such as Spring Security
- MTLS
    - Clients and Servers must secure the certificate's private key following secrets management processes
    - Servers must validate the incoming certificate (signature, signing chain, and expiration)

### Test Configuration
The security configuration should be validated by tests, both unit tests and acceptance tests.
Test with both authenticated and unauthenticated clients on each secured endpoint.  Test endpoints that do not exist.

### Authentication in Staticfile Buildpack PCF - NGINX
Security Engineering is working to integrate the ADFS Agent with NGINX for static websites.

### SPA Authorization
For SPAs, the data is acquired from authenticated service calls. Do not send data to the SPA that shouldn't be accessible by the client.
Authorization in the SPA is about providing a better user experience by restricting available options displayed, it isn't for limiting data to display that has already been acquired.
Remember that the SPA can be bypassed and users can query the back end directly with other tools such as Postman and CURL.

## Authorization 
Authorization varies across applications depending on the data type and restrictions needed.

Authorization methods include:
- FIM Groups
- User Attributes (Employee Type, Manager Status, ...)
- APS
- Custom
- ADS PDP (Local Axiomatics PDP deployed with the app)

### Concerns
- Ensure the data used for decision making is secure from tampering
    - Call FDS using LDAPS
    - Call APS over HTTPS
    - Verify signature of signed data (Spring Security validates JWT tokens)

The most important part of authorization is testing to ensure it works as expected and doesn't break during future enhancements.
As authorization complexity rises, testing becomes more complex and it's easy to open security holes.

Single-Page Applications (SPAs) typically have some level of authorization in the client.  This is for the user experience not security.
Any data returned to the client can be accessed by the user even if it's being filtered by the SPA.  
The service should never return data not available to the client.

## Testing


### Unit Tests
Overall authentication posture testing is conducted in the 
[WebSecurityConfigurationTest.java](src/test/java/com/ford/devenablement/owasp/WebSecurityConfigurationTest.java)
with an unauthenticated client.  This file will test your endpoints looking at the response codes.

Autowire Spring's reactive test client (Note class name is WebTestClient not WebClient):
```java
	@Autowired
	private WebTestClient webClient;
```

Include tests for success and client error as displayed below:
```java
    // Test for unknown endpoint response
	@Test
	public void should_notAllowOtherEndpoints_withoutAuthentication() {
		webClient.get().uri("/other-does-not-exist").exchange().expectStatus().is4xxClientError();
	}

    // Test for endpoints that should not require authentication
	@Test
	public void should_allowSwaggerEndpoints_withoutAuthentication() {
		webClient.get().uri("/swagger-ui.html").exchange().expectStatus().is2xxSuccessful();
		webClient.get().uri("/v2/api-docs").exchange().expectStatus().is2xxSuccessful();
	}

    // Test for endpoints that should require authentication
	@Test
	public void should_notAllowGetMeApi_withoutAuthentication() {
		webClient.get().uri("/api/v1/admin/me").exchange().expectStatus().is4xxClientError();
	}
```


### Acceptance Tests
Acceptance tests bring authorization into the equation by using authenticated clients and are executed in the pipeline during blue/green deployment.  Once the temp app is started, the tests are ran.
If a test fails, the build fails and the pipeline will not continue deployment.

Our Gradle Boost plugin adds a task for running acceptance tests, it's executed as below:
```shell script
./gradlew acceptanceTest
```
It looks for acceptance tests using the following criteria.  
** Note that it depends on environmental variables to function properly.
```groovy
class JavaAcceptanceConfig {
    List<String> testClasses = [ '**/*AcceptanceTest.class', '**/acceptance/**/*.class' ]
}
```

Credentials are stored securely in Jenkins Credential Manager,  our Spring-Base-Test library integrates with the pipeline to use those credentials creating WebClient instances.

Test clients can be created for the following using our builder:
- Generic ID using Resource Owner Password Credentials (ROPC) - Emulates a human user
- Machine client using Client Credentials
- Basic Authentication
- Unauthenticated Client


See the example setup below:
```java
    @Before
    public void setup() {
        ccGrantWebClient = AcceptanceTestUtil.webClientBuilder().withOAuth2ClientCredentials().build();
        ropcGrantWebClient = AcceptanceTestUtil.webClientBuilder().withROPC().build();
        basicWebClient = AcceptanceTestUtil.webClientBuilder().withBasicAuth().build();
        webClient = AcceptanceTestUtil.webClientBuilder().build();
    }
```

Ecoboost projects come with two authentication/authorization acceptance test files:
- [ActuatorSecurityAcceptanceTest]()
- [WebSecurityAcceptanceTest]()




## References
- [Acceptance Testing with Ecoboost](https://github.ford.com/DevEnablement/pcfdev-guides/tree/master/pipeline-jenkins#Acceptance-Testing)
- [APS Sample](https://github.ford.com/cyourman/aps3)
- [FIM Groups using LDAP and FDS](https://github.ford.com/cyourman/LDAP-MemberOf)

[Home](README.md)
