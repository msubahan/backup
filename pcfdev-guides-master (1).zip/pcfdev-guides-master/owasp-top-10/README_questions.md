
Are there scans run on PCF/CaaS to check for vulnerable components?

How to open a ticket for my Fossa scan with the OWASP jar:
https://ford.fossa.com/projects/custom%2B1%2Fowasptop10/refs/branch/master/804d8afad2d4cb601be184331e25e00e4de870be/issues/licensing/3165?revisionScanId=37766&status=active


TODOs
Add code links to validation guide

Determine how to override the default exception handler.
ControllerExceptionHandler
com/ford/cloudnative/base/app/web/exception/handler/ControllerExceptionHandler.java


