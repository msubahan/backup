# Data Validation
Malicous input data can exploit a variety of vulnerabilities and attacks include:
* Cross-site attacks
* Data exposure
* Unapproved access
* Remote control.

Identify all sources of data supplied to the application and ensure that the data is sanitized before being processed:
* REST
* Files
* Messages
* Sockets
* ...


Data validation includes both input and output data validation.  Input validation is obvious, stop it at the source.
Concept for output validation is for two reasons:

1 Its the last step before data is returned

2 Compromised data might have snuck into the system do to input validation failure/defect

## SPA
The SPA rendering pages must also consider XSS attacks in data.  Do not embed user data within scripts and do not execute code received from external sources including the backing service.


### Spring Security Firewall
Spring Security includes a firewall class that performs a layer of validations.  Failed validations result in 401 FORBIDDEN responses.
Amoung other things, it checks the URI for the following:
* Encoded Period
* Semicolon
* Forward Slash
* Double Forward Slash
* Backslash

For more information research this class:  [org.springframework.security.web.firewall.StrictHttpFirewall](https://docs.spring.io/spring-security/site/docs/current/api/org/springframework/security/web/firewall/StrictHttpFirewall.html)

### Input Validation
Untrusted data must be validated at points where it enters the system:
* REST Controller
* File Imports and Uploads
* Object Deserialization
* External Databases
* Sockets and other sources of data

It is important to block or filter malicious content from entering the system and potentially persisted.  Some questionable content may not be malicious but may not be acceptable.
Filtering can be applied with encoders or other input filters that modify the incoming content.  Validators can be used to constrain the data allowed in a field.
Validators result in exceptions, encoders do not.  For services backing an SPA with no machine clients, data restrictions could be configured in the SPA and validators applied to the fields skipping encoders altogether.
This should not affect the user experience as that data should never reach the application.  For instance say part numbers may accept alphanumeric content and not special characters.
If the SPA is filtering out the request to alphanumeric information, a validator can be used in the service. 

#### REST Controller
Performing input validation on a REST controller involves locating all the places external data is supplied.
HTTP Methods that persist and modify data are most important as they present a persisted XSS threat to mitigate.
GET requests also present a threat surface as they are used for SQL injection attacks and reflected XSS attacks.

### Output Validation
Output validation is the last line of defense to blocking malicious content from reaching the client.
It is possible that malicious content can be built by combining multiple data sources or from data retrieved but not sanitized.

## Field Level Validations
Popular JSR 380 bean validations:
* @Min
* @Max
* @Size
* @NotNull
* @AssertTrue

They are enforced when the class is validated which is triggered by the `@Valid` decorator on classes marked with `@Validated`.

There are cases that don't require @Valid such as Lombok validations.

### Custom Field-Level Annotations
[spring-base-security](https://github.ford.com/DevEnablement/spring-base-security) provides a collection of additional validators include some allowing customization.

```text
@AlphaNumericOnlyValidator: Fails if non-alphanumeric characters found
@AlphaNumericPunctuationOnlyValidator: Fails if non-alphanumeric or punctuation characters found
@BlacklistCharsValidator: Fails if characters found matching supplied blacklist characters parameter
@BlacklistRegexValidator: Fails if characters found matching supplied regular expression parameter
@NoSuspiciousCharactersValidator: Fails if the OWASP HTML Encoder finds HTML characters
@WhitelistCharsValidator: Fails if characters found outside the supplied whitelist characters parameter
@WhitelistRegexValidator: Fails if characters found outside the supplied whitelist regular expression parameter
```

### Limitations to Field-Level Validation


### Custom Filter Annotations
One limitation of field-level validations is the exception thrown (depending on how execution is triggered) halting the request from completing.  This may not be desirable behavior.  Other methods of validation are needed when data filtering is required.

[spring-base-security](https://github.ford.com/DevEnablement/spring-base-security) provides a collection of filters and encoders include some allowing customization.

```text
@UriEncodeInputData - URI encode strings in input objects
@HtmlEncodeInputData - HTML encode strings in input objects
@HtmlEncodeInputOutputData - HTML encode strings in both input and output (Will double encode HTML)
@HtmlEncodeOutputData - HTML encode strings in output objects
@RemoveScriptTagsOutputData - Remove script tags in output objects
@WhitelistRegexInputData - Filter input to match accepted characters supplied in regex
@BlacklistRegexInputData - Filter input to omit characters supplied in regex
```

In addition the validators and filters, there are also a few String functions, see the lib repo for more information.


## Injection Attacks

### Cross-Site Scripting (XSS)
Two types of XSS are:
* Reflected
* Stored

Stored is more dangerous becuase the attack becomes hosted by the application itself.  Typically this means 
the malicious script is stored in the app's database and becomes generated on pages that can be viewed by multiple
users.  The script can get added by insufficient input filtering or by adding input filtering post production launch.
Output filtering is the last line of defense.

Reflected attacks require a victim user to click a malicious link that includes the malicious script in the URI.
Attackers can encode the script such that it isn't obvious to the casual user.  Input filtering is very effective
against this form of attack.

The UIV controller is deliberately vulnerable to XSS.  Anything supplied in the "id" query string parameter is echo'ed back to the browser.


```java
@RequestMapping(path = "/api/v1/uiv")
public class UivController {

    @ApiOperation(value = "GET Test endpoint", notes = "Returns posted string")
    @GetMapping
    public String get(@RequestParam(name = "id") UivGetRequest uivGetRequest) {
        return uivGetRequest.getData();
    }
```

This provides a good way to see if the validation filtering code introduced later functions.


```
Common XSS test using browser:
http://localhost:8080/api/v1/uiv?id=<script>alert(123)</script>
Same using CURL:
curl -G http://localhost:8080/api/v1/uiv --data-urlencode "id=\"<script>alert</script>\""

XSS redirect (This is why you have to register redirects)
http://localhost:8080/api/v1/uiv?id=<script>document.location="http://www.google.com"</script>

Cookie Stealing
http://localhost:8080/api/v1/uiv?id=<script>alert(document.cookie)</script>

Session Storage Mining
http://localhost:8080/api/v1/uiv?id=<script>alert(sessionStorage.token)</script>

```
### SQL Injection
ORM provides a significant amount of protection against SQL injection.  I haven't identified SQL injection 
vulnerabilities using Spring Data JPA's generated queries or using 'declared queries'.  In order to create a vulnerable
test bed I had to use EntityManager to process my crafted vulnerable query that didn't use parameterization:

```java
    @Override
    public List<Greeting> findGreetingsByMessageKeyword(String keyword) {
        String keywordQuery = "select g from Greeting g where g.message like '%" + keyword + "%'";
        Query query = this.entityManager.createQuery(keywordQuery, Greeting.class);
        List<Greeting> greetingList = query.getResultList();
        return greetingList;
    }
```
This is a good example of what NOT TO DO.  This is vulnerable to SQL Injection when input filtering is not sufficient.


Attack:
```shell script
curl http://localhost:8080/api/v1/greetings/keyword/s\'%20or%201\=1%20OR%20g.message%20like%20\'z
```

This attack applies the text below to the keyword variable:  
```text
s\' or 1\=1 OR g.message like \'z
```

This results in the following query:
```sql
select g from Greeting g where g.message like '%s' or 1=1 OR g.message like 'z%'
```

Injecting "or 1=1" into the query allows all records to be returned.


## Data Filtering
Running data through encoders can remove/encode/replace suspicious content without stopping the flow of execution.
The big questions are where and how.  Setters sound good on paper but that breaks Lombok as well as purest rules that setters should set the data without modification.
Additional class functions can be added but they will need to be replicated across the codebase.
Aspect-Oriented Programming (AOP) is an attractive option.


### Aspect-Oriented Programming - AOP
AOP allows you to thread functionality into the program execution flow.  User input can be collect and sent through filters as can output data.  
The functionality can be replicated simply reducing duplication and speeding implementation.
Making security easy to implement is always a good thing.

The trick with AOP is determining what triggers the functionality and what 'advice type' to use.  There are a number of options but I feel @Around is the best option as it makes both the input and output available for modification and it can handle multiple arguments.
Defining the Aspect and triggering it with a custom annotation also brings an element of control so it's easy to toggle.

[spring-base-security](https://github.ford.com/DevEnablement/spring-base-security) uses this approach.  If you have ideas to expand the functionality or improve it, feel free to contact us or initiate a pull request.

##### Create Tests
We already have tests for the happy path, the expected input.  Now we need some malicious input.  Security tools do this through fuzzing.  Fuzzers can be customized based on the target field.  For instance is a number is expected, send in a character, a string, a huge number, a huge string.  A good way to test is using an automated tool but a few unit or acceptance tests should ensure the app has some form of input validation.

When creating the tests, consider how the data is being processed and how it is being used.
What special characters are involved with your database?  Is your data going back to a browser?  A message queue?  Use those in the request.
This is especially important if SQL queries are being created manually.  A few common examples are shown below:
* 'OR 1=1--'
* '<script>alert(123)</script>'
* AAAAAAAAAAAA...A <- A huge amount of them such as 1K, 10K, 100K, 1G

```java
public class HelloSecurityAcceptanceTest {
    ...

    @Test
    public void testPostXssHelloEndpoint() throws Exception {
        HelloRequest helloRequest = HelloRequest.builder().name("<script>alert(123)</script>").build();
        HelloResponse helloResponse = (HelloResponse) post(webClient, "/api/v1/hello", helloRequest, HelloResponse.class);
        assertThat(helloResponse.getResult().getGreeting()).isNotEqualTo("Hello <script>alert(123)</script>");
    }

    @Test
    public void testPostSqlInjectionHelloEndpoint() throws Exception {
        HelloRequest helloRequest = HelloRequest.builder().name("'-- OR 1=1'").build();
        HelloResponse helloResponse = (HelloResponse) post(webClient, "/api/v1/hello", helloRequest, HelloResponse.class);
        assertThat(helloResponse.getResult().getGreeting()).isNotEqualTo("Hello '-- OR 1=1'");
    }
```

## Conclusion
Data validation and scanning can be implemented in a manner that is simple to implement resulting in large security gains.



[Home](README.md)
