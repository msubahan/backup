# Extras

This section includes additional notes and also security suggestions outside the current OWASP Top 10 list.

## Ecoboost project modifications during creation of this content
- Added channel security as https redirector in security config
- Added HSTS header in security config
- Added custom error handler
- Added spring-base-security validators and filters/encoders
- Added SQL injectable query for testing
- Added controller vulnerable to XSS for testing
- Added security tests:
    - Invalid input
    - Unhandled Exceptions


# Header Security
By default a few security related headers are enabled:

To view the headers returned, simply run Curl against an endpoint with the -i option:
```shell script
curl -i http://localhost:8080/actuator/health
```

## Default Headers
### X-Content-Type-Options: nosniff
Tells the browser not to sniff/guess the artifact type.
An attacker could upload a .jpg file which is really malicious JavaScript.  
The browser would then execute the JavaScript without the header.

### X-XSS-Protection: 1; mode=block
Browsers will not render a page if they detect a reflected XSS.  
In my opinion this doesn't seem effective.

### X-Frame-Options: DENY
Clickjacking defense.  Instructs the browser not to load the page in a frame.

### CSRF/XSRF
These attacks occur when a user clicks or is otherwised tricked into executing a request to a site they are currently logged in.
The browser automatically sends the cookie to the back-end.  The attack is more complicated when data must be posted.

### Check supported methods
```java
curl -i -H "access-control-request-headers: authorization,content-type" -X OPTIONS  http://localhost:8080/api/v1/uiv
```

#### Defense
User Action:  Logging out and clearing cookies after completing actions on a website.

Enabling the use of CSRF tokens on the server in the security configuration.  This token is used on all requests that modify data.
```java
http.csrf().enable()  // Enabled by default in Java configurations
```
The token must be received either via form parameter or http header.


## Developer Configured

### Cross-site request forgery
Required for server-side web apps using redirect URI


### HSTS and Channel Security (Redirect from HTTP to HTTPS)

The HSTS header tells browsers to alway use HTTPS.  
This header cannot be set over HTTP so a redirect is required before it can be set.
By default the header states the browser should honor this for 1 year for all subdomains but this can be tuned.

#### Spring Boot
Both options are trivial to enable in SpringBoot but there are unintended consequenses that can be mitigated using the techniques below:
1) How does this work on localhost?
2) What about unit tests such as controller integration tests?

```java
		@Autowired
		private Environment environment;
        ...
        			String[] profiles = this.environment.getActiveProfiles();
        			if (!Arrays.deepToString(profiles).contains("local")) {
        				http.headers().httpStrictTransportSecurity();
        				http.requiresChannel().anyRequest().requiresSecure();
        			}
```

As shown above, this configuration is skipped for local profiles.
To avoid 302 redirects in unit tests configure profiles in applicable tests:

```java
@RunWith(SpringRunner.class)
@AutoConfigureMockMvc
@SpringBootTest(webEnvironment = RANDOM_PORT)
@Import(ExceptionHandlerConfiguration.class)
@AutoConfigureWebTestClient(timeout = "30000")
@ActiveProfiles({"local"})
public class ActuatorsSecurityTest {
```

Other adjustments will be needed for the run configurations depending on what is being used (IDE, bootRun,..)

#### NGINX
For the SPA, this is done by modifying the nginx.conf.
You can use SSH to log into your SPA in on-prem PCF preprod: `> cf ssh [appname]`
then locate and copy it's contents for local modification:

```
cyourman$ cf ssh dev-services-ui
vcap@83a31828-097e-4fa8-78a7-4ffc:~$ find ./ -name nginx.conf
./app/nginx/conf/nginx.conf
vcap@83a31828-097e-4fa8-78a7-4ffc:~$ cat ./app/nginx/conf/nginx.conf
```

Redirect to HTTPS:

```
server {
    ...
    listen 8080;
    server_name myvanitydomain.com;
    return 301 https://linuxize.com$request_uri;
    ...
}
```

HSTS Header:
```
server {
    ...
    add_header Strict-Transport-Security "max-age=31536000; includeSubDomains" always;
    ...
}
```

server {
    listen 8080;
    server_name myvanitydomain.com;
    return 301 https://linuxize.com$request_uri;
}  

server {
    add_header Strict-Transport-Security "max-age=31536000; includeSubDomains" always;
    
    location /health {
        default_type application/json;
        return 200 '{"status":"UP"}';
    }
}


## Additional Resources
[Three Rs of Security](https://builttoadapt.io/the-three-r-s-of-enterprise-security-rotate-repave-and-repair-f64f6d6ba29d
)

[Home](README.md)
