# Known Vulnerable Components

Ensure your application is not using known vulnerable components.  This can be handled in CI/CD via Static Application Security Testing (SAST) tools.
One concern is applications can become stale becoming vulnerable over time as security issues are discovered in the app's dependencies.  App teams may need processes to run regular code scans to ensure newly discovered vulnerabilities get flagged.
Additionally, Spring is updated regularly and it's important for applications to run the current recommended version.

### Determine Ford-Recommended SpringBoot Version
[D/C/S Ecoboost](https://dcs.ford.com/project-workflow/springboot) is maintained to the currently recommended version.  Teams can generate a new project to identify the recommended version.

DevEnablement provides [migration guides](https://github.ford.com/DevEnablement/pcfdev-guides/tree/master/migrations) to ease the upgrade process.
 
### Code Scanning
- CI/CD
    - [Fossa](https://github.ford.com/DevEnablement/pcfdev-guides/blob/master/fossa/README.md)
    - [Checkmarx](http://wiki.ford.com/pages/viewpage.action?spaceKey=SDE&title=Checkmarx+SAST)
    - [SonarQube](https://github.ford.com/DevEnablement/pcfdev-guides/tree/master/sonarqube)
- Local Environment
    - [Fossa](http://github.ford.com/DevEnablement/pcfdev-guides/blob/master/fossa/README.md#FOSSA-analysis-command-prompt-example)
    - Checkmarx
        - [IntelliJ](https://checkmarx.atlassian.net/wiki/spaces/SD/pages/45056225/Running+a+Scan+from+IntelliJ+up+to+v8.9.0)
        - [Eclipse](https://checkmarx.atlassian.net/wiki/spaces/SD/pages/43778199/Running+a+Scan+from+Eclipse+up+to+v8.9.0)
    - [SonarQube](https://github.ford.com/DevEnablement/pcfdev-guides/tree/master/sonarqube#Submit-to-SonarQube-from-command-line)
    - [OWASP Dependency-Check](https://owasp.org/www-project-dependency-check)

[Home](README.md)
