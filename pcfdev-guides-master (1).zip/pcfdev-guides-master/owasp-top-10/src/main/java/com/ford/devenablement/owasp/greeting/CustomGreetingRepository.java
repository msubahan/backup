package com.ford.devenablement.owasp.greeting;

import java.util.List;

public interface CustomGreetingRepository {
    public List<Greeting> findGreetingsByMessageKeyword(String keyword);
}
