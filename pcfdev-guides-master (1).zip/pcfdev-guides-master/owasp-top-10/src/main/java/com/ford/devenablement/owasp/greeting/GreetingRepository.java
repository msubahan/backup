package com.ford.devenablement.owasp.greeting;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.Repository;

import java.util.List;
import java.util.Optional;

public interface GreetingRepository extends Repository<Greeting, Long> {

	String QUERY_GREETINGS_MESSAGE_KEYWORD = "select g from Greeting g where g.message like %:messageKeyword%";

	List<Greeting> findAll();

	Greeting save(Greeting greeting);

	Optional<Greeting> findById(Long id);

	@Query(QUERY_GREETINGS_MESSAGE_KEYWORD)
	List<Greeting> findGreetingsByMessageKeyword(String messageKeyword);

}
