package com.ford.devenablement.owasp.greeting.api;

import com.ford.cloudnative.base.api.BaseBodyResponse;
import com.ford.devenablement.owasp.greeting.api.CreateGreetingResponse.CreateGreetingResponseResult;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

public class CreateGreetingResponse extends BaseBodyResponse<CreateGreetingResponseResult> {

	@Data
	@Builder
	@NoArgsConstructor
	@AllArgsConstructor
	public static class CreateGreetingResponseResult {
		GreetingApi greeting;
	}

}
