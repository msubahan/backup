package com.ford.devenablement.owasp.greeting.api;

import javax.validation.constraints.NotNull;

import com.ford.cloudnative.annotations.AlphaNumericOnlyValidator;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CreateGreetingRequest {
    @AlphaNumericOnlyValidator
    @NotNull String message;

    @AlphaNumericOnlyValidator
    String authorName;
}
