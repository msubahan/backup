package com.ford.devenablement.owasp.greeting;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.OffsetDateTime;
import java.util.List;
import java.util.Optional;

@Service
public class GreetingService {

	private GreetingRepository greetingRepository;
	private CustomGreetingImpl customGreetingImpl;

	@Autowired
	public GreetingService(GreetingRepository greetingRepository, CustomGreetingImpl customGreetingImpl) {
		this.greetingRepository = greetingRepository;
		this.customGreetingImpl = customGreetingImpl;
	}

	public Greeting create(Greeting newGreeting) {
		newGreeting.setCreated(OffsetDateTime.now());
		return this.greetingRepository.save(newGreeting);
	}

	public List<Greeting> getAllGreetings() {
		return this.greetingRepository.findAll();
	}

	public Optional<Greeting> getGreeting(Long id) {
		return this.greetingRepository.findById(id);
	}

	public List<Greeting> getGreeting(String keyword) {
//		return this.greetingRepository.findGreetingsByMessageKeyword(keyword);
		return this.customGreetingImpl.findGreetingsByMessageKeyword(keyword);
	}
}
