package com.ford.devenablement.owasp.uiv.api;

import com.ford.cloudnative.annotations.WhitelistCharsValidator;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class UivExceptionGetRequest {
    @WhitelistCharsValidator(chars = {'A'})
    String data;
}
