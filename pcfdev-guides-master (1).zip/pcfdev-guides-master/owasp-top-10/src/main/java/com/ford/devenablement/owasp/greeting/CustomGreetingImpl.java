package com.ford.devenablement.owasp.greeting;

import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import java.util.List;

@Repository
public class CustomGreetingImpl implements CustomGreetingRepository {

    @PersistenceContext
    EntityManager entityManager;

    @Override
    public List<Greeting> findGreetingsByMessageKeyword(String keyword) {
        String keywordQuery = "select g from Greeting g where g.message like '%" + keyword + "%'";
        Query query = this.entityManager.createQuery(keywordQuery, Greeting.class);
        List<Greeting> greetingList = query.getResultList();
        return greetingList;
    }
}
