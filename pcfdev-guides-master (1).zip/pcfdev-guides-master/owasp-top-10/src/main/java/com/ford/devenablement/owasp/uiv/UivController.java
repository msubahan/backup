package com.ford.devenablement.owasp.uiv;

import com.ford.cloudnative.annotations.HtmlEncodeInputData;
import com.ford.devenablement.owasp.uiv.api.*;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

@Slf4j
@Validated
@RestController
@RequestMapping(path = "/api/v1/uiv")
public class UivController {
    // ============= DEMO - TEST METHOD ==============
    @ApiOperation(value = "GET Test endpoint", notes = "Returns posted string")
    @GetMapping
//    @HtmlEncodeInputData(loggingEnabled = true)
    public String get(@RequestParam(name = "id") UivGetRequest uivGetRequest) {
        return uivGetRequest.getData();
    }

    @ApiOperation(value = "Test endpoint for verbose exception", notes = "Send chars that are not all 'A's.")
    @GetMapping("exception")
    public String getException(@RequestParam(name = "id") @Valid UivExceptionGetRequest uivExceptionGetRequest) {
        return uivExceptionGetRequest.getData();
    }

    @ApiOperation(value = "POST Test endpoint", notes = "Returns posted string")
    @PostMapping
    @HtmlEncodeInputData(loggingEnabled = true)
    public UivPostResponse helloNameUIVTest(@RequestBody @Valid UivPostRequest uivPostRequest) {
        UivPostResponse postResponse = UivPostResponse.builder()
                .data1(uivPostRequest.getData1())
                .data2(uivPostRequest.getData2())
                .number(uivPostRequest.getNumber())
                .build();
        return postResponse;
    }

    @ApiOperation(value = "Complex POST data test endpoint", notes = "Returns posted string")
    @PostMapping("/complex")
    @HtmlEncodeInputData(loggingEnabled = true)
    public UivPostComplexRequest helloNameUIVTest(@RequestBody @Valid UivPostComplexRequest uivComplexPostRequest) {
        return uivComplexPostRequest;
    }

    @GetMapping("/{id}/{version}")
    @HtmlEncodeInputData(loggingEnabled = true)
    public String getStackTechnologyDetailsBy(
            @PathVariable int id, @PathVariable String version) {
        return version;
    }
}
