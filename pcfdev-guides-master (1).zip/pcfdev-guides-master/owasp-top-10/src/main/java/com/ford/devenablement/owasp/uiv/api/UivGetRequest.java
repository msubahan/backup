package com.ford.devenablement.owasp.uiv.api;

import com.ford.cloudnative.annotations.WhitelistCharsValidator;
import lombok.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class UivGetRequest {
    @NonNull
    String data;
}
