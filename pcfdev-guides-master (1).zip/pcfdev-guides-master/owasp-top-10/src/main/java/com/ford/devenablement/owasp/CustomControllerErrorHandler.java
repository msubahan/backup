package com.ford.devenablement.owasp;

import com.ford.cloudnative.base.api.BaseBodyError;
import com.ford.cloudnative.base.api.BaseBodyResponse;
import com.ford.cloudnative.base.app.web.exception.BaseBodyResponseException;
import com.ford.cloudnative.base.app.web.exception.handler.CommonBaseBodyErrorAttributes;
import com.ford.cloudnative.base.app.web.tracer.DefaultRequestTracerConfiguration;
import com.ford.cloudnative.base.app.web.tracer.RequestTracer;
import com.ford.cloudnative.base.app.web.tracer.SleuthRequestTracerConfiguration;
import com.ford.cloudnative.helpers.SecurityHelper;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.Import;
import org.springframework.core.annotation.AnnotatedElementUtils;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.util.WebUtils;

import java.util.Map;

import static org.springframework.http.HttpStatus.BAD_REQUEST;
import static org.springframework.http.HttpStatus.INTERNAL_SERVER_ERROR;

@Slf4j
@ControllerAdvice
@RequiredArgsConstructor
@Import({CommonBaseBodyErrorAttributes.class, SleuthRequestTracerConfiguration.class, DefaultRequestTracerConfiguration.class})
public class CustomControllerErrorHandler {
    @NonNull CommonBaseBodyErrorAttributes commonBaseBodyErrorAttributes;
    @NonNull RequestTracer requestTracer;

    @ExceptionHandler(Exception.class)
    @ResponseBody
    protected ResponseEntity<?> handleUncaughtException(Exception ex, WebRequest request) {
        String message = "An error has occurred, please contact the administrator";
        ResponseEntity<?> responseEntity;

        if (ex instanceof BaseBodyResponseException) {
            BaseBodyResponseException bodyResponseEx = (BaseBodyResponseException) ex;

            // populate any missing default error attributes
            if (bodyResponseEx.getBodyResponse().getError() != null) {
                Map<String, Object> errorAttributes = bodyResponseEx.getBodyResponse().getError().getAttributes();
                this.commonBaseBodyErrorAttributes.populateAttributes(errorAttributes, ex, request);
            }

            responseEntity = new ResponseEntity<>(bodyResponseEx.getBodyResponse(), bodyResponseEx.getHttpStatus());
        } else {
            String traceId = requestTracer.getTraceId();
            log.error("Unexpected exception: Principal=" + SecurityHelper.getJwtSubject() + " message= " + ex.getMessage());
            ResponseStatus responseStatus = AnnotatedElementUtils.findMergedAnnotation(ex.getClass(), ResponseStatus.class);

            HttpStatus httpStatus;
            if (responseStatus == null) {
                httpStatus = (ex.getMessage().contains("Validation failed")) ? BAD_REQUEST : INTERNAL_SERVER_ERROR;
            } else {
                httpStatus = responseStatus.code();
            }

            BaseBodyError baseBodyError = BaseBodyError.builder()
                    .message(message)
                    .errorCode(String.valueOf(httpStatus.value()))
                    .build();
            responseEntity = new ResponseEntity<>(BaseBodyResponse.error(baseBodyError), httpStatus);
        }

        if (request != null && HttpStatus.INTERNAL_SERVER_ERROR.equals(responseEntity.getStatusCode()))
            request.setAttribute(WebUtils.ERROR_EXCEPTION_ATTRIBUTE, ex, WebRequest.SCOPE_REQUEST);
        return responseEntity;
    }
}
