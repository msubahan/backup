package com.ford.devenablement.owasp;

import com.ford.cloudnative.annotations.EnableFordSecurityTools;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@EnableFordSecurityTools
@SpringBootApplication
public class OwaspApplication {

	public static void main(String[] args) {
		SpringApplication.run(OwaspApplication.class, args);
	}

}
