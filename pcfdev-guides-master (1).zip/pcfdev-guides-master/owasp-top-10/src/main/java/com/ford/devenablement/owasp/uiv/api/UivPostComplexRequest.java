package com.ford.devenablement.owasp.uiv.api;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class UivPostComplexRequest {
    String data1;
    String data2;
    int number;
    String[] stringArray;
    UivPostRequest uivPostRequest;
    Object anotherThing;
    List<UivPostRequest> postRequestList;
}
