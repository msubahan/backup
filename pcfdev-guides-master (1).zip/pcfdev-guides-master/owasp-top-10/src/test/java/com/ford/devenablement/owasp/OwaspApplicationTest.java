package com.ford.devenablement.owasp;

import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class OwaspApplicationTest {
	@Test
	public void contextLoads() {
	}
}