package com.ford.devenablement.owasp.acceptance;

import com.ford.cloudnative.base.test.acceptance.AcceptanceTestUtil;
import lombok.extern.slf4j.Slf4j;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.springframework.web.reactive.function.client.ClientResponse;
import org.springframework.web.reactive.function.client.WebClient;
import static com.ford.devenablement.owasp.TestUtil.*;
import static org.assertj.core.api.Assertions.assertThat;

@Slf4j
public class UivAcceptanceTest {

    WebClient webClient;

    @Before
    public void setup() {

        webClient = AcceptanceTestUtil.webClientBuilder().build();
    }

    @Test
    @Ignore // Defaulting app to insecure for demo purposes, uncomment @HtmlEncodeInputData in UivController
    public void crossSiteScriptingGetTest() {
        String xss = "<script>alert('xss');</script>";
        ClientResponse response = get(webClient, "/api/v1/uiv?id=" + xss);
        String result = response.bodyToMono(String.class).block();
        assertThat(result).isNotEqualTo(xss);
    }

    @Test
    public void crossSiteScriptingPostTest() {
        String xss = "<script>alert('xss');</script>";
        ClientResponse response = post(webClient, "/api/v1/uiv", xss);
        String result = response.bodyToMono(String.class).block();
        log.info(result);
        assertThat(result).isNotEqualTo(xss);
    }
}
