package com.ford.devenablement.owasp;

import com.ford.devenablement.owasp.greeting.GreetingController;
import com.ford.devenablement.owasp.greeting.GreetingMapper;
import com.ford.devenablement.owasp.greeting.GreetingService;
import lombok.extern.slf4j.Slf4j;
import org.junit.After;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.security.oauth2.jwt.JwtDecoder;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.ResultActions;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultHandlers;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@Slf4j
@ActiveProfiles({"local"})
@RunWith(SpringRunner.class)
@WebMvcTest(controllers = {GreetingController.class, GreetingMapper.class})
public class ErrorHandlerConfigurationTest {
    private final ByteArrayOutputStream outContent = new ByteArrayOutputStream();
    private final ByteArrayOutputStream errContent = new ByteArrayOutputStream();
    private final PrintStream originalOut = System.out;
    private final PrintStream originalErr = System.err;

    @Autowired
    MockMvc mockMvc;

    @MockBean
    JwtDecoder jwtDecoder;

    @MockBean
    GreetingService greetingService;

    @Before
    public void setup() {
        when(this.greetingService.getAllGreetings()).thenThrow(new RuntimeException("Verbose Error"));
        System.setOut(new PrintStream(outContent));
    }

    @After
    public void restoreStreams() {
        System.setOut(originalOut);
    }

    @Test
    @Ignore // Defaulting to insecure for demo purposes - Set this property to false: cn.app.exception-handler.enabled
    public void should_return500errorWithSanitizedMessage() throws Exception {
        String message = "An error has occurred, please contact the administrator";
        jsonGet("/api/v1/greetings")
                .andExpect(status().is5xxServerError())
                .andExpect(jsonPath("$.error.messages[0]").value(message));
        assertThat(outContent.toString().contains("Unexpected exception: referenceId=")).isTrue();
    }

    ResultActions jsonGet(String url) throws Exception {
        return this.mockMvc.perform(MockMvcRequestBuilders.get(url))
                .andDo(MockMvcResultHandlers.print());
    }
}
