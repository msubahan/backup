package com.ford.devenablement.owasp.encoders;

import com.ford.devenablement.owasp.greeting.api.CreateGreetingRequest;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;

@SpringBootTest
@RunWith(SpringRunner.class)
public class SecurityInputOutputValidationTest {
    @Autowired
    TestInputValidationsHelper testInputValidationsHelper;

    @Test
    public void checkInputValidations_CreateStackRequest() {
        CreateGreetingRequest request = CreateGreetingRequest.builder()
                .message(getMaliciousString())
                .authorName(getMaliciousString())
                .build();

        testInputValidationsHelper.encodeCreateGreetingRequest(request);
        assertEquals(request.getMessage(), getSanitizedString());
        assertNotEquals(request.getMessage(), getMaliciousString());
        assertEquals(request.getAuthorName(), getSanitizedString());
        assertNotEquals(request.getAuthorName(), getMaliciousString());
    }

    private String getMaliciousString() {
        return "<script>alert('test')</script>'or 1=1--";
    }
    private String getSanitizedString() {
        return "&lt;script&gt;alert(&#39;test&#39;)&lt;/script&gt;&#39;or 1=1--";
    }
}
