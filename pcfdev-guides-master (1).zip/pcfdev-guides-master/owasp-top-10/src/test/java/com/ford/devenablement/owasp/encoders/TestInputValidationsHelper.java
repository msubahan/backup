package com.ford.devenablement.owasp.encoders;

import com.ford.cloudnative.annotations.HtmlEncodeInputData;
import com.ford.devenablement.owasp.greeting.api.CreateGreetingRequest;
import org.springframework.stereotype.Component;

@Component
public class TestInputValidationsHelper {

    @HtmlEncodeInputData(loggingEnabled = true)
    CreateGreetingRequest encodeCreateGreetingRequest(CreateGreetingRequest request) {
        return request;
    }

}
