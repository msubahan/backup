##  Service Registry Guide

The concept of service registry is covered by many tutorials online including this one: [Introduction to Spring Cloud Netflix – Eureka](http://www.baeldung.com/spring-cloud-netflix-eureka).

This guide demonstrates how to integrate your application specifically with Pivotal's *service registry*  offering in PCF. It is also provides a method to disable that local connection loopback error while developing locally without a local Eureka instance running.

<br/>

### Service Registry Tile

It is very easy to integrate your Spring Boot application with Pivotal's *service registry* tile. Before you do that, 
you must first create a *service registry* tile in your CF space. You have a few options.

- One option is to manually create the tile by logging into the Cloud Foundry Portal, navigating to your CF space, 
clicking the *Services* tab, and click *Add Service*. Select *Service Registry* and continue to create your service. 
Consider naming it [team_name]-service-registry; i.e. pcfdev-service-registry.

- Another option is to create a service instance using the *cf cli* utility:

```
cf create-service p.service-registry standard devenablement-service-registry
```

- Yet another option is using the Dev Enablement pipeline and having a service instance created lazily, that is one can
be created during code deploy if one is not already existing. 
See [CAB](https://github.ford.com/PCFDev-CAB/cab-service-fordair/blob/master/pipeline/pipeline.cf-services.sh) for an 
example, or our [Pipeline Guide](https://devservices.ford.com/dev-guides?search=Jenkins%20Pipeline) for more details.

<br/>

### Implementation

Place the following dependency in your [build.gradle](build.gradle):

```
io.pivotal.spring.cloud:spring-cloud-services-starter-service-registry
```

Lastly, you need to bind to the tile while deploying the application to CF. You can do in the application's [manifest file](cf/manifest-template.yml):

<pre>
applications:
- name: devenablement-service-registry
  memory: 1G
  services:
  <strong>- devenablement-service-registry</strong>
</pre>


<br/>

### Local Development

By adding the above service registry dependency, your application by default will attempt to connect a local service 
registry (i.e. Eureka server). If you do not have a local Eureka server instance running, then the failed attempt will 
be logged and the application will retry every few seconds. The repeated error messages will create noise in the 
application logs and it would make difficult to detect and troubleshoot real local errors.

Service registry integration is typically not required for most local development. To counter these chatty error 
messages, we can rely on CloudNative Spring starter `com.ford.cloudnative:spring-boot-starter-ford` to disable service 
registry integration by default during local development. To achieve this, add the CloudNative Spring dependency and 
set the following property in your *application.properties*:

```
cn.app.disable-local-discovery-client.enabled=true
```

In the event you do want to connect to a service registry while developing locally, then you can override this property 
setting by setting the above property to false, or by setting an environment variable *CN_APP_DISABLE_LOCAL_DISCOVERY_CLIENT_ENABLED=false*.

> Note: This property only impacts localhost. Your applciation deployed to PCF will look for a Eureka Server and will log errors if one is not found.

## Use Cases
Below are some use cases where Service Registry solution shall be considered:

Clients of a service use either Client-side discovery or Server-side discovery to determine the location of a service instance to which to send requests.

- #### The Client‑Side Discovery
Client-side registry, where the microservices have the knowledge of registries, locate an instance, and then call them to get the address of a service they need.

- #### The Server‑Side Discovery 
The client makes a request to a service via a load balancer. The load balancer queries the service registry and routes each request to an available service instance. 

 - #### C2C networking using App Service Discovery 
 C2C networking can be accomplished using App Service Discovery by just registering the apps in the Service Registry using 'direct' registration method and by adding the required network policies (https://github.ford.com/DevEnablement/pcfdev-guides/blob/master/c2c_networking/ReadMe.md).


## Blue/Green Deployment Issue
When using the EcoBoost Jenkins pipeline offering with an application that is using an instance of a service registry, the name of your application will appear in the Service Registry using the "-temp" suffix that is assigned during the Blue/Green deploy. Unfortunately, when the application is released as part of the pipeline, the route changes but the name of the application in the Service Registry is not updated and will remain with the "-temp" suffix.

One solution to this issue is to use the post release script feature that was introduced in the [v3.1.0](https://github.ford.com/DevEnablement/ecoboost-pipeline/releases/tag/v3.1.0) release of the pipeline. In this script, you can opt to use the CF CLI [“Zero downtime restart”](https://docs.cloudfoundry.org/devguide/deploy-apps/rolling-deploy.html#restart) command (this command differs depending on the version of thge CF CLI) to restart the application. This will cause the application instance(s) to be registered with the proper name.

>Note: This is optional, since the name of the app as it appears in the Service Registry console will not have any impact on how your application functions.




 

