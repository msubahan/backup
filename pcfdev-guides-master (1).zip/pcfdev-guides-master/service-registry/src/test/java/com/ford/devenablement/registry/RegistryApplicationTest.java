package com.ford.devenablement.registry;

import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class RegistryApplicationTest {
	@Test
	public void contextLoads() {
	}
}