# TimeZone Support

This guide will explain how to configure your Spring Boot application to use a specific TimeZone, and thus overriding the default behavior which is to use the TimeZone of the underlying operating system.

There are many [posts on the web](https://lmgtfy.com/?q=set%20default%20timezone%20spring%20boot&p=1&s=g) that will explain how to do this for a spring boot application. Some opt for a JVM setting and some opt for an application code setting. Our solution chooses the later, so that the setting is portable whether the code is running from the command line, IDE, or deployed environment.

We feel that using UTC makes the most sense as a default TimeZone, but ultimately that is a team decision. The default behavior is that all creation of Dates or Times in Java, as well as timestamps written to logs, will be based on the local operating system timestamp format. This default in PCF, your localhost, and most other server environments at Ford is to use local time (for us here in Dearborn we use EDST). After applying the change as prescibed in this guide, you will witness the timestamps in your logs (or console in your IDE) relfect the new TimeZone shortly into the server startup process (i.e. if changing to UTC, you will see the time initially display as local and then as UTC).



## Prerequisite
This solution we offer does take advantage of a property setting that is supported by our Ford Spring Base Libraries. There are many other features in this library, so feel free to explore the code in it's [GitHub repo](https://github.ford.com/DevEnablement/spring-base-dependencies).  

> *Note:* Inclusion of the Ford Spring Base libraries makes many other capabilities available, but we have purposely made it so that you need to opt in for them to be configured. Many of the other Guides in this repo speak to specific capabilities that you can selectively opt-in and enable. See the [Base Service Guide](../base-service) or the [CAB referance application](https://github.ford.com/PCFDev-CAB/cab-service-fordair) for more details or examples on using the other capabilities.

In order to include this library in your project, simply add the library to your project. Below is an example for Gradle that would be added to your `build.gradle` file.

```
implementation 'com.ford.cloudnative:spring-boot-starter-ford:2.2.0'
```



## Solution

Assuming you are using the prerequisite Ford Spring Base Libraries via the inclusion of our spring-boot-starter-ford pom, you will be able to set the TimeZone simply by adding an entry to your `application.properties` file in your project. Below is an example from our CAB reference application, where we opted to use UTC as our TimeZone.

```
# Use UTC as clock for server
cn.app.configure.default-time-zone=UTC
```

## References

Examples from our CAB Reference Application:
- [build.gradle](https://github.ford.com/PCFDev-CAB/cab-service-fordair/blob/master/build.gradle)
- [application.properties](https://github.ford.com/PCFDev-CAB/cab-service-fordair/blob/master/src/main/resources/application.properties)
