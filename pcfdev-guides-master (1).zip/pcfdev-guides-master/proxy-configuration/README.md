# Proxy Guide

This guide explains required settings to get your various tools/processses (e.g. CLI tools, IDE, Jenkins, apps, browsers) configured with Ford's proxy servers so that they can communicate with the internet outside the firewall.

<br/>

## Ford Proxy Servers

A proxy server is a gateway between the local network and a larger-scale network such as the public internet. Proxy servers provide increased performance and security. At Ford, network traffic reaching out to the public internet must flow through one of the Ford proxy servers. Network traffic between internal resources, on the other hand, must NOT flow thru any Ford proxy server.

The following is a list of all available Ford proxy server(s). Make sure to use the apprioriate proxy server based on your region.

<table>
 <tr><td valign="top" width="400">Proxy Load Balancer</td>
      <td width="100">Port  </td>
      <td width="400">Region <br/></td></tr> 
  <tr><td valign="top" width="400">internet.ford.com</td>
      <td width="100">83</td>
      <td width="400">Americas (Load Balanced)<br/></td></tr>
  <tr><td valign="top" width="400">proxyvipchi.nls.ford.com</td>
      <td width="100">83</td>
      <td width="400">Americas (Chicago)<br/></td></tr>
  <tr><td valign="top" width="400">proxyvipash.nls.ford.com</td>
      <td width="100">83</td>
      <td width="400">Americas (Ashburn)<br/></td></tr> 
  <tr><td valign="top" width="400">proxyvipfra.nb.ford.com</td>
      <td width="100">83</td>
      <td width="400">Europe<br/></td></tr>
  <tr><td valign="top" width="400">proxyvipsgh.nb.ford.com</td>
      <td width="100">83</td>
      <td width="400">Asia<br/></td></tr>                   
           
</table>

> Source: [https://azureford.sharepoint.com/sites/ExtranetCoreServices/sitepages/http%20configuration.aspx](https://azureford.sharepoint.com/sites/ExtranetCoreServices/sitepages/http%20configuration.aspx)

<br/>

## Command Line Tools

Most tools rely on the following environment variables to configure proxy settings; i.e. `http_proxy`, `https_proxy`, `no_proxy`. These variables may be set at the system-level so they apply to all applications or terminal sessions. Alternatively these variables can be set temporary in specific terminal sessions.

For example, if you are located in the *Americas* region, the following proxy configurations will typically<sup>[1]</sup> work:

```sh
 export http_proxy=http://internet.ford.com:83  
 export https_proxy=http://internet.ford.com:83
 export no_proxy=localhost,127.0.0.1,19.0.0.0/8,10.0.0.0/8,172.16.0.0/12,.ford.com
```

> NOTE: For Windows command prompt, replace ~~**export**~~ with **set** keyword.

<br/>

#### <sup>[1]</sup>`no_proxy` special considerations

The `no_proxy` environment variable controls which hosts should be excluded from proxy servers. This should be a comma-separated list of hostnames, domain names, or a mixture of both. Asterisks can be used as wildcards, but not all tools may support that. Domain names may be indicated by a leading dot.

Recall that all network traffic to internal resources should not flow thru proxy servers. Therefore, the `no_proxy` variable should be setup with all internal Ford hosts the team's tools/processes attempt to access (e.g. *www.nexus.ford.com*, *www.sonarqube.ford.com*, *.edc1.cf.ford.com*, *sys-pcf02v2.cf.ford.com*, *apps-pcf02v2i.cf.ford.com*). **As long as ALL of the \*.ford.com resources accessed are internal, teams can choose to use the single rule <u>\.ford.com</u> to cover their internal access**.

> NOTE: Teams that deploy to **Microsoft Azure** PCF foundations do NOT have the option to use <u>**\.ford.com**</u> because their public PCF foundation is a sub-domain of ford.com. They must individually specify all internal ford resources they access.

<br/>

#### Other environment variable names

Other tools may rely on different environment variable name other than `http_proxy`. Consider setting these other environment names using the same values:
 - HTTP_PROXY
 - HTTPS_PROXY
 - npm_config_proxy, npm_config_https_proxy
 - rsync_proxy, RSYNC_PROXY
 - ftp_proxy, FTP_PROXY
 
Consider also setting `NO_PROXY` environment variable with the same `no_proxy` value

<br/>


## Java Based Tools & Applications

Refer to Oracle's [Java Networking and Proxies](https://docs.oracle.com/javase/8/docs/technotes/guides/net/proxies.html) on standard ways to set proxy settings.

When dealing with Spring Boot/Cloud Native applications, we recommend teams set proxy settings at the JVM-level via system properties passed thru the command line.

```
java
  -Dhttps.proxyHost=internet.ford.com
  -Dhttps.proxyPort=83
  -Dhttps.nonProxyHosts="localhost|127.0.0.1|19.0.0.0/8|10.0.0.0/8|172.16.0.0/12|*.ford.com"
  -Dhttp.proxyHost=internet.ford.com
  -Dhttp.proxyPort=83
  -Dhttp.nonProxyHosts="localhost|127.0.0.1|19.0.0.0/8|10.0.0.0/8|172.16.0.0/12|*.ford.com"
...
```
Spring `WebClient` doesn't support system properties as confirmed by reactor-netty team [here](https://github.com/reactor/reactor-netty/issues/887#issuecomment-549439355). So when spring `WebClient`is used to make a HTTP API call to an external point, then the proxy needs to be set this way at the level of `WebClient`

```java

public WebClient buildWebClientForSomeExternalApi() {
     return WebClient.builder()
                .clientConnector(httpProxyConnector())
                .apply(.....) 
                .build();

}


private ReactorClientHttpConnector httpProxyConnector() {

        String httpsProxyHost = System.getProperty("https.proxyHost");
        Integer httpsProxyPort = Integer.parseInt(System.getProperty("https.proxyPort"));

        HttpClient httpClient = HttpClient.create()
                .tcpConfiguration(tcpClient -> tcpClient
                        .proxy(proxy -> proxy
                                .type(ProxyProvider.Proxy.HTTP)
                                .host(httpsProxyHost)
                                .port(httpsProxyPort)));

        return new ReactorClientHttpConnector(httpClient);

    }
```



Some startup scripts rely on `JAVA_OPTS` to pull in additional system properties. You can set the above system properties like so:

```
export JAVA_OPTS="-Dhttps.proxyHost=internet.ford.com -Dhttps.proxyPort=83 -Dhttps.nonProxyHosts=\"localhost|127.0.0.1|19.0.0.0/8|10.0.0.0/8|172.16.0.0/12|*.ford.com\" -Dhttp.proxyHost=internet.ford.com -Dhttp.proxyPort=83 -Dhttp.nonProxyHosts=\"localhost|127.0.0.1|19.0.0.0/8|10.0.0.0/8|172.16.0.0/12|*.ford.com\""
```

### Cloud Foundry manifest file

You can leverage the JAVA_OPTS approach as outlined above by including the adding a JAVA_OPTS setting in a manifest file used for deploying applications to Pivotal Cloud Foundry. If you already have a JAVA_OPTS, just append the settings from the example below, if you don't have a JAVA_OPTS use the entire row below.
```
_JAVA_OPTIONS: -Dhttps.proxyHost=internet.ford.com -Dhttps.proxyPort=83 -Dhttps.nonProxyHosts="localhost|127.0.0.1|19.0.0.0/8|10.0.0.0/8|172.16.0.0/12|*.ford.com" -Dhttp.proxyHost=internet.ford.com -Dhttp.proxyPort=83 -Dhttp.nonProxyHosts="localhost|127.0.0.1|19.0.0.0/8|10.0.0.0/8|172.16.0.0/12|*.ford.com"
```
<br/>

### Ford JCOE Framework Based Java Applications

When using the <a href="https://github.ford.com/JCOE/itcore/blob/DEV/readme.txt" target="_blank">ITCore</a>, <a href="https://github.ford.com/JCOE/wscore/blob/dev/readme.txt" target="_blank">WsCore</a> or <a href="https://github.ford.com/JCOE/ford-rest/blob/dev/FordREST/src/main/java/com/ford/it/rest/client/FRestClientPO.java" target="_blank">FordRest</a> JCOE frameworks, use their respective functions or configurations file to setup the proxy. Please refer to each framework's documentation in GitHub for details.
<br/>

### Gradle Wrapper

There are multiple ways to set proxy settings for projects that rely on Gradle. One way is to set `JAVA_OPTS` as mentioned above. (Alternatively you can use `GRADLE_OPTS` environment variable instead.)

Another option is to set proxy settings within `gradle.properties` file as described here in [Gradle Documentation](https://docs.gradle.org/current/userguide/build_environment.html#sec:accessing_the_web_via_a_proxy). This sample [gradle.properties](gradle.properties) configures Gradle with Ford proxy servers.

> NOTE: If you are configuring Gradle proxy settings solely for access to Maven Central, then you can alternatively add https://www.nexus.ford.com/repository/external-proxy-group as a *repositories* maven source and skip setting Gradle proxy settings altogether.

<br/>

### Maven Wrapper

Similar to Gradle, you can set `MAVEN_OPTS` environment variable to match the above `JAVA_OPTS` value.

Alternatively you can set proxy settings within `settings.xml` file described here in [Maven Documentation](https://maven.apache.org/guides/mini/guide-proxies.html)

<br/>

### Eclipse

If you are trying to allow Eclipse itself to connect through the proxy (e.g. to access marketplace plugins), you can configure proxy settings in Window -> Preferences -> General -> Network Connections.

If you are trying to configure a running application or JUnit test with proxy settings, you can set the proxy system properties (i.e. -D properties) in the __Run as...__ dialog.

<br/>

### IntelliJ

Refer to JetBrain's official [HTTP Proxy](https://www.jetbrains.com/help/idea/settings-http-proxy.html) documentation on how to set proxy settings.

In addition to manual proxy configuration, IntelliJ supports auto-detecting proxy settings or even setting the automatic proxy configuration URL; refer to the section [Web Browsers](#web-browsers) below for the URL values.

<br/>

## Jenkins

### Proxy Configuration - System Wide Environment Variable 
  
  1. Log into Jenkins GUI
  2. Select Manage Jenkins
  3. Select Configure System
  4. Select Add Environment Variable
  5. Add values for `http_proxy`, `https_proxy`, and `no_proxy`

### Plug-in Manager

1. Log on to your Jenkins GUI
2. Select Manage Jenkins
3. Select Manage Plugins
4. Select the Advanced tab
5. Enter the proxy server information (e.g. server, port, no proxy)
6. Click on the Advanced button and validate a test URL (e.g. http://www.google.com, ). If all works then submit to save.
7. Restart Jenkins, verity that the proxy settings are still set, and perform a workspace load with a Jenkins job to test

> NOTE: Alternatively you can set the proxy settings in jenkins.xml file located within the Jenkins installation directory as [described under Solution #2 found here](https://jazz.net/forum/questions/214230/how-do-you-configure-jenkins-to-work-with-a-proxy-server)

<br/>


## Web Browsers

Web browsers typically rely on a special proxy configuration script that embeds both logic and proxy server information.

### Windows
All Ford Windows workstations should have their web browsers automatically configured with the correct proxy configuration script. In Internet Explorer, the proxy configuration settings can be found under the TOOLS menu > Internet Options > Connections > Lan Settings. "Use automatic configuration script" should be checked and Address set to http://browsers.ford.com/ie/proxy.js

Chrome takes its configuration from Windows, which in turn takes it from Internet Explorer. No further configuration is required.

### Mac

Open Network settings from the System Preferences. In the Wi-Fi settings, click the Advanced button. Click on the proxies tab and check the box next to Automatic Proxy Configuration. Click the text "Automatic Proxy Configuration" to reveal the Proxy Configuration File input text box. Input "http://browsers.ford.com/mac/mac.js" (without the quotes) for the URL. Click OK.

<br/>

## Dr. Proxy

Our friends at Ford Labs have authored a nice utility for dealing with the Ford proxy settings. See the Dr. Proxy GitHub page at [https://github.ford.com/FordLabs/dr-proxy](https://github.ford.com/FordLabs/dr-proxy).



   
