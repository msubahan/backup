## LDAP Guide

This guide demonstrates how to connect and query Ford's corporate LDAP servers. It also demonstrates how to rely on an embedded LDAP Server for local development and testing.

As outlined by [Ford Directory Service documentation](https://azureford.sharepoint.com/sites/FordDirectoryService/Pages/general.aspx), Ford has two LDAP servers:
- **Production:** fds.ford.com:636
- **Testing:** fdsamd.ford.com:636

**_Note:_** Authentication is required when connecting to the LDAP servers &mdash; thus all applications must register [here first.](https://azureford.sharepoint.com/sites/DirectoryServices/FDS/Pages/default.aspx) This solution will not work when deployed unless authorized credentials are configured in the application.

<br/>

### Testing from the command line
 
To test the credentials and configuration, ldapsearch can be run on Mac/LINUX/UNIX.  See example below: 


```
ldapsearch -xH ldaps://fdsamd.ford.com:636 -D "fordGID=[ACCT GUID],OU=Employee,OU=People,O=ford,C=US" -b "o=Ford,c=US" -w "[PASSWORD]" "uid=[CDSID TO SEARCH]"
```

<br/>

### Implementation

#### Dependencies

Dependencies required in your [build.gradle](build.gradle):

```
implementation 'org.springframework.boot:spring-boot-starter-data-ldap'
implementation 'com.unboundid:unboundid-ldapsdk'
```
We rely on *unboundid* dependency for the in-memory embedded LDAP server implementation.

#### Configuration

The embedded LDAP server is driven by a local ldif configuration placed in the *resources* folder &mdash; i.e.   [schema_localonly.ldif](src/main/resources/schema_localonly.ldif). 

Configuration of both *embedded* and *real* LDAP servers are placed in *application's* [application.properties](src/main/resources/application.properties):

```
# Local LDAP
spring.ldap.embedded.base-dn=o=Ford,c=US
spring.ldap.embedded.credential.username=uid=admin
spring.ldap.embedded.credential.password=secret
spring.ldap.embedded.ldif=classpath:schema_localonly.ldif
spring.ldap.embedded.port=12345
spring.ldap.embedded.validation.enabled=false
  
# Prod Ford LDAP
ldap.url=ldaps://fds.ford.com:636
ldap.base=o=Ford,c=US
ldap.userDn=fordGID=<GID_THAT_YOU_HAVE>,OU=Employee,OU=People,O=ford,C=US 
ldap.password=<Password_THAT_YOU_HAVE>
```

#### LDAP Template

All LDAP operations would be executed via Spring's [LdapTemplate](https://docs.spring.io/spring-ldap/docs/current/apidocs/org/springframework/ldap/core/LdapTemplate.html). 

Spring Boot will automatically register a *LdapTemplate* bean if `spring.ldap.embedded.*` properties are set and a *LdapTemplate* bean has not been defined already. Therefore, in order to test against an embedded LDAP server locally while connect to the real Ford LDAP servers while deployed in the cloud environment, the application must only register a *LDAPTemplate* when deployed. You can do this with the following [LdapConfiguration](src/main/java/com/ford/pcfdev/ldap/LDAPConfiguration.java) class:

```
@Configuration
@Profile("cloud")
@EnableConfigurationProperties
public class LDAPConfiguration {
  
    @Bean
    public LdapTemplate configureLdapTemplateForCloud() {
        return new LdapTemplate(contextSource()) ;
    }
  
    @Bean
    @ConfigurationProperties(prefix = "ldap")
    public LdapContextSource contextSource() {
        return new LdapContextSource();
    }

}
```

<br/>

### Sample Query
Many examples online look like the code below.  Note that the base is supplied as an empty string below.  If the base is configured in the template, send an empty string.  If the base is not configured in the LdapTemplate, it must be supplied in the query.

```
    public List<String> search(String username) {
        return ldapTemplate
                .search(
                        "",
                        "uid=" + username,
                        (AttributesMapper<String>) attrs -> (String) attrs.get("cn").get());
    }
```

A better query implementation is shown below which was copied from this repo's example [service.](../ldap/src/main/java/com/ford/pcfdev/ldap/lookup/LDAPService.java) 


```
    public Optional <LDAPModel> getByCDSId(String cdsId) {
        LdapQuery ldapQuery = LdapQueryBuilder.query()
                .searchScope(SearchScope.SUBTREE)
                .where("objectclass").is("person")
                .and("uid").like(cdsId);

        List<LDAPModel> ldapModelList = ldapTemplate.search(ldapQuery, (Attributes attrs) ->
                LDAPModel.builder()
                .sn(getValue(attrs.get("sn")))
                .cn(getValue(attrs.get("cn")))
                .build()
        );

        return ldapModelList.isEmpty()? Optional.empty() : Optional.of(ldapModelList.get(0)) ;
    }
```

### Debugging

If queries work from the command line but are failing from the application, make sure the base is not getting duplicated as described the the sample query section.

For authentication issues, verify the ldap.userDn is properly configured for the test ID. Use https://www.sdcds.ford.com and look up the ID to obtain the correct Distinguished Name.  

<br/>

___
This project is generated by [**Spring EcoBoost**](http://x.ford.com/spring-ecoboost).
