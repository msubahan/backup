package com.ford.devenablement.ldap.lookup;

import com.ford.devenablement.ldap.lookup.api.LookupResponse;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.Optional;

import static com.ford.devenablement.ldap.lookup.api.LookupResponse.LookupResponseResult;
import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class LDAPControllerTest {

    @Mock
    LDAPService ldapService;

    @Mock
    LDAPMapper ldapMapper;

    @InjectMocks
    LDAPController ldapController;

    @Test
    public void testGetByCDSId() throws Exception {

        System.out.println("Running : testGetByCDSId()");

        String cdsID = "marunk20";
        LDAPModel mockLdapModel = mock(LDAPModel.class);
        when(ldapService.getByCDSId(cdsID)).thenReturn(Optional.of(mockLdapModel));
        LookupResponseResult mockLookupResponseResult = mock(LookupResponseResult.class);
        when(ldapMapper.toLookupResponseResult(mockLdapModel)).thenReturn(mockLookupResponseResult);

        ResponseEntity<LookupResponse> response = ldapController.getByCDSId(cdsID);
        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.OK);
        assertThat(response.getBody().getError()).isNull();
        assertThat(response.getBody().getResult()).isNotNull();
        assertThat(response.getBody().getResult()).isEqualTo(mockLookupResponseResult);

        System.out.println("Completed : testGetByCDSId()");

    }

}
