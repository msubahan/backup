package com.ford.devenablement.ldap.lookup;

import com.ford.devenablement.ldap.lookup.api.LookupResponse.LookupResponseResult;
import org.springframework.stereotype.Component;

@Component
public class LDAPMapper {

    public LookupResponseResult toLookupResponseResult(LDAPModel ldapModel) {
        return LookupResponseResult.builder()
                .firstName(ldapModel.getFirstName())
                .lastName(ldapModel.getLastName())
                .title(ldapModel.getTitle())
                .userId(ldapModel.getUserId())
                .departmentName(ldapModel.getDepartment())
                .build();
    }
}
