package com.ford.devenablement.ldap;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LDAPExampleApplication {

	public static void main(String[] args) {
		SpringApplication.run(LDAPExampleApplication.class, args);
	}

}
