package com.ford.devenablement.ldap.lookup.api;

import com.ford.cloudnative.base.api.BaseBodyResponse;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

public class LookupResponse extends BaseBodyResponse<LookupResponse.LookupResponseResult> {
    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class LookupResponseResult {
        String firstName;
        String lastName;
        String userId;
        String title;
        String departmentName;
    }

}
