package com.ford.devenablement.ldap.lookup;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ldap.core.LdapTemplate;
import org.springframework.ldap.query.LdapQuery;
import org.springframework.ldap.query.LdapQueryBuilder;
import org.springframework.ldap.query.SearchScope;
import org.springframework.stereotype.Service;

import javax.naming.NamingException;
import javax.naming.directory.Attribute;
import javax.naming.directory.Attributes;
import java.util.List;
import java.util.Optional;

@Service
public class LDAPService {

    private LdapTemplate ldapTemplate;

    @Autowired
    public LDAPService(LdapTemplate ldapTemplate) {
        this.ldapTemplate = ldapTemplate;
    }


    public Optional<LDAPModel> getByCDSId(String cdsId) {
        LdapQuery ldapQuery = LdapQueryBuilder.query()
                .searchScope(SearchScope.SUBTREE)
                .where("objectclass").is("person")
                .and("uid").like(cdsId);

        List<LDAPModel> ldapModelList = ldapTemplate.search(ldapQuery, (Attributes attrs) ->
                LDAPModel.builder()
                        .firstName(getValue(attrs, "givenName"))
                        .lastName(getValue(attrs, "sn"))
                        .department(getValue(attrs, "fordDeptName"))
                        .email(getValue(attrs, "mail"))
                        .title(getValue(attrs, "title"))
                        .userId(getValue(attrs, "uid"))
                        .build());

        return ldapModelList.isEmpty() ? Optional.empty() : Optional.of(ldapModelList.get(0));
    }

    private String getValue(Attributes attrs, String key) {

        Attribute attribute = attrs.get(key);

        String value = "";
        try {
            value = attribute != null ? attribute.get().toString() : null;
        } catch (NamingException e) {
            throw new IllegalArgumentException("Exception looking up ldap attribute by key [" + key + "]", e);
        }

        return value;
    }

}


