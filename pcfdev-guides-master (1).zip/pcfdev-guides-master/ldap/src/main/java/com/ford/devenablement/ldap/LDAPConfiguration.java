package com.ford.devenablement.ldap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.ldap.core.LdapTemplate;
import org.springframework.ldap.core.support.LdapContextSource;

@Configuration
@Profile("cloud")
@EnableConfigurationProperties
public class LDAPConfiguration {

    @Bean
    public LdapTemplate configureLdapTemplateForCloud() {
        return new LdapTemplate(contextSource()) ;
    }

    @Bean
    @ConfigurationProperties(prefix = "ldap")
    public LdapContextSource contextSource() {
        return new LdapContextSource();
    }

}
