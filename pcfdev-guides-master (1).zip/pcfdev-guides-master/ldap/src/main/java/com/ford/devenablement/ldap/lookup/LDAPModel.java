package com.ford.devenablement.ldap.lookup;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class LDAPModel {
    //uid
    String userId;

    //givenName
    String firstName;

    //sn
    String lastName;

    //title
    String title;

    //fordDeptName
    String department;

    //mail
    String email;
}
