package com.ford.devenablement.ldap.lookup;

import com.ford.devenablement.ldap.lookup.api.LookupResponse;
import com.ford.devenablement.ldap.lookup.api.LookupResponse.LookupResponseResult;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Optional;

@RestController
@RequestMapping(path = "/api/v1/lookup")
public class LDAPController {

    private LDAPService ldapService;
    private LDAPMapper ldapMapper;

    @Autowired
    public LDAPController(LDAPService ldapService, LDAPMapper ldapMapper) {
        this.ldapService = ldapService;
        this.ldapMapper = ldapMapper;
    }

    @GetMapping("/{cdsId}")
    public ResponseEntity<LookupResponse> getByCDSId(@PathVariable String cdsId) {
        Optional<LDAPModel> ldapModel = ldapService.getByCDSId(cdsId);

        if (!ldapModel.isPresent()) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }

       LookupResponseResult result = ldapMapper.toLookupResponseResult(ldapModel.get()) ;

        return ResponseEntity.ok(LookupResponse.result(result, LookupResponse.class));
    }

}
