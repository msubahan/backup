# Oracle JDK migration to Adoptium (OpenJDK)

> IMPORTANT: Using Oracle JDK/JRE? New Oracle licensing affects Ford applications and developers! Read below for more info

## Quick Summary

Due to Oracle license changes made in January 2019, Oracle’s "free" JDK/JRE updates for new installations or updates will require Ford to pay a subscription fee. Review the "Path Forward” section below for alternate options. A recommended free option is to directly download and use the approved OpenJDK distributions from [(https://adoptium.net/](https://adoptium.net/) and continue to receive free support patches for your application and remain compliant with the Ford ISP. If you are unable to remediate your application, please open an OIC and include in your 5 year Tech Refresh plan a remediation strategy to address.

## What Happened?
Public updates for Oracle Java SE 8 released after January 2019 are not be available for business, commercial or production use without a commercial license.

If your team has been relying on the latest free (unlicensed) Oracle JDK/JRE 8 binary distributions to develop and run your applications, then Oracle’s new licensing model impacts your team. Oracle JDK/JRE 8u202 is the last version in which Ford (and other companies) are allowed to use freely without a commercial license. Since newer versions will still be made "freely" available via Oracle’s website under their new license, it is easy for individuals to fall into the trap mistakenly download newer Oracle JDK/JRE versions that will both violate Oracle’s license and not observe Ford’s approved technology catalog.

> NOTE: Oracle JDK/JRE 8u202 and prior versions will still be offered under their original licenses without any changes.


## What is the Alternative?

[https://adoptium.net/](https://adoptium.net/) 

There are many free alternatives to Oracle JDK/JRE binaries. Some teams may already be using some of these alternatives. Oracle binaries are primarily built from OpenJDK source code. Since OpenJDK is open-source, anyone can freely build from the same codebase. In fact, there are many providers that already do this and make their OpenJDK binaries freely available without commercial restrictions. While primarily there is no major core java functional differences between OpenJDK and Oracle binaries, Oracle may have packaged additional components such as Java Plug-in, Web Start, and tools which you may have to turn to additional open-source alternatives if you depend on them.

Many factors such as supported Java versions, supported platforms, time frames, quality, license, openness, support, adoption, and reputation were considered when choosing the right alternative OpenJDK provider for Ford. Today, for those who relied on Oracle JDK/JRE, we have chosen [https://adoptium.net/](https://adoptium.net/) as the new JDK/JRE binary distribution provider for JDK/JRE versions 8+.  Adoptium OpenJDK is a community of Java User Group (JUG) members, developers and vendors (i.e. IBM, Microsoft, Pivotal, Red Hat) who are advocates of OpenJDK. Currently Adoptium OpenJDK supports Java Temurin(LTS)versions 8 & 11 and many platforms including Docker, Windows, Mac, Linux, Solaris, and AIX.


## Path Forward

Your impact by Oracle’s new license updates is tied to your team’s dependency on Oracle’s JDK/JRE updates. If you do not rely on free Oracle JDK/JRE updates for your local development workstations or hosting/server environments, then there is no impact to you. Here are some helpful information to know if you are unsure about your impact:

* Applications deployed to PCF are not impacted because all built-in buildpacks do not rely on Oracle JDK/JRE.
* Any hosted WebSphere applications are not impacted because WebSphere does not run on Oracle JDK/JRE.
* Any local development against WebSphere applications are not impacted because developers should be developing against IBM JDK and not Oracle JDK/JRE.
* Solaris & SUSE installations should not be impacted because JDK/JRE packages should be pulling from repository sources covered by existing licenses.
* Applications or workstations that still run on Oracle JDK/JRE 7 or older are not directly impacted because they are already outdated and stuck on previous versions. Oracle’s new licenses only impacts the newer Oracle JDK/JRE updates. Original licenses for JDK/JRE 8u202 and older versions will remain intact. Upgrading Java versions is not in scope.
* Oracle JDK/JRE distributions that come licensed as a part of a bundle under Ford purchased or COTS products are not impacted. Licensed Oracle JDK/JRE installations should adhere to vendor installation instructions.
* Refer to the Additional Notes section below on how to determine the vendor/version of a specific JDK/JRE copy.

### Oracle JDK/JRE Usages on Local Workstations

You have two options when it comes to your local workstation:

1. Do nothing. You can just stick with your existing outdated Oracle JDK/JRE version (up to 8u202). While security patches may be less of a concern for local workstations, the longer you run on an outdated version, the greater risk inconsistencies can exist between your local machine and hosting environment(s).
2. **Recommended:** Download and stay up-to-date with the latest OpenJDK w/ HotSpot distributions from https://adoptium.net/


### Oracle JDK/JRE Usages on Host/Server Environments

It is important that hosted/server environments stay up-to-date with the latest fixes and security patches. Teams and server administrators that once relied on free unlicensed Oracle JDK/JRE 8 updates should switch and stay up-to-date with the latest OpenJDK w/ HotSpot binary distributions from [https://adoptium.net/](https://adoptium.net/). As part of the switch or any update in general, application teams should test their applications to ensure there is no impact.


## Additional Notes

* All Adoptium OpenJDK versions/platforms/JVM options have been approved for download. TM #7020195
* Teams should adoptium only Temurin(LTS) versions since Temurin(LTS) versions are more suitable for an enterprise.
   * Java 8 (Temurin 8 (LTS)) releases supported at least until September 2023
   * Java 11 (Temurin 11 (LTS)) releases supported at least until September 2023
* Adoptium OpenJDK offers standalone JRE installation packages. You must drill down into the website to be presented with the JRE option.
* Adoptium OpenJDK offers Java 11 (Temurin 11 (LTS)) for any teams interested in Java 11 development.
> NOTE: No application teams should have Oracle JDK 11 installed since all Oracle JDK 11 versions fall under the new Oracle licensing model.

* Adoptium OpenJDK offers OpenJ9 which is an alternative open-source JVM implementation donated and led by IBM. (J9 is the underlying JVM for IBM JDK.) While HotSpot is the default built-in OpenJDK JVM and the more widely used JVM by OpenJDK providers including Oracle JDK, teams can choose to experiment and test with OpenJ9.
* You can determine a JDK/JRE’s version and vendor make (i.e. Oracle) by running its "java -version" command. Oracle JDK/JRE binaries start off with the text "java version" as part of their version command output.
* Any downloaded or installed software must comply with Technology Management. Downloading unapproved and unlicensed Oracle software for any use, needs to be AVOIDED from the following pages or domains:
  * https://www.oracle.com/technetwork/java/javase/downloads/jdk8-downloads-2133151.html
  * https://www.oracle.com/technetwork/java/javase/downloads/jdk11-downloads-5066655.html
  * https://www.oracle.com/technetwork/java/javase/downloads/index.html
  * https://www.java.com/*
  * https://jdk.java.net/*
