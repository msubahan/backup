# Java Guide

This guide documents the Dev Enablement teams current recommendations and support for using Java in the context of Cloud Native applications. Teams that have WebSphere Liberty applications (PCF/CaaS) or WebSphere Application Server applications are to use the IBM JDK recommended by WAS engineering. This includes recommendations on use of a JDK on your local workstation, the use of the Java buildpack in PCF, and the implications of Java versions on your IDE's and CI servers. The focus of the document is towards Java 11, as it is the most current Long Term Support (LTS) version of Java as of the writing (4Q 2021) of this guide.Eclipse Temurin is the name of the OpenJDK distribution from Adoptium. 

## Our Recommendation - use Java 11!
You will see more rational for the specific use of Adoptium OpenJDK, and leveraging Temurin(LTS) versions of the JDK below in this document. That said, our recomendation is that **all new Cloud Native development in Java should use Java 11, and those still using Java 8 should upgrade**.
>**Note:** WAS Liberty applications that are using Java 8 should refer to the [WAS Liberty and WebSphere Applications](#WAS-Liberty-and-WebSphere-Applications) section at the end of this guide.

## JDK
Since the license changes to Oracle's JDK went into effect in early 2019, we have recommended the use of Adoptium OpenJDK for use on your local workstation. Please see the detailed [Oracle JDK migration to Adoptium OpenJDK](./ORACLE_TO_ADOPTIUM_JDK.md) for more details on the need to use an appropriately licensed offering (i.e. DO NOT USE THE ORACLE JDK!).

Our recommendation is to stay current with the latest LTS version of Java, provided it is also available/supported by your tools, frameworks, and infrastructure. The recommendation for Cloud Native Java applications is to use Temurin 11 (LTS). Java 11 is supported by the Spring Framework, Gradle, PCF's Java buildpack, and our most widely used IDE's (IntelliJ & Eclipse).

We do not recommend using versions that are not LTS versions, as the rate of change (Java releases versions every 6 months) and the support and maintainability may cause issues for your application in the long term. 

> NOTE: See the [Java Version History wiki](https://en.wikipedia.org/wiki/Java_version_history) to understand the LTS structure and versions. This wiki also details what new JDK Enhancement Proposal's (JEP) were included in each relase.

## JAVA_HOME
In many cases people may require both Java 8 and Java 11 to be installed and available on their workstation. It would be ideal to have your JAVA_HOME point to Java 11, and have the ability to easy switch to Java 8 as needed. Most IDE's allow for the JDK to be set as a project setting, thus avoiding the need to switch you JAVA_HOME. See this [JAVA_HOME guide](https://www.baeldung.com/java-home-on-windows-7-8-10-mac-os-x-linux) for instructions on setting your JAVA_HOME environment variable.


## IDE

Support for Java 11 has been available beginning with version 2018.2 of IntelliJ, and version 2018-09 of Eclipse.
Beginning with IntelliJ 20202.1, it is required to have you JAVA_HOME environment variable configured to use Java 11 (or greater).

## Spring Framework

Since the Spring Boot and Spring Framework are our core tools for cloud native application using Java, it is important to mention that Java 11 support was added beginning with Spring Boot 2.1 and Spring Framework 5.1.


## PCF & Java Buildpack

The Java buildpack available in PCF supports the ability to run your application using either the Java 8 JRE or the Java 11 JRE. It defaults to Java 8, so in order to configure it to use Java 11 you need to add the following environment variable setting to you manifest file:
```
  env:
    JBP_CONFIG_OPEN_JDK_JRE: '{ jre: { version: 11.+ } }'
```
You can view the CAB application's [manifest template file](https://github.ford.com/PCFDev-CAB/cab-service-fordair/blob/master/cf/manifest-template.yml) to see a more rich example of a manifest file which includes the configuration to use Java 11 JRE.


## EcoBoost Java 11 Migration Guide

See [EcoBoost Java 11 migration guide](https://github.ford.com/DevEnablement/pcfdev-guides/blob/master/migrations/Java-11.md) for details on migrating your EcoBoost application that perhaps was using Java 8 and a version of Spring Boot prior to 2.1.


## WAS Liberty and WebSphere Applications

This section covers the Java implications for WebSphere Liberty (PCF/CaaS) & WebSphere Application Server applications.

JEE applications that are deployed to WebSphere Application Server (WAS), PCF using the WebSphere Liberty buildpack, or CaaS using the WebSphere Liberty container image will continue to use the IBM JDK provided by WebSphere engineering. This version is currently based on Java 8, and is commercially licensed (it’s not open source) via our contract with IBM.

IBM will continue to support Java 8 until April 2025, and the current Liberty version supports Java 11 also.

Further, IBM pledges to support Java SE versions as long as Adoptium  provides support for them, and Adoptium intends to support Java 8 until at least May 2026. Bear in mind this is an Adoptium JDK Java 8 which does not support all of the IBM Java 8's features. 

See [IBM developer kits lifecycle dates](https://developer.ibm.com/javasdk/support/lifecycle/), [Revised statement of standard support through at least 2030](http://ibm.biz/WAS2030Announcement) and [AdoptiumSupport](https://adoptium.net/support.html)

Application teams can start to review their applications that are running in Liberty/PCF and CaaS, and consider migration to Adoptium Temurin 11 (Java 11).

Migrating from IBM Java 8 to Adoptium Temurin(OpenJDK) Java 11 involves more than just replacing the JDK runtime. Consider the following:

* Java 11 removes some Java EE related packages, such as `javax.xml.bind`.  If your application uses any of these removed packages, you need to add them to your build scripts. The good news is that all of the removed packages are provided by existing Liberty features, for example jaxb-2.2.

* Adoptium Temurin(OpenJDK) does not include IBM specific packages. If your application uses any IBM specific packages, you need to replace them.

* If you have any certificates generated by an IBM JDK, you may need to regenerate them with Adoptium Temurin(OpenJDK).

* Application teams need to perform thorough regression testing of their application with Java 11, especially when integrating with outside applications, if they are taking on such a migration.

* Liberty versions 19.0.0.1 and later support Java 11 (Hotspot) -https://www.nexus.ford.com/#browse/browse:was_engineering_private_release_repository:liberty. 


In order to use Java 11 in PCF, add the following lines to the deployment manifest file.

```yaml
env:
  JVM: openjdk
  JBP_CONFIG_OPENJDK: "version: 0.11.0_6" #during testing
```

>Note: The JBP_CONFIG_OPENJDK would become 11.x when it becomes the default JDK version in the future.
