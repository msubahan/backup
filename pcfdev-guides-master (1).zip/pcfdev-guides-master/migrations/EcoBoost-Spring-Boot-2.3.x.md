# EcoBoost Project - Spring Boot 2.3 Migration

This guide details what it takes to upgrade an EcoBoost Spring Boot 2.2.x project to Spring Boot 2.3.x. This guide only covers 
the migration path for the out-of-the-box EcoBoost generated implementation and not any other custom team code added to the 
application. 
If your EcoBoost application is using a version of Spring Boot prior to 2.2.x you should refer to the specific migration
guide(s) for your case and apply the migrations in order up to and including this guide.

Prior to upgrading, refer to Pivotal's [Spring Boot 2.3 Release Notes](https://github.com/spring-projects/spring-boot/wiki/Spring-Boot-2.3-Release-Notes) 
to learn more about other potential upgrade impacts to your application.

>**Note**: The Spring Boot GA version provided in this guide was GA as of the date this guide was last updated (March 19, 2021). 
Please update to patched versions as they are released as GA, and don't necessarily rely on the version you see in this guide. 
See [Spring Boot Versions](https://mvnrepository.com/artifact/org.springframework.boot/spring-boot) to see the 
versions available. As noted below, you can use CAB as a refernce to understand the latest versions availble since we regually update CAB.


## Reference Application
At any point, you can refer to [CAB Reference application](https://github.ford.com/PCFDev-CAB/cab-service-fordair/tree/v5.0), 
which is upgraded with Spring Boot 2.3.9, Spring Cloud Hoxton SR10 and with other dependencies detailed in this migration guide.

## Major Changes
In addition to Spring Boot, their are several other changes to major components of the EcoBoost technology stack.
* Spring Boot 2.3.x
* Spring Cloud Hoxton SR10
* Gradle 6.5.x
* Spring Cloud Connector removal
* Spring Validation starter removal from Spring managed dependencies
* Spring Boot BOM support update
* Gradle Boost 3.1
* Dev Enablement pipeline offering 3.0
* spring-boot-starter-ford 2.4.0
* **new** springfox-bean-validators 2.9.2

## Instructions

**RECOMMENDED:** To upgrade Spring Boot along with Gradle Boost 3.1, Jenkins pipeline offering 3.0 and other major components 
listed above, please refer to our [GradleBoost plugin 3.x migration guide](https://github.ford.com/DevEnablement/gradle-boost-plugin/wiki/Migrate-to-Gradle-Boost-3.x).

If you want to upgrade only Spring Boot and Spring Cloud libraries, continuing further with this guide.

Update Spring Boot to version `2.3.9.RELEASE` in `build.gradle`.
```aidl
plugins {
    id 'org.springframework.boot' version '2.3.9.RELEASE'
}
```

Spring Boot 2.3 [replaced Spring Cloud Connectors starter dependency with CFEnv](https://github.com/spring-projects/spring-boot/wiki/Spring-Boot-2.3-Release-Notes#spring-cloud-connectors-starter-has-been-removed). 
Remove the below dependency from `build.gradle`, if previously used by the application.
```aidl
implementation 'org.springframework.boot:spring-boot-starter-cloud-connectors'
```

Disable the data source configuration property in `application.properties` file, if present, which is used by Ford Cloud Native Spring Boot starter dependency.
```aidl
# Scan for and configure DataSource(s) based on CF user-provided-services
cn.app.datasource-configure.enabled=false
```

> Note: If you are using PCF User Provided Service (UPS) and making use of Ford Cloud Native Spring Boot Starter's 
> data source configuration feature for UPS with the above property enabled, contact [Dev Enablement team](thall6@ford.com) for further support.

Spring Boot 2.3 [removed Validation starter from web starters](https://github.com/spring-projects/spring-boot/wiki/Spring-Boot-2.3-Release-Notes#validation-starter-no-longer-included-in-web-starters). 
Add the dependency explicitly in `build.gradle`, if previously used by the application.
```aidl
implementation 'org.springframework.boot:spring-boot-starter-validation'
```

> Note: For other Spring Boot 2.3.x upgrades and removals, refer to [Spring Boot 2.3 Release Notes](https://github.com/spring-projects/spring-boot/wiki/Spring-Boot-2.3-Release-Notes)

Update Spring Cloud version to `Hoxton.SR6` and SCS depedencies to version `2.2.4.RELEASE` in `build.gradle`.
```aidl
dependencyManagement {
    imports {
        mavenBom 'org.springframework.cloud:spring-cloud-dependencies:Hoxton.SR6'
        mavenBom 'io.pivotal.spring.cloud:spring-cloud-services-dependencies:2.2.4.RELEASE'
        ...
```

Spring Boot 2.3 requires Gradle 6.3+. Update `distribution-url` in **gradle-wrapper.properties** to **_Gradle 6.5.1_**.
```aidl
distributionUrl=https\://www.nexus.ford.com/repository/gradle-distributions/gradle-6.5.1-bin.zip
```

Update **spring-boot-starter-ford** to version `2.4.0`. Refer to the [release notes](https://github.ford.com/DevEnablement/spring-base-dependencies/releases/tag/v2.4.0) for related changes.

```
implementation 'com.ford.cloudnative:spring-boot-starter-ford:2.4.0'
```

**spring-boot-starter-ford** and **spring-base-app** version `2.4.0` are now dependent on **springfox-bean-validators**. Make sure to include this dependency in application's **build.gradle** file to avoid runtime exceptions.
```
implementation 'io.springfox:springfox-bean-validators:2.9.2'
```

Do a gradle refresh build and test your application with sanity checks.
