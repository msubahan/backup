# EcoBoost Project - Spring Base Dependencies 3.0 Migration

**Important:** Dev Enablement team recommends upgrading to **Spring Base Dependencies version 3.0** along with **Spring Boot version to 2.4**
for a smoother integration between the dependencies, and for staying compatible with Spring Boot releases and CVE fixes.

Upgrading  **Spring Base Dependencies to version 3.0** alone is suggested only for a temporary situation where Spring Boot upgrade need to be delayed for a purpose.

To begin with **Spring Boot migration to 2.4**, start from [EcoBoost Project - Spring Boot 2.4 & Spring Base Dependencies 3.0 Migration Guide](EcoBoost-Spring-Boot-2.4.x.md). 
To migrate only **Spring Base Dependencies to version 3.0**, continue further.

>**Note:** Future upgrades (major/minor) in **Spring Base Dependencies** may not be compatible with Spring Boot 2.3. 
Not all possible dependency combinations are tested with this library and Spring Boot 2.3. We recommend reaching out to Dev Enablement team, if you encounter an issue.

## Migration Steps
### Changes in build.gradle
Upgrade **Ford Cloud Native Spring Boot Starter** library version to **`3.0.0`** and **Ford Cloud Native Spring Base Test** library version to **`3.0.0`**.

    ```
    dependencies {
        //Core libraries
        ...
        implementation 'com.ford.cloudnative:spring-boot-starter-ford:3.0.0'
        ...
    
        /*********** TEST libs ***********/
        testImplementation 'com.ford.cloudnative:spring-base-test:3.0.0'
        ...
    }
    ```

### Changes in application.properties 
- Remove `springfox.documentation.swagger.use-model-v3` property, if added previously as instructed in [Spring Base Dependencies release v2.5.0](https://github.ford.com/DevEnablement/spring-base-dependencies/releases/tag/v2.5.0). 
The use of this property is found to cause a number format issue with specific swagger fields, and hence a different approach is followed in the base library.

  **Note:** The [Spring Base Dependencies release v2.5.0](https://github.ford.com/DevEnablement/spring-base-dependencies/releases/tag/v2.5.0) originally provided recommendation to upgrade to springfox 3.0.0. If you haven't done this already, make sure you upgrade the library with this migration.
  
  In your **build.gradle**, replace **springfox** dependencies version **`2.9.2`** with **springfox-boot-starter** version **`3.0.0`**

   ~~`implementation 'io.springfox:springfox-swagger2:2.9.2'`~~
   
   ~~`implementation 'io.springfox:springfox-swagger-ui:2.9.2'`~~
   
   ~~`implementation 'io.springfox:springfox-bean-validators:2.9.2'`~~
   
     `implementation 'io.springfox:springfox-boot-starter:3.0.0'`

- When the spring-base-dependencies' common exception handler is enabled, i.e., `cn.app.exception-handler.enabled=true`, the handler configuration makes use of the new StandardErrorResponse error structure, by default, in conformance 
with [REST Error Response style guide](https://www.eesewiki.ford.com/display/FEAPIS/Style+Guide#RESTAPIStyleGuide-1413028761). 
Existing projects need to use the following properties for backwards compatibility with the BaseBodyResponse error structure, until migrated to the new structure.

   ```
   # Backwards compatibility for BaseBodyResponse error structure
   cn.app.exception-handler.use-base-body-response=true
   cn.app.exception-handler.attributes.include-exception=true
   cn.app.exception-handler.data-errors.include-code=true
   cn.app.exception-handler.data-errors.include-value=true
   cn.app.exception-handler.use-empty-values=true
   ```

   >Note: To migrate to the new StandardErrorResponse error structure and to remove the use of BaseBodyResponse structure, refer to examples by generating a sample Spring Boot application using [DCS Standard template](https://dcs.ford.com/project-workflow/springboot) or refer to [CAB Reference Application](https://github.ford.com/PCFDev-CAB/cab-service-fordair).

<br/>

For migration along with **Spring Boot 2.4**, go back to the [EcoBoost Project - Spring Boot 2.4 & Spring Base Dependencies 3.0 Migration Guide](EcoBoost-Spring-Boot-2.4.x.md#bootstrap-starter) after this step, else continue further.

Refresh gradle dependencies and clean build your application. 

Contact Dev Enablement team, if you need further assistance.
