# EcoBoost Project - Spring Boot 2.1 Migration

This guide details what it takes to upgrade an EcoBoost Spring Boot 2.0.x project to Spring Boot 2.1.x. This guide only covers the migration path for the out-of-the-box EcoBoost generated implementation and not any other custom team code added to the application. 
If your EcoBoost application is using Spring Boot 1.5.x, see the [EcoBoost Spring Boot 2.0 Migration](https://github.ford.com/PCFDev-Reference/pcfdev-guides/blob/master/spring-boot-migrations/EcoBoost-Spring-Boot-2.0.x.md) guide first to understand the steps for getting to 2.0.x first, as there are many more steps to consider. You can then follow the additional steps to complete the upgrade to Spring Boot 2.1.x.

Prior to upgrading, refer to Pivotal's [Spring Boot 2.1 Release Notes](https://github.com/spring-projects/spring-boot/wiki/Spring-Boot-2.1-Release-Notes) to learn more about other potential upgrade impacts of your application.

**_NOTE_**: The Spring Boot GA version provided in this guide was GA as of the date this guide was authored. Please update to patched versions as they are released as GA, and don't necessarily rely on the version you see in this guide. See [Spring Boot Versions](https://mvnrepository.com/artifact/org.springframework.boot/spring-boot) to see the versions available.


## Single Project applications



#### build.gradle

- Upgrade Spring Boot gradle plugin version.

```
plugins {
  ...
  id 'org.springframework.boot' version '2.1.7.RELEASE'
}
```

- Upgrade the dependencyManagement (maven BOM) section like so.
<br/>**_NOTE_**: We updated Spring Cloud version to Greenwich and **removed** the `com.ford.cloudnative:spring-base-dependencies:2.0.0` entry.

```groovy
   dependencyManagement {
      imports {
         mavenBom 'org.springframework.cloud:spring-cloud-dependencies:Greenwich.SR2'
         mavenBom 'io.pivotal.spring.cloud:spring-cloud-services-dependencies:2.1.1.RELEASE'
         mavenBom  org.springframework.boot.gradle.plugin.SpringBootPlugin.BOM_COORDINATES
      }
   }
   
```



- **Replace** `com.ford.cloudnative:spring-base-app` and `com.ford.cloudnative:spring-base-api` dependencies with  the new Ford Spring Boot starter. `com.ford.cloudnative:spring-boot-starter-ford`

```
   dependencies {
      ...
      implementation 'com.ford.cloudnative:spring-boot-starter-ford:2.1.0'
      ...
   }
```

<br/>

## Multi-Project applications (separate api & application projects)

## root Project

#### build.gradle

- Upgrade Spring Boot gradle plugin version.

```
plugins {
  ...
  id 'org.springframework.boot' version '2.1.7.RELEASE'
}
```

- Upgrade the dependencyManagement (maven BOM) section.
<br/>**_NOTE_**: We updated to Greenwich for Spring Cloud, and we removed the Spring Base Dependencies BOM.
<br/>**_NOTE_**: Unlike single module project, we need to include a BOM for the Spring Base Dependencies. We will use the Ford Spring Boot Starter in the build.gradle of the application module.

```groovy
   dependencyManagement {
      imports {
         mavenBom 'org.springframework.cloud:spring-cloud-dependencies:Greenwich.SR2'
         mavenBom 'io.pivotal.spring.cloud:spring-cloud-services-dependencies:2.1.1.RELEASE'
         mavenBom 'com.ford.cloudnative:spring-base-dependencies:2.1.0'
         mavenBom  org.springframework.boot.gradle.plugin.SpringBootPlugin.BOM_COORDINATES
      }
   }
   
```


## /api project


- No changes required. Updated Spring Base Api version is provided by changes made in root build.gradle file.


## /application project


- Upgrade the dependencies by adding the Ford Spring Boot Starter, and removing the references to the spring-base-app and spring-base-api dependencies.

```
   
   dependencies {
      ...
      implementation 'com.ford.cloudnative:spring-boot-starter-ford'
      ...
   }
```
<br/>**_NOTE_**: Remember to delete the following from dependencies section:
- ~~implementation 'com.ford.cloudnative:spring-base-app'~~
- ~~implementation 'com.ford.cloudnative:spring-base-api'~~

<br/><br/><br/>
