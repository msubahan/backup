# Migration Guides

The migration guides below are here to assist with migrating previous versions of Spring, EcoBoost, GradleBoost, our Jenkins pipeline, as well as others. 

All application teams are encouraged to keep their dependencies version updated as and when minor patch releases are introduced. 
This is critical in reducing the risk of security vulnerabilities.


## Spring Boot / EcoBoost

EcoBoost applications that were created using Spring Boot 1.5.x, 2.0.x, 2.1.x, 2.2.x, 2.3.x can use the migration guides provided below. 
These guides assist specifically with changes from Spring as well as the libraries in EcoBoost that are authored by the Dev Enablement team. Leveraging Pivotal's documentation is also encouraged. 

Applications needing to migrate from 1.5.x or 2.0.x all the way to 2.4.x should follow through all the migration guides 
sequentially for in between versions. Please note that several of these versions are no longer supported by the vendor, and pose a risk of having or bring in components with known security vulnerabilities. See the official [Spring Boot Wiki](https://github.com/spring-projects/spring-boot/wiki/Supported-Versions#released-versions) for the current supported versions information.


* [Spring Boot 2.0.x migration guide](EcoBoost-Spring-Boot-2.0.x.md) *This version is End Of Life (see note below)
                                      
* [Spring Boot 2.1.x migration guide](EcoBoost-Spring-Boot-2.1.x.md) *This version is End Of Life (see note below)

* [Spring Boot 2.2.x migration guide](EcoBoost-Spring-Boot-2.2.x.md) *This version is End Of Life (see note below)

* [Spring Boot 2.3.x migration guide](EcoBoost-Spring-Boot-2.3.x.md) *This version is End Of Life (see note below)

* [Spring Boot 2.4.x migration guide](EcoBoost-Spring-Boot-2.4.x.md)

> *NOTE: Several of these versions are no longer supported by the vendor, and pose a risk of having or bring in components with known security vulnerabilities. See the official [Spring Boot Supported Versions](https://spring.io/projects/spring-boot#support) for the current supported versions information.


## GradleBoost

The following link to the GradleBoost wiki provides a relase history and migration guides available for the GradleBoost product.

* [GradleBoost Wiki](https://github.ford.com/DevEnablement/gradle-boost-plugin/wiki)


## Jenkins Pipeline

* [Jenkins pipeline Release Notes/History](https://github.ford.com/DevEnablement/pcfdev-guides/tree/master/pipeline-jenkins#revision-history)

* [Jenkins Pipeline Migration Guide](https://github.ford.com/DevEnablement/pcfdev-guides/blob/master/pipeline-jenkins/Pipeline_Version_Migration_Steps.md)

## Spring Boot Starter Ford

* [Spring Boot Starter Ford Release Notes](https://github.ford.com/DevEnablement/spring-base-dependencies/releases)

## Misc

* [Java 11 migration guide](Java-11.md) 

* [Spring Cloud Services 3.x upgrade](Spring_Cloud_Services-3.x.md) 

* [Spring Boot Vendor Wiki](https://github.com/spring-projects/spring-boot/wiki)
