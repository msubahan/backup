# EcoBoost Project - Spring Boot 2.2 Migration

This guide details what it takes to upgrade an EcoBoost Spring Boot 2.1.x project to Spring Boot 2.2.x. This guide only covers the migration path for the out-of-the-box EcoBoost generated implementation and not any other custom team code added to the application. 
If your EcoBoost application is using Spring Boot 2.0.x, see the [EcoBoost Spring Boot 2.1 Migration](EcoBoost-Spring-Boot-2.1.x.md) guide first to understand the steps for getting to 2.1.x first, as there are many more steps to consider. You can then follow the additional steps to complete the upgrade to Spring Boot 2.2.x.

Prior to upgrading, refer to Pivotal's [Spring Boot 2.2 Release Notes](https://github.com/spring-projects/spring-boot/wiki/Spring-Boot-2.2-Release-Notes) to learn more about other potential upgrade impacts of your application.

>**Note**: The Spring Boot GA version provided in this guide was GA as of the date this guide was authored. Please update to patched versions as they are released as GA, and don't necessarily rely on the version you see in this guide. See [Spring Boot Versions](https://mvnrepository.com/artifact/org.springframework.boot/spring-boot) to see the versions available.


## Reference Application
At any point, you can refer to [CAB Reference application](https://github.ford.com/PCFDev-CAB/cab-service-fordair), which is upgraded with Spring Boot 2.2.5, Spring Cloud Hoxton SR1 and with other dependencies detailed in this migration guide.

## Files to Update

### build.gradle

- Upgrade Spring Boot gradle plugin version.

```
plugins {
  ...
  id 'org.springframework.boot' version '2.2.7.RELEASE'
}
```

- Upgrade the dependencyManagement (maven BOM) section.

    >**Note**: We upgraded Spring Cloud version to Hoxton SR3 and stayed with Spring Cloud Services dependencies version 2.1.4.RELEASE for compatibility with Spring Cloud Services tile in FORD PCF Foundations.

```groovy
    dependencyManagement {
        imports {
            mavenBom 'org.springframework.cloud:spring-cloud-dependencies:Hoxton.SR4'
            mavenBom 'io.pivotal.spring.cloud:spring-cloud-services-dependencies:2.1.4.RELEASE'
            ...
        }
    }
```

- Upgrade Ford Spring Boot Starter version from 2.1.0 to 2.2.0.

```groovy
    dependencies {
        ...
        implementation 'com.ford.cloudnative:spring-boot-starter-ford:2.2.0'
        ...
    }
```

- If you are using Microsoft SQL Server 2014, then downgrade Flyway Core version to 5.2.4 to get support with Flyway Community Edition.

    >**Note:** Flyway Community Edition version 5.2.x does not offer support for Oracle Database version 12.1.0.x or older. 
    Downgrading Flyway Core version below 5.2.0 will cause incompatibility issues with Ford Spring Boot Starter 2.2.x.
    Refer to [FlywayDB Release Notes](https://flywaydb.org/documentation/releaseNotes) for database version compatibility details.
```groovy
    dependencies {
        ...
        implementation 'org.flywaydb:flyway-core:5.2.4'
        ...
    }
```

- Upgrade Ford Spring Base Test version from 2.0.0 to 2.2.0 and **add** Spring Security Test dependency
```groovy
    dependencies {
        ...
        testImplementation 'com.ford.cloudnative:spring-base-test:2.2.0'
        ...
        testImplementation 'org.springframework.security:spring-security-test'
        ...
    }
```

### WebSecurityConfiguration.java
The following changes are required in the WebSecurityConfiguration class, due to underlying changes to Spring Security.

- Reformat Security Filter Chain declaration(s) with antMatchers instead of antMatcher pattern as below:

```gradle
    @Configuration
    @Order(10)
    public static class ResourceServerSecurityConfiguration extends WebSecurityConfigurerAdapter {
        ...
        @Override
        protected void configure(HttpSecurity http) throws Exception {
            ...
            http
                .antMatcher("/api/**")      //replace with your root url pattern to apply below security filters
                    .csrf().disable()
                    .authorizeRequests()
                        .antMatchers("/api/v1/unsecured/**").permitAll()    //replace with your endpoint url
                        .antMatchers("/api/v1/secured/**").authenticated()  //replace with your endpoint url
                    .and()
                    ...
        }
    }        
```

- If using Basic Auth Security, add the below code to declare an InMemoryUserDetailsManager bean configuring the basic auth security properties.

```gradle
    @Bean
    public InMemoryUserDetailsManager inMemoryUserDetailsManager(
            SecurityProperties properties, ObjectProvider<PasswordEncoder> passwordEncoder) {

        return new UserDetailsServiceAutoConfiguration().inMemoryUserDetailsManager(properties, passwordEncoder);
    }
```

### Controller Integration Tests (if any)
The following changes are required to the Controller Integration Test classes, if any, due to underlying changes to Spring Security and Spring Auto Configurer.

- Remove the previously deprecated property *'~~secure = false~~'* from @WebMvcTest annotation.
```gradle
@WebMvcTest(controllers = {...})
``` 

- Declare a JwtDecoder Mock Bean.

```gradle
    @MockBean
    JwtDecoder jwtDecoder;
```

<br/>
