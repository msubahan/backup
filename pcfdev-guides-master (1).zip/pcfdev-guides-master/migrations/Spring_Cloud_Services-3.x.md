# Spring Cloud Services (SCS) v3.x Migration

This guide details what it takes to upgrade the Spring Cloud Services (SCS) v2.x  to Spring Cloud Services (SCS) 3.x and later.

Spring Cloud Services (SCS) 3.x includes several architectural changes/enhancements which are outlined below.

SCS plan names is changed with version 3.x to the following:
* p.config-server
* p.service-registry

### Service Registry: 
No changes to the core functionality from an application standpoint except for the plan name change mentioned above.

### Config Server: 
Core functionality remains the same and includes enhancements as outlined in the below references:

* New Features: https://docs.pivotal.io/spring-cloud-services/3-1/common/config-server/refreshing-properties.html

* Differences from SCS 2.x: https://docs.pivotal.io/spring-cloud-services/3-1/common/config-server/managing-service-instances.html#differences-between-3-0-and-earlier


## Reference Application
At any point, you can refer to [CAB Reference application](https://github.ford.com/PCFDev-CAB/cab-service-fordair), which is upgraded with Spring Cloud Services(SCS) v3.x.


## Creating new config server and Service registry 

The following steps can be used via the cf utility: https://docs.pivotal.io/spring-cloud-services/3-1/common/config-server/managing-service-instances.html#migrating-2-0-or-1-5-service-instances


> NOTE: we recommend you to use Jenkins pipeline, pipeline.cf-services.sh to create new service instance  
>

The following are the steps if you are using the Dev Enablement Jenkins pipeline odffering for creation of new config server and service registry.

1. For each app bound to the existing Config Server service instance, unbind the app from the existing Config Server and delete existing Config Server service instance using Apps Manager or command line via the cf utility. 

   a. Log into Apps Manager as a Space Developer.

   b. Navigate to the organization and space that contain the service instance you want to delete.

   c. Click Services and then click the Name of the service you want to delete.

   d. Click Settings and then click Delete Service Instance. On the pop-up, click Delete Service Instance again to confirm you want to  delete the service instance and service bindings.
   
   
   
>Note: This action cannot be undone. Deleting a service instance deletes the configurations on the service instance, as well as the associated service bindings. You must bind any apps bound to the deleted service instance to a new service instance.
>
 


2. Update pipeline.cf-services.sh,with the new service type name **p.config-server**.  


```
if serviceEnabled "$CONFIGSERVER_ENABLED" && serviceMissing 'cab-config-server' ; then
cf create-service p.config-server standard cab-config-server -c "$(cat <<EOF
    {
        "git": {
            "uri": "$GITHUB_CONFIG_REPO_URL",
            "privateKey": "$GITHUB_SSH_KEY"
        }
    }
EOF
)"
fi
```


3. For each app bound to the existing service registry, unbind the app from the existing service registry and delete service registry  using Apps Manager or command line.


4. Update pipeline.cf-services.sh with the new service registry **p.service-registry**

```
if serviceMissing 'cab-service-registry' ; then
	cf create-service p.service-registry standard cab-service-registry
fi
```

5. Check-in and the pipeline should do the rest of the job(building and deploying to PCF).

6. After your app is successfully deployed, bind config server and service registry to your application and  verify config server and service registry functionality  and check services via the cf utility.

```
$ cf services 
```

This will display services **p.config-server** and **p.service-registry** instaed instead of old service instance. 

```
name                     service               plan         bound apps         last operation 

cab-config-server        p.config-server      standard     cab-fordair-dev     create succeeded

cab-service-registry     p.service-registry   standard     cab-fordair-dev     create succeeded
 
```
You can access an Actuator endpoint on a service instance by appending the path /actuator/endpoint using following Monitoring SCS service instances link from additional refrence.



### Additional References

* Config Server Client Dev Guide - https://github.ford.com/DevEnablement/pcfdev-guides/tree/master/config-client

* Config Server Setup Dev Guide - https://github.ford.com/DevEnablement/pcfdev-guides/blob/master/config-client/CONFIG_SERVER_SETUP.md

* Pivotal Config Server Doc - https://docs.pivotal.io/spring-cloud-services/3-1/common/config-server/index.html

* Pivotal Configuration Properties Doc - https://docs.pivotal.io/spring-cloud-services/3-1/common/config-server/configuring-with-git.html#general-configuration

* Pivotal Monitoring SCS service instances Doc - https://docs.pivotal.io/spring-cloud-services/3-1/common/actuator-endpoints.html
