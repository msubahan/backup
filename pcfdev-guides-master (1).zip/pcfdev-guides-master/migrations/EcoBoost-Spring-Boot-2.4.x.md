# EcoBoost Project - Spring Boot 2.4 & Spring Base Dependencies 3.0 Migration

This guide details what it takes to upgrade an EcoBoost Spring Boot 2.3.x project to Spring Boot 2.4.x, along with Spring Base Dependencies 3.0.x. 
This guide only covers the migration path for the out-of-the-box EcoBoost generated implementation and not any other custom team code added to the 
application. 
If your EcoBoost application is using a version of Spring Boot prior to 2.3.x, you should refer to the specific migration
guide(s) for your case and apply the migrations in order up to and including this guide.

Prior to upgrading, refer to Pivotal's [Spring Boot 2.4 Release Notes](https://github.com/spring-projects/spring-boot/wiki/Spring-Boot-2.4-Release-Notes) 
to learn more about other potential upgrade impacts to your application.

>**Note**: The Spring Boot GA version provided in this guide was GA as of the date this guide was last updated (July 30, 2021). 
Please update to patched versions as they are released as GA, and don't necessarily rely on the version you see in this guide. 
See [Spring Boot Versions](https://mvnrepository.com/artifact/org.springframework.boot/spring-boot) to see the 
versions available. You can also refer to [CAB Reference Application](https://github.ford.com/PCFDev-CAB/cab-service-fordair) to understand the latest versions available since we regularly update CAB.

## Major Changes
In addition to Spring Boot, there are several other changes to major components of the EcoBoost technology stack.
* [Spring Boot 2.4.x](https://github.com/spring-projects/spring-boot/wiki/Spring-Boot-2.4-Release-Notes)
* [Spring Cloud 2020.0.x](https://spring.io/projects/spring-cloud)
* [Spring Cloud Service Dependencies 2.4.x](https://docs.pivotal.io/spring-cloud-services/3-1/common/client-dependencies.html)
* [Spring Boot Starter Ford 3.0.x](https://github.ford.com/DevEnablement/spring-base-dependencies/releases/tag/v3.0.0)
* [Gradle 6.9.x](https://docs.gradle.org/6.9/release-notes.html)
* [Gradle Boost Plugin 3.4.x](https://github.ford.com/DevEnablement/gradle-boost-plugin/releases/tag/v3.4.0)

## Sample Reference Application for this specific migration scenario 
At any point, you can refer to this sample application [SpringBoot 2.3 to Full Migration](https://github.ford.com/DevEnablement/devenablement-service-sb23tofullmigrtn), 
which is upgraded with Spring Boot 2.4.x, Spring Cloud 2020.0.x, Spring Base Dependencies 3.0.x and with other dependencies detailed in this migration guide.

## Migration Steps 

The following steps will help you to migrate your application code to **Spring Boot 2.4** with **Spring Base Dependencies 3.0** and other dependencies listed above.

### Changes in gradle-wrapper.properties
In **`gradle-wrapper.properties`** file, located inside _`[Project_Root]/gradle/wrapper`_ folder, upgrade the gradle distribution file version to **`6.9`**, if not done already.

```aidl
distributionUrl=https\://www.nexus.ford.com/repository/gradle-distributions/gradle-6.9-bin.zip
```
<br/>

### Changes in build.gradle

#### Spring Boot & Gradle Boost Plugins
Upgrade Spring Boot plugin to version `2.4.13` (latest GA as of this writing).

> Note: There is no longer **.RELEASE** suffix in the spring boot and related dependencies beginning this release.

Optionally, upgrade **Gradle Boost plugin to version `3.3.0` or latest**. This is optional for Spring Boot 2.4 but is required in future for Spring Boot 2.5.

```aidl
plugins {
    id 'org.springframework.boot' version '2.4.13'
    id 'gradle-boost' version '3.4.0'
}
```

#### Spring Cloud and Spring Cloud Services
Upgrade **Spring Cloud** dependencies to version **`2020.0.4`** and **Spring Cloud Services** dependencies to version **`2.4.1`** (latest GA as of this writing).

```aidl
dependencies {
    // Bill Of Materials Imports
    bomImport platform('org.springframework.cloud:spring-cloud-dependencies:2020.0.4')
    ...
    bomImport platform('io.pivotal.spring.cloud:spring-cloud-services-dependencies:2.4.1')
    ...
}
```

<br/>

### Spring Base Dependencies 3.0 (**REQUIRED)
To migrate to **Spring Base Dependencies 3.0.x**, follow the [Spring Base Dependencies Migration Steps](Spring-Base-Dependencies-3.0.x.md#migration-steps). Once done, **come back here** to this guide and continue further.

<br/>

#### BootStrap Starter
Bootstrap, provided by spring-cloud-commons, is no longer enabled by default. EcoBoost generated apps rely on bootstrap configuration functionality.
In order to use the legacy bootstrap configuration method, include the new `spring-cloud-starter-bootstrap` dependency.

```aidl
dependencies {
    //Core libraries
    ...
    implementation 'org.springframework.cloud:spring-cloud-starter-bootstrap'
    ...
}
```

#### SRE Metrics
Upgrade **SRE Metrics** dependency, if used and not upgraded already, to version **`2.2.0`**. Previous versions are incompatible with **Spring Boot 2.4**.

```aidl
dependencies {
    ...
    implementation "com.ford.mpp.pe.sre:metrics:2.2.0"
    ...
}
```
>Note: Beginning SRE observability release 2.2.1, the library is only compatible with JDK11. 

#### JUnit 4 Support
As of Spring Boot 2.4, JUnit 5’s vintage engine has been removed from spring-boot-starter-test. If your application still requires JUnit 4 support, include the following dependency.

```aidl
dependencies {
    ...
    /*********** TEST libs ***********/
    testImplementation ('org.junit.vintage:junit-vintage-engine') {
        exclude group: "org.hamcrest", module: "hamcrest-core"
    }
    ...
}
```

Refresh gradle dependencies and clean build your application before continuing further.

<br/>

### Actuator Endpoints Update (if applicable)
Actuator endpoints with dashes (-) in between, have been updated to remove them:

- bus-env is now busenv
- bus-refresh is now busrefresh
- service-registry is now serviceregistry

If used in your application, update these new endpoints under `management.endpoints.web.exposure.include` property or perform a search and replace, in the **application.properties** file.

Also, update these new endpoints in **WebSecurityConfiguration.java** class (and related test classes, if applicable) with a search and replace.

<br/>

### Handling Deprecations
**Spring Boot 2.4** upgrade may introduce some deprecations based on the features used in your application. 
Below are the instructions to handle some of these known deprecations.

#### WebClient.exchange() function in TestUtil.java
If you have **TestUtil.java** class in your codebase, provided as part of recently generated EcoBoost app, you will notice 
a deprecation warning in the usage of `WebClient.exchange()` function.
To resolve this deprecation, replace the `get` and `post` methods in the **TestUtil.java** class with the respective refactored methods from the [Sample reference application](https://github.ford.com/DevEnablement/devenablement-service-sb23tofullmigrtn/blob/master/src/test/java/com/ford/devenablement/sb23tofullmigrtn/TestUtil.java#L29).

>Note: Make sure to re-organize your imports after replacing the above methods. You can modify these methods as you see fit to your application. 

You will also need to make changes to the caller of these methods. Refer to examples from the Sample reference application's 
[ActuatorsSecurityAcceptanceTest.java](https://github.ford.com/DevEnablement/devenablement-service-sb23tofullmigrtn/blob/master/src/test/java/com/ford/devenablement/sb23tofullmigrtn/acceptance/ActuatorsSecurityAcceptanceTest.java), 
[WebSecurityAcceptanceTest.java](https://github.ford.com/DevEnablement/devenablement-service-sb23tofullmigrtn/blob/master/src/test/java/com/ford/devenablement/sb23tofullmigrtn/acceptance/WebSecurityAcceptanceTest.java) and
[AdminAcceptanceTest.java](https://github.ford.com/DevEnablement/devenablement-service-sb23tofullmigrtn/blob/master/src/test/java/com/ford/devenablement/sb23tofullmigrtn/acceptance/admin/AdminAcceptanceTest.java) classes, and follow a similar pattern.


#### StringUtils.isNotEmpty()/isEmpty() functions in AuditAwareImpl.java
If you have **AuditAwareImpl.java** class in your codebase, provided as part of **Database** feature in recently generated EcoBoost app, you will notice
a deprecation warning in the usage of `StringUtils.isNotEmpty()` or `!StringUtils.isEmpty()` function (whichever is used).
To resolve this deprecation, replace the `StringUtils.isNotEmpty(...)` or `!StringUtils.isEmpty()` function with `StringUtils.hasLength(...)` function accordingly. 
Refer to example from Sample reference application's [AuditAwareImpl.java](https://github.ford.com/DevEnablement/devenablement-service-sb23tofullmigrtn/blob/master/src/main/java/com/ford/devenablement/sb23tofullmigrtn/AuditAwareImpl.java) class. 

<br/>

Clean build your application after all the recommended changes.

Contact **DevEnablement team** if you face any issue with the steps described above.
