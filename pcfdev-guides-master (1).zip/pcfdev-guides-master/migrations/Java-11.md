# EcoBoost Java 11 Migration

This guide details what it takes to upgrade your EcoBoost Spring Boot project to support Java 11.

## Required EcoBoost Changes

**Depending on when your EcoBoost project was generated, some of these changes may already be present in your project.**

If your EcoBoost project still uses Spring Boot 2.0, refer to the [Spring Boot 2.1 migration guide](EcoBoost-Spring-Boot-2.1.x.md) to update your project first.

 1. Update your cf **manifest-template.yml** file with the below *JBP_CONFIG_OPEN_JDK_JRE* environment variable. This environment variable will instruct PCF's Java buildpack to use OpenJDK 11 when deploying your application.
```
  env:
    JBP_CONFIG_OPEN_JDK_JRE: '{ jre: { version: 11.+ } }'
```
 2. Add another Lombok dependency using *annotationProcessor* in **build.gradle**. (Some EcoBoost projects may have multiple **build.gradle** files.) You should have duplicate entries in each *build.gradle* for lombok.
```
compileOnly 'org.projectlombok:lombok:1.18.8'
annotationProcessor 'org.projectlombok:lombok:1.18.8'
```
 3. Upgrade any springfox-swagger dependency to a version >= 2.9.2 in **build.gradle** to avoid JAXB dependencies issue.
```
implementation 'io.springfox:springfox-swagger2:2.9.2'
implementation 'io.springfox:springfox-swagger-ui:2.9.2'
```
 4. Update **gradle-properties.properties** *distributionUrl* value to point to a Gradle 5+ distribution.
```
distributionUrl=https\://www.nexus.ford.com/repository/gradle-distributions/gradle-5.3.1-bin.zip 
```

## Workstation Setup
#### JDK 11
You must install JDK 11 on your local workstation to develop Java 11 applications. You can download and install approved any OpenJDK 11 distribution from https://adoptopenjdk.net (DO NOT download Oracle JDK/JRE 11 since it is no longer approved due to Oracle license changes). See our [JDK/JRE notice](https://github.ford.com/DevEnablement/pcfdev-guides/blob/master/java/ORACLE_TO_ADOPT_JDK.md) to understand the implications and options for JDK usage.
>If you rely on Jenkins for build automation, then your [Jenkins server must also be configured with JDK 11](../pipeline-jenkins/MIGRATE_TO_JENK8S.md#jdk-11-optional).

#### IDE
Ensure that your IDE version supports Java 11.

1. Eclipse (>= 2018-09)
2. IntelliJ (>= 2018.2)

> The community has the approval to download the latest versions of the above IDEs directly from their vendor sites.
> The versions above are first versions that supported Java 11; We strongly encourage you to always use the latest version of Eclipse or IntelliJ.

**Do not forget to install and enable use of Lombok for your IDE.** Lombok setup instructions can be found [here](https://github.ford.com/DevEnablement/pcfdev-guides/tree/master/base-service#lombok).

## What's New Java 9+

Some internet resource links to learn more about new features since Java 8.

- https://www.baeldung.com/new-java-9
- https://www.baeldung.com/java-10-overview
- https://www.geeksforgeeks.org/java-11-features-and-comparison/) 
- https://www.baeldung.com/java-9-modularity

## Example Application

To see an example of an EcoBoost generated app that has been fully migrated to using Java 11, please refer to our reference application [CAB (Cloud-native Adventure Builder)](https://github.ford.com/PCFDev-CAB/cab-service-fordair). The Ford Air microservice in CAB is using Java 11 and followed all the instructions above. It also uses some of the new Java 9+ syntax, and thus is not backwards compatible with Java 8.  
#### CAB Jenkins Pipeline Update
The CAB application is built in Jenkins, and as such had to [install the Java 11 JDK on our Jenkins machine](../pipeline-jenkins/MIGRATE_TO_JENK8S.md#jdk-11-optional). The Adopt Java 11 JDK was used on our team's workstations as well as on our Jenkins server. We set the JAVA_HOME environment variable to point to our Java 11 JDK from the [pipeline.config.groovy](https://github.ford.com/PCFDev-CAB/cab-service-fordair/blob/master/pipeline/pipeline.configuration.groovy) file that was provided by EcoBoost.
  
##  Troubleshooting  

Certain libraries & packages, which were part of Java 8, have been removed in OpenJDK 11. If your project or dependencies depend on these missing packages, then you must add additional dependencies in your **build.gradle** to workaround this change.

```
// JAF (java.activation)
implementation 'com.sun.activation:javax.activation:1.2.0'

// JAXB (java.xml.bind)
implementation 'javax.xml.bind:jaxb-api:2.3.0'
implementation 'com.sun.xml.bind:jaxb-core:2.3.0'
implementation 'com.sun.xml.bind:jaxb-impl:2.3.0'

// JTA (java.transaction)
implementation 'javax.transaction:javax.transaction-api:1.2'

// JAX-WS (java.xml.ws)
implementation 'com.sun.xml.ws:jaxws-ri:2.3.2'
 
// Common Annotations (java.xml.ws.annotation)  
implementation 'javax.annotation:javax.annotation-api:1.3.2'

// COBRA (java.cobra)
// Currently no replacement has been identified
```
