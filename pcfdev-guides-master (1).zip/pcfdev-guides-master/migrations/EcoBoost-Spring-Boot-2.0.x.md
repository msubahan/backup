# EcoBoost Project - Spring Boot 2.0 Migration

This guide details what it takes to upgrade an EcoBoost Spring Boot 1.x project to Spring Boot 2.0.x. This guide only covers the migration path for the out-of-the-box EcoBoost generated implementation and not any other custom team code added to the application. Prior to upgrading, refer to the [Spring Boot 2.0 Migration Guide](https://github.com/spring-projects/spring-boot/wiki/Spring-Boot-2.0-Migration-Guide) to learn more about other potential upgrade impacts of your application.


## root Project

#### build.gradle

- Upgrade the following gradle plugin versions:

```groovy
plugins {
  id 'gradle-boost' version '2.0.0'
  id 'org.springframework.boot' version '2.0.6.RELEASE' apply false
}
```

- Upgrade the following maven BOM and individual dependencies:

```groovy
    dependencyManagement {
        imports {
            mavenBom 'org.springframework.cloud:spring-cloud-dependencies:Finchley.SR2'
            mavenBom 'io.pivotal.spring.cloud:spring-cloud-services-dependencies:2.1.1.RELEASE'
            mavenBom org.springframework.boot.gradle.plugin.SpringBootPlugin.BOM_COORDINATES
            mavenBom 'com.ford.cloudnative:spring-base-dependencies:2.0.0'
        }
        dependencies {
            dependency 'com.ford.cloudnative:spring-base-test:2.0.0'

            dependency 'io.springfox:springfox-swagger2:2.8.0'
            dependency 'io.springfox:springfox-swagger-ui:2.8.0'
        }
    }
```

**Note:** Version declaration of `org.flywaydb:flyway-core:4.x` should be **removed** from the block. `mssql-jdbc` dependency is optional.

<br/>

## /api Project

#### build.gradle

For `hibernate-validator` dependency, update the group name from `org.hibernate` to `org.hibernate.validator`. 

```groovy
dependencies {
	...
	implementation 'org.hibernate.validator:hibernate-validator'
	...
}
```

<br/>

## /application Project

#### build.gradle

- Remove the following dependencies (if applicable):

  ```
    implementation 'org.hibernate:hibernate-java8'
	implementation 'com.fasterxml.jackson.datatype:jackson-datatype-jsr310'
  ```

- Change `com.h2database:h2` dependency configuration from `implementation` to `localOnly`  (if applicable).

  ```
    localOnly 'com.h2database:h2'
  ```

#### application.properties

- Rename `security.user.password` property to `spring.security.user.password`.

- Flyway properties (i.e. `flyway.`) were moved to the spring namespace (i.e. `spring.flyway`)
 - Rename `flyway.table` to `spring.flyway.table`
 - Rename `flyway.baseline-on-migrate` to `spring.flyway.baseline-on-migrate`
 - Rename `flyway.enabled` to `spring.flyway.enabled`

- Replace `cn.app.datasource-populate.location=classpath:db/` with `spring.flyway.locations=classpath:db/{vendor}`

- Replace `spring.datasource.initialize=false` with `spring.datasource.initialization-mode=never`

- Remove the following unnecessary or defunct properties (if applicable):

  ```
   management.context-path=/actuator
   management.add-application-context-header=false

   spring.jackson.serialization.WRITE_DATES_AS_TIMESTAMPS=false
  ```



#### WebSecurityConfiguration.java

- Remove `@Order(SecurityProperties.ACCESS_OVERRIDE_ORDER)` annotation.

- If your application includes Actuator, then consider this additional request-matcher to re-open the safe */info* and */health* actuator endpoints
  ```
    http
    ...
    .authorizeRequests()
      ...
      .requestMatchers(EndpointRequest.to("info", "health")).permitAll()
      ...
   ```

#### WebSecurityConfigurationTest.java

 - If you do not plan to enable other actuator endpoints other */info* and */health*, then remove the @Test case `should_allowSensitiveActuatorEndpoints_withValidAuthentication`. Refer to [Spring Boot 2.0 Migration Guide](https://github.com/spring-projects/spring-boot/wiki/Spring-Boot-2.0-Migration-Guide#endpoints) on how to enable an actuator endpoint. Make sure to then update the @Test case with the enabled actuator endpoints.


<br/>

## /client Project

Ignore this section if your application does not have a */client* project.

- `FeignClient` class has been moved to a new package. Update `org.springframework.cloud.netflix.feign.FeignClient` import references with `org.springframework.cloud.openfeign.FeignClient`. 


<br/>

## Jenkins Pipeline

Ignore this section if your application does not included Dev Enablement's Jenkins pipeline.

#### Jenkinsfile

- Replace the following lines
 - `sh './gradlew pipelineStage'` &rarr; `sh './gradlew cfManifest pipelineCfStage acceptanceTests'`
 - `sh './gradlew pipelineRelease'` &rarr; `sh './gradlew pipelineCfRelease'`
 - `env.PIPELINE_BUILD=1` &rarr; `env.cfManifestFile='manifest-generated.yml'`


#### pipeline.configuration.groovy

- Replace the following environment variable names
 - `CF_DOMAINS` &rarr; `cfDomains`
 - `MANIFEST_TARGET` &rarr; `cfManifestTarget`

<br/>


<br/><br/><br/><br/><br/>