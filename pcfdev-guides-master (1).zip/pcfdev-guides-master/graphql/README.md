[![FOSSA Status](https://ford.fossa.com/api/projects/custom%2B1%2FSpringBoot-Graphql.svg?type=shield)](https://ford.fossa.com/projects/custom%2B1%2FSpringBoot-Graphql?ref=badge_shield)

# GraphQL with Spring Boot

A GraphQL with Spring Boot reference application to demonstrate query and mutation with Vehicle use case.
The reference spring boot application uses the Vehicle service to access the data from the database by exposing the service API endpoint using GraphQL.

![VehicleClassDiag](https://github.ford.com/DevEnAP/devenablement-service-graphql/wiki/images/VehicleClassDiagram.PNG)

# GraphQL
GraphQL is a query language for APIs. It allows consumers to specify exactly what is needed, and then it fetches just that — nothing more, nothing less.
## How GraphQL Works?
A GraphQL server provides a client with a predefined schema that can be requested from the server. The schema consists of type definitions and defines what queries can be made, what type of data can be fetched, relationships between these types. A client can validate their query against the schema to make sure the server will be able to respond to the query.
The Resolvers are the executors of the methods defined in the schema that are responsible for populating the data for fields in our schema.  
Once a GraphQL operation reaches the backend application, it’s interpreted against the entire schema there, and resolved with data for the frontend application.
![GraphqlArc](https://github.ford.com/DevEnAP/devenablement-service-graphql/wiki/images/graphqlArchitecture.png)

## GraphQL Implementation
To build a GraphQL server with Spring Boot, all you need to do is generate spring boot project from dcs.ford.com and add below dependency to the build.gradle.

`implementation 'com.graphql-java:graphql-spring-boot-starter:5.0.2'`

`implementation 'com.graphql-java:graphql-java-tools:5.2.4'`

## Schema 
GraphQL server uses a schema to describe the shape of your data graph. The schema consists of type definitions and defines what queries can be made, what type of data can be fetched, relationships between these types.
Schemas must be written in the classpath with the extension “.graphqls”.

```
type Vehicle {
    vin: ID!,
    vehicleDescription: String,
    ...
    msrp: Msrp
}

input VehicleInput {
    vin: ID,
    vehicleDescription: String,
    ...
    msrp: MsrpInput
}
```
Schema for Query Resolver method

```
type Query {
Vehicle(vin: ID): Vehicle
}
```
Schema for Mutation Resolver method
```
type Mutation{
createVehicle(vehicle : VehicleInput!):Vehicle
}
```

# Resolvers
A resolver is responsible for populating the data for the fields in the schema. If we are fetching the data from multiple data sources and external API’s the data is resolved as per the schema defined, in a single API call instead of having chain of requests.
It is required to have implementation for Query resolvers and Mutation resolvers.

### Query resolvers 
```
@Component
public class VehicleQueryResolver implements GraphQLQueryResolver {
    @Autowired
    private VehicleService vehicleService;

    public Vehicle Vehicle(final String vin) {
        Optional<Vehicle> vehicle= this.vehicleService.getVehicle(vin);
        return vehicle.isPresent()? vehicle.get(): null ;
    }
}

```
### Mutation resolvers

```
@Component
public class VehicleMutationResolver implements GraphQLMutationResolver {
    @Autowired
    private VehicleService vehicleService;

    public Vehicle createVehicle(Vehicle vehicle) {
        return this.vehicleService.createVehicle(vehicle);

    }
}

```
# Query
Query is used for querying or SELECT operations. The keyword **type** is used in the schema.
```
type Vehicle {
    ...
}
```

# Mutation
Mutations are used for creating new data, updating and deleting existing data. The keyword **input** is used in the schema.
```
input VehicleInput {
    ...
}
```

# Testing
Single endpoint for all the operations, you can test your API’s using Postman. 
http://localhost:8080/graphql

**Query**
**Request**
```
{
	vehicle(vin: "1F1FK1F53AEA00018") {
		vin
		vehicleDescription
		brand
		modelYear
		adas {
		   invoiceDate
		   bodystyle
		   wheelbase
		}	
	}
}
```
**Response**

```
{
    "data": {
        "Vehicle": {
            "vin": "1F1FK1F53AEA00018",
            "vehicleDescription": "FORD EXPEDITION 002",
            "brand": "FORD",
            "modelYear": null,
            "adas": {
                "invoiceDate": "MODEL YEAR 02",
                "bodystyle": "NAME PLATE001",
                "wheelbase": null,
            }
        }
    }
}

```
**Mutation**
**Request**

```
mutation {
	createVehicle(
		vehicle: {
			vin: "1F1FK1F53AEA00019"
			vehicleDescription: "FORD EXPEDITION 002"
			brand: "FORD"
			adas: { invoiceDate: "MODEL YEAR 02", bodystyle: "NAME PLATE001" }
			collision: {
				regionCode: "regionCode01"
				wersFamilyCode: "wersFamilyCode01"
				wersFamDesc: "wersFamDesc01"
			}
		}
	) {
		vin
		vehicleDescription
		brand
		adas {
			invoiceDate
			bodystyle
		}
	}
}
```

**Response**

```
{
    "data": {
        "createVehicle": {
            "vin": "1F1FK1F53AEA00019",
            "vehicleDescription": "FORD EXPEDITION 002",
            "brand": "FORD",
            "adas": {
                "invoiceDate": "MODEL YEAR 02",
                "bodystyle": "NAME PLATE001"
            }
        }
    }
}
```
#### Input Validation and DoS Limitations

Depth Limiting: Enables us to limit the maximum depth of incoming queries to mitigate the attacks caused from deeply nested queries or infinitely recursive queries. As a part of the solution, the property graphql.servlet.max-query-depth limit the query depth. However, this limitation has found to be implicitly set on introspection query(usually has a depth of 13) that is responsible for generating schema and docs in documentation tools such as playground etc. To set the depth limitation only on incoming query, it is identified that a manual implementation is required. https://github.com/graphql-java/graphql-java/issues/1055 

Amount Limiting: Each object requested in a query can have an amount specified (e.g. 99999999 of an object). This can be unlimited which is expensive and may lead to a DoS attack. Limits must be set against how much amount of data can be requested in a single query by restricting the maximum value to a threshold which is the pagination concept.

This limitation is covered in output pagination.

Timeouts: The request timeout that adds up over several queries and fields has been implemented. The beginning of the execution time is started globally and is checked after each field whether the time has expired. If so, the execution is canceled.

Query Cost limiting:  Involves assigning costs to the resolution of fields or types in incoming queries so that the server can reject queries that cost too much to run or will consume too many resources. APIs using graphql-java can utilize the built-in MaxQueryComplexityInstrumentation to enforce max query complexity that has default complexity of 1 on each field. 

Rate Limiting: The three possible solutions for rate limiting are 

1. Building it as part of the solution using algorithms that checks the incoming call and counts the incoming requests per user or IP address during a time window.

2. Build some component or use a built-in component that is independent of the current solution that acts a API Gateway that does the job. 

3. Use an API Manager that has rate limiting.

https://stackoverflow.com/questions/44042412/how-to-set-rate-limit-for-each-user-in-spring-boot 

## Build & Deploy

This project requires **JDK 11** to build and run the application. It also requires **cf** CLI if you want to deploy to PCF. You can visit [Dev Enablement's OnBoarding](http://x.ford.com/dev-onboard) page for links to download these resources or sign-up for a free-trial PCF foundation.

>If your workstation is not already setup to develop with Java 11, then you can refer to [Java 11 Workstation Setup](https://github.ford.com/DevEnablement/pcfdev-guides/blob/master/migrations/Java-11.md#workstation-setup).


#### Run & Test Locally

To build, run `./gradlew build`
> Note: Windows users do not use the `./` in front of the `gradew` commands. The instructions assume Mac command prompt

To start and run the application, run `./gradlew bootRun`. 

Your local running app is served on port 8080. If you have actuator installed, you can test app using:
- [http://localhost:8080/actuator/health](http://localhost:8080/actuator/health) 
 
 
Press `^C` (control-C) to stop your app

#### Deploy manually using CF CLI

In order to deploy, you must first build (`./gradlew build`).

To deploy your built application:

```bash
# login into your PCF space
# cf login -a https://[foundation-api-host] ...

# generate manifest based on 'dev-edc1' settings
./gradlew -PcfManifestTarget=dev-edc1 cfManifest

# push generated manifest
cf push -f manifest-generated.yml
```

#### IDE

Your IDE version must support Java 11 &mdash; i.e. Eclipse (>= 2018-09), IntelliJ (>= 2018.2).

**Your must install and enable use of Lombok for your IDE.** Lombok setup instructions can be found [here](https://github.ford.com/DevEnablement/pcfdev-guides/blob/master/base-service/README.md#lombok).

<br/>


## EcoBoost Project Features
This [**EcoBoost Project**](http://x.ford.com/spring-ecoboost) was originally generated with the following features:

- [**Core Features**](https://github.ford.com/DevEnablement/pcfdev-guides/blob/master/base-service/README.md#core-features) &mdash; 
  Spring Boot 2
, Gradle 5
, Java 11
, [Gradle Boost Plugin](https://github.ford.com/DevEnablement/gradle-boost-plugin)
, [Lombok](https://projectlombok.org/)
, Firewall Friendly

- [**Recommended Web Features**](https://github.ford.com/DevEnablement/pcfdev-guides/blob/master/base-service/README.md#recommended-web-features) &mdash; 
Swagger
, Actuator
, Sleuth
, X-Application-Info
, X-Request-Info
, Common Error Handling


- Other Features & Reference Code &mdash; 
[Simple REST Controller](https://github.ford.com/DevEnablement/pcfdev-guides/tree/master/rest-controller)
, [PCF Dev Jenkins Pipeline](https://github.ford.com/DevEnablement/pcfdev-guides/tree/master/pipeline-jenkins)
, [Externalized Configuration](https://github.ford.com/DevEnablement/pcfdev-guides/tree/master/config-client)

## Dev Enablement Resources
Need to learn more about your EcoBoost project or learn more about additional integrations available for your Spring Boot app? See our Dev Guides, Community Forum, and other resources in our Dev Services portal at [http://devservices.ford.com](http://devservices.ford.com).


## Contact Us
Need to notify us of a bug, have issues, new feature request or simply want to brag? Join the /d/c/s Community Channels!

- [/Dev/Central/Station Slack](https://app.slack.com/client/T5V3ZFCD6/C9L83E6DQ)
- [/Dev/Central/Station Webex Teams](https://www.webexteams.ford.com/space?r=fz8y)


