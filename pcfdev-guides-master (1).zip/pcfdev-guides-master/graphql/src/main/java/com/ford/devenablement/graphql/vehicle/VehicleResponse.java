package com.ford.devenablement.graphql.vehicle;

import com.ford.devenablement.graphql.vehicle.entity.Vehicle;
import graphql.annotations.annotationTypes.GraphQLField;
import graphql.annotations.annotationTypes.GraphQLName;
import lombok.Data;

@Data
@GraphQLName("vehicleResponse")
public class VehicleResponse {

   @GraphQLField
    private Vehicle vehicle;

    @GraphQLField
    private VehicleProfile vehicleProfile;
}
