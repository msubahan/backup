package com.ford.devenablement.graphql.vehicle.entity;

import graphql.annotations.annotationTypes.GraphQLField;
import graphql.annotations.annotationTypes.GraphQLName;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.Column;
import javax.persistence.Embeddable;

@Data
@Embeddable
@GraphQLName("adas")
public class Adas {

    @Column(name = "VDB001_INV_DT_Y")
    @GraphQLField
    private String invoiceDate;
    @Column(name = "VDB001_BODY_CAB_STYLE_X")
    @GraphQLField
    private String bodystyle;
    @Column(name = "VDB001_WHLBS_X")
    @GraphQLField
    private String wheelbase;
    @Column(name = "VDB001_VEH_SYNC_F")
    @GraphQLField
    private String vehicleSyncFlag;
    @Column(name = "VDB001_VEH_SIRIUS_F")
    @GraphQLField
    private String vehicleSiriusFlag;
}
