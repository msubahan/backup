package com.ford.devenablement.graphql.vehicle;

import com.ford.devenablement.graphql.vehicle.entity.Vehicle;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Service;

import java.util.Optional;
import java.util.concurrent.CompletableFuture;

@Service
public class VehicleService {

    @Autowired
    private VehicleRepository vehicleRepository;


    @Async
    @PreAuthorize("@authorizeService.isAuthorized('GraphQL:vdab','read')")
    public CompletableFuture<Vehicle> getVehicleById(String vin) {
            Optional<Vehicle> vehicleDetail = vehicleRepository.findById(vin);
            return CompletableFuture.completedFuture(vehicleDetail.isPresent() ? vehicleDetail.get() : new Vehicle());
    }
}
