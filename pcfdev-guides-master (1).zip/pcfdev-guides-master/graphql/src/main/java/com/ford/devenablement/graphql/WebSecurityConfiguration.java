package com.ford.devenablement.graphql;

import org.springframework.beans.factory.ObjectProvider;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.security.SecurityProperties;
import org.springframework.boot.autoconfigure.security.servlet.UserDetailsServiceAutoConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.annotation.Order;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.oauth2.jwt.JwtDecoder;
import org.springframework.security.provisioning.InMemoryUserDetailsManager;
import java.util.List;


@EnableWebSecurity
@EnableGlobalMethodSecurity(prePostEnabled = true)
public class WebSecurityConfiguration {

	/*****************************************************************************************************************
	 * Other - Basic/Public
	 *****************************************************************************************************************/

	// helper
	static JwtDecoder wrapJwtDecoderWithAudienceCheck(JwtDecoder jwtDecoder, List<String> audience) {
		return token -> jwtDecoder.decode(token);
	}


	@Configuration
	@Order(30)
	public static class HttpSecurityConfiguration extends WebSecurityConfigurerAdapter {

		@Value("#{'${audience-id}'.split(',')}")
		List<String> audience;

		@Autowired
		JwtDecoder jwtDecoder;

		@Override
		protected void configure(HttpSecurity http) throws Exception {
			JwtDecoder newJwtDecoder = wrapJwtDecoderWithAudienceCheck(this.jwtDecoder, audience);
			http
					.requestMatchers()
					.antMatchers("/graphql","/vehicleService/**")
					.and()
					.authorizeRequests()
					.anyRequest().authenticated()
					.and()
					.sessionManagement()
					.sessionCreationPolicy(SessionCreationPolicy.STATELESS)
					.and()
					.oauth2ResourceServer()
					.jwt()
					.decoder(newJwtDecoder)
			;
		}
	}

	@Bean
	public InMemoryUserDetailsManager inMemoryUserDetailsManager(
			SecurityProperties properties, ObjectProvider<PasswordEncoder> passwordEncoder) {
		return new UserDetailsServiceAutoConfiguration().inMemoryUserDetailsManager(properties, passwordEncoder);
	}

}