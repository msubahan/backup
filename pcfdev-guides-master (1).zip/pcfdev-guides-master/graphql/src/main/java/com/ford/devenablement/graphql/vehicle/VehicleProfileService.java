package com.ford.devenablement.graphql.vehicle;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.ResponseBody;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.util.concurrent.CompletableFuture;

@Service
public class VehicleProfileService {

    @Autowired
    private OkHttpClient okHttpClient;

    @Async
    @PreAuthorize("@authorizeService.isAuthorized('GraphQL:vehicleprofile','read')")
    public CompletableFuture<VehicleProfile> getVehicleProfile(String vin) throws VehicleException {

        if(!StringUtils.isEmpty(vin)) {

            Request request = new Request.Builder()
                    .url("https://devenablement-vehicleprofile-dev.apps.pp01i.edc1.cf.ford.com/api/v1/vehicleprofile/" + vin)
                    .get()
                    .build();
            VehicleProfileResponse response = null;
            try {
                response = (VehicleProfileResponse) mapResponse(okHttpClient.newCall(request).execute(), VehicleProfileResponse.class);
            } catch (IOException e) {
                throw new VehicleException(e);
            }
            return CompletableFuture.completedFuture(response.getResult() != null ? response.getResult().getVehicleProfile() : null);
        }
        return null;
    }

    private static <T> Object mapResponse(Response response, Class<T> tClass) throws VehicleException {
        try {
            ObjectMapper mapper = new ObjectMapper();
            mapper.configure(DeserializationFeature.ACCEPT_SINGLE_VALUE_AS_ARRAY, true);
            mapper.configure(DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT, true);

            if (response.code() == HttpURLConnection.HTTP_OK) {
                ResponseBody res = response.body();
                if(res != null) {
                    String responseBody =  res.string();
                    return mapper.readValue(responseBody, tClass);
                }
            }
            return tClass.getConstructor().newInstance();
        } catch (Exception e) {
            throw new VehicleException(e);
        }
    }

}
