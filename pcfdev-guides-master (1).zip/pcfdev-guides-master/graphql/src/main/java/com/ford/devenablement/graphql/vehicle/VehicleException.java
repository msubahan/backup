package com.ford.devenablement.graphql.vehicle;

public class VehicleException extends  Exception{

    public VehicleException(Exception exception) {
        super(exception);
    }
}
