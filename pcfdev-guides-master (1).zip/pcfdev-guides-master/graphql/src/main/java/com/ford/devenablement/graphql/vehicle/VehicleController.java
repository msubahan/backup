package com.ford.devenablement.graphql.vehicle;

import graphql.ExecutionInput;
import graphql.ExecutionResult;
import graphql.GraphQL;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.Authorization;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;

import java.util.Map;

@RestController
@RequestMapping(path = "/vehicleService/graphql")
public class VehicleController {

    @Autowired
    private final GraphQL graphQL;

    public VehicleController(GraphQL graphQL) {
        this.graphQL = graphQL;
    }

    @ApiOperation(value = "Retrieve vehicle by vin ID", notes = "Returns vehicle matches the vin ID", authorizations = { @Authorization(value="jwtToken") })
    @PostMapping
    @ResponseBody
    public ResponseEntity<Object> getVehicle(@RequestBody Map<String, String> request, HttpServletRequest raw) {

        ExecutionResult executionResult = graphQL.execute(ExecutionInput.newExecutionInput()
                .query(request.get("query"))
                .context(raw)
                .build());
        return new ResponseEntity<Object>(executionResult, HttpStatus.OK);

    }

}