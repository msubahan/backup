package com.ford.devenablement.graphql.vehicle.entity;

import graphql.annotations.annotationTypes.GraphQLField;
import graphql.annotations.annotationTypes.GraphQLName;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.Column;
import javax.persistence.Embeddable;

@Data
@Embeddable
@GraphQLName("msrp")
public class Msrp {

    @Column(name = "VDB001_TOT_OPTN_PRC_A")
    @GraphQLField
    private String totalOptionsPrice;
    @Column(name = "VDB001_DEST_DLVRY_PRC_A")
    @GraphQLField
    private String destinationAndDelivery;
    @Column(name = "VDB001_TOT_BFR_DISC_A")
    @GraphQLField
    private String totalBeforeDiscounts;
    @Column(name = "VDB001_DISC1_X")
    @GraphQLField
    private String discount1Name;
    @Column(name = "VDB001_DISC1_PRC_A")
    @GraphQLField
    private String discount1Price;
    @Column(name = "VDB001_DISC2_X")
    @GraphQLField
    private String discount2Name;
    @Column(name = "VDB001_DISC2_PRC_A")
    @GraphQLField
    private String discount2Price;
    @Column(name = "VDB001_DISC3_X")
    @GraphQLField
    private String discount3Name;
    @Column(name = "VDB001_DISC3_PRC_A")
    @GraphQLField
    private String discount3Price;
    @Column(name = "VDB001_DISC4_X")
    @GraphQLField
    private String discount4Name;
    @Column(name = "VDB001_DISC4_PRC_A")
    @GraphQLField
    private String discount4Price;
    @Column(name = "VDB001_TOT_SAVNG_A")
    @GraphQLField
    private String totalSavings;
}
