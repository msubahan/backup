package com.ford.devenablement.graphql;

import com.ford.aps.spring.configuration.EnableApsService;
import com.ford.cloudnative.annotations.EnableFordSecurityTools;
import okhttp3.OkHttpClient;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

@SpringBootApplication
@EnableFordSecurityTools
@EnableApsService
public class GraphqlApplication {
	public static void main(String[] args) {
		SpringApplication.run(GraphqlApplication.class, args);
	}

	@Bean
	public OkHttpClient okHttpClient() {
		return new OkHttpClient();
	}


}
