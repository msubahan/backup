package com.ford.devenablement.graphql.vehicle.entity;

import graphql.annotations.annotationTypes.GraphQLField;
import graphql.annotations.annotationTypes.GraphQLName;
import lombok.Data;

import javax.persistence.*;

@Entity
@Data
@Table(name = "GVDB001_VIN_DIMENSION",schema= "vdab")
@GraphQLName("vehicle")
public class Vehicle {
    @Id
    @GraphQLField
    @Column(name = "VDB001_VIN_D")
    private String vin;
    @Column(name = "VDB001_VEH_DESC_X")
    @GraphQLField
    private String vehicleDescription;
    @Column(name = "VDB001_BRND_C")
    @GraphQLField
    private String brand;
    @Column(name = "VDB001_MDL_YR_R")
    @GraphQLField
    private String modelYear;
    @Column(name = "VDB001_NAMPLT_X")
    @GraphQLField
    private String nameplate;
    @Column(name = "VDB001_DRVLN_X")
    @GraphQLField
    private String driveline;
    @Column(name = "VDB001_ENG_X")
    @GraphQLField
    private String engine;
    @Column(name = "VDB001_TRANS_X")
    @GraphQLField
    private String transmission;
    @Column(name = "VDB001_MKTG_BODY_C")
    @GraphQLField
    private String marketingBodyCode;
    @Column(name = "VDB001_TRIM_X")
    @GraphQLField
    private String trimLevel;
    @Column(name = "VDB001_PROD_TYPE_C")
    @GraphQLField
    private String productType;
    @Column(name = "VDB001_FUEL_TYPE_CATG_X")
    @GraphQLField
    private String fuelTypeCategory;
    @Column(name = "VDB001_MSRP_R")
    @GraphQLField
    private String msrpR;
    @Column(name = "VDB001_BUILD_DT_Y")
    @GraphQLField
    private String buildDate;

    @Embedded
    @AttributeOverrides({
            @AttributeOverride( name = "invoiceDate", column = @Column(name = "VDB001_INV_DT_Y")),
            @AttributeOverride( name = "bodystyle", column = @Column(name = "VDB001_BODY_CAB_STYLE_X")),
            @AttributeOverride( name = "wheelbase", column = @Column(name = "VDB001_WHLBS_X")),
            @AttributeOverride( name = "vehicleSyncFlag", column = @Column(name = "VDB001_VEH_SYNC_F")),
            @AttributeOverride( name = "vehicleSiriusFlag", column = @Column(name = "VDB001_VEH_SIRIUS_F"))
    })
    @GraphQLField
    private Adas adas;

    @Embedded
    @AttributeOverrides({
            @AttributeOverride( name = "regionCode", column = @Column(name = "VDB001_RGN_C")),
            @AttributeOverride( name = "wersFamilyCode", column = @Column(name = "VDB001_FAM_C")),
            @AttributeOverride( name = "wersFeatureCode", column = @Column(name = "VDB001_FTR_C")),
            @AttributeOverride( name = "wersFamDesc", column = @Column(name = "VDB001_FAM_DESC_X")),
            @AttributeOverride( name = "wersFtrDesc", column = @Column(name = "VDB001_FTR_DESC_X")),
            @AttributeOverride( name = "plantName", column = @Column(name = "VDB001_PLANT_N")),
            @AttributeOverride( name = "boxSize", column = @Column(name = "VDB001_BOX_SIZE_X")),
            @AttributeOverride( name = "colorCode", column = @Column(name = "VDB001_EXT_CLR_C")),
            @AttributeOverride( name = "colorName", column = @Column(name = "VDB001_EXT_CLR_DESC_X")),
            @AttributeOverride( name = "colorRetailCost", column = @Column(name = "VDB001_EXT_CLR_PRC_A"))


    })
    @GraphQLField
    private Collision collision;

    @Embedded
    @AttributeOverrides({
            @AttributeOverride( name = "intCode", column = @Column(name = "VDB001_INT_CLR_C")),
            @AttributeOverride( name = "interiorDescription", column = @Column(name = "VDB001_INT_CLR_DESC_X")),
            @AttributeOverride( name = "intCost", column = @Column(name = "VDB001_INT_CLR_PRC_A")),
            @AttributeOverride( name = "equipmentCode", column = @Column(name = "VDB001_EQUIP_C")),
            @AttributeOverride( name = "eqCodeCost", column = @Column(name = "VDB001_EQUIP_PRC_A")),
            @AttributeOverride( name = "engCode", column = @Column(name = "VDB001_ENG_C")),
            @AttributeOverride( name = "engineDescription", column = @Column(name = "VDB001_ENG_DESC_X")),
            @AttributeOverride( name = "transCode", column = @Column(name = "VDB001_TRANS_C")),
            @AttributeOverride( name = "transDescription", column = @Column(name = "VDB001_TRANS_DESC_X"))
    })
    @GraphQLField
    private Pep pep;

    @Embedded
    @AttributeOverrides({
            @AttributeOverride( name = "totalOptionsPrice", column = @Column(name = "VDB001_TOT_OPTN_PRC_A")),
            @AttributeOverride( name = "destinationAndDelivery", column = @Column(name = "VDB001_DEST_DLVRY_PRC_A")),
            @AttributeOverride( name = "totalBeforeDiscounts", column = @Column(name = "VDB001_TOT_BFR_DISC_A")),
            @AttributeOverride( name = "discount1Name", column = @Column(name = "VDB001_DISC1_X")),
            @AttributeOverride( name = "discount1Price", column = @Column(name = "VDB001_DISC1_PRC_A")),
            @AttributeOverride( name = "discount2Name", column = @Column(name = "VDB001_DISC2_X")),
            @AttributeOverride( name = "discount2Price", column = @Column(name = "VDB001_DISC2_PRC_A")),
            @AttributeOverride( name = "discount3Name", column = @Column(name = "VDB001_DISC3_X")),
            @AttributeOverride( name = "discount3Price", column = @Column(name = "VDB001_DISC3_PRC_A")),
            @AttributeOverride( name = "discount4Name", column = @Column(name = "VDB001_DISC4_X")),
            @AttributeOverride( name = "discount4Price", column = @Column(name = "VDB001_DISC4_PRC_A")),
            @AttributeOverride( name = "totalSavings", column = @Column(name = "VDB001_TOT_SAVNG_A")),

            @AttributeOverride( name = "optCode1", column = @Column(name = "VDB001_OPT1_C")),
            @AttributeOverride( name = "optCode2", column = @Column(name = "VDB001_OPT2_C")),
            @AttributeOverride( name = "optCode3", column = @Column(name = "VDB001_OPT3_C")),
            @AttributeOverride( name = "optCode4", column = @Column(name = "VDB001_OPT4_C")),
            @AttributeOverride( name = "optCode5", column = @Column(name = "VDB001_OPT5_C")),
            @AttributeOverride( name = "optCode6", column = @Column(name = "VDB001_OPT6_C")),
            @AttributeOverride( name = "optCode7", column = @Column(name = "VDB001_OPT7_C")),
            @AttributeOverride( name = "optCode8", column = @Column(name = "VDB001_OPT8_C")),
            @AttributeOverride( name = "optCode9", column = @Column(name = "VDB001_OPT9_C")),
            @AttributeOverride( name = "optCode10", column = @Column(name = "VDB001_OPT10_C")),

            @AttributeOverride( name = "optCode11", column = @Column(name = "VDB001_OPT11_C")),
            @AttributeOverride( name = "optCode12", column = @Column(name = "VDB001_OPT12_C")),
            @AttributeOverride( name = "optCode13", column = @Column(name = "VDB001_OPT13_C")),
            @AttributeOverride( name = "optCode14", column = @Column(name = "VDB001_OPT14_C")),
            @AttributeOverride( name = "optCode15", column = @Column(name = "VDB001_OPT15_C")),
            @AttributeOverride( name = "optCode16", column = @Column(name = "VDB001_OPT16_C")),
            @AttributeOverride( name = "optCode17", column = @Column(name = "VDB001_OPT17_C")),
            @AttributeOverride( name = "optCode18", column = @Column(name = "VDB001_OPT18_C")),
            @AttributeOverride( name = "optCode19", column = @Column(name = "VDB001_OPT19_C")),
            @AttributeOverride( name = "optCode20", column = @Column(name = "VDB001_OPT20_C")),
            @AttributeOverride( name = "optCode21", column = @Column(name = "VDB001_OPT21_C")),
            @AttributeOverride( name = "optCode22", column = @Column(name = "VDB001_OPT22_C")),
            @AttributeOverride( name = "optCode23", column = @Column(name = "VDB001_OPT23_C")),
            @AttributeOverride( name = "optCode24", column = @Column(name = "VDB001_OPT24_C")),
            @AttributeOverride( name = "optCode25", column = @Column(name = "VDB001_OPT25_C")),
            @AttributeOverride( name = "optCode26", column = @Column(name = "VDB001_OPT26_C")),
            @AttributeOverride( name = "optCode27", column = @Column(name = "VDB001_OPT27_C")),
            @AttributeOverride( name = "optCode28", column = @Column(name = "VDB001_OPT28_C")),
            @AttributeOverride( name = "optCode29", column = @Column(name = "VDB001_OPT29_C")),
            @AttributeOverride( name = "optCode30", column = @Column(name = "VDB001_OPT30_C")),
            @AttributeOverride( name = "optCode31", column = @Column(name = "VDB001_OPT31_C")),
            @AttributeOverride( name = "optCode32", column = @Column(name = "VDB001_OPT32_C")),
            @AttributeOverride( name = "optCode33", column = @Column(name = "VDB001_OPT33_C")),
            @AttributeOverride( name = "optCode34", column = @Column(name = "VDB001_OPT34_C")),
            @AttributeOverride( name = "optCode35", column = @Column(name = "VDB001_OPT35_C")),
            @AttributeOverride( name = "optCode36", column = @Column(name = "VDB001_OPT36_C")),
            @AttributeOverride( name = "optCode37", column = @Column(name = "VDB001_OPT37_C")),
            @AttributeOverride( name = "optCode38", column = @Column(name = "VDB001_OPT38_C")),
            @AttributeOverride( name = "optCode39", column = @Column(name = "VDB001_OPT39_C")),
            @AttributeOverride( name = "optCode40", column = @Column(name = "VDB001_OPT40_C")),
            @AttributeOverride( name = "optCode41", column = @Column(name = "VDB001_OPT41_C")),
            @AttributeOverride( name = "optCode42", column = @Column(name = "VDB001_OPT42_C")),
            @AttributeOverride( name = "optCode43", column = @Column(name = "VDB001_OPT43_C")),
            @AttributeOverride( name = "optCode44", column = @Column(name = "VDB001_OPT44_C")),
            @AttributeOverride( name = "optCode45", column = @Column(name = "VDB001_OPT45_C")),
            @AttributeOverride( name = "optCode46", column = @Column(name = "VDB001_OPT46_C")),
            @AttributeOverride( name = "optCode47", column = @Column(name = "VDB001_OPT47_C")),
            @AttributeOverride( name = "optCode48", column = @Column(name = "VDB001_OPT48_C")),
            @AttributeOverride( name = "optCode49", column = @Column(name = "VDB001_OPT49_C")),
            @AttributeOverride( name = "optCode50", column = @Column(name = "VDB001_OPT50_C")),
            @AttributeOverride( name = "optCode51", column = @Column(name = "VDB001_OPT51_C")),
            @AttributeOverride( name = "optCode52", column = @Column(name = "VDB001_OPT52_C")),
            @AttributeOverride( name = "optCode53", column = @Column(name = "VDB001_OPT53_C")),
            @AttributeOverride( name = "optCode54", column = @Column(name = "VDB001_OPT54_C")),
            @AttributeOverride( name = "optCode55", column = @Column(name = "VDB001_OPT55_C")),
            @AttributeOverride( name = "optCode56", column = @Column(name = "VDB001_OPT56_C")),
            @AttributeOverride( name = "optCode57", column = @Column(name = "VDB001_OPT57_C")),
            @AttributeOverride( name = "optCode58", column = @Column(name = "VDB001_OPT58_C")),
            @AttributeOverride( name = "optCode59", column = @Column(name = "VDB001_OPT59_C")),
            @AttributeOverride( name = "optCode60", column = @Column(name = "VDB001_OPT60_C")),
            @AttributeOverride( name = "optCode61", column = @Column(name = "VDB001_OPT61_C")),
            @AttributeOverride( name = "optCode62", column = @Column(name = "VDB001_OPT62_C")),
            @AttributeOverride( name = "optCode63", column = @Column(name = "VDB001_OPT63_C")),
            @AttributeOverride( name = "optCode64", column = @Column(name = "VDB001_OPT64_C")),
            @AttributeOverride( name = "optCode65", column = @Column(name = "VDB001_OPT65_C")),
            @AttributeOverride( name = "optCode66", column = @Column(name = "VDB001_OPT66_C")),
            @AttributeOverride( name = "optCode67", column = @Column(name = "VDB001_OPT67_C")),
            @AttributeOverride( name = "optCode68", column = @Column(name = "VDB001_OPT68_C")),
            @AttributeOverride( name = "optCode69", column = @Column(name = "VDB001_OPT69_C")),
            @AttributeOverride( name = "optCode70", column = @Column(name = "VDB001_OPT70_C")),
            @AttributeOverride( name = "optCode71", column = @Column(name = "VDB001_OPT71_C")),
            @AttributeOverride( name = "optCode72", column = @Column(name = "VDB001_OPT72_C")),
            @AttributeOverride( name = "optCode73", column = @Column(name = "VDB001_OPT73_C")),
            @AttributeOverride( name = "optCode74", column = @Column(name = "VDB001_OPT74_C")),
            @AttributeOverride( name = "optCode75", column = @Column(name = "VDB001_OPT75_C")),
            @AttributeOverride( name = "optCode76", column = @Column(name = "VDB001_OPT76_C")),
            @AttributeOverride( name = "optCode77", column = @Column(name = "VDB001_OPT77_C")),
            @AttributeOverride( name = "optCode78", column = @Column(name = "VDB001_OPT78_C")),
            @AttributeOverride( name = "optCode79", column = @Column(name = "VDB001_OPT79_C")),
            @AttributeOverride( name = "optCode80", column = @Column(name = "VDB001_OPT80_C")),
            @AttributeOverride( name = "optCode81", column = @Column(name = "VDB001_OPT81_C")),
            @AttributeOverride( name = "optCode82", column = @Column(name = "VDB001_OPT82_C")),
            @AttributeOverride( name = "optCode83", column = @Column(name = "VDB001_OPT83_C")),
            @AttributeOverride( name = "optCode84", column = @Column(name = "VDB001_OPT84_C")),
            @AttributeOverride( name = "optCode85", column = @Column(name = "VDB001_OPT85_C")),
            @AttributeOverride( name = "optCode86", column = @Column(name = "VDB001_OPT86_C")),
            @AttributeOverride( name = "optDescription1", column = @Column(name = "VDB001_OPT1_DESC_X")),
            @AttributeOverride( name = "optDescription2", column = @Column(name = "VDB001_OPT2_DESC_X")),
            @AttributeOverride( name = "optDescription3", column = @Column(name = "VDB001_OPT3_DESC_X")),
            @AttributeOverride( name = "optDescription4", column = @Column(name = "VDB001_OPT4_DESC_X")),
            @AttributeOverride( name = "optDescription5", column = @Column(name = "VDB001_OPT5_DESC_X")),
            @AttributeOverride( name = "optDescription6", column = @Column(name = "VDB001_OPT6_DESC_X")),
            @AttributeOverride( name = "optDescription7", column = @Column(name = "VDB001_OPT7_DESC_X")),
            @AttributeOverride( name = "optDescription8", column = @Column(name = "VDB001_OPT8_DESC_X")),
            @AttributeOverride( name = "optDescription9", column = @Column(name = "VDB001_OPT9_DESC_X")),
            @AttributeOverride( name = "optDescription10", column = @Column(name = "VDB001_OPT10_DESC_X")),
            @AttributeOverride( name = "optDescription11", column = @Column(name = "VDB001_OPT11_DESC_X")),
            @AttributeOverride( name = "optDescription12", column = @Column(name = "VDB001_OPT12_DESC_X")),
            @AttributeOverride( name = "optDescription13", column = @Column(name = "VDB001_OPT13_DESC_X")),
            @AttributeOverride( name = "optDescription14", column = @Column(name = "VDB001_OPT14_DESC_X")),
            @AttributeOverride( name = "optDescription15", column = @Column(name = "VDB001_OPT15_DESC_X")),
            @AttributeOverride( name = "optDescription16", column = @Column(name = "VDB001_OPT16_DESC_X")),
            @AttributeOverride( name = "optDescription17", column = @Column(name = "VDB001_OPT17_DESC_X")),
            @AttributeOverride( name = "optDescription18", column = @Column(name = "VDB001_OPT18_DESC_X")),
            @AttributeOverride( name = "optDescription19", column = @Column(name = "VDB001_OPT19_DESC_X")),
            @AttributeOverride( name = "optDescription20", column = @Column(name = "VDB001_OPT20_DESC_X")),

            @AttributeOverride( name = "optDescription21", column = @Column(name = "VDB001_OPT21_DESC_X")),
            @AttributeOverride( name = "optDescription22", column = @Column(name = "VDB001_OPT22_DESC_X")),
            @AttributeOverride( name = "optDescription23", column = @Column(name = "VDB001_OPT23_DESC_X")),
            @AttributeOverride( name = "optDescription24", column = @Column(name = "VDB001_OPT24_DESC_X")),
            @AttributeOverride( name = "optDescription25", column = @Column(name = "VDB001_OPT25_DESC_X")),
            @AttributeOverride( name = "optDescription26", column = @Column(name = "VDB001_OPT26_DESC_X")),
            @AttributeOverride( name = "optDescription27", column = @Column(name = "VDB001_OPT27_DESC_X")),
            @AttributeOverride( name = "optDescription28", column = @Column(name = "VDB001_OPT28_DESC_X")),
            @AttributeOverride( name = "optDescription29", column = @Column(name = "VDB001_OPT29_DESC_X")),
            @AttributeOverride( name = "optDescription30", column = @Column(name = "VDB001_OPT30_DESC_X")),

            @AttributeOverride( name = "optDescription31", column = @Column(name = "VDB001_OPT31_DESC_X")),
            @AttributeOverride( name = "optDescription32", column = @Column(name = "VDB001_OPT32_DESC_X")),
            @AttributeOverride( name = "optDescription33", column = @Column(name = "VDB001_OPT33_DESC_X")),
            @AttributeOverride( name = "optDescription34", column = @Column(name = "VDB001_OPT34_DESC_X")),
            @AttributeOverride( name = "optDescription35", column = @Column(name = "VDB001_OPT35_DESC_X")),
            @AttributeOverride( name = "optDescription36", column = @Column(name = "VDB001_OPT36_DESC_X")),
            @AttributeOverride( name = "optDescription37", column = @Column(name = "VDB001_OPT37_DESC_X")),
            @AttributeOverride( name = "optDescription38", column = @Column(name = "VDB001_OPT38_DESC_X")),
            @AttributeOverride( name = "optDescription39", column = @Column(name = "VDB001_OPT39_DESC_X")),
            @AttributeOverride( name = "optDescription40", column = @Column(name = "VDB001_OPT40_DESC_X")),

            @AttributeOverride( name = "optDescription41", column = @Column(name = "VDB001_OPT41_DESC_X")),
            @AttributeOverride( name = "optDescription42", column = @Column(name = "VDB001_OPT42_DESC_X")),
            @AttributeOverride( name = "optDescription43", column = @Column(name = "VDB001_OPT43_DESC_X")),
            @AttributeOverride( name = "optDescription44", column = @Column(name = "VDB001_OPT44_DESC_X")),
            @AttributeOverride( name = "optDescription45", column = @Column(name = "VDB001_OPT45_DESC_X")),
            @AttributeOverride( name = "optDescription46", column = @Column(name = "VDB001_OPT46_DESC_X")),
            @AttributeOverride( name = "optDescription47", column = @Column(name = "VDB001_OPT47_DESC_X")),
            @AttributeOverride( name = "optDescription48", column = @Column(name = "VDB001_OPT48_DESC_X")),
            @AttributeOverride( name = "optDescription49", column = @Column(name = "VDB001_OPT49_DESC_X")),
            @AttributeOverride( name = "optDescription50", column = @Column(name = "VDB001_OPT50_DESC_X")),

            @AttributeOverride( name = "optDescription51", column = @Column(name = "VDB001_OPT51_DESC_X")),
            @AttributeOverride( name = "optDescription52", column = @Column(name = "VDB001_OPT52_DESC_X")),
            @AttributeOverride( name = "optDescription53", column = @Column(name = "VDB001_OPT53_DESC_X")),
            @AttributeOverride( name = "optDescription54", column = @Column(name = "VDB001_OPT54_DESC_X")),
            @AttributeOverride( name = "optDescription55", column = @Column(name = "VDB001_OPT55_DESC_X")),
            @AttributeOverride( name = "optDescription56", column = @Column(name = "VDB001_OPT56_DESC_X")),
            @AttributeOverride( name = "optDescription57", column = @Column(name = "VDB001_OPT57_DESC_X")),
            @AttributeOverride( name = "optDescription58", column = @Column(name = "VDB001_OPT58_DESC_X")),
            @AttributeOverride( name = "optDescription59", column = @Column(name = "VDB001_OPT59_DESC_X")),
            @AttributeOverride( name = "optDescription60", column = @Column(name = "VDB001_OPT60_DESC_X")),

            @AttributeOverride( name = "optDescription61", column = @Column(name = "VDB001_OPT61_DESC_X")),
            @AttributeOverride( name = "optDescription62", column = @Column(name = "VDB001_OPT62_DESC_X")),
            @AttributeOverride( name = "optDescription63", column = @Column(name = "VDB001_OPT63_DESC_X")),
            @AttributeOverride( name = "optDescription64", column = @Column(name = "VDB001_OPT64_DESC_X")),
            @AttributeOverride( name = "optDescription65", column = @Column(name = "VDB001_OPT65_DESC_X")),
            @AttributeOverride( name = "optDescription66", column = @Column(name = "VDB001_OPT66_DESC_X")),
            @AttributeOverride( name = "optDescription67", column = @Column(name = "VDB001_OPT67_DESC_X")),
            @AttributeOverride( name = "optDescription68", column = @Column(name = "VDB001_OPT68_DESC_X")),
            @AttributeOverride( name = "optDescription69", column = @Column(name = "VDB001_OPT69_DESC_X")),
            @AttributeOverride( name = "optDescription70", column = @Column(name = "VDB001_OPT70_DESC_X")),

            @AttributeOverride( name = "optDescription71", column = @Column(name = "VDB001_OPT71_DESC_X")),
            @AttributeOverride( name = "optDescription72", column = @Column(name = "VDB001_OPT72_DESC_X")),
            @AttributeOverride( name = "optDescription73", column = @Column(name = "VDB001_OPT73_DESC_X")),
            @AttributeOverride( name = "optDescription74", column = @Column(name = "VDB001_OPT74_DESC_X")),
            @AttributeOverride( name = "optDescription75", column = @Column(name = "VDB001_OPT75_DESC_X")),
            @AttributeOverride( name = "optDescription76", column = @Column(name = "VDB001_OPT76_DESC_X")),
            @AttributeOverride( name = "optDescription77", column = @Column(name = "VDB001_OPT77_DESC_X")),
            @AttributeOverride( name = "optDescription78", column = @Column(name = "VDB001_OPT78_DESC_X")),
            @AttributeOverride( name = "optDescription79", column = @Column(name = "VDB001_OPT79_DESC_X")),
            @AttributeOverride( name = "optDescription80", column = @Column(name = "VDB001_OPT80_DESC_X")),

            @AttributeOverride( name = "optDescription81", column = @Column(name = "VDB001_OPT81_DESC_X")),
            @AttributeOverride( name = "optDescription82", column = @Column(name = "VDB001_OPT82_DESC_X")),
            @AttributeOverride( name = "optDescription83", column = @Column(name = "VDB001_OPT83_DESC_X")),
            @AttributeOverride( name = "optDescription84", column = @Column(name = "VDB001_OPT84_DESC_X")),
            @AttributeOverride( name = "optDescription85", column = @Column(name = "VDB001_OPT85_DESC_X")),
            @AttributeOverride( name = "optDescription86", column = @Column(name = "VDB001_OPT86_DESC_X")),
            @AttributeOverride( name = "retailPrice1", column = @Column(name = "VDB001_OPT1_RTL_PRC_A")),
            @AttributeOverride( name = "retailPrice2", column = @Column(name = "VDB001_OPT2_RTL_PRC_A")),
            @AttributeOverride( name = "retailPrice3", column = @Column(name = "VDB001_OPT3_RTL_PRC_A")),
            @AttributeOverride( name = "retailPrice4", column = @Column(name = "VDB001_OPT4_RTL_PRC_A")),
            @AttributeOverride( name = "retailPrice5", column = @Column(name = "VDB001_OPT5_RTL_PRC_A")),
            @AttributeOverride( name = "retailPrice6", column = @Column(name = "VDB001_OPT6_RTL_PRC_A")),
            @AttributeOverride( name = "retailPrice7", column = @Column(name = "VDB001_OPT7_RTL_PRC_A")),
            @AttributeOverride( name = "retailPrice8", column = @Column(name = "VDB001_OPT8_RTL_PRC_A")),
            @AttributeOverride( name = "retailPrice9", column = @Column(name = "VDB001_OPT9_RTL_PRC_A")),
            @AttributeOverride( name = "retailPrice10", column = @Column(name = "VDB001_OPT10_RTL_PRC_A")),

            @AttributeOverride( name = "retailPrice11", column = @Column(name = "VDB001_OPT11_RTL_PRC_A")),
            @AttributeOverride( name = "retailPrice12", column = @Column(name = "VDB001_OPT12_RTL_PRC_A")),
            @AttributeOverride( name = "retailPrice13", column = @Column(name = "VDB001_OPT13_RTL_PRC_A")),
            @AttributeOverride( name = "retailPrice14", column = @Column(name = "VDB001_OPT14_RTL_PRC_A")),
            @AttributeOverride( name = "retailPrice15", column = @Column(name = "VDB001_OPT15_RTL_PRC_A")),
            @AttributeOverride( name = "retailPrice16", column = @Column(name = "VDB001_OPT16_RTL_PRC_A")),
            @AttributeOverride( name = "retailPrice17", column = @Column(name = "VDB001_OPT17_RTL_PRC_A")),
            @AttributeOverride( name = "retailPrice18", column = @Column(name = "VDB001_OPT18_RTL_PRC_A")),
            @AttributeOverride( name = "retailPrice19", column = @Column(name = "VDB001_OPT19_RTL_PRC_A")),
            @AttributeOverride( name = "retailPrice20", column = @Column(name = "VDB001_OPT20_RTL_PRC_A")),

            @AttributeOverride( name = "retailPrice21", column = @Column(name = "VDB001_OPT21_RTL_PRC_A")),
            @AttributeOverride( name = "retailPrice22", column = @Column(name = "VDB001_OPT22_RTL_PRC_A")),
            @AttributeOverride( name = "retailPrice23", column = @Column(name = "VDB001_OPT23_RTL_PRC_A")),
            @AttributeOverride( name = "retailPrice24", column = @Column(name = "VDB001_OPT24_RTL_PRC_A")),
            @AttributeOverride( name = "retailPrice25", column = @Column(name = "VDB001_OPT25_RTL_PRC_A")),
            @AttributeOverride( name = "retailPrice26", column = @Column(name = "VDB001_OPT26_RTL_PRC_A")),
            @AttributeOverride( name = "retailPrice27", column = @Column(name = "VDB001_OPT27_RTL_PRC_A")),
            @AttributeOverride( name = "retailPrice28", column = @Column(name = "VDB001_OPT28_RTL_PRC_A")),
            @AttributeOverride( name = "retailPrice29", column = @Column(name = "VDB001_OPT29_RTL_PRC_A")),
            @AttributeOverride( name = "retailPrice30", column = @Column(name = "VDB001_OPT30_RTL_PRC_A")),

            @AttributeOverride( name = "retailPrice31", column = @Column(name = "VDB001_OPT31_RTL_PRC_A")),
            @AttributeOverride( name = "retailPrice32", column = @Column(name = "VDB001_OPT32_RTL_PRC_A")),
            @AttributeOverride( name = "retailPrice33", column = @Column(name = "VDB001_OPT33_RTL_PRC_A")),
            @AttributeOverride( name = "retailPrice34", column = @Column(name = "VDB001_OPT34_RTL_PRC_A")),
            @AttributeOverride( name = "retailPrice35", column = @Column(name = "VDB001_OPT35_RTL_PRC_A")),
            @AttributeOverride( name = "retailPrice36", column = @Column(name = "VDB001_OPT36_RTL_PRC_A")),
            @AttributeOverride( name = "retailPrice37", column = @Column(name = "VDB001_OPT37_RTL_PRC_A")),
            @AttributeOverride( name = "retailPrice38", column = @Column(name = "VDB001_OPT38_RTL_PRC_A")),
            @AttributeOverride( name = "retailPrice39", column = @Column(name = "VDB001_OPT39_RTL_PRC_A")),
            @AttributeOverride( name = "retailPrice40", column = @Column(name = "VDB001_OPT40_RTL_PRC_A")),

            @AttributeOverride( name = "retailPrice41", column = @Column(name = "VDB001_OPT41_RTL_PRC_A")),
            @AttributeOverride( name = "retailPrice42", column = @Column(name = "VDB001_OPT42_RTL_PRC_A")),
            @AttributeOverride( name = "retailPrice43", column = @Column(name = "VDB001_OPT43_RTL_PRC_A")),
            @AttributeOverride( name = "retailPrice44", column = @Column(name = "VDB001_OPT44_RTL_PRC_A")),
            @AttributeOverride( name = "retailPrice45", column = @Column(name = "VDB001_OPT45_RTL_PRC_A")),
            @AttributeOverride( name = "retailPrice46", column = @Column(name = "VDB001_OPT46_RTL_PRC_A")),
            @AttributeOverride( name = "retailPrice47", column = @Column(name = "VDB001_OPT47_RTL_PRC_A")),
            @AttributeOverride( name = "retailPrice48", column = @Column(name = "VDB001_OPT48_RTL_PRC_A")),
            @AttributeOverride( name = "retailPrice49", column = @Column(name = "VDB001_OPT49_RTL_PRC_A")),
            @AttributeOverride( name = "retailPrice50", column = @Column(name = "VDB001_OPT50_RTL_PRC_A")),

            @AttributeOverride( name = "retailPrice51", column = @Column(name = "VDB001_OPT51_RTL_PRC_A")),
            @AttributeOverride( name = "retailPrice52", column = @Column(name = "VDB001_OPT52_RTL_PRC_A")),
            @AttributeOverride( name = "retailPrice53", column = @Column(name = "VDB001_OPT53_RTL_PRC_A")),
            @AttributeOverride( name = "retailPrice54", column = @Column(name = "VDB001_OPT54_RTL_PRC_A")),
            @AttributeOverride( name = "retailPrice55", column = @Column(name = "VDB001_OPT55_RTL_PRC_A")),
            @AttributeOverride( name = "retailPrice56", column = @Column(name = "VDB001_OPT56_RTL_PRC_A")),
            @AttributeOverride( name = "retailPrice57", column = @Column(name = "VDB001_OPT57_RTL_PRC_A")),
            @AttributeOverride( name = "retailPrice58", column = @Column(name = "VDB001_OPT58_RTL_PRC_A")),
            @AttributeOverride( name = "retailPrice59", column = @Column(name = "VDB001_OPT59_RTL_PRC_A")),
            @AttributeOverride( name = "retailPrice60", column = @Column(name = "VDB001_OPT60_RTL_PRC_A")),

            @AttributeOverride( name = "retailPrice61", column = @Column(name = "VDB001_OPT61_RTL_PRC_A")),
            @AttributeOverride( name = "retailPrice62", column = @Column(name = "VDB001_OPT62_RTL_PRC_A")),
            @AttributeOverride( name = "retailPrice63", column = @Column(name = "VDB001_OPT63_RTL_PRC_A")),
            @AttributeOverride( name = "retailPrice64", column = @Column(name = "VDB001_OPT64_RTL_PRC_A")),
            @AttributeOverride( name = "retailPrice65", column = @Column(name = "VDB001_OPT65_RTL_PRC_A")),
            @AttributeOverride( name = "retailPrice66", column = @Column(name = "VDB001_OPT66_RTL_PRC_A")),
            @AttributeOverride( name = "retailPrice67", column = @Column(name = "VDB001_OPT67_RTL_PRC_A")),
            @AttributeOverride( name = "retailPrice68", column = @Column(name = "VDB001_OPT68_RTL_PRC_A")),
            @AttributeOverride( name = "retailPrice69", column = @Column(name = "VDB001_OPT69_RTL_PRC_A")),
            @AttributeOverride( name = "retailPrice70", column = @Column(name = "VDB001_OPT70_RTL_PRC_A")),

            @AttributeOverride( name = "retailPrice71", column = @Column(name = "VDB001_OPT71_RTL_PRC_A")),
            @AttributeOverride( name = "retailPrice72", column = @Column(name = "VDB001_OPT72_RTL_PRC_A")),
            @AttributeOverride( name = "retailPrice73", column = @Column(name = "VDB001_OPT73_RTL_PRC_A")),
            @AttributeOverride( name = "retailPrice74", column = @Column(name = "VDB001_OPT74_RTL_PRC_A")),
            @AttributeOverride( name = "retailPrice75", column = @Column(name = "VDB001_OPT75_RTL_PRC_A")),
            @AttributeOverride( name = "retailPrice76", column = @Column(name = "VDB001_OPT76_RTL_PRC_A")),
            @AttributeOverride( name = "retailPrice77", column = @Column(name = "VDB001_OPT77_RTL_PRC_A")),
            @AttributeOverride( name = "retailPrice78", column = @Column(name = "VDB001_OPT78_RTL_PRC_A")),
            @AttributeOverride( name = "retailPrice79", column = @Column(name = "VDB001_OPT79_RTL_PRC_A")),
            @AttributeOverride( name = "retailPrice80", column = @Column(name = "VDB001_OPT80_RTL_PRC_A")),

            @AttributeOverride( name = "retailPrice81", column = @Column(name = "VDB001_OPT81_RTL_PRC_A")),
            @AttributeOverride( name = "retailPrice82", column = @Column(name = "VDB001_OPT82_RTL_PRC_A")),
            @AttributeOverride( name = "retailPrice83", column = @Column(name = "VDB001_OPT83_RTL_PRC_A")),
            @AttributeOverride( name = "retailPrice84", column = @Column(name = "VDB001_OPT84_RTL_PRC_A")),
            @AttributeOverride( name = "retailPrice85", column = @Column(name = "VDB001_OPT85_RTL_PRC_A")),
            @AttributeOverride( name = "retailPrice86", column = @Column(name = "VDB001_OPT86_RTL_PRC_A")),

            @AttributeOverride( name = "currencyCode", column = @Column(name = "VDB001_CRCY_C"))

    })
    @GraphQLField
    private Msrp msrp;
}
