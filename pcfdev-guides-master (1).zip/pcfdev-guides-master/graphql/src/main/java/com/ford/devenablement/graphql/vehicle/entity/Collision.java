package com.ford.devenablement.graphql.vehicle.entity;

import graphql.annotations.annotationTypes.GraphQLField;
import graphql.annotations.annotationTypes.GraphQLName;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.Column;
import javax.persistence.Embeddable;

@Data
@Embeddable
@GraphQLName("collision")
public class Collision {

    @Column(name = "VDB001_RGN_C")
    @GraphQLField
    private String regionCode ;
    @Column(name = "VDB001_FAM_C")
    @GraphQLField
    private String wersFamilyCode;
    @Column(name = "VDB001_FTR_C")
    @GraphQLField
    private String wersFeatureCode;
    @Column(name = "VDB001_FAM_DESC_X")
    @GraphQLField
    private String wersFamDesc;
    @Column(name = "VDB001_FTR_DESC_X")
    @GraphQLField
    private String wersFtrDesc;
    @Column(name = "VDB001_PLANT_N")
    @GraphQLField
    private String plantName;
    @Column(name = "VDB001_BOX_SIZE_X")
    @GraphQLField
    private String boxSize;
    @Column(name = "VDB001_EXT_CLR_C")
    @GraphQLField
    private String colorCode;
    @Column(name = "VDB001_EXT_CLR_DESC_X")
    @GraphQLField
    private String colorName;
    @Column(name = "VDB001_EXT_CLR_PRC_A")
    @GraphQLField
    private String colorRetailCost;
}
