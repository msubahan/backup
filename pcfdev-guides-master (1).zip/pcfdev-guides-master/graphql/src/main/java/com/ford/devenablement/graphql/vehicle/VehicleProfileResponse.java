package com.ford.devenablement.graphql.vehicle;

import lombok.Data;

@Data
public class VehicleProfileResponse {

    private Result result;
    private String error;

}