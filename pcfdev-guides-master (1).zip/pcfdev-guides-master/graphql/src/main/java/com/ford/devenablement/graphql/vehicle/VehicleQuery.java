package com.ford.devenablement.graphql.vehicle;

import com.ford.devenablement.graphql.vehicle.entity.Vehicle;
import graphql.annotations.annotationTypes.GraphQLField;
import graphql.annotations.annotationTypes.GraphQLName;
import graphql.kickstart.graphql.annotations.GraphQLQueryResolver;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import javax.validation.constraints.NotNull;
import org.springframework.security.access.AccessDeniedException;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;
import java.util.logging.Logger;

@Slf4j
@GraphQLQueryResolver
@Component
public class VehicleQuery {

    private static VehicleService vehicleService;

    private static VehicleProfileService vehicleProfileService;

    @Autowired
    private VehicleQuery(VehicleService vehicleService,VehicleProfileService vehicleProfileService){
        VehicleQuery.vehicleService = vehicleService;
        VehicleQuery.vehicleProfileService = vehicleProfileService;
    }

    @GraphQLField
    public static VehicleResponse retrieveVehicle(@NotNull @GraphQLName("vin") String vin) throws VehicleException {
        VehicleResponse vehicleResponse = new VehicleResponse();
        vehicleResponse.setVehicle(getVehicleDetails(vin));
        vehicleResponse.setVehicleProfile(getVehicleProfileDetail(vin));
        return vehicleResponse;
    }

    private static VehicleProfile getVehicleProfileDetail(String vin) throws VehicleException {
        CompletableFuture<VehicleProfile> vehicleProfile = null;
        try {
            vehicleProfile = vehicleProfileService.getVehicleProfile(vin);
            return vehicleProfile != null? vehicleProfile.get() : null;
        } catch (AccessDeniedException accessDeniedException) {
            log.info(accessDeniedException.getMessage());
        } catch (Exception exception) {
            throw new VehicleException(exception);
        }
        return null;
    }

    private static Vehicle getVehicleDetails(String vin) throws VehicleException {
        CompletableFuture<Vehicle> vehicle = null;
        try {
            vehicle =  vehicleService.getVehicleById(vin);
            return vehicle!=null? vehicle.get():null;
        } catch (AccessDeniedException accessDeniedException){
            log.info(accessDeniedException.getMessage());
        } catch (Exception exception) {
            throw new VehicleException(exception);
        }
       return null;
    }
}
