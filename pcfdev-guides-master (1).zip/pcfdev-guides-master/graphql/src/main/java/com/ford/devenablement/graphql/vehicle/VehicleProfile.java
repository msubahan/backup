package com.ford.devenablement.graphql.vehicle;

import graphql.annotations.annotationTypes.GraphQLField;
import graphql.annotations.annotationTypes.GraphQLName;
import lombok.Data;


@Data
@GraphQLName("vehicleProfile")
public class VehicleProfile {

    @GraphQLField
    private String vin;

    @GraphQLField
    private String showEvBatteryLevel;

    @GraphQLField
    private String showFuelLevel;

    @GraphQLField
    private String alarmFunctionality;

    @GraphQLField
    private String vehicleYear;

    @GraphQLField
    private String vehicleImage;

    @GraphQLField
    private String vinLookupWindowSticker;

    @GraphQLField
    private String doubleLocking;

    @GraphQLField
    private String vinLookupImage;

    @GraphQLField
    private String model;

    @GraphQLField
    private String sdn;

    @GraphQLField
    private String make;

    @GraphQLField
    private String displaySmartCharging;

    @GraphQLField
    private String productType;
}