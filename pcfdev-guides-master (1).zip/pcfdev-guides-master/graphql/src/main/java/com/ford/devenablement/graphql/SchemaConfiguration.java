package com.ford.devenablement.graphql;

import com.ford.devenablement.graphql.vehicle.VehicleQuery;
import graphql.GraphQL;
import graphql.annotations.AnnotationsSchemaCreator;
import graphql.schema.GraphQLSchema;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class SchemaConfiguration {

    @Bean
    public GraphQL getVehicleSchemaConfig(){
        GraphQLSchema schema = AnnotationsSchemaCreator.newAnnotationsSchema().query(VehicleQuery.class).build();
        return GraphQL.newGraphQL(schema).build() ;
    }

}