package com.ford.devenablement.graphql.vehicle;

import lombok.Data;

@Data
public class Result {

    private VehicleProfile vehicleProfile;
}