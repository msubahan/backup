package com.ford.devenablement.graphql.vehicle.entity;

import graphql.annotations.annotationTypes.GraphQLField;
import graphql.annotations.annotationTypes.GraphQLName;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.Column;
import javax.persistence.Embeddable;

@Data
@Embeddable
@GraphQLName("pep")
public class Pep {

    @Column(name = "VDB001_INT_CLR_C")
    @GraphQLField
    private String intCode;
    @Column(name = "VDB001_INT_CLR_DESC_X")
    @GraphQLField
    private String interiorDescription;
    @Column(name = "VDB001_INT_CLR_PRC_A")
    @GraphQLField
    private String intCost;
    @Column(name = "VDB001_EQUIP_C")
    @GraphQLField
    private String equipmentCode;
    @Column(name = "VDB001_EQUIP_PRC_A")
    @GraphQLField
    private String eqCodeCost;
    @Column(name = "VDB001_ENG_C")
    @GraphQLField
    private String engCode;
    @Column(name = "VDB001_ENG_DESC_X")
    @GraphQLField
    private String engineDescription;
    @Column(name = "VDB001_TRANS_C")
    @GraphQLField
    private String transCode;
    @Column(name = "VDB001_TRANS_DESC_X")
    @GraphQLField
    private String transDescription;
}
