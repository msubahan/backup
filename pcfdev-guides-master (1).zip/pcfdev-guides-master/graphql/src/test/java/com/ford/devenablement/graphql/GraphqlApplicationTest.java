package com.ford.devenablement.graphql;

import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;


@SpringBootTest
public class GraphqlApplicationTest {

	@Test
	public void contextLoads() {
	}
}
