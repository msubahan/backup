package com.ford.devenablement.graphql.vehicle;

import com.ford.devenablement.graphql.vehicle.entity.Vehicle;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.Optional;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;

@RunWith(SpringRunner.class)
public class VehicleServiceTest {

    @InjectMocks
    private VehicleService vehicleService;
    @Mock
    private VehicleRepository vehicleRepository;

    private String vin = "1F1JK1F54AEA00071";

    @Test
    public void shouldReturnVehicle() throws ExecutionException, InterruptedException {
        when(vehicleRepository.findById(anyString())).thenReturn(Optional.of(getVehicle()));
        CompletableFuture<Vehicle> vehicle = vehicleService.getVehicleById(vin);
        assertThat(vehicle).isNotNull();
        assertThat(vehicle.get().getVin()).isEqualTo(vin);
    }
    @Test
    public void shouldReturnNullForInvalidVin() throws ExecutionException, InterruptedException {
        when(vehicleRepository.findById(anyString())).thenReturn(Optional.ofNullable(null));
        CompletableFuture<Vehicle> vehicle = vehicleService.getVehicleById(vin);
        assertThat(vehicle.get().getVin()).isNull();
    }
    @Test
    public void shouldReturnNullForEmptyVin() throws ExecutionException, InterruptedException {
        when(vehicleRepository.findById(anyString())).thenReturn(Optional.ofNullable(null));
        CompletableFuture<Vehicle> vehicle = vehicleService.getVehicleById(vin);
        assertThat(vehicle.get().getVin()).isNull();
    }

    private Vehicle getVehicle(){
        Vehicle vehicle = new Vehicle();
        vehicle.setVin("1F1JK1F54AEA00071");
        return vehicle;
    }
}
