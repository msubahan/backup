package com.ford.devenablement.graphql.vehicle;

import graphql.GraphQL;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import graphql.ExecutionResult;
import java.util.HashMap;
import java.util.Map;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;


@RunWith(MockitoJUnitRunner.class)
public class VehicleControllerTest {

    @Mock
    private GraphQL graphQL;

    @InjectMocks
    VehicleController controller;

    @Test
    public void shouldFetchVehicleDetail() throws Exception {
        Map<String,String> requestMap = new HashMap<String,String>();
        requestMap.put("query","{\"query\":\"{\\n retrieveVehicle(vin:\\\"1F1FK1F53AEA00018\\\"){\\n vin\\n }\\n}\"}");
        ExecutionResult builderMock = mock(ExecutionResult.class);
        assertNotNull(controller.getVehicle(requestMap,null));
    }

}
