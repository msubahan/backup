package com.ford.devenablement.graphql.vehicle;

import okhttp3.*;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.springframework.test.context.junit4.SpringRunner;

import java.io.IOException;
import java.util.concurrent.CompletableFuture;

@RunWith(SpringRunner.class)
public class VehicleProfileServiceTest {

    @Mock
    OkHttpClient okHttpClient;

    @InjectMocks
     VehicleProfileService vehicleProfileService;

    @Test
    public void shouldReturnVehicleProfileForGivenVin() throws Exception {
        Response response = new Response.Builder()
                .request(new Request.Builder().url("https://devenablement-vehicleprofile-dev.apps.pp01i.edc1.cf.ford.com/api/v1/vehicleprofile/1F1JK1F54AEA00071").build())
                .protocol(Protocol.HTTP_2)
                .code(200) // status code
                .message("")
                .body(ResponseBody.create(
                        MediaType.get("application/json; charset=utf-8"),
                        "{\"result\":{\"vehicleProfile\":{\"vin\":\"1F1JK1F54AEA00071\",\"showEvBatteryLevel\":\"True\",\"showFuelLevel\":\"False\",\"alarmFunctionality\":\"False\",\"vehicleYear\":\"2015\",\"vehicleImage\":\"https://stg.api.mps.ford.com/api/vehicleimage/v1/data?key=1F1JK1F54AEA00071-4-full\",\"vinLookupWindowSticker\":\"True\",\"doubleLocking\":\"False\",\"vinLookupImage\":\"True\",\"model\":\"Focus Electric\",\"sdn\":\"VSDN\",\"make\":\"Ford\",\"displaySmartCharging\":\"Available\",\"productType\":\"C\"}},\"error\":null}\n"
                ))
                .build();
        final Call remoteCall = mock(Call.class);
        when(okHttpClient.newCall(any())).thenReturn(remoteCall);
         when(remoteCall.execute()).thenReturn(response);
        CompletableFuture<VehicleProfile> vehicleProfile = this.vehicleProfileService.getVehicleProfile("1F1JK1F54AEA00071");
        assertNotNull(vehicleProfile);
        assertEquals("1F1JK1F54AEA00071",vehicleProfile.get().getVin());
    }

    @Test(expected = VehicleException.class)
    public void shouldThrowExceptionForInvalidVehicleProfileResponse() throws Exception {
        Response response = new Response.Builder()
                .request(new Request.Builder().url("https://devenablement-vehicleprofile-dev.apps.pp01i.edc1.cf.ford.com/api/v1/vehicleprofile/1F1JK1F54AEA00071").build())
                .protocol(Protocol.HTTP_2)
                .code(200) // status code
                .message("")
                .body(ResponseBody.create(
                        MediaType.get("application/json; charset=utf-8"),
                        "{\"result\":{\"vehicrofile\":{\"vin\":\"1F1JK1F54AEA00071\",\"showEvBatteryLevel\":\"True\",\"showFuelLevel\":\"False\",\"alarmFunctionality\":\"False\",\"vehicleYear\":\"2015\",\"vehicleImage\":\"https://stg.api.mps.ford.com/api/vehicleimage/v1/data?key=1F1JK1F54AEA00071-4-full\",\"vinLookupWindowSticker\":\"True\",\"doubleLocking\":\"False\",\"vinLookupImage\":\"True\",\"model\":\"Focus Electric\",\"sdn\":\"VSDN\",\"make\":\"Ford\",\"displaySmartCharging\":\"Available\",\"productType\":\"C\"}},\"error\":null}\n"
                ))
                .build();
        final Call remoteCall = mock(Call.class);
        when(okHttpClient.newCall(any())).thenReturn(remoteCall);
        when(remoteCall.execute()).thenReturn(response);
        CompletableFuture<VehicleProfile> vehicleProfile = this.vehicleProfileService.getVehicleProfile("1F1JK1F54AEA00071");
        assertNotNull(vehicleProfile);
        assertEquals("1F1JK1F54AEA00071",vehicleProfile.get().getVin());
    }
    @Test
    public void shouldReturnNullVehicleProfileForInvalidVin() throws Exception {
        Response response = new Response.Builder()
                .request(new Request.Builder().url("https://devenablement-vehicleprofile-dev.apps.pp01i.edc1.cf.ford.com/api/v1/vehicleprofile/VIN001").build())
                .protocol(Protocol.HTTP_2)
                .code(200) // status code
                .message("")
                .body(ResponseBody.create(
                        MediaType.get("application/json; charset=utf-8"),
                        "{\"result\":null,\"error\":null}"     ))
                .build();
        final Call remoteCall = mock(Call.class);
        when(okHttpClient.newCall(any())).thenReturn(remoteCall);
        when(remoteCall.execute()).thenReturn(response);
        CompletableFuture<VehicleProfile> vehicleProfile = this.vehicleProfileService.getVehicleProfile("VIN001");
        assertNull(vehicleProfile.get());
    }

    @Test(expected = VehicleException.class)
    public void shouldThrowExceptionWhileVehicleProfileServiceIsDown() throws Exception {
        Response response = new Response.Builder()
                .request(new Request.Builder().url("https://devenablement-vehicleprofile-dev.apps.pp01i.edc1.cf.ford.com/api/v1/vehicleprofile/VIN001").build())
                .protocol(Protocol.HTTP_2)
                .code(200) // status code
                .message("")
                .body(ResponseBody.create(
                        MediaType.get("application/json; charset=utf-8"),
                        "{\"result\":null,\"error\":null}"     ))
                .build();
        final Call remoteCall = mock(Call.class);
        when(okHttpClient.newCall(any())).thenReturn(remoteCall);
        when(remoteCall.execute()).thenThrow(IOException.class);
        this.vehicleProfileService.getVehicleProfile("VIN001");
    }

    @Test
    public void shouldReturnNullResponseOnUnsuccessfulStatusCodeFromVehicleProfileService() throws Exception {
        Response response = new Response.Builder()
                .request(new Request.Builder().url("https://devenablement-vehicleprofile-dev.apps.pp01i.edc1.cf.ford.com/api/v1/vehicleprofile/VIN001").build())
                .protocol(Protocol.HTTP_2)
                .code(400) // status code
                .message("")
                .body(ResponseBody.create(
                        MediaType.get("application/json; charset=utf-8"),
                        "{\"result\":null,\"error\":null}"     ))
                .build();
        final Call remoteCall = mock(Call.class);
        when(okHttpClient.newCall(any())).thenReturn(remoteCall);
        when(remoteCall.execute()).thenReturn(response);
        CompletableFuture<VehicleProfile> vehicleProfile = this.vehicleProfileService.getVehicleProfile("VIN001");
        assertNull(vehicleProfile.get());
    }

    @Test
    public void shouldReturnNullResponseOnEmptyResponseBodyFromVehicleProfileService() throws Exception {
        Response response = new Response.Builder()
                .request(new Request.Builder().url("https://devenablement-vehicleprofile-dev.apps.pp01i.edc1.cf.ford.com/api/v1/vehicleprofile/VIN001").build())
                .protocol(Protocol.HTTP_2)
                .code(200) // status code
                .message("")
                .body(null)
                .build();
        final Call remoteCall = mock(Call.class);
        when(okHttpClient.newCall(any())).thenReturn(remoteCall);
        when(remoteCall.execute()).thenReturn(response);
        CompletableFuture<VehicleProfile> vehicleProfile = this.vehicleProfileService.getVehicleProfile("VIN001");
        assertNull(vehicleProfile.get());
    }

    @Test
    public void shouldReturnNullResponseForEmptyVin() throws Exception {
        CompletableFuture<VehicleProfile> vehicleProfile = this.vehicleProfileService.getVehicleProfile("");
        assertNull(vehicleProfile);
    }
    @Test
    public void shouldReturnNullResponseForNullVin() throws Exception {
        CompletableFuture<VehicleProfile> vehicleProfile = this.vehicleProfileService.getVehicleProfile(null);
        assertNull(vehicleProfile);
    }
}
