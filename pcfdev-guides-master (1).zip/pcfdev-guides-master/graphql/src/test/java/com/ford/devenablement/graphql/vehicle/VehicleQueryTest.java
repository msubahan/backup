package com.ford.devenablement.graphql.vehicle;

import com.ford.aps.spring.service.AuthorizeService;
import com.ford.devenablement.graphql.vehicle.entity.Vehicle;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.Optional;
import java.util.concurrent.CompletableFuture;

import static junit.framework.TestCase.assertNull;
import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.*;

@RunWith(SpringRunner.class)
public class VehicleQueryTest {

    @InjectMocks
    private VehicleQuery vehicleQuery;
    @Mock
    private VehicleService vehicleService;

    @Mock
    private AuthorizeService authorizeService;

    @Mock
    private VehicleProfileService vehicleProfileService;

    @Mock
    private VehicleResponse vehicleResponse;

    private String vin = "1F1JK1F54AEA00071";

    @Test
    public void shouldReturnVehicleResponse() throws Exception {
        Vehicle vehicle = getVehicle();
        when(vehicleService.getVehicleById(anyString())).thenReturn(CompletableFuture.completedFuture(vehicle));
        when(vehicleProfileService.getVehicleProfile(anyString())).thenReturn(CompletableFuture.completedFuture(getVehicleProfile()));
        VehicleResponse vehicleResponse = vehicleQuery.retrieveVehicle(vin);
        assertThat(vehicleResponse.getVehicle().getVin()).isEqualTo(vin);
        assertThat(vehicleResponse.getVehicleProfile().getVin()).isEqualTo(vin);

    }

    @Test
    public void shouldReturnNullForInvalidRequest() throws Exception {
        Vehicle vehicle = new Vehicle();
        when(vehicleService.getVehicleById(anyString())).thenReturn(CompletableFuture.completedFuture(vehicle));
        when(vehicleProfileService.getVehicleProfile(anyString())).thenReturn(CompletableFuture.completedFuture(new VehicleProfile()));
        VehicleResponse vehicleResponse = vehicleQuery.retrieveVehicle(vin);
        assertNull(vehicleResponse.getVehicle().getVin());
    }



    private Vehicle getVehicle(){
        Vehicle vehicle = new Vehicle();
        vehicle.setVin("1F1JK1F54AEA00071");
        return vehicle;
    }

    private VehicleProfile getVehicleProfile(){
        VehicleProfile vehicleProfile = new VehicleProfile();
        vehicleProfile.setVin("1F1JK1F54AEA00071");
        return vehicleProfile;
    }
}
