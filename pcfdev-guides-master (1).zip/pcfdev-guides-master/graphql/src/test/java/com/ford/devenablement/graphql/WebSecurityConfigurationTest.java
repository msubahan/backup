package com.ford.devenablement.graphql;

import com.ford.cloudnative.base.app.web.exception.handler.ExceptionHandlerConfiguration;
import org.assertj.core.api.Assertions;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.context.annotation.Import;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.oauth2.jwt.JwtDecoder;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.boot.test.autoconfigure.web.reactive.AutoConfigureWebTestClient;
import org.springframework.test.web.reactive.server.WebTestClient;
import static org.assertj.core.api.Assertions.assertThat;

import java.util.Arrays;
import java.util.List;

import static org.springframework.boot.test.context.SpringBootTest.WebEnvironment.RANDOM_PORT;

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = RANDOM_PORT)
@Import(ExceptionHandlerConfiguration.class)
@AutoConfigureWebTestClient(timeout = "30000")
public class WebSecurityConfigurationTest {

	@Autowired
	private TestRestTemplate restTemplate;

	@Mock
	JwtDecoder jwtDecoder;

	@Autowired
	private WebTestClient webClient;


	/***********************************************************************************************
	 * ENDPOINTS: Swagger
	 ***********************************************************************************************/

	@Test
	public void should_allowSwaggerEndpoints_withoutAuthentication() {
		webClient.get().uri("/swagger-ui.html").exchange().expectStatus().is2xxSuccessful();
		//webClient.get().uri("/v2/api-docs").exchange().expectStatus().is2xxSuccessful();
	}

	/***********************************************************************************************
	 * ENDPOINTS: Other
	 ***********************************************************************************************/

	@Test
	public void should_notAllowOtherEndpoints_withoutAuthentication() {
		webClient.get().uri("/other-does-not-exist").exchange().expectStatus().is4xxClientError();
	}


	@Test
	public void shouldDecodeJWTWithAudience(){

		List<String> audience = Arrays.asList("urn:grapqhqlpoc:resource:web_website001:dev");
		Assertions.assertThat(WebSecurityConfiguration.wrapJwtDecoderWithAudienceCheck(jwtDecoder,audience)).isNotNull();

	}


	@Test
	public void should_notAllowGetMeApi_withoutAuthentication() {
		assertNoAccess(get("/api/v1/admin/me"));
	}

	@Test
	public void should_notAllowGetSystemInfoApi_withoutAuthentication() {
		assertNoAccess(get("/api/v1/admin/system"));
	}


	private ResponseEntity<?> get(String urlPath) {
		return restTemplate.getForEntity(urlPath, String.class);
	}
	private void assertAccess(ResponseEntity<?> entity) {
		assertThat(entity.getStatusCode()).isNotIn(HttpStatus.UNAUTHORIZED, HttpStatus.FORBIDDEN, HttpStatus.NOT_FOUND);
	}

	private void assertNoAccess(ResponseEntity<?> entity) {
		assertThat(entity.getStatusCode()).isIn(HttpStatus.UNAUTHORIZED, HttpStatus.FORBIDDEN, HttpStatus.NOT_FOUND);
	}

	@Test
	public void shouldDecodeJWTWithInvalidAudience(){

		List<String> audience = Arrays.asList("urn:grapqhqlpoc:resource:web_website001:dev11");
		Assertions.assertThat(WebSecurityConfiguration.wrapJwtDecoderWithAudienceCheck(jwtDecoder,audience)).isNotNull();

	}
}
