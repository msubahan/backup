# Common Vulnerabilities and Exposures (CVE) Patch Recommendations

This is a frequently updated guide that maintains the CVE patch recommendations by Dev Enablement team, based on vulnerabilities reported by FOSSA scan on a standard EcoBoost template Spring Boot application and/or on other Dev Enablement team recommended solutions, frameworks and patterns.

Any new application generated using [/d/c/s ecoBoost template](https://dcs.ford.com/project-workflow/springboot) will contain applicable patches based on the Spring Boot version included. At any point in time, application teams 
shall also refer to the [CAB FordAir application](https://github.ford.com/PCFDev-CAB/cab-service-fordair) for applicable patches based on the current recommended version of Spring Boot in-use, by Dev Enablement team.

The patches recommended below will usually go into the **build.gradle** file of the application, inside the `dependencies { ... }` block. In EcoBoost template applications and CAB reference application, 
these patches shall be found within the `///BEGIN - CVE Patches  ...  ///END - CVE Patches` section of the `dependencies` block.

## Jump to a CVE Patch
<table>
<tr align="center">
<td width="200"><a href="#cve-2021-42550---logback-core-module">CVE-2021-42550</a></td>
<td width="200"><a href="#cve-2021-27568-cve-2021-31684---json-small-and-fast-parser">CVE-2021-27568</a></td>
<td width="200"><a href="#cve-2021-27568-cve-2021-31684---json-small-and-fast-parser">CVE-2021-31684</a></td>
<td width="200"><a href="#">&nbsp;</a></td>
<td width="200"><a href="#">&nbsp;</a></td>
<td width="200"><a href="#">&nbsp;</a></td>
</tr>
</table>
<br/>

## Patch Recommendations
## 🐞[CVE-2021-42550](https://nvd.nist.gov/vuln/detail/CVE-2021-42550) - Logback Core Module

**Applicable Spring Boot versions:** `2.4`

**Vulnerable version:** `1.2.7`

**Recommended patched version:** `1.2.9`

**Patch with:**

```
implementation("ch.qos.logback:logback-core") {
    version {
        strictly "1.2.9"
    }
    because "patch CVE brought in by Logback Core Module."
}
```
<hr/>

## 🐞[CVE-2021-27568](https://nvd.nist.gov/vuln/detail/CVE-2021-27568), 🐞[CVE-2021-31684](https://nvd.nist.gov/vuln/detail/CVE-2021-31684) - JSON Small and Fast Parser

**Applicable Spring Boot versions:** `2.5 and lower`

**Vulnerable version:** `2.3.1`

**Recommended patched version:** `2.4.7`

**Patch with:**

```
implementation("net.minidev:json-smart") {
    version {
        strictly "2.4.7"
    }
    because "patch CVE brought in by Spring, Outh, etc."
}
```
<hr/>

## 🐞[CVE-2015-5211](https://nvd.nist.gov/vuln/detail/CVE-2015-5211) - Spring WebSocket

**Applicable Dependencies:** `com.graphql-java-kickstart:graphql-kickstart-spring-boot-autoconfigure-graphql-annotations:11.0.0`

**Vulnerable version:** `5.3.13`

**Recommended patched version:** `none`

**Patch with:**

```
None available yet...
```
<hr/>
