## FOSSA

FOSSA is a tool that helps Ford manage open-source usage by "automating the mass reporting and compliance for projects using open source". This automation can be achieved via the inclusion of FOSSA into CI/CD pipelines (i.e. Jenkins).

FOSSA provides the following features: 
1. Tracks all of the open-source and third-party code being used in a project
2. Enforces licensing and security policy; detection and raising of compliance issues
3. Provides reports on the use of open source and the compliance with Ford authored policies

> NOTE: FOSSA now is approved for use as part of Ford's overall FOSS (Free & Open Source Software) process. See the Architecture Management's "[Guide to Open Source Software Process](https://azureford.sharepoint.com/sites/amo/publications/OfficialPublications/Shared%20Documents/Guides/Guide%20to%20Open%20Source%20Software%20Process%20(002).pdf)" for all the details on how FOSSA can be used to comply with Ford's policy on use of open source.
> 

### FOSSA Info Page
You can visit the main [info page for FOSSA](https://azureford.sharepoint.com/sites/SDE/SitePages/FOSSA/FOSSA_Overview.aspx) to learn more about the tool, FAQ's, process documents, etc.


### Onboarding 

In order to use FOSSA, a team must be onboarded using the documented process in order to use FOSSA for their projects. See the [FOSSA SharePoint page](https://azureford.sharepoint.com/sites/SDE/SitePages/FOSSA/FOSSA_Overview.aspx) which contains links to many FOSSA resources including onboarding information.


### FOSSA CLI installation

Whether you opt to install the FOSSA CLI on your personal/local workstation and/or a CI server such as Jenkins, you should download the CLI from the Ford Nexus repository. 
>NOTE: We are currently in transitioning from FOSSA CLI v1.x to v2.x. We have not officially cutover to 2.x, so pick the one you are most comfortable with! Picking the latest version in either the 1.x or 2.x line is the best option. 

The links to Nexus where you can find versions of the CLI:
* CLI for Jenkins Custom Tool Setup - [https://www.nexus.ford.com/#browse/search=keyword%3Dcustom-tools%2Fbin%2Ffossa](https://www.nexus.ford.com/#browse/search=keyword%3Dcustom-tools%2Fbin%2Ffossa)
* CLI for localhost (pick appropriate OS version) - [https://www.nexus.ford.com/#browse/search=keyword%3Dfossa-cli](https://www.nexus.ford.com/#browse/search=keyword%3Dfossa-cli)

Once you have the version picked, you can download via the Nexus UI or you can use the CURL command to download the zip file. As an example, you can use the following syntax to download the 2.19.5 version for Mac OS and then immediately unzip it using the following syntax:
```
curl -OL https://www.nexus.ford.com/repository/jenkins_tools/fossa-cli/fossa_2.19.5_darwin_amd64.zip
unzip fossa_2.19.5_darwin_amd64.zip
```

If you opt to use a Jenkins pipeline to automatically have FOSSA analyze your project (this is highly recommended!), you will need to install the FOSSA CLI on your Jenkins server. Instructions for installing the CLI using the version from Ford Nexus are located in our SharePoint site at the following locations:
* **Jenkins Custom Tool Setup for FOSSA CLI** ([EcoBoost Jenkins Pipeline](https://github.ford.com/DevEnablement/ecoboost-pipeline/blob/master/MIGRATE_TO_JENK8S.md#fossa-optional) | [General - SDE Format](https://azureford.sharepoint.com/sites/SDE/SitePages/FOSSA/Custom-Tool-Setup---Fossa.aspx))
* [Localhost FOSSA CLI Installation](https://azureford.sharepoint.com/sites/SDE/SitePages/FOSSA/INSTALL_FOSSA_CLI_LOCALHOST.aspx)


### FOSSA in your Jenkins pipeline

The Dev Enablement team's EcoBoost Jenkins pipeline offering, which is documented in the [Jenkins Pipeline Guide](https://github.ford.com/DevEnablement/ecoboost-pipeline), comes with built-in support for FOSSA. This pipeline is also provided to new projects created using EcoBoost in [/dev/central/station](http://dcs.ford.com).

Whether you use the EcoBoost Jenkins pipeline or not, in order to use a pipeline and fully integrate with FOSSA, you are required to do the onboarding and FOSSA CLI installation steps documented above. You will also be required to use an API Key from FOSSA. It is recommended that you use a generic user account's API key. To get access to an API key (if you have been onboarded), go to [https://ford.fossa.com/account/settings/integrations/api_tokens](https://ford.fossa.com/account/settings/integrations/api_tokens) while logged into FOSSA as the user you wish to retrieve the API key for.

> NOTE: If you are using the Dev Enablement team's EcoBoost Jenkins pipeline offering, then you will need to store the FOSSA API key in the Jenkins credentials plugin and [install the FOSSA CLI as per the instructions given here](https://github.ford.com/DevEnablement/ecoboost-pipeline/blob/master/MIGRATE_TO_JENK8S.md#fossa-optional).

To see a real example of FOSSA integrated using the Dev Enablement pipeline, you can refer to the CAB Ford Air reference application at [https://github.ford.com/PCFDev-CAB/cab-service-fordair](https://github.ford.com/PCFDev-CAB/cab-service-fordair). Take special note of the following files:
- [Jenkinsfile](https://github.ford.com/PCFDev-CAB/cab-service-fordair/blob/master/Jenkinsfile#L52): See the FOSSA CLI commands being used.
- [pipeline.helper.groovy](https://github.ford.com/PCFDev-CAB/cab-service-fordair/blob/master/pipeline/pipeline.helper.groovy#L53): See how we pull the FOSSA API key and store it in an environment variable required by the FOSSA CLI.
- [pipeline.configuration.groovy](https://github.ford.com/PCFDev-CAB/cab-service-fordair/blob/master/pipeline/pipeline.configuration.groovy#L37): See how we enable FOSSA, and provide key configuration settings used by the pipeline. 



### FOSSA analysis command prompt example

We strongly recommend integrating FOSSA analysis into you CI server, but if you are not using Jenkins, or even Java and Spring Boot, the basic steps required for running a FOSSA analysis remain similar. Running FOSSA locally can be a good place to start to get familiar with how the CLI works before attempting to configure Jenkins or other CI server! The following steps can be used from a command line (shell) assuming your team has been onboarded to the FOSSA tool:

1. Download the FOSSA CLI using instructions from section earlier in this document.
1. Generate (or reuse) an API token in FOSSA. You can generate or locate an existing API token at [https://ford.fossa.com/account/settings/integrations/api_tokens](https://ford.fossa.com/account/settings/integrations/api_tokens).  A "push-only api" for your Team in FOSSA is enough for this guide.
1. Set the API token into an environment variable in you shell. 

    - Windows uses ```set FOSSA_API_KEY=someAPItoken ```
    - Unix/Mac uses ```export FOSSA_API_KEY=someAPItoken```

1. Run the fossa command provided by the fossa CLI. You must run from the root folder of your project, and the FOSSA CLI must be in this folder or on the path. If this were a Java/Gradle project, you would need to be in the folder where the build.gradle file exists. We recommend you pass the Team Name, Project Name, and branch name using the -T, -p, --policy, and -b arguments respectively. The command below will cause data to be sent to FOSSA server and analysis will occur asynchronously.  There is a slight change in syntax if you are using the v2.x version of the CLI. See Mac OS examples below (Windows users don't need "./" before command):

   - FOSSA v1.x
   ``` 
   ./fossa -e https://ford.fossa.com -T DevEnablement -p cab-service-fordair --policy 'Website/Hosted Service Use' -b master  
   ```
   - FOSSA v2.x (introduces analyze command)
   ``` 
   ./fossa analyze -e https://ford.fossa.com -T DevEnablement -p cab-service-fordair --policy 'Website/Hosted Service Use' -b master  
   ```

1. (Optional) Use the FOSSA test command to poll for results of previous analysis. See the "Breaking your Build" section below for the details.

   ```
   ./fossa test -e https://ford.fossa.com -p cab-service-fordair --timeout 3600
   ```


> NOTE 1: Your environment must have a [proxy configured](https://devservices.ford.com/dev-guides/guides?search=Ford%20Proxy%20Servers) to make the call from the Ford network.
>    
> NOTE 2: The value provided above for the “--policy” argument is very important. Your project needs to declare which policy is appropriate. The example given assumes the application will be hosted as a backend website. This policy is not appropriate for distributed applications (In-Vehicle, Mobile, etc.).
>  

### Use GradleBoost plugin to run FOSSA scan from command prompt

Application's that are using Gradle, such as those using the EcoBoost template from DCS, can use the Dev Enablement team's GradleBoost plugin 3.x+ which includes a task for getting your project analyzed by FOSSA. See the [GradleBoost plugin document](https://github.ford.com/DevEnablement/gradle-boost-plugin/tree/master#fossa-module) to run FOSSA scan analysis from your command prompt locally. Below is an example of the basic commands needed (using MacOS example):

```
> export FOSSA_API_KEY=xxxxxxx        
> export BOOST_FOSSA_TEAM_NAME=DevEnablement
> ./gradlew fossaScan
```

### Breaking your Build

The fossa command demonstrated above causes the FOSSA CLI to analyze the dependencies of your project locally, and then send the dependency list to the FOSSA 
server where the actual analysis of your dependencies is completed. This analysis happens asynchronously, which is why the command completes so quickly. If you 
want to get the results from analysis or from a pipeline you want to have the detection of any Issues in FOSSA break your build, you can use the fossa test command. 
 
 ```
 ./fossa test -e https://ford.fossa.com -p cab-service-fordair --timeout 3600
 ```

This command will poll the server based on the previous fossa command, and will eventually respond with the results. If successful, and no Issues are found you 
we see "Test Passed! 0 issues found" displayed at console. If any Issues are detected, then an error code will be returned that will cause Jenkins to fail. The timeout argument may need to be tweaked depending on your project.

### CVE Patch Recommendations
[Click here](CVEPatch.md) for CVE patch recommendations by Dev Enablement team, based on vulnerabilities reported by FOSSA scan on a standard EcoBoost template Spring Boot application and/or on other Dev Enablement team recommended solutions, frameworks and patterns.

### Need Help?

Need assistance or more details on the Open Source policy and FOSSA - see the following:
* Ask Questions or Help others in the [FOSSA WebEx Teams Space](https://www.webexteams.ford.com/space?r=ukki)
* [FOSSA SharePoint site](https://azureford.sharepoint.com/sites/SDE/SitePages/FOSSA/FOSSA_Overview.aspx) contains lots of documentation on Ford open source policy as well as or use of FOSSA
