package com.ford.devenablement.encryptedemail;

import com.ford.devenablement.encryptedemail.exceptions.NonFordEmailException;
import com.ford.devenablement.encryptedemail.globalcatalog.GlobalCatalogService;
import com.ford.devenablement.encryptedemail.ldap.LdapConfig;
import com.ford.devenablement.encryptedemail.ldap.LdapService;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doNothing;

@RunWith(SpringRunner.class)
@SpringBootTest
@ContextConfiguration(classes = {MailTestConfiguration.class, EmailService.class, LdapService.class,
        LdapConfig.class, GlobalCatalogService.class, CertificateService.class})
public class UnencryptedEmailApplicationTests {
    private final String validGenericAddr1 = "ssotest@ford.com";
    private final String validGenericAddr2 = "dvnmail@ford.com";
    private final String invalidExternalAddr1 = "blah@blah.com";

    @Mock
    private JavaMailSender mockJavaMailSender;

    @InjectMocks
    @Autowired
    private EmailService emailService;

    @Before
    public void Setup() {
        MockitoAnnotations.initMocks(this);
        doNothing().when(mockJavaMailSender).send(any(SimpleMailMessage.class));
    }


    @Test
    public void sendUnencryptedEmailToSingleRecipient() {
        reset();
        emailService.sendUnencryptedEmail("Unencrypted", "Test Body", validGenericAddr1);
    }

    @Test
    public void sendUnencryptedEmailToMultpleRecipients() {
        reset();
        emailService.sendUnencryptedEmail("Unencrypted", "Test Body",
                new String[]{validGenericAddr1, validGenericAddr2});
    }

    @Test(expected = NonFordEmailException.class)
    public void sendUnencryptedEmailwithNonFordSender() {
        reset();
        emailService.setSender(invalidExternalAddr1);
        emailService.sendUnencryptedEmail("Unencrypted", "Test Body",
                new String[]{validGenericAddr1, validGenericAddr2});
    }

    @Test
    public void sendUnencryptedEmailwithNonFordRecipient() {
        reset();
        emailService.sendUnencryptedEmail("Unencrypted", "Test Body",
                new String[]{validGenericAddr1, validGenericAddr2});
    }

    private void reset() {
        emailService.setSender(validGenericAddr1);
    }
}
