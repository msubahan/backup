package com.ford.devenablement.encryptedemail;

import com.ford.devenablement.encryptedemail.ldap.LdapService;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.security.cert.Certificate;
import java.security.cert.CertificateException;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.List;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.when;

@RunWith(SpringRunner.class)
@SpringBootTest
@ContextConfiguration(classes = {MailTestConfiguration.class, EmailService.class, CertificateService.class,
        EmailServiceConfiguration.class})
public class EmailServiceTests {
    List<Certificate> dualCerts = new ArrayList<>();
    private String certPEM1 = "-----BEGIN CERTIFICATE-----\n" +
            "MIIIZDCCB0ygAwIBAgIKNS8mmwAFACsBTjANBgkqhkiG9w0BAQsFADCBhzELMAkGA1UEBhMCVVMxGzAZBgNVBAoTEkZvcmQgTW90b3IgQ29tcGFueTERMA8GA1UEBxMIRGVhcmJvcm4xETAPBgNVBAgTCE1pY2hpZ2FuMTUwMwYDVQQDEyxGb3JkIE1vdG9yIENvbXBhbnkgLSBFbnRlcnByaXNlIElzc3VpbmcgQ0EwMTAeFw0xODAzMTMyMDAyMjlaFw0xOTAzMTMyMDAyMjlaMIGpMRMwEQYKCZImiZPyLGQBGRYDY29tMRQwEgYKCZImiZPyLGQBGRYEZm9yZDETMBEGCgmSJomT8ixkARkWA25hMTEQMA4GA1UECxMHVVNFUklEUzEMMAoGA1UECxMDR1BPMRIwEAYDVQQLEwlMZXZlbDAxMDAxETAPBgNVBAMTCEpTVEFLTkkxMSAwHgYJKoZIhvcNAQkBFhFqc3Rha25pMUBmb3JkLmNvbTCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBAIxn73XoSuVgGAEaOal1bDOKKMG0F6OVaCwwwmomAaVDwSHln7IGc0lt4z86EjLWYLfFBsBhUK+QyheCDXoco3cC5wXz6Qon/1h9+LDxi+goJOs6gehsZTw5S0wCiJvPD/xXJI/LujpI6pqbUZhbMD/ncuyb6YUNUla3CZ1Hx2H8iJRpraBomYsPx2grHTysi+UC+OA6L7gyiodzErqcspfHMpBoyX0DEHw9L/KPGnTAPw5ya4W047So2OBdIVNjnt1MHERMko18CFphIq6u8K72quybnWhdDHn1gOtLLo68qoGspxHNIz8kucoB5XFK3+yX5vpjH9Q9jewvXA2Lxt0CAwEAAaOCBKwwggSoMAsGA1UdDwQEAwIFoDBEBgkqhkiG9w0BCQ8ENzA1MA4GCCqGSIb3DQMCAgIAgDAOBggqhkiG9w0DBAICAIAwBwYFKw4DAgcwCgYIKoZIhvcNAwcwOwYJKwYBBAGCNxUHBC4wLAYkKwYBBAGCNxUIhpX+FYXV+3qFpYcl6p5Wh8zkBnbBqluDqYRLAgFkAgEIMCkGA1UdJQQiMCAGCCsGAQUFBwMCBggrBgEFBQcDBAYKKwYBBAGCNwoDBDA1BgkrBgEEAYI3FQoEKDAmMAoGCCsGAQUFBwMCMAoGCCsGAQUFBwMEMAwGCisGAQQBgjcKAwQwRgYDVR0gBD8wPTA7BgorBgEEAYHuMQoBMC0wKwYIKwYBBQUHAgEWH2h0dHA6Ly9jcmwuZm9yZC5jb20vUmVwb3NpdG9yeS8wPwYDVR0RBDgwNqAhBgorBgEEAYI3FAIDoBMMEUpTVEFLTkkxQGZvcmQuY29tgRFqc3Rha25pMUBmb3JkLmNvbTAdBgNVHQ4EFgQUUZPGBP2L8zvqi8JJYLKU6+NcC4kwHwYDVR0jBBgwFoAUg8WFOa1p4N+y7NRtNKbr+Qa9Z54wggFVBgNVHR8EggFMMIIBSDCCAUSgggFAoIIBPIZXaHR0cDovL2NybC5mb3JkLmNvbS9jcmwvRm9yZCUyME1vdG9yJTIwQ29tcGFueSUyMC0lMjBFbnRlcnByaXNlJTIwSXNzdWluZyUyMENBMDEoMykuY3JshoHgbGRhcDovLy9DTj1Gb3JkJTIwTW90b3IlMjBDb21wYW55JTIwLSUyMEVudGVycHJpc2UlMjBJc3N1aW5nJTIwQ0EwMSgzKSxDTj1GTUNVVEwyMCxDTj1DRFAsQ049UHVibGljJTIwS2V5JTIwU2VydmljZXMsQ049U2VydmljZXMsQ049Q29uZmlndXJhdGlvbixEQz1mb3JkLERDPWNvbT9jZXJ0aWZpY2F0ZVJldm9jYXRpb25MaXN0P2Jhc2U/b2JqZWN0Q2xhc3M9Y1JMRGlzdHJpYnV0aW9uUG9pbnQwggGQBggrBgEFBQcBAQSCAYIwggF+MH4GCCsGAQUFBzAChnJodHRwOi8vY3JsLmZvcmQuY29tL2NybC9GTUNVVEwyMC5kZWFyYm9ybi5mb3JkLmNvbV9Gb3JkJTIwTW90b3IlMjBDb21wYW55JTIwLSUyMEVudGVycHJpc2UlMjBJc3N1aW5nJTIwQ0EwMSg1KS5jcnQwgdQGCCsGAQUFBzAChoHHbGRhcDovLy9DTj1Gb3JkJTIwTW90b3IlMjBDb21wYW55JTIwLSUyMEVudGVycHJpc2UlMjBJc3N1aW5nJTIwQ0EwMSxDTj1BSUEsQ049UHVibGljJTIwS2V5JTIwU2VydmljZXMsQ049U2VydmljZXMsQ049Q29uZmlndXJhdGlvbixEQz1mb3JkLERDPWNvbT9jQUNlcnRpZmljYXRlP2Jhc2U/b2JqZWN0Q2xhc3M9Y2VydGlmaWNhdGlvbkF1dGhvcml0eTAlBggrBgEFBQcwAYYZaHR0cDovL29jc3AuZm9yZC5jb20vb2NzcDANBgkqhkiG9w0BAQsFAAOCAQEAzVjKMqnJeEM4vtKcLDJ/nKA2hnK1nmLiJM4ecq36zaBTTBgxdvO8csRoUpdRD1vNqK5HWj3wSBxb1gZJPcs33uzDzyq/2fdcOz41WW6ieIi+m9bPLD47TPTqLY1MuegD3vFy0gpwI59h5AwxUmxC+RysWqKTlUNgQBg5dBUCo+UZC1f2MxA/IxcIFXtr07ocyPJCTm3XJLm9IGthu+nV5fW+2vigU2xulNSHX1AvR8GWD9Q87HihYbWGQrSf0u+XzQuk5AJvbhULake1ak6T/hl2mMTv0JimBGDs6JbcXZtDBLu0UWpoREsiJpMiuGwfnP5xs0fzksJDRBD+5MJxNA==-----END CERTIFICATE-----\n" +
            "-----BEGIN CERTIFICATE-----";

    private String certPEM2 = "-----BEGIN CERTIFICATE-----\n" +
            "MIIIZDCCB0ygAwIBAgIKFM1fTwAFAC8MPDANBgkqhkiG9w0BAQsFADCBhzELMAkGA1UEBhMCVVMxGzAZBgNVBAoTEkZvcmQgTW90b3IgQ29tcGFueTERMA8GA1UEBxMIRGVhcmJvcm4xETAPBgNVBAgTCE1pY2hpZ2FuMTUwMwYDVQQDEyxGb3JkIE1vdG9yIENvbXBhbnkgLSBFbnRlcnByaXNlIElzc3VpbmcgQ0EwMTAeFw0xOTAxMzEwMDQzMTJaFw0yMDAxMzEwMDQzMTJaMIGpMRMwEQYKCZImiZPyLGQBGRYDY29tMRQwEgYKCZImiZPyLGQBGRYEZm9yZDETMBEGCgmSJomT8ixkARkWA25hMTEQMA4GA1UECxMHVVNFUklEUzEMMAoGA1UECxMDR1BPMRIwEAYDVQQLEwlMZXZlbDAxMDAxETAPBgNVBAMTCEpTVEFLTkkxMSAwHgYJKoZIhvcNAQkBFhFqc3Rha25pMUBmb3JkLmNvbTCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBAOo0JlgS/EfJnwB9ubOh3icwjxZsst1gCnr6YKgGtASpeLai7RWxE5eLkh8rTFyjn2JZ3eG71yr/HetS8eYUfArj4T2dTKnYrFay4heG4PTNXqCm6baudbaVEw/7f+sKeUR37TsMGbO51n8z8sy+CZeZnR5rW0Pi7vxVEsi3LR6EW6sn1Nv05S3BElIh2MkvurGyJKt1kPcm71+4BgbZcEyPh8nTPU/dgfPZJ20ZSaztoINyn+8hladYaq4uqgIgv4QS5A6p3AT10ms+AsWRCwbGRDqmVqb+FwcZT/wdvK+nseaUZO18x4Gdal/PyDN/3/ta8HkE4MK3sIx/okjp+fECAwEAAaOCBKwwggSoMAsGA1UdDwQEAwIFoDBEBgkqhkiG9w0BCQ8ENzA1MA4GCCqGSIb3DQMCAgIAgDAOBggqhkiG9w0DBAICAIAwBwYFKw4DAgcwCgYIKoZIhvcNAwcwOwYJKwYBBAGCNxUHBC4wLAYkKwYBBAGCNxUIhpX+FYXV+3qFpYcl6p5Wh8zkBnbBqluDqYRLAgFkAgEIMCkGA1UdJQQiMCAGCCsGAQUFBwMCBggrBgEFBQcDBAYKKwYBBAGCNwoDBDA1BgkrBgEEAYI3FQoEKDAmMAoGCCsGAQUFBwMCMAoGCCsGAQUFBwMEMAwGCisGAQQBgjcKAwQwRgYDVR0gBD8wPTA7BgorBgEEAYHuMQoBMC0wKwYIKwYBBQUHAgEWH2h0dHA6Ly9jcmwuZm9yZC5jb20vUmVwb3NpdG9yeS8wPwYDVR0RBDgwNqAhBgorBgEEAYI3FAIDoBMMEUpTVEFLTkkxQGZvcmQuY29tgRFqc3Rha25pMUBmb3JkLmNvbTAdBgNVHQ4EFgQU9YR0/GDqqHV9zclk9QhL5PBpx0cwHwYDVR0jBBgwFoAUg8WFOa1p4N+y7NRtNKbr+Qa9Z54wggFVBgNVHR8EggFMMIIBSDCCAUSgggFAoIIBPIZXaHR0cDovL2NybC5mb3JkLmNvbS9jcmwvRm9yZCUyME1vdG9yJTIwQ29tcGFueSUyMC0lMjBFbnRlcnByaXNlJTIwSXNzdWluZyUyMENBMDEoMykuY3JshoHgbGRhcDovLy9DTj1Gb3JkJTIwTW90b3IlMjBDb21wYW55JTIwLSUyMEVudGVycHJpc2UlMjBJc3N1aW5nJTIwQ0EwMSgzKSxDTj1GTUNVVEwyMCxDTj1DRFAsQ049UHVibGljJTIwS2V5JTIwU2VydmljZXMsQ049U2VydmljZXMsQ049Q29uZmlndXJhdGlvbixEQz1mb3JkLERDPWNvbT9jZXJ0aWZpY2F0ZVJldm9jYXRpb25MaXN0P2Jhc2U/b2JqZWN0Q2xhc3M9Y1JMRGlzdHJpYnV0aW9uUG9pbnQwggGQBggrBgEFBQcBAQSCAYIwggF+MH4GCCsGAQUFBzAChnJodHRwOi8vY3JsLmZvcmQuY29tL2NybC9GTUNVVEwyMC5kZWFyYm9ybi5mb3JkLmNvbV9Gb3JkJTIwTW90b3IlMjBDb21wYW55JTIwLSUyMEVudGVycHJpc2UlMjBJc3N1aW5nJTIwQ0EwMSg1KS5jcnQwgdQGCCsGAQUFBzAChoHHbGRhcDovLy9DTj1Gb3JkJTIwTW90b3IlMjBDb21wYW55JTIwLSUyMEVudGVycHJpc2UlMjBJc3N1aW5nJTIwQ0EwMSxDTj1BSUEsQ049UHVibGljJTIwS2V5JTIwU2VydmljZXMsQ049U2VydmljZXMsQ049Q29uZmlndXJhdGlvbixEQz1mb3JkLERDPWNvbT9jQUNlcnRpZmljYXRlP2Jhc2U/b2JqZWN0Q2xhc3M9Y2VydGlmaWNhdGlvbkF1dGhvcml0eTAlBggrBgEFBQcwAYYZaHR0cDovL29jc3AuZm9yZC5jb20vb2NzcDANBgkqhkiG9w0BAQsFAAOCAQEAShz1W+5S0rILdJjUD45tMkhUllqPdSQyX4vRvmjJdu3DnQf8oVZ5rQaSSexKpEIAgPndpo6WHYOCMl0WHcnD7N9jmFUu8SgMGSAW2YWbj/GZgKod7E9EmbMyTxxrZpokE8YVkGW3NCQMBTtQK7EMV2eqtdxHwn6u4fxz039pgAXEt7WASrGZ2pT388uJz67ABa6XjK1I10OIt40pTECDd9qaMfwAYsZTrY69pPq8zm5KqTaqkfB5jiDXyTlagi1R2c42lmblQuA7gPhVLu2owtjY98SBv29LydGh3x3Kjv3CUaHCIKflhrMsoOhGeBzJukBcW2aj72vUlQwaD+uYrQ==-----END CERTIFICATE-----";

    @Mock
    private JavaMailSender mockJavaMailSender;

    @Mock
    private LdapService mockLdapService;

    @InjectMocks
    @Autowired
    private EmailService emailService;

    @Before
    public void Setup() throws CertificateException {
        MockitoAnnotations.initMocks(this);
        doNothing().when(mockJavaMailSender).send(any(SimpleMailMessage.class));
        dualCerts.add(convertPemToCert(certPEM1));
        dualCerts.add(convertPemToCert(certPEM2));
        when(mockLdapService.searchForUserCertificates("jstakni1"))
                .thenReturn(dualCerts);
    }

    @Test
    public void selectsNewestCertWhenTwoAvailable() {
        List<Certificate> newestCert = emailService.getNewestValidCert((ArrayList<Certificate>) dualCerts);
        assert(newestCert.size() == 1);
        X509Certificate selectedCert = (X509Certificate)newestCert.get(0);
        X509Certificate correctCert = (X509Certificate)convertPemToCert(certPEM2);
        assert(selectedCert.getSerialNumber() == correctCert.getSerialNumber());

        dualCerts.add(dualCerts.get(0)); // Reverse order and try again
        dualCerts.remove(0);
        newestCert = (List<Certificate>) emailService.getNewestValidCert((ArrayList<Certificate>) dualCerts);
        selectedCert = (X509Certificate)newestCert.get(0);
        assert(selectedCert.getSerialNumber() == correctCert.getSerialNumber());
    }

    private Certificate convertPemToCert(String pem) {
        Certificate cert = null;
        try {
            CertificateFactory cf = CertificateFactory.getInstance("X.509");
            InputStream is = new ByteArrayInputStream(pem.getBytes(StandardCharsets.UTF_8));
            cert = cf.generateCertificate(is);
        } catch (CertificateException e) {
            e.printStackTrace();
        }
        return cert;
    }
}
