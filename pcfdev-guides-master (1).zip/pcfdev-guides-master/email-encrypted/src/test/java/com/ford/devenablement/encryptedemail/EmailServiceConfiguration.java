package com.ford.devenablement.encryptedemail;

import com.ford.devenablement.encryptedemail.ldap.LdapService;
import org.mockito.Mockito;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;

@Configuration
public class EmailServiceConfiguration {

    @Bean
    @Primary
    public LdapService ldapService() {
        return Mockito.mock(LdapService.class);
    }
}
