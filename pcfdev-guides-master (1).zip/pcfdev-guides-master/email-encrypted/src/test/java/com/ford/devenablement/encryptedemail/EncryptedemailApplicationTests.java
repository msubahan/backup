package com.ford.devenablement.encryptedemail;

import com.ford.devenablement.encryptedemail.exceptions.EncryptedEmailSendException;
import com.ford.devenablement.encryptedemail.exceptions.NoPublicCertFoundException;
import com.ford.devenablement.encryptedemail.exceptions.NonFordEmailException;
import com.ford.devenablement.encryptedemail.globalcatalog.GlobalCatalogService;
import com.ford.devenablement.encryptedemail.ldap.LdapConfig;
import com.ford.devenablement.encryptedemail.ldap.LdapService;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doNothing;

@RunWith(SpringRunner.class)
@SpringBootTest
@ContextConfiguration(classes = {MailTestConfiguration.class, EmailService.class, LdapService.class,
        LdapConfig.class, GlobalCatalogService.class, CertificateService.class})
public class EncryptedemailApplicationTests {
    private final String validGenericAddr1 = "ssotest@ford.com";
    private final String validRealAddr1 = "cyourman@ford.com";
    private final String validRealAddr2 = "dstacer@ford.com";
    private final String invalidExternalAddr1 = "blah@blah.com";
    private final String invalidFordAddr1 = "blah@ford.com";

    @Mock
    private JavaMailSender mockJavaMailSender;

    @InjectMocks
    @Autowired
    private EmailService emailService;

    @Before
    public void Setup() {
        MockitoAnnotations.initMocks(this);
        doNothing().when(mockJavaMailSender).send(any(SimpleMailMessage.class));
    }

    @Test
    public void sendEncryptedEmailToSingleRecipient() throws Exception {
        reset();
        emailService.sendEncryptedEmail("Encrypted", "Test Body", new String[]{validRealAddr1});
    }

    @Test
    public void sendEncryptedEmailToMultpleRecipients() throws Exception{
        reset();
        emailService.sendEncryptedEmail("Encrypted", "Test Body",
                new String[]{validRealAddr1, validRealAddr2});
    }

    @Test(expected = EncryptedEmailSendException.class)
    public void cantSendEncryptedEmailToGenericId() throws Exception {
        reset();
        emailService.sendEncryptedEmail("Encrypted", "Test Body", new String[]{validGenericAddr1});
    }

    @Test(expected = NoPublicCertFoundException.class)
    public void sendEncryptedEmailToInvalidInternalRecipient() throws Exception {
        reset();
        emailService.sendEncryptedEmail("Encrypted", "Test Body", new String[]{invalidFordAddr1});
    }

    @Test(expected = NonFordEmailException.class)
    public void sendEncryptedEmailToInvalidExternalRecipient() throws Exception {
        reset();
        emailService.sendEncryptedEmail("Encrypted", "Test Body", new String[]{invalidExternalAddr1});
    }

    @Test(expected = NonFordEmailException.class)
    public void sendEncryptedEmailwithNonFordSender() throws Exception{
        reset();
        emailService.setSender(invalidExternalAddr1);
        emailService.sendEncryptedEmail("Encrypted", "Test Body",
                new String[]{validRealAddr1});
    }

    private void reset() {
        emailService.setSender(validGenericAddr1);
    }
}
