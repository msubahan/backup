package com.ford.devenablement.encryptedemail.exceptions;

public class NonFordEmailException extends RuntimeException {
    public NonFordEmailException(String msg) {
        super(msg);
    }
}
