package com.ford.devenablement.encryptedemail;

import com.ford.devenablement.encryptedemail.exceptions.EncryptedEmailSendException;
import com.ford.devenablement.encryptedemail.exceptions.NoPublicCertFoundException;
import com.ford.devenablement.encryptedemail.exceptions.NonFordEmailException;
import com.ford.devenablement.encryptedemail.ldap.LdapService;
import org.bouncycastle.cms.CMSAlgorithm;
import org.bouncycastle.cms.CMSException;
import org.bouncycastle.cms.jcajce.JceCMSContentEncryptorBuilder;
import org.bouncycastle.cms.jcajce.JceKeyTransRecipientInfoGenerator;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.bouncycastle.mail.smime.SMIMEEnvelopedGenerator;
import org.bouncycastle.mail.smime.SMIMEException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import javax.mail.Address;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import java.io.IOException;
import java.security.Security;
import java.security.cert.Certificate;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.*;

@Service
public class EmailService {
    @Value("${from-email-address}")
    private String fromEmailAddress;

    private JavaMailSender javaMailSender;
    private LdapService ldapService;

    @Autowired
    public EmailService(JavaMailSender javaMailSender, LdapService ldapService) {
        Security.addProvider(new BouncyCastleProvider());
        this.javaMailSender = javaMailSender;
        this.ldapService = ldapService;
    }

    public void sendUnencryptedEmail(String subject, String message, String... toAddresses) {
        validateAddressesAreFordEmailAddress(toAddresses);
        validateAddressesAreFordEmailAddress(new String[]{fromEmailAddress});
        SimpleMailMessage mailMessage = new SimpleMailMessage();
        mailMessage.setTo(toAddresses);
        mailMessage.setSubject(subject);
        mailMessage.setText(message);
        mailMessage.setFrom(fromEmailAddress);
        mailMessage.setSentDate(new Date());
        javaMailSender.send(mailMessage);
    }

    public void sendEncryptedEmail(String subject, String message, String... toAddresses) {
        validateAddressesAreFordEmailAddress(toAddresses);
        validateAddressesAreFordEmailAddress(new String[]{fromEmailAddress});
        Session session = Session.getDefaultInstance(System.getProperties());
        MimeMessage mimeMessage = new MimeMessage(session);

        try {
            mimeMessage.setFrom(new InternetAddress(fromEmailAddress));
            mimeMessage.addRecipients(Message.RecipientType.TO, generateAddressArrayFromStringArray(toAddresses));
            mimeMessage.setSubject(subject);
            mimeMessage.setContent(message, "text/html;charset=UTF-8");
            mimeMessage.setSentDate(new Date());

            List<X509Certificate> userCertificates = getUserCertificates(toAddresses);
            encryptEmail(mimeMessage, userCertificates);
            javaMailSender.send(encryptEmail(mimeMessage, userCertificates));
        } catch (CertificateException | IOException | MessagingException | CMSException | SMIMEException e) {
            throw new EncryptedEmailSendException("Error sending encrypted email: " + e);
        }
    }

    private Address[] generateAddressArrayFromStringArray(String[] toAddresses) throws AddressException {
        List<InternetAddress> addressesList = new ArrayList<>();
        for (String recipient : toAddresses) {
            InternetAddress address = new InternetAddress(recipient);
            addressesList.add(address);
        }
        Address[] addressArray = new Address[addressesList.size()];
        addressArray = addressesList.toArray(addressArray);
        return addressArray;
    }

    private MimeMessage encryptEmail(MimeMessage mimeMessage, List<X509Certificate> userCertificates)
            throws CertificateException, IOException, MessagingException, CMSException, SMIMEException {
        SMIMEEnvelopedGenerator gen = new SMIMEEnvelopedGenerator();

        for (X509Certificate cert : userCertificates) {
            gen.addRecipientInfoGenerator(new JceKeyTransRecipientInfoGenerator(cert).setProvider("BC"));
        }

        MimeBodyPart msg = new MimeBodyPart();
        msg.setContent(mimeMessage.getContent(), mimeMessage.getContentType());

        JceCMSContentEncryptorBuilder encryptorBuilder = new JceCMSContentEncryptorBuilder(CMSAlgorithm.RC2_CBC);
        MimeBodyPart mp = gen.generate(msg, encryptorBuilder.setProvider("BC").build());
        mimeMessage.setContent(mp.getContent(), mp.getContentType());
        mimeMessage.saveChanges();
        return mimeMessage;
    }

    private String getCdsid(String emailAddress) {
        return emailAddress.substring(0, emailAddress.indexOf("@"));
    }

    public List<X509Certificate> getUserCertificates(String[] addresses) throws CertificateException {
        List<Certificate> certs = new ArrayList<>();

        for (String emailAddress : addresses) {
            List<Certificate> userCertificates = (List<Certificate>)
                    ldapService.searchForUserCertificates(getCdsid(emailAddress));

            if (!userCertificates.isEmpty()) {
                userCertificates = (List<Certificate>) getNewestValidCert(userCertificates);
            }

            certs.addAll(userCertificates);
        }
        return convertCertificatesToX509Certificates(certs);
    }

    private List<X509Certificate> convertCertificatesToX509Certificates(List<Certificate> certificates) {
        List<X509Certificate> x509Certificates = new ArrayList<>();
        for (Certificate currentCert : certificates) {
            if (currentCert instanceof X509Certificate) {
                x509Certificates.add((X509Certificate) currentCert);
            } else {
                throw new NoPublicCertFoundException("Certificate is not correct type: " + currentCert.toString());
            }
        }
        return x509Certificates;
    }

    protected List<Certificate> getNewestValidCert(List<Certificate> userCertificates) {
        List<Certificate> selectedCert = new ArrayList<>();
        Map<Date, Certificate> validCerts = createMapValidCerts(userCertificates);
        selectedCert.add(getNewestCertificate(validCerts));
        return selectedCert;
    }

    private Certificate getNewestCertificate(Map<Date, Certificate> validCerts) {
        Set<Date> keys = validCerts.keySet();
        Date newest = null;
        for (Date key : keys) {
            if (newest == null)
                newest = key;
            else {
                if (key.after(newest))
                    newest = key;
            }
        }
        return validCerts.get(newest);
    }

    private Map<Date, Certificate> createMapValidCerts(List<Certificate> userCertificates) {
        Map<Date, Certificate> validCerts = new HashMap<>();
        for (Certificate currentCert : userCertificates) {
            X509Certificate x509cert = (X509Certificate) currentCert;
            try {
                x509cert.checkValidity();
            } catch (Exception e) {
                continue;
            }
            validCerts.put(x509cert.getNotAfter(), x509cert);
        }
        return validCerts;
    }

    private void validateAddressesAreFordEmailAddress(String[] addresses) {
        for (String address : addresses) {
            if (!StringUtils.endsWithIgnoreCase(address, "ford.com")) {
                String msg = "All email sent from Ford must contain a '@ford.com' from address. " +
                        "Unfortunately application is currently configured to use from address --> ";
                throw new NonFordEmailException(msg + address);
            }
        }
    }

    protected void setSender(String sender) {
        this.fromEmailAddress = sender;
    }
}
