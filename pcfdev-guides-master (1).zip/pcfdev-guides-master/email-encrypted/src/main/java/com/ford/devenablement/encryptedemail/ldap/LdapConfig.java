package com.ford.devenablement.encryptedemail.ldap;

import com.ford.devenablement.encryptedemail.globalcatalog.GlobalCatalogService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.ldap.core.ContextSource;
import org.springframework.ldap.core.LdapTemplate;
import org.springframework.ldap.core.support.LdapContextSource;

import java.util.HashMap;
import java.util.Map;

@Configuration
public class LdapConfig {
    @Autowired
    GlobalCatalogService globalCatalogService;

    @Value("${spring.ldap.username}")
    private String user;

    @Value("${spring.ldap.password}")
    private String pass;

    @Bean
    public LdapTemplate ldapTemplate() {
        return new LdapTemplate(contextSource());
    }

    @Bean
    public ContextSource contextSource() {
        String url = buildLdapUrl();
        final LdapContextSource contextSource = new LdapContextSource();
        contextSource.setUrl(url);
        contextSource.setUserDn(user);
        contextSource.setPassword(pass);
        contextSource.setBaseEnvironmentProperties(this.buildBaseEnvProps());
        return contextSource;
    }

    private String buildLdapUrl() {
        return "ldaps://" + globalCatalogService.getGlobalCatalogHost() + ":3269";
    }

    private Map<String, Object> buildBaseEnvProps() {
        final Map<String, Object> envProps = new HashMap<>();
        envProps.put("java.naming.ldap.attributes.binary", "userCertificate");
        return envProps;
    }
}
