package com.ford.devenablement.encryptedemail.exceptions;

public class EncryptedEmailSendException extends RuntimeException {
    public EncryptedEmailSendException(String msg) {
        super(msg);
    }
}
