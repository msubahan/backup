package com.ford.devenablement.encryptedemail.globalcatalog;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@Builder
public class SrvRecord {
    int priority;
    int weight;
    int port;
    String srvHostname;
}
