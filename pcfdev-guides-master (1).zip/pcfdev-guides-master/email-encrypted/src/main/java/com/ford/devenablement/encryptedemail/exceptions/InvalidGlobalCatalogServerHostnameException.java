package com.ford.devenablement.encryptedemail.exceptions;

public class InvalidGlobalCatalogServerHostnameException extends RuntimeException {
    public InvalidGlobalCatalogServerHostnameException(String msg) {
        super(msg);
    }
}
