package com.ford.devenablement.encryptedemail;

import org.springframework.stereotype.Service;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.security.cert.Certificate;
import java.security.cert.CertificateException;
import java.security.cert.CertificateFactory;
import java.util.ArrayList;
import java.util.List;

@Service
public class CertificateService {
    public List<Certificate> convertLdapCertResponseObjectsToCertificates(Object[] certs) throws CertificateException {
        List<Certificate> certificates = new ArrayList<>();
        for (Object object: certs) {
            CertificateFactory certFactory = CertificateFactory.getInstance("X.509");
            InputStream in = new ByteArrayInputStream((byte[]) object);
            Certificate cert = (Certificate)certFactory.generateCertificate(in);
            certificates.add(cert);
        }
        return certificates;
    }
}
