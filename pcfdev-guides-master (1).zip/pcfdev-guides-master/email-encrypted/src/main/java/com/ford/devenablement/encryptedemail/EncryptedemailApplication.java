package com.ford.devenablement.encryptedemail;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EncryptedemailApplication {

	public static void main(String[] args) {
		SpringApplication.run(EncryptedemailApplication.class, args);
	}

}
