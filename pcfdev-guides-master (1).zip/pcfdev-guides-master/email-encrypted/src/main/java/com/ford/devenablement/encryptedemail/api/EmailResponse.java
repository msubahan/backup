package com.ford.devenablement.encryptedemail.api;

import com.ford.cloudnative.base.api.BaseBodyResponse;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

public class EmailResponse extends BaseBodyResponse<EmailResponse.EmailResponseResult> {
	
	@Data
	@NoArgsConstructor
	@AllArgsConstructor
	@Builder
	public static class EmailResponseResult {
		String status;
	}

}
