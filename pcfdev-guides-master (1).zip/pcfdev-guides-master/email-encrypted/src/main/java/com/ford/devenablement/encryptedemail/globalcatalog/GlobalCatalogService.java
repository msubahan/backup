package com.ford.devenablement.encryptedemail.globalcatalog;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ford.devenablement.encryptedemail.exceptions.InvalidGlobalCatalogServerHostnameException;
import org.springframework.stereotype.Service;

import javax.naming.NamingException;
import javax.naming.directory.Attribute;
import javax.naming.directory.Attributes;
import javax.naming.directory.DirContext;
import javax.naming.directory.InitialDirContext;
import java.util.ArrayList;
import java.util.List;

@Service
public class GlobalCatalogService {
    ObjectMapper mapper;

    public GlobalCatalogService(ObjectMapper mapper) {
        this.mapper = mapper;
    }

    public String getGlobalCatalogHost() {
        try {
            return getGlobalCatalogs().get(0).getSrvHostname();
        } catch (NamingException e) {
            throw new InvalidGlobalCatalogServerHostnameException("Unable to get a global catalog hostname");
        }
    }

    public List<SrvRecord> getGlobalCatalogs() throws NamingException {
        DirContext ctx = new InitialDirContext();
        Attributes attrs = ctx.getAttributes("dns:/_gc._tcp.A-NADC._sites.ford.com");
        return getSrvRecords(attrs.get("srv"));
    }

    private List<SrvRecord> getSrvRecords(Attribute attribute) throws NamingException {
        List<SrvRecord> srvRecords = new ArrayList<>();


        for (int i = 0; i < attribute.size(); i++) {
            String entry = (String) attribute.get(i);
            String[] elements = entry.split(" ");
            elements[3] = stripTrailingDot(elements[3]);

            SrvRecord record = SrvRecord.builder()
                    .priority(Integer.parseInt(elements[0]))
                    .weight(Integer.parseInt(elements[1]))
                    .port(Integer.parseInt(elements[2]))
                    .srvHostname(elements[3])
                    .build();

            srvRecords.add(record);
        }
        return srvRecords;
    }

    private String stripTrailingDot(String in) {
        return in.substring(0, in.length() - 1);
    }
}
