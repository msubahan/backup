package com.ford.devenablement.encryptedemail.exceptions;

public class NoPublicCertFoundException extends RuntimeException {
    public NoPublicCertFoundException(String msg) {
        super(msg);
    }
}
