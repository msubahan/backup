package com.ford.devenablement.encryptedemail.ldap;


import com.ford.devenablement.encryptedemail.CertificateService;
import com.ford.devenablement.encryptedemail.exceptions.EncryptedEmailSendException;
import com.ford.devenablement.encryptedemail.exceptions.NoPublicCertFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ldap.core.ContextMapper;
import org.springframework.ldap.core.DirContextAdapter;
import org.springframework.ldap.core.LdapTemplate;
import org.springframework.stereotype.Service;

import java.security.cert.Certificate;
import java.security.cert.CertificateException;
import java.util.List;

@Service
public class LdapService {

    LdapTemplate ldapTemplate;

    CertificateService certificateService;

    @Autowired
    public LdapService(LdapTemplate ldapTemplate, CertificateService certificateService) {
        this.ldapTemplate = ldapTemplate;
        this.certificateService = certificateService;
    }

    public List<Certificate> searchForUserCertificates(String username) throws CertificateException {

        ContextMapper<Object[]> certificate = ctx -> {
            DirContextAdapter adapter = (DirContextAdapter) ctx;
            return adapter.getObjectAttributes("userCertificate");
        };

        List<Object[]> userCertificatesResponse = (List<Object[]>) ldapTemplate
                .search(
                        "DC=Ford,DC=com",
                        "samaccountname=" + username,
                        certificate);


        if (userCertificatesResponse.isEmpty()) {
            throw new NoPublicCertFoundException("No public certificate found for user " + username);
        }

        Object[] certs = userCertificatesResponse.get(0);
        if (certs == null) {
            throw new EncryptedEmailSendException("Can't send encrypted email to generic id.  " + username);
        }

        return certificateService.convertLdapCertResponseObjectsToCertificates(certs);
    }
}
