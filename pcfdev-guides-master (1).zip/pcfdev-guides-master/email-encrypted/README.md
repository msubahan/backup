## Encrypted Email Guide

This guide demonstrates how to send secure email messages using Ford SMTP relay servers to Ford email addresses.  To send encrypted email, the recipient's public certificate is required to encrypt the email.  These are stored in AD DS accessible using the LDAP protocol.

FDS shows userCertificate in the schema but the field is null. 
 
 
 Unfortunately you cannot directly send emails from your desktop because STMP relay servers use IP restrictions for security. You will need to adopt a mocking strategy to test locally.

You must register your application and ID if you want to send email messages from your deployed cloud applications (both for Pre-Prod and Prod). To register, click on the Request SMTP Email Relay Access for PCF Applications link on the following [Platform page](https://communities.spt.ford.com/sites/PCF/SitePages/Platform.aspx#InplviewHash313caf61-3257-4a77-910a-b97ec5f51bd1=ShowInGrid%3DTrue).

This example code requires that your application is registered to send email in a Ford environment, and that you have a LDAP ID registered for use by your application.


Email cannot be sent to external addresses.

## Requirements
#### Sendmail Registration
See this page for [registration instructions.](https://communities.spt.ford.com/sites/PCF/SitePages/Platform.aspx#InplviewHash313caf61-3257-4a77-910a-b97ec5f51bd1=ShowInGrid%3DTrue)

#### AD DS Registration
No registration is needed to query ADFS.  FDS accessed with LDAP requires a registered client but FDS is not used in this demo app.

## Implementation

#### Dependencies
Beyond normal Ecoboost app dependencies, the following are needed.  Include the latest approved version of BouncyCastle and the SpringBoot starters for mail, and ldap.
```aidl
    compile 'org.bouncycastle:bcprov-jdk15on:1.57'
    compile 'org.bouncycastle:bcmail-jdk15on:1.57'
    compile 'org.bouncycastle:bcpkix-jdk15on:1.57'
    implementation 'org.springframework.boot:spring-boot-starter-data-ldap'
    implementation 'org.springframework.boot:spring-boot-starter-mail'
```

#### Configuration
Spring will pick up the JavaMailSender configuration from application properties.  LDAP configuration must match the configuration in LdapConfig.  This configuration is NOT FDS/LDAP.  This is Active Directory Directory Services.  All generic IDs should work by default.

The from email address is also configured via properties. 

```aidl
spring.ldap.username= CN=[Generic ID],OU=Level0400,OU=GPO,OU=USERIDS,DC=na1,DC=ford,DC=com
spring.ldap.password= [PASSORD Source]

# JavaMailSender configuration
spring.mail.host=mrl.azell.com
spring.mail.port=25

# email setting(s)
from-email-address=dvnmail@ford.com
```

### Generating Mail
To use this feature, autowire the EmailService and call one of the send methods.  There are two methods: sendEncryptedEmail and sendUnencryptedEmail.  Both have parameters for Subject, Body, and a list of email addresses.  The 'from' comes from application properties but a setter is also provided.  See the example below;

```aidl
emailService.sendEncryptedEmail("Encrypted", "Test Body", new String[]{"cyourman@ford.com", "echurchm@ford.com"});
```
When sending encrypted email, behind the scenes the following things happen:

- A new mime message is created representing the email to send
- The GlobalCatalogService is called to identify a Domain Controller to query
- Active Directory is queried to collect the recipient's email certs.  Some users may have two certificates if thier primary certificate is expiring soon.  In these cases the newest certificate is used.
- A collection of certificates is built holding one cert for each recipient.
- For each recipient certificate, the mail message is encrypted using BouncyCastle.
- Encrypted email is sent to the configured SMTP server

### Testing the Sample App

After configuring the sample app with your registered app ID and placing it in the appropriate environment, the sample app can be tested by sending a POST to the application.  The format of the post is shown in the example below:

```aidl
{
	"to": ["cyourman@ford.com", "echurchm@ford.com"],
	"subject": "Subject",
	"message": "Message"
}
```

The application will send both an encrypted and a plain text email to the recipients.

A dummy SMTP server can also be used provided it's approved on the TSL.

## Debugging
There are a collection of things to go wrong:
  
- A domain controller may not respond to the certificate query
- Email addresses can be incorrect, external, or removed
- The recipient may not have a certificate
- The application may not be registered to use Ford's SMTP server
- The application may be registered but the connection is coming from an IP address not included in the registration
- The application's registration could be expired
- The application's generic ID credentials could be expired or incorrect
- The userDN can be incorrect blocking the application from querying for user certificate
