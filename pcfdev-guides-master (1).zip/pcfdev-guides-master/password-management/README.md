# Password Management Guide

This guide covers some techniques that can be followed in order to update a password without the need for application
downtime. When we use a secrets management solution to manage our database password, the updates need to be applied with
care as to avoid any impact to the running application and avoid locking the database account we are using. See the 
[Secrets Management Guide](../secrets-management/README.md) for more information on how to securely store passwords 
(or any secrets) for a Spring Boot application.
> Note: This guide is covering a use case for updating a password and updating it in a PCF app. It may be translatable to other platforms.


## Leverage Dual Accounts for DB Access
When a team has to update a password, say for a database account, it is important to realize that the password cannot
be updated while the running application is using the id & password to access the database (or other type of service).
It is for this reason that we suggest that teams request two accounts to access a database.

This approach involves having 2 accounts for the source system, and only one configured and in use in the running 
application. Both accounts are valid, but by having two accounts you can update 1 account while the other is still in 
use and then swap in the unused account before the account in use expires. If you have a single account, you either 
need to stop the application to perform the password update or update it while its in use. If you update while it is 
in use, application failures and potential account locking will occur. See the diagram below to see how this works 
over time.

![alt text](dualaccounts.png)


## Zero Downtime Password Update Pattern
The following are the steps you can follow for updating a password with zero downtime by rotating in a new credential
assuming you have 2 accounts as described in previous section:
1. Team has 2 accounts for use with a database; i.e. account myappid1 & myappid2
2. Application is using a credential, myappid1, that will (soon) expire
3. The account that is currently NOT in use by the application, myappid2, has its password updated in order to reset
   the expiration date.
4. The team updates the secret (in CredHub, Config Server, or other secrets management solution) so that myappid2
   and its associated password will be used.
5. The team restarts the app using a rolling restart (cf cli command) in order to have the new credentials utilized by
   the app.
6. The team updates the password for myappid1 now that is no longer being used by the application as to prevent it
   from expiring or being locked and also stopping ongoing expiration notifications.