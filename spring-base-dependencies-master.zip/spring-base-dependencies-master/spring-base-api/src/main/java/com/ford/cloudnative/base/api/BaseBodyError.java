package com.ford.cloudnative.base.api;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.Singular;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class BaseBodyError {

    @Size(max = 100)
    @Pattern(regexp = "^.{0,100}$")
    String errorCode;

    @Singular
    @Size(max = 8192)
    List<@Size(max = 32768) @Pattern(regexp = "^.{0,32768}$") String> messages;

    @Singular
    @Size(max = 8192)
    List<@NotNull BaseBodyDataError> dataErrors;

    @Singular
    Map<String, Object> attributes;

    // helper function to update attributes more easily
    @JsonIgnore
    public Map<String, Object> getAttributesMutable() {
    	if (this.attributes == null) {
    		this.attributes = new HashMap<>();
    	} else if (!(this.attributes instanceof HashMap<?,?>)) {
    		this.attributes = new HashMap<>(this.attributes);
    	}
    	return this.attributes;
    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class BaseBodyDataError {

        @Size(max = 1024, message = "code length is limited to 1024 characters")
        @Pattern(regexp = "^.{0,1024}$")
        String code;

        @Size(max = 1024, message = "name length is limited to 1024 characters")
        @Pattern(regexp = "^.{0,1024}$")
        String name;

        @Size(max = 1024, message = "value length is limited to 1024 characters")
        @Pattern(regexp = "^.{0,1024}$")
        String value;

        @Size(max = 1024, message = "message length is limited to 1024 characters")
        @Pattern(regexp = "^.{0,1024}$")
    	String message;
    }
}
