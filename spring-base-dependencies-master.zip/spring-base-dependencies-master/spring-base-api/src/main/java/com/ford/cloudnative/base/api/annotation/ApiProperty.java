package com.ford.cloudnative.base.api.annotation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Repeatable;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Target({ElementType.METHOD, ElementType.FIELD, ElementType.PARAMETER, ElementType.ANNOTATION_TYPE, ElementType.TYPE_USE})
@Retention(RetentionPolicy.RUNTIME)
@Repeatable(ApiProperty.Container.class)
public @interface ApiProperty {
    String name();
    String value();

    @Target({ElementType.METHOD, ElementType.FIELD, ElementType.PARAMETER, ElementType.ANNOTATION_TYPE, ElementType.TYPE_USE})
    @Retention(RetentionPolicy.RUNTIME)
    @interface Container {
        ApiProperty[] value();
    }

    // Boolean
    @Target({ElementType.METHOD, ElementType.FIELD, ElementType.PARAMETER, ElementType.ANNOTATION_TYPE, ElementType.TYPE_USE})
    @Retention(RetentionPolicy.RUNTIME)
    @Repeatable(ApiProperty.Boolean.Container.class)
    @interface Boolean {
        String name();
        boolean value() default false;

        @Target({ElementType.METHOD, ElementType.FIELD, ElementType.PARAMETER, ElementType.ANNOTATION_TYPE, ElementType.TYPE_USE})
        @Retention(RetentionPolicy.RUNTIME)
        @interface Container {
            ApiProperty.Boolean[] value();
        }
    }

    // Integer
    @Target({ElementType.METHOD, ElementType.FIELD, ElementType.PARAMETER, ElementType.ANNOTATION_TYPE, ElementType.TYPE_USE})
    @Retention(RetentionPolicy.RUNTIME)
    @Repeatable(ApiProperty.Integer.Container.class)
    @interface Integer {
        String name();
        int value();

        @Target({ElementType.METHOD, ElementType.FIELD, ElementType.PARAMETER, ElementType.ANNOTATION_TYPE, ElementType.TYPE_USE})
        @Retention(RetentionPolicy.RUNTIME)
        @interface Container {
            ApiProperty.Integer[] value();
        }
    }

    // Long
    @Target({ElementType.METHOD, ElementType.FIELD, ElementType.PARAMETER, ElementType.ANNOTATION_TYPE, ElementType.TYPE_USE})
    @Retention(RetentionPolicy.RUNTIME)
    @Repeatable(ApiProperty.Long.Container.class)
    @interface Long {
        String name();
        long value();

        @Target({ElementType.METHOD, ElementType.FIELD, ElementType.PARAMETER, ElementType.ANNOTATION_TYPE, ElementType.TYPE_USE})
        @Retention(RetentionPolicy.RUNTIME)
        @interface Container {
            ApiProperty.Long[] value();
        }
    }

    // Double
    @Target({ElementType.METHOD, ElementType.FIELD, ElementType.PARAMETER, ElementType.ANNOTATION_TYPE, ElementType.TYPE_USE})
    @Retention(RetentionPolicy.RUNTIME)
    @Repeatable(ApiProperty.Double.Container.class)
    @interface Double {
        String name();
        double value();

        @Target({ElementType.METHOD, ElementType.FIELD, ElementType.PARAMETER, ElementType.ANNOTATION_TYPE, ElementType.TYPE_USE})
        @Retention(RetentionPolicy.RUNTIME)
        @interface Container {
            ApiProperty.Double[] value();
        }
    }

    // Float
    @Target({ElementType.METHOD, ElementType.FIELD, ElementType.PARAMETER, ElementType.ANNOTATION_TYPE, ElementType.TYPE_USE})
    @Retention(RetentionPolicy.RUNTIME)
    @Repeatable(ApiProperty.Float.Container.class)
    @interface Float {
        String name();
        float value();

        @Target({ElementType.METHOD, ElementType.FIELD, ElementType.PARAMETER, ElementType.ANNOTATION_TYPE, ElementType.TYPE_USE})
        @Retention(RetentionPolicy.RUNTIME)
        @interface Container {
            ApiProperty.Float[] value();
        }
    }

    // Json
    @Target({ElementType.METHOD, ElementType.FIELD, ElementType.PARAMETER, ElementType.ANNOTATION_TYPE, ElementType.TYPE_USE})
    @Retention(RetentionPolicy.RUNTIME)
    @Repeatable(ApiProperty.Json.Container.class)
    @interface Json {
        String name();
        String value();

        @Target({ElementType.METHOD, ElementType.FIELD, ElementType.PARAMETER, ElementType.ANNOTATION_TYPE, ElementType.TYPE_USE})
        @Retention(RetentionPolicy.RUNTIME)
        @interface Container {
            ApiProperty.Json[] value();
        }
    }

    // Null
    @Target({ElementType.METHOD, ElementType.FIELD, ElementType.PARAMETER, ElementType.ANNOTATION_TYPE, ElementType.TYPE_USE})
    @Retention(RetentionPolicy.RUNTIME)
    @Repeatable(ApiProperty.Null.Container.class)
    @interface Null {
        String name();

        @Target({ElementType.METHOD, ElementType.FIELD, ElementType.PARAMETER, ElementType.ANNOTATION_TYPE, ElementType.TYPE_USE})
        @Retention(RetentionPolicy.RUNTIME)
        @interface Container {
            ApiProperty.Null[] value();
        }
    }
}

