package com.ford.cloudnative.base.api.cache;

import com.ford.cloudnative.base.api.BaseBodyResponse;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@EqualsAndHashCode(callSuper=true)
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class CachableBodyResponse<T> extends BaseBodyResponse<T> {
    public enum CacheStatus {
        CURRENT, CACHED, UNAVAILABLE
    }
    
    CacheStatus cacheStatus;
    
    public CachableBodyResponse<T> with(CacheStatus cacheStatus) {
    	this.cacheStatus = cacheStatus;
    	return this;
    }
}
