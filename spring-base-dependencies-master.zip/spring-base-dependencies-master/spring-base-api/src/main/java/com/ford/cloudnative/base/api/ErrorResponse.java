package com.ford.cloudnative.base.api;

public interface ErrorResponse {
    BaseBodyError getError();
}
