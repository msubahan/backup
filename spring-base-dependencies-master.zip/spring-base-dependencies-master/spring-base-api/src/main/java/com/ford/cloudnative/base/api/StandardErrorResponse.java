package com.ford.cloudnative.base.api;

import lombok.Data;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

@Data
@SuppressWarnings("squid:S1170")
public final class StandardErrorResponse implements ErrorResponse {
    public static final String ERROR_TYPE = "https://apiguide.ford.com/metadata/ford-standard-error";

    @Size(min = 1, max = 200, message = "type length is limited to 200 characters")
    @Pattern(regexp = "^.{1,200}$")
    @NotNull
    final String type = ERROR_TYPE;

    @Size(min = 1, max = 200, message = "title length is limited to 100 characters")
    @Pattern(regexp = "^.{1,200}$")
    @NotNull
    final String title = "This error is detailed using Ford's standard error format.";

    @Min(value = 400, message = "status must be either a valid 4xx or 5xx HTTP status code")
    @Max(value = 599, message = "status must be either a valid 4xx or 5xx HTTP status code")
    @NotNull
    Integer status;

    BaseBodyError error;

    public StandardErrorResponse(BaseBodyError error) {
        setError(error);
    }

    public void setError(BaseBodyError error) {
        if (error == null) throw new IllegalArgumentException("Error cannot be null");
        this.error = error;
    }

    public static StandardErrorResponse error(BaseBodyError error) {
        return new StandardErrorResponse(error);
    }

    public static StandardErrorResponse error(BaseBodyError error, Integer status) {
        StandardErrorResponse response = new StandardErrorResponse(error);
        response.setStatus(status);
        return response;
    }
}
