package com.ford.cloudnative.base.test.response;

import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;

import org.springframework.test.web.servlet.result.JsonPathResultMatchers;

public class BaseBodyErrorResultMatchers {

	public static JsonPathResultMatchers dataError(String name) {
		return jsonPath(String.format("$.error.dataErrors[?(@.name == '%s')]", name));
	}

	public static JsonPathResultMatchers dataErrorWithCode(String name, String code) {
		return jsonPath(String.format("$.error.dataErrors[?(@.name == '%s' && @.code == '%s')]", name, code));
	}

	public static JsonPathResultMatchers dataErrorWithMessage(String name, String message) {
		return jsonPath(String.format("$.error.dataErrors[?(@.name == '%s' && @.message == '%s')]", name, message));
	}

}
