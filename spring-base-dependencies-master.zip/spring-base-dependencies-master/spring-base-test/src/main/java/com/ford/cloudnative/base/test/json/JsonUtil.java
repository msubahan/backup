package com.ford.cloudnative.base.test.json;

import org.springframework.boot.test.json.JsonContent;

public class JsonUtil {

	public static JsonContent<?> jsonContent(String json) {
		return new JsonContent<>(JsonContent.class, null, json);
	}

}
