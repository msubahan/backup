package com.ford.cloudnative.base.test.acceptance;

public class AcceptanceTestUtil {
	public static final String DEFAULT_ACCEPTANCE_APP_BASE_URL = "http://localhost:8080";

	public static String getAppBaseUrl() {
		String baseUrl = System.getenv("ACCEPTANCE_APP_BASE_URL");
		return (baseUrl == null || baseUrl.trim().isEmpty()) ? DEFAULT_ACCEPTANCE_APP_BASE_URL : baseUrl;
	}

	/**
	 * Returns an instance of {@link AcceptanceTestRestTemplateBuilder}
	 * @return AcceptanceTestRestTemplateBuilder
	 * @deprecated since 2.3.0 in favor of
	 * {@link AcceptanceTestUtil#webClientBuilder()}
	 */
	@Deprecated
	public static AcceptanceTestRestTemplateBuilder restTemplateBuilder() {
		return new AcceptanceTestRestTemplateBuilder();
	}

	/**
	 * Returns an instance of {@link AcceptanceTestWebClientBuilder}
	 * @return AcceptanceTestWebClientBuilder
	 */
	public static AcceptanceTestWebClientBuilder webClientBuilder() {
		return new AcceptanceTestWebClientBuilder();
	}

}
