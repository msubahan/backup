package com.ford.cloudnative.base.test.acceptance;

import org.springframework.boot.web.client.RootUriTemplateHandler;
import org.springframework.http.client.ClientHttpResponse;
import org.springframework.http.client.support.BasicAuthenticationInterceptor;
import org.springframework.web.client.DefaultResponseErrorHandler;
import org.springframework.web.client.RestTemplate;

import java.io.IOException;

/**
 * @deprecated since 2.3.0 in favor of
 * {@link AcceptanceTestWebClientBuilder}
 */
@Deprecated
@SuppressWarnings("deprecation")
public class AcceptanceTestRestTemplateBuilder {

	String namespace = "default";
	boolean basicAuth, oauth2ClientCredentials, disableErrorHandler;

	AcceptanceTestRestTemplateBuilder() {
	}

	public AcceptanceTestRestTemplateBuilder namespace(String namespace) {
		this.namespace = namespace;
		return this;
	}

	public AcceptanceTestRestTemplateBuilder withBasicAuth() {
		this.basicAuth = true;
		return this;
	}

	public AcceptanceTestRestTemplateBuilder withOAuth2ClientCredentials() {
		this.oauth2ClientCredentials = true;
		return this;
	}

	public AcceptanceTestRestTemplateBuilder disableErrorHandler() {
		this.disableErrorHandler = true;
		return this;
	}

	public RestTemplate build() {
		if (this.basicAuth && this.oauth2ClientCredentials) {
			throw new IllegalStateException("Both Basic Auth and OAuth2 credentials cannot be enabled for the same given RestTemplate.");
		}

		RestTemplate restTemplate = null;
		if (this.basicAuth) {
			restTemplate = restTemplateWithBasicAuth();
		} else if (this.oauth2ClientCredentials) {
			restTemplate = new OAuth2RestTemplateBuilder().restTemplateWithOAuth2ClientCredentials();
		} else {
			restTemplate = new RestTemplate();
		}

		if (this.disableErrorHandler) {
			restTemplate.setErrorHandler(new DefaultResponseErrorHandler() {
				public void handleError(ClientHttpResponse response) throws IOException {
					/* nop */ }
			});
		}

		restTemplate.setUriTemplateHandler(new RootUriTemplateHandler(AcceptanceTestUtil.getAppBaseUrl()));
		return restTemplate;
	}

	private RestTemplate restTemplateWithBasicAuth() {
		String username = getPropertyValue("basic_auth_user");
		String password = getPropertyValue("basic_auth_pass");

		RestTemplate restTemplate = new RestTemplate();
		restTemplate.getInterceptors().add(new BasicAuthenticationInterceptor(username, password));
		return restTemplate;
	}

	String getPropertyValue(String name) {
		String envName = String.format("ACCEPTANCE_%s_%s", this.namespace, name).toUpperCase();
		String value = System.getenv(envName);
		if (value == null || value.trim().isEmpty()) {
			throw new IllegalArgumentException(String.format("Environment variable '%s' is not set or is blank.", envName));
		}
		return value;
	}
	
	// this class is needed to avoid class errors pertaining to lack of oauth2 dependency
	class OAuth2RestTemplateBuilder {
		RestTemplate restTemplateWithOAuth2ClientCredentials() {
			org.springframework.security.oauth2.client.token.grant.client.ClientCredentialsResourceDetails resourceDetails =
					new org.springframework.security.oauth2.client.token.grant.client.ClientCredentialsResourceDetails();
			resourceDetails.setAccessTokenUri(AcceptanceTestRestTemplateBuilder.this.getPropertyValue("oauth2_client_access_token_uri"));
			resourceDetails.setClientId(AcceptanceTestRestTemplateBuilder.this.getPropertyValue("oauth2_client_id"));
			resourceDetails.setClientSecret(AcceptanceTestRestTemplateBuilder.this.getPropertyValue("oauth2_client_secret"));
			return new org.springframework.security.oauth2.client.OAuth2RestTemplate(resourceDetails);
		}
	}
}
