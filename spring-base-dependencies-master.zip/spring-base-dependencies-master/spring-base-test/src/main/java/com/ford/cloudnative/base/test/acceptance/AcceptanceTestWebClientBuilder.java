package com.ford.cloudnative.base.test.acceptance;

import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.reactive.function.BodyInserters;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClientResponseException;

import java.util.Base64;
import java.util.Collections;
import java.util.Objects;

import static com.ford.cloudnative.base.test.acceptance.AcceptanceTestUtil.getAppBaseUrl;

@Slf4j
public class AcceptanceTestWebClientBuilder {
    private static final String AUTHORIZATION = "Authorization";
    private static final String CLIENTCREDENTIALS = "client_credentials";
    private static final String ROPC = "password";
    boolean oauth2ClientCredentials;
    boolean oauth2ROPC;
    boolean basicAuth;
    String namespace = "default";

    public WebClient build() {
        if (oauth2ClientCredentials || oauth2ROPC) {
            return WebClient.builder()
                    .baseUrl(getAppBaseUrl())
                    .defaultHeaders(httpHeaders -> httpHeaders.set(AUTHORIZATION, "Bearer " + getOauthToken()))
                    .build();
        }
        if (basicAuth) {
            return WebClient.builder()
                    .baseUrl(getAppBaseUrl())
                    .defaultHeaders(httpHeaders -> httpHeaders.set(AUTHORIZATION, "Basic " + getBasicAuth()))
                    .build();
        }
        return WebClient.builder()
                .baseUrl(getAppBaseUrl())
                .build();
    }


    public AcceptanceTestWebClientBuilder withOAuth2ClientCredentials() {
        this.oauth2ClientCredentials = true;
        return this;
    }

    public AcceptanceTestWebClientBuilder withROPC() {
        this.oauth2ROPC = true;
        return this;
    }

    public AcceptanceTestWebClientBuilder withBasicAuth() {
        this.basicAuth = true;
        return this;
    }

    private String getBasicAuth() {
        String username = getPropertyValue("basic_auth_user");
        String password = getPropertyValue("basic_auth_pass");
        String basicHeaderValue = username + ":" + password;
        return Base64.getEncoder().encodeToString(basicHeaderValue.getBytes());
    }

    private String getOauthToken() {
        WebClient tokenWebClient = WebClient.builder().build();
        AdfsTokenResponse tokenResponse;
        MultiValueMap<String, String> request = (oauth2ClientCredentials) ? getCCGrantRequest() : getROPCGrantRequest();
        try {
             tokenResponse = tokenWebClient.post()
                .uri(this.getPropertyValue("oauth2_client_access_token_uri"))
                .header(HttpHeaders.ACCEPT, MediaType.APPLICATION_JSON_VALUE)
                .header(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_FORM_URLENCODED_VALUE)
                .body(BodyInserters.fromFormData(request))
                .retrieve()
                .bodyToMono(AdfsTokenResponse.class)
                .block();
        } catch (WebClientResponseException e) {
            log.error("Unable to get access token: " + e.getMessage());
            return "";
        }
        return Objects.requireNonNull(tokenResponse).getAccessToken();
    }

    private MultiValueMap<String, String> getROPCGrantRequest() {
        MultiValueMap<String, String> requestMap = new LinkedMultiValueMap<>();
        requestMap.put("grant_type", Collections.singletonList(ROPC));
        requestMap.put("client_id", Collections.singletonList(this.getPropertyValue("oauth2_app_client_id")));
        requestMap.put("username", Collections.singletonList(this.getPropertyValue("oauth2_ropc_username")));
        requestMap.put("password", Collections.singletonList(this.getPropertyValue("oauth2_ropc_password")));
        requestMap.put("resource", Collections.singletonList(this.getPropertyValue("oauth2_resource")));
        return requestMap;
    }

    private MultiValueMap<String, String> getCCGrantRequest() {
        MultiValueMap<String, String> requestMap = new LinkedMultiValueMap<>();
        requestMap.put("grant_type", Collections.singletonList(CLIENTCREDENTIALS));
        requestMap.put("client_id", Collections.singletonList(this.getPropertyValue("oauth2_client_id")));
        requestMap.put("client_secret", Collections.singletonList(this.getPropertyValue("oauth2_client_secret")));
        requestMap.put("resource", Collections.singletonList(this.getPropertyValue("oauth2_resource")));
        return requestMap;
    }

    String getPropertyValue(String name) {
        String envName = String.format("ACCEPTANCE_%s_%s", this.namespace, name).toUpperCase();
        String value = System.getenv(envName);
        if (value == null || value.trim().isEmpty()) {
            throw new IllegalArgumentException(String.format("Environment variable '%s' is not set or is blank.", envName));
        }
        return value;
    }
}
