# Spring Base Dependencies

These libraries provide support Spring Boot applications and  application architecture patterns endorsed by the Dev Enablement team. 
They are core to the EcoBoost application generator that is part of [/dev/central/station](http:/dcs.ford.com). 
The binaries for these libraries are published to Ford's Nexus repository, and can be included in your Spring Boot application by including the following line in your build.gradle:

``` implementation 'com.ford.cloudnative:spring-boot-starter-ford:3.0.0'  ```

Supported feature configurations shall be enabled/disabled with help of relevant application properties.

To see the libraries in use, you can either generate your own EcoBoost application using [/d/c/s](https://dcs.ford.com/project-workflow/springboot), 
or refer to our reference application [CAB in GitHub](https://github.ford.com/PCFDev-CAB/cab-service-fordair).


## Individual libraries

The Spring Base Dependencies typically are included using the Spring Boot starter as deomostrated above, but are really comprised of the following indivudal components:

1. [Spring Base API](spring-base-api)
2. [Spring Base App](spring-base-app)
3. [Spring Base Test](spring-base-test)

## Internal (DevEn Team) Only
Refer to [Library Publishing Steps](/DevEnTeamOnly_PublishGuide.md) for instructions on how to build and publish individual libraries and starter POM files in Nexus.
