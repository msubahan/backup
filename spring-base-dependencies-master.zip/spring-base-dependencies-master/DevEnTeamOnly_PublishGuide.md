# Instructions for publishing changes to libraries (managed by Dev Enablement Team only)

1. Publish update to individual library module (i.e. app, api, client, test) -- in each dir

2. Update the module's library version in build.gradle

3. Build component ```./gradlew build```

4. Publish component to Ford Nexus

Run the pubish command directly from the module
```
export BOOST_PUBLISH_TEAM_REPO_URL=http://www.nexus.ford.com/content/groups/PCFDevEnablement_public_release_repository
export BOOST_PUBLISH_TEAM_REPO_USER=
export BOOST_PUBLISH_TEAM_REPO_PASS=
./gradlew publish
```

Note - Only the module being modified needs to be published.  No need to publish the other untouched modules.

If updating spring.base.app or spring.base.api libraries then pom-starter.xml also needs to be updated to reference the new versions.
If updating spring.base.test library alone, the update is complete at this point.

## Instructions for Publishing updated Spring Boot Starter Ford

After changes are made to individual libraries, and they are published to Nexus, the Spring Boot Starter Ford needs to be updated to reference the new version(s) of individual libraries.

### Release Version
Publish new version of the starter - update pom-starter.xml with versions (i.e. starter version, app, api)
``` 
BOOST_PUBLISH_TEAM_REPO_USER=dvnops BOOST_PUBLISH_TEAM_REPO_PASS=**** ./publish-pom-starter.sh
```

### Snapshot Version
Publish new version of the snapshot starter - update SNAPSHOT-pom-starter.xml with snapshot versions (i.e. starter version, app, api)
``` 
BOOST_PUBLISH_TEAM_REPO_USER=dvnops BOOST_PUBLISH_TEAM_REPO_PASS=**** ./SNAPSHOT-publish-pom-starter.sh
```

## Instructions for Publishing updated Spring Base Dependencies Ford
>**Note:** Predecessor of Spring Boot Starter Ford, still used by few teams.

After changes are made to individual libraries, and they are published to Nexus, the Spring Base Dependencies Ford needs to be updated to reference the new version(s) of individual libraries.

Publish new version of the dependencies - update pom.xml with versions (i.e. dependencies version, app, api, starter version)
``` 
BOOST_PUBLISH_TEAM_REPO_USER=dvnops BOOST_PUBLISH_TEAM_REPO_PASS=**** ./publish-pom.sh
```

## Instructions for Integration, Development, and Testing
It is helpful to integrate a local test application integrated to the local library for testing, debugging, etc...  These instructions explain how integrate without using the published jar in Nexus.

1) Clone spring-base-dependencies project
2) Build a test project to implement it
3) In the test project, update the build.gradle:
```
   //implementation 'com.ford.cloudnative:spring-boot-starter-ford:3.0.0'
   implementation 'com.ford.cloudnative:spring-base-api:3.0.0'
   implementation 'com.ford.cloudnative:spring-base-app:3.0.0'
   implementation 'com.ford.cloudnative:spring-base-test:3.0.0'
 ```
**Note:**  I had to comment out the starter and manually add the dependencies imported by the starter to get this to work.
To determine what dependencies to add, I copied the list from dependencies.gradle from the spring-base-dependencies root directory.
 
4) In the test project, update the settings.gradle to include the following:
```
includeBuild ('../spring-base-dependencies/spring-base-test') {
    dependencySubstitution { substitute module('com.ford.cloudnative:spring-base-test:3.0.0') with project(':') }
}
```

5) Rebuild the test project in IntelliJ and verify that the local version of the lib is being used.
In project view, scroll to the External Libraries.  You should see the local import before the external libraries.
 
