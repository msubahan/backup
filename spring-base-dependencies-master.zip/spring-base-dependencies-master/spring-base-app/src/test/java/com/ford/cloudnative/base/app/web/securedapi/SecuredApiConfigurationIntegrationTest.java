package com.ford.cloudnative.base.app.web.securedapi;

import com.ford.cloudnative.base.web.app.DummyApplication;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultHandlers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT, classes = DummyApplication.class,
        properties = {
                "spring.flyway.enabled=false",
                "cn.app.secured-api.enabled=true"
        })
@AutoConfigureMockMvc
public class SecuredApiConfigurationIntegrationTest {

    @Autowired
    private WebApplicationContext webApplicationContext;

    @Autowired
    MockMvc mockMvc;

    @Test
    public void should_disableTrailingSlashMatch_forValidRequestWithTrailingSlash() throws Exception {
        mockMvc.perform(MockMvcRequestBuilders.get("/dummy/"))
                .andDo(MockMvcResultHandlers.print())
                .andExpect(status().isNotFound())
                .andReturn();
    }

    @Test
    public void should_enforceStringStrictDeserialization_forValidRequestWithNonStringInput() throws Exception {
        MockMvc mockMvc = MockMvcBuilders.webAppContextSetup(webApplicationContext).build();
        mockMvc.perform(MockMvcRequestBuilders
                .post("/dummy")
                .contentType(MediaType.APPLICATION_JSON_VALUE)
                .content("{\"dummyStringField\": 123}")
        )
                .andDo(MockMvcResultHandlers.print())
                .andExpect(status().isBadRequest())
                .andReturn();
    }

    @Test
    public void should_notSupportHttpHeadMethod() throws Exception {
        mockMvc.perform(MockMvcRequestBuilders
                .head("/dummy")
        )
                .andDo(MockMvcResultHandlers.print())
                .andExpect(status().isMethodNotAllowed())
                .andReturn();
    }

    @Test
    public void should_notSupportNonCorsHttpOptionsMethod() throws Exception {
        mockMvc.perform(MockMvcRequestBuilders
                .options("/dummy")
        )
                .andDo(MockMvcResultHandlers.print())
                .andExpect(status().isMethodNotAllowed())
                .andReturn();
    }

    @Test
    public void should_supportCorsHttpOptionsMethod() throws Exception {
        mockMvc.perform(MockMvcRequestBuilders
                .options("/dummy")
                .header("Access-Control-Request-Headers", "Authorization")
                .header("Access-Control-Request-Method", "GET")
                .header("Origin", "https://api.ford.com")
        )
                .andDo(MockMvcResultHandlers.print())
                .andExpect(status().isOk())
                .andReturn();
    }
}
