package com.ford.cloudnative.base.app.web.exception;

import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.http.HttpStatus.SERVICE_UNAVAILABLE;

import java.util.Arrays;

import org.junit.Test;

import com.ford.cloudnative.base.app.web.exception.BaseBodyResponseException;

public class BaseBodyResponseExceptionTest {

	@Test
	public void testExceptionDataEncapsulation() throws Exception {
		BaseBodyResponseException exception = new BaseBodyResponseException("ERROR-MESSAGE", SERVICE_UNAVAILABLE, "ERROR-CODE");
		assertThat(exception.getMessage()).isEqualTo("ERROR-MESSAGE");
		assertThat(exception.getHttpStatus()).isEqualTo(SERVICE_UNAVAILABLE);
		assertThat(exception.getBodyResponse().getError().getErrorCode()).isEqualTo("ERROR-CODE");
		assertThat(exception.getBodyResponse().getError().getMessages()).isEqualTo(Arrays.asList("ERROR-MESSAGE"));
		assertThat(exception.getError().getErrorCode()).isEqualTo("ERROR-CODE");
		assertThat(exception.getError().getMessages()).isEqualTo(Arrays.asList("ERROR-MESSAGE"));

	}
	
}
