package com.ford.cloudnative.base.web.app;

import com.ford.cloudnative.base.api.StandardErrorResponse;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

@Validated
@RestController
@RequestMapping(path="/dummy")
@CrossOrigin(origins = "https://api.ford.com", allowedHeaders = "Authorization", methods = {RequestMethod.GET, RequestMethod.POST})
public class DummyController {

	@GetMapping(produces = {MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_PROBLEM_JSON_VALUE})
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "OK", response = String.class),
			@ApiResponse(code = 0, message = "All Errors", response = StandardErrorResponse.class)})
	public String dummyGet() {
		return "dummy-response";
	}

	@PostMapping(produces = {MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_PROBLEM_JSON_VALUE})
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Success", response = String.class),
			@ApiResponse(code = 0, message = "All Errors", response = StandardErrorResponse.class)})
	public ResponseEntity<?> dummyPost(@Valid @RequestBody DummyRequest request) {
		return ResponseEntity.ok("Success");
	}
}
