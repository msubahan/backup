package com.ford.cloudnative.base.app.web.header;

import static com.ford.cloudnative.base.app.web.header.ApplicationInfoHeaderResponseBodyAdvice.APPLICATION_INFO_HEADER_NAME;
import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;

import java.util.LinkedHashMap;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.ford.cloudnative.base.app.TestUtils;
import com.ford.cloudnative.base.app.web.header.ApplicationInfoHeaderResponseBodyAdvice;
import com.ford.cloudnative.base.web.app.DummyController;

@RunWith(SpringRunner.class)
public class ApplicationInfoHeaderResponseBodyAdviceTest {

	ApplicationInfoHeaderResponseBodyAdvice bodyAdvice;
	Map<String, String> attributes;

	@Before
	public void setup() {
		attributes = new LinkedHashMap<>();
		bodyAdvice = new ApplicationInfoHeaderResponseBodyAdvice(attributes);
	}

	@Test
	public void testWithNoBodyAdvice() throws Exception {
		MockMvc mockMvc = mockMvc();
		
		MockHttpServletResponse response = mockMvc.perform(get("/dummy")).andReturn().getResponse();
		assertThat(response.getHeader(APPLICATION_INFO_HEADER_NAME)).isNull();
	}
	
	@Test
	public void testBodyAdviceWithNoAttributes() throws Exception {
		MockMvc mockMvc = mockMvc();
		
		MockHttpServletResponse response = mockMvc.perform(get("/dummy")).andReturn().getResponse();
		assertThat(response.getHeader(APPLICATION_INFO_HEADER_NAME)).isNull();
	}

	@Test
	public void testBodyAdviceWithAttributes() throws Exception {
		MockMvc mockMvc = mockMvc("name=foo-service", "version=1.0");
		
		MockHttpServletResponse response = mockMvc.perform(get("/dummy")).andReturn().getResponse();
		assertThat(response.getHeader(APPLICATION_INFO_HEADER_NAME)).isEqualTo("name=foo-service; version=1.0;");
	}
	
	private MockMvc mockMvc(String... attributes) {
		return MockMvcBuilders
				.standaloneSetup(new DummyController())
				.setControllerAdvice(new ApplicationInfoHeaderResponseBodyAdvice(TestUtils.map(attributes)))
				.build();
	}
	
}
