package com.ford.cloudnative.base.app.web.exception.handler;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.fail;

import com.ford.cloudnative.base.app.web.exception.handler.servlet.ControllerExceptionHandler;
import com.ford.cloudnative.base.app.web.exception.handler.servlet.ErrorViewConfiguration;
import com.ford.cloudnative.base.app.web.exception.handler.servlet.FallbackErrorAttributesHandler;
import org.junit.After;
import org.junit.Test;
import org.springframework.beans.factory.NoSuchBeanDefinitionException;
import org.springframework.boot.autoconfigure.validation.ValidationAutoConfiguration;
import org.springframework.boot.autoconfigure.web.ServerProperties;
import org.springframework.boot.test.util.TestPropertyValues;
import org.springframework.web.context.support.AnnotationConfigWebApplicationContext;

public class ExceptionHandlerConfigurationTest {

    AnnotationConfigWebApplicationContext context;
	
	@After
	public void closeContext() {
		if (this.context != null)
			this.context.close();
	}

	@Test
	public void testExceptionHandlerComponentsAreNotRegisteredWithNoEnabledProperty() {
		this.context = load();
		assertBeanNotRegistered(ErrorResponseBuilder.class);
		assertBeanNotRegistered(ControllerExceptionHandler.class);
		assertBeanNotRegistered(ErrorViewConfiguration.class);
		assertBeanNotRegistered(FallbackErrorAttributesHandler.class);
	}
	
	@Test
	public void testExceptionHandlerComponentsAreNotRegisteredWithFalseEnabledProperty() {
		this.context = load("cn.app.exception-handler.enabled=false");
		assertBeanNotRegistered(ErrorResponseBuilder.class);
		assertBeanNotRegistered(ControllerExceptionHandler.class);
		assertBeanNotRegistered(ErrorViewConfiguration.class);
		assertBeanNotRegistered(FallbackErrorAttributesHandler.class);
	}
	
	@Test
	public void testExceptionHandlerComponentsAreRegisteredWithTrueEnabledProperty() {
		this.context = load("cn.app.exception-handler.enabled=true");
		assertThat(this.context.getBean(ErrorResponseBuilder.class)).isNotNull();
		assertThat(this.context.getBean(ControllerExceptionHandler.class)).isNotNull();
		assertThat(this.context.getBean(ErrorViewConfiguration.class)).isNotNull();
		assertThat(this.context.getBean(FallbackErrorAttributesHandler.class)).isNotNull();
	}
	
	void assertBeanNotRegistered(Class<?> clz) {
		try {
			this.context.getBean(clz);
			fail("Failed because not expecting a bean of class type '%s' to be registered", clz);
		} catch (NoSuchBeanDefinitionException ex) {
			//ignore
		}
	}
	
	private AnnotationConfigWebApplicationContext load(String... properties) {
		AnnotationConfigWebApplicationContext ctx = new AnnotationConfigWebApplicationContext();
		TestPropertyValues.of(properties).applyTo(ctx);
		ctx.register(ExceptionHandlerConfiguration.class);
		ctx.register(ValidationAutoConfiguration.class);
		ctx.register(ServerProperties.class);
		ctx.refresh();
		return ctx;
	}
	
}
