package com.ford.cloudnative.base.app.datasource.populate;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.After;
import org.junit.Test;
import org.springframework.beans.factory.NoSuchBeanDefinitionException;
import org.springframework.boot.test.util.TestPropertyValues;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.ford.cloudnative.base.app.datasource.populate.DataSourcePopulateConfiguration.DataSourcePopulatorInitializer;

public class DataSourcePopulateConfigurationTest {

	AnnotationConfigApplicationContext context;
	
	@After
	public void closeContext() {
		if (this.context != null)
			this.context.close();
	}

	@Test(expected = NoSuchBeanDefinitionException.class)
	public void testAdviceIsNotRegisteredWithNoEnabledProperty() {
		this.context = load();
		this.context.getBean(DataSourcePopulatorInitializer.class);
	}
	
	@Test(expected = NoSuchBeanDefinitionException.class)
	public void testAdviceIsNotRegisteredWithFalseEnabledProperty() {
		this.context = load("cn.app.datasource-populate.enabled=false");
		this.context.getBean(DataSourcePopulatorInitializer.class);
	}
	
	@Test
	public void testAdviceIsRegisteredWithTrueEnabledProperty() {
		this.context = load("cn.app.datasource-populate.enabled=true");
		assertThat(this.context.getBean(DataSourcePopulatorInitializer.class)).isNotNull();
	}
	
	private AnnotationConfigApplicationContext load(String... properties) {
		AnnotationConfigApplicationContext ctx = new AnnotationConfigApplicationContext();
		TestPropertyValues.of(properties).applyTo(ctx);
		ctx.register(DataSourcePopulateConfiguration.class);
		ctx.refresh();
		return ctx;
	}
	
}
