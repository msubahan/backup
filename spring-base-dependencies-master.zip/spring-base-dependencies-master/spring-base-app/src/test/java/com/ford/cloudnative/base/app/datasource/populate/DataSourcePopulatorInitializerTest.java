package com.ford.cloudnative.base.app.datasource.populate;

import com.ford.cloudnative.base.app.datasource.populate.DataSourcePopulateConfiguration.DataSourcePopulatorInitializer;
import com.ford.cloudnative.base.app.datasource.populate.DataSourcePopulateConfiguration.FlywayMigrator;
import org.flywaydb.core.Flyway;
import org.flywaydb.core.api.Location;
import org.flywaydb.core.api.configuration.FluentConfiguration;
import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentCaptor;
import org.springframework.context.ApplicationContext;
import org.springframework.core.io.Resource;
import org.springframework.jdbc.support.MetaDataAccessException;

import javax.sql.DataSource;
import java.io.IOException;
import java.sql.DatabaseMetaData;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Stream;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.*;

public class DataSourcePopulatorInitializerTest {

    ApplicationContext context;
    Flyway configuredFlyway;
    DataSource h2DataSource;

    @Before
    public void setup() throws Exception {
        context = mock(ApplicationContext.class, RETURNS_DEEP_STUBS);

        configuredFlyway = Flyway.configure()
                .baselineDescription("BASELINE-DESCRIPTION")
                .encoding("UTF-8")
                .schemas("SCHEMA")
                .load();

        h2DataSource = mockDataSource("jdbc:h2:~/test");
        addDataSourceBean(context, h2DataSource, "h2DataSourceBeanName");
    }

    @Test
    public void testFlywayMigratorCallsMigrate() throws Exception {
        FlywayMigrator flywayMigrator = new FlywayMigrator();
        Flyway flyway = mock(Flyway.class);

        flywayMigrator.migrate(flyway);
        verify(flyway).migrate();
    }

    @Test
    public void testDataSourceNotMigratedBecauseOfNoResourceDirectories() throws Exception {
        String[] locations = {"classpath:db-path"};

        FlywayMigrator flywayMigrator = mock(FlywayMigrator.class);
        new DataSourcePopulatorInitializer(context, configuredFlyway, flywayMigrator, locations).initialize();

        verify(flywayMigrator, never()).migrate(null);

    }

    @Test
    public void testDataSourceMigratedWithDirectoryMatchingDBProductName() throws Exception {
        String[] configuredLocations = {"classpath:db-path/{vendor}"};
        String resourceDir = "classpath:db-path/h2/*";
        String[] expectedSearchedLocations = { "classpath:db-path/h2" };

        assertThatSpecificLocationsAreSearched(configuredLocations, resourceDir, expectedSearchedLocations);
    }

    void assertThatSpecificLocationsAreSearched(String[] configuredLocations, String resourceDir, String[] expectedSearchedLocations) throws IOException, MetaDataAccessException {
        addResourceDirectory(context, resourceDir);

        FlywayMigrator flywayMigrator = mock(FlywayMigrator.class);
        new DataSourcePopulatorInitializer(context, configuredFlyway, flywayMigrator, configuredLocations).initialize();

        final ArgumentCaptor<Flyway> captor = ArgumentCaptor.forClass(Flyway.class);
        verify(flywayMigrator).migrate(captor.capture());
        Flyway actualFlyway = captor.getValue();

        assertThat(actualFlyway.getConfiguration().getDataSource()).isSameAs(h2DataSource);
        assertThat(actualFlyway.getConfiguration().getLocations()).isEqualTo(locations(expectedSearchedLocations));
    }

    @Test
    public void testDataSourceMigratedWithMultipleDirectories() throws Exception {
        String[] configuredLocations = {"classpath:db-path-2/{name}"};
        String resourceDir = "classpath:db-path-2/h2DataSourceBeanName/*";
        String[] expectedSearchedLocations = { "classpath:db-path-2/h2DataSourceBeanName" };

        assertThatSpecificLocationsAreSearched(configuredLocations, resourceDir, expectedSearchedLocations);
    }

    @Test
    public void testDataSourceMigratedWithHigherPrecedenceDirectoryMatchingDataSourceBeanName() throws Exception {
        String[] configuredLocations = {"classpath:db-path/{vendor}", "classpath:db-path/{name}"};
        String resourceDir = "classpath:db-path/h2DataSourceBeanName/*";
        String[] expectedSearchedLocations = { "classpath:db-path/h2", "classpath:db-path/h2DataSourceBeanName" };

        assertThatSpecificLocationsAreSearched(configuredLocations, resourceDir, expectedSearchedLocations);
    }

    @Test
    public void testDataSourceMigratedWithSpecificDirectory() throws Exception {
        String[] locations = {"classpath:db-path"};
        addResourceDirectory(context, "classpath:db-path/*");

        FlywayMigrator flywayMigrator = mock(FlywayMigrator.class);
        new DataSourcePopulatorInitializer(context, configuredFlyway, flywayMigrator, locations).initialize();

        final ArgumentCaptor<Flyway> captor = ArgumentCaptor.forClass(Flyway.class);
        verify(flywayMigrator).migrate(captor.capture());
        Flyway actualFlyway = captor.getValue();

        assertThat(actualFlyway.getConfiguration().getDataSource()).isSameAs(h2DataSource);
        assertThat(actualFlyway.getConfiguration().getLocations()).isEqualTo(locations("classpath:db-path"));
    }

    @Test
    public void testFlywayMigratedWithConfiguredProperties() throws Exception {
        String[] locations = {"classpath:db-path/{vendor}"};
        addResourceDirectory(context, "classpath:db-path/h2/*");

        FlywayMigrator flywayMigrator = mock(FlywayMigrator.class);
        new DataSourcePopulatorInitializer(context, configuredFlyway, flywayMigrator, locations).initialize();

        final ArgumentCaptor<Flyway> captor = ArgumentCaptor.forClass(Flyway.class);
        verify(flywayMigrator).migrate(captor.capture());
        Flyway actualFlyway = captor.getValue();

        assertThat(actualFlyway).usingRecursiveComparison().ignoringFields("configuration", "locations", "dataSource", "configurationValidator").isEqualTo(configuredFlyway);
        assertThat(actualFlyway.getConfiguration().getDataSource()).isSameAs(h2DataSource);
    }

    @Test
    public void testMultipleDataSourcesCanBeMigrated() throws Exception {
        String[] locations = {"classpath:db-path/{vendor}"};
        addResourceDirectory(context, "classpath:db-path/h2/*");
        addResourceDirectory(context, "classpath:db-path/sqlserver/*");

        DataSource sqlServerDataSource = mockDataSource("jdbc:sqlserver://host");
        addDataSourceBean(context, sqlServerDataSource, "sqlServerDataSourceBeanName");

        FlywayMigrator flywayMigrator = mock(FlywayMigrator.class);
        new DataSourcePopulatorInitializer(context, configuredFlyway, flywayMigrator, locations).initialize();

        final ArgumentCaptor<Flyway> captor = ArgumentCaptor.forClass(Flyway.class);
        verify(flywayMigrator, times(2)).migrate(captor.capture());

        Flyway actualFlyway = captor.getAllValues().get(0);
        assertThat(actualFlyway).usingRecursiveComparison().ignoringFields("configuration", "locations", "dataSource", "configurationValidator").isEqualTo(configuredFlyway);
        assertThat(actualFlyway.getConfiguration().getDataSource()).isSameAs(h2DataSource);
        assertThat(actualFlyway.getConfiguration().getLocations()).isEqualTo(locations("classpath:db-path/h2"));

        actualFlyway = captor.getAllValues().get(1);
        assertThat(actualFlyway).usingRecursiveComparison().ignoringFields("configuration", "locations", "dataSource", "configurationValidator").isEqualTo(configuredFlyway);
        assertThat(actualFlyway.getConfiguration().getDataSource()).isSameAs(sqlServerDataSource);
        assertThat(actualFlyway.getConfiguration().getLocations()).isEqualTo(locations("classpath:db-path/sqlserver"));
    }

    @Test
    public void testCaseWhenNoDataSourcesAreRegistered() throws Exception {
        context = mock(ApplicationContext.class, RETURNS_DEEP_STUBS);
        when(context.getBeanNamesForType(DataSource.class)).thenReturn(new String[0]);
        String[] locations = {"classpath:db-path"};

        FlywayMigrator flywayMigrator = mock(FlywayMigrator.class);
        new DataSourcePopulatorInitializer(context, configuredFlyway, flywayMigrator, locations).initialize();

        verify(flywayMigrator, never()).migrate(null);
    }

    @Test
    public void testTableNamePlaceholdersAreResolved() throws Exception {
        String[] locations = {"classpath:db-path/{vendor}"};
        addResourceDirectory(context, "classpath:db-path/h2/*");

        this.configuredFlyway = configuredFlywayConfig()
                .table("my_{name}_table")
                .load();

        FlywayMigrator flywayMigrator = mock(FlywayMigrator.class);
        new DataSourcePopulatorInitializer(context, configuredFlyway, flywayMigrator, locations).initialize();

        final ArgumentCaptor<Flyway> captor = ArgumentCaptor.forClass(Flyway.class);
        verify(flywayMigrator).migrate(captor.capture());
        Flyway actualFlyway = captor.getValue();

        assertThat(actualFlyway.getConfiguration().getDataSource()).isSameAs(h2DataSource);
        assertThat(actualFlyway.getConfiguration().getTable()).isEqualTo("my_h2DataSourceBeanName_table");
    }

    private void addResourceDirectory(ApplicationContext context, String locationPattern) throws IOException {
        addResourceDirectory(context, locationPattern, mock(Resource.class));
    }

    private void addResourceDirectory(ApplicationContext context, String locationPattern, Resource mock) throws IOException {
        when(context.getResources(locationPattern)).thenReturn(new Resource[]{mock});
    }

    private void addDataSourceBean(ApplicationContext context, DataSource dataSource, String beanName) {
        String[] beanNamesForType = context.getBeanNamesForType(DataSource.class);
        List<String> beanNames = beanNamesForType == null ? new ArrayList<>() : new ArrayList<>(Arrays.asList(beanNamesForType));
        beanNames.add(beanName);
        when(context.getBeanNamesForType(DataSource.class)).thenReturn(beanNames.toArray(new String[0]));
        when(context.getBean(beanName, DataSource.class)).thenReturn(dataSource);
    }

    private DataSource mockDataSource(String url) throws SQLException {
        DataSource dataSource = mock(DataSource.class, RETURNS_DEEP_STUBS);
        DatabaseMetaData databaseMetaData = mock(DatabaseMetaData.class);
        when(databaseMetaData.getURL()).thenReturn(url);
        when(dataSource.getConnection().getMetaData()).thenReturn(databaseMetaData);
        return dataSource;
    }

    private Location[] locations(String... locations) {
        return Stream.of(locations).map(Location::new).toArray(Location[]::new);
    }

    private FluentConfiguration configuredFlywayConfig() {
        return Flyway.configure().configuration(this.configuredFlyway.getConfiguration());
    }

}
