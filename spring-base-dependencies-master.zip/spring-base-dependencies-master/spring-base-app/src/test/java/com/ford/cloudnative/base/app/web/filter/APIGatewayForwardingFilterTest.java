package com.ford.cloudnative.base.app.web.filter;

import org.junit.Test;
import org.mockito.Mock;
import org.springframework.http.HttpMethod;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

import static org.assertj.core.api.Assertions.assertThat;

public class APIGatewayForwardingFilterTest {

    public static final String TEST_BASE_PATH = "/testbasepath";
    public static final String TEST_API_URI_PATH = "/api/v1/testservice";

    @Mock
    FilterChain filterChain;

    HttpServletResponse response = new MockHttpServletResponse();

    @Test
    public void should_notStripAPIGatewayBasePath_whenNotPresentInBeginning() throws ServletException, IOException {
        mockRequestAndAssertForwardedUri(TEST_BASE_PATH, TEST_API_URI_PATH + TEST_BASE_PATH, TEST_API_URI_PATH + TEST_BASE_PATH);
    }

    @Test
    public void should_applyFilterAndForwardWithBasePathStripped_whenUriHasBasePathAtBeginning() throws ServletException, IOException {
        mockRequestAndAssertForwardedUri(TEST_BASE_PATH, TEST_BASE_PATH + TEST_API_URI_PATH, TEST_API_URI_PATH);
    }

    private void mockRequestAndAssertForwardedUri(String basePath, String fullApiUriPath, String forwardedApiUriPath) throws ServletException, IOException {
        APIGatewayForwardingFilter apiGatewayForwardingFilter = new APIGatewayForwardingFilter(basePath);
        HttpServletRequest request = new MockHttpServletRequest(HttpMethod.GET.toString(), fullApiUriPath);
        apiGatewayForwardingFilter.doFilterInternal(request, response, filterChain);
        assertThat(((MockHttpServletResponse) response).getForwardedUrl()).isEqualTo(forwardedApiUriPath);
    }
}
