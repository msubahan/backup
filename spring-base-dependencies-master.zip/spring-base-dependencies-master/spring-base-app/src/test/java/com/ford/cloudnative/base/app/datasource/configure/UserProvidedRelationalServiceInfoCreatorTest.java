package com.ford.cloudnative.base.app.datasource.configure;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.*;

import java.util.HashMap;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;

import com.ford.cloudnative.base.app.datasource.configure.UserProvidedRelationalServiceInfo;
import com.ford.cloudnative.base.app.datasource.configure.UserProvidedRelationalServiceInfoCreator;
import com.ford.cloudnative.base.app.TestUtils;

public class UserProvidedRelationalServiceInfoCreatorTest {

	UserProvidedRelationalServiceInfoCreator infoCreator;
	Map<String, Object> serviceData;
	
	@Before
	public void setup() {
		infoCreator = new UserProvidedRelationalServiceInfoCreator();
		serviceData = new HashMap<>();
	}
	
	@Test
	public void testInfoCreatorShouldAcceptIfCredentialsMapContainsProperty() throws Exception {
		serviceData.put("credentials", TestUtils.map("jdbcDbUrl=JDBC-URL"));
		assertThat(infoCreator.accept(serviceData)).isTrue();
	}
	
	@Test
	public void testInfoCreatorShouldRejectsIfCredentialsMapDoesNotContainProperty() throws Exception {
		serviceData.put("credentials", TestUtils.map("jdbcUrl=JDBC-URL", "uri=URI", "host=foo"));
		assertThat(infoCreator.accept(serviceData)).isFalse();
	}
	
	@Test
	public void testInfoCreatorShouldRejectsIfCredentialsNotAMap() throws Exception {
		serviceData.put("credentials", 1);
		assertThat(infoCreator.accept(serviceData)).isFalse();
	}
	
	@Test
	public void testInfoCreatorShouldRejectsIfCredentialsDoesNotExist() throws Exception {
		assertThat(infoCreator.accept(serviceData)).isFalse();
	}
	
	@Test
	public void testCreateServiceInfo() throws Exception {
		UserProvidedRelationalServiceInfo serviceInfo = infoCreator.createServiceInfo(serviceData);
		assertThat(serviceInfo.getServiceData()).isSameAs(serviceData);
	}
	
}
