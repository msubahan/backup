package com.ford.cloudnative.base.app.web.header;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.After;
import org.junit.Test;
import org.springframework.beans.factory.NoSuchBeanDefinitionException;
import org.springframework.boot.test.util.TestPropertyValues;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.ford.cloudnative.base.app.web.tracer.DefaultRequestTracerConfiguration;

public class RequestInfoHeaderConfigurationTest {

	AnnotationConfigApplicationContext context;
	
	@After
	public void closeContext() {
		if (this.context != null)
			this.context.close();
	}

	@Test(expected = NoSuchBeanDefinitionException.class)
	public void testAdviceIsNotRegisteredWithNoEnabledProperty() {
		this.context = load();
		this.context.getBean(ApplicationInfoHeaderResponseBodyAdvice.class);
	}
	
	@Test(expected = NoSuchBeanDefinitionException.class)
	public void testAdviceIsNotRegisteredWithFalseEnabledProperty() {
		this.context = load("cn.app.request-info-header.enabled=false");
		this.context.getBean(ApplicationInfoHeaderResponseBodyAdvice.class);
	}
	
	@Test
	public void testAdviceIsRegisteredWithTrueEnabledProperty() {
		this.context = load("cn.app.request-info-header.enabled=true");
		assertThat(this.context.getBean(RequestInfoHeaderResponseBodyAdvice.class)).isNotNull();
	}
	
	@Test
	public void testAdviceIsRegisteredWithSleuthTracer() {
		this.context = load("cn.app.request-info-header.enabled=true");
		RequestInfoHeaderResponseBodyAdvice advice = this.context.getBean(RequestInfoHeaderResponseBodyAdvice.class);
		assertThat(advice).isNotNull();
		assertThat(advice.requestTracer).isNotNull();
	}
	
	private AnnotationConfigApplicationContext load(String... properties) {
		AnnotationConfigApplicationContext ctx = new AnnotationConfigApplicationContext();
		TestPropertyValues.of(properties).applyTo(ctx);
		ctx.register(DefaultRequestTracerConfiguration.class);
		ctx.register(RequestInfoHeaderConfiguration.class);
		ctx.refresh();
		return ctx;
	}
	
}
