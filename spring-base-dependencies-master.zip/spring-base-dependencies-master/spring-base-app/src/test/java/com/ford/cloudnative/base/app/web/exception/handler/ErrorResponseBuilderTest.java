package com.ford.cloudnative.base.app.web.exception.handler;

import static com.ford.cloudnative.base.app.web.exception.handler.ExceptionHandlerProperties.DEFAULT_WHITE_LIST_GENERIC_MESSAGE;
import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

import com.ford.cloudnative.base.api.ErrorResponse;
import com.ford.cloudnative.base.api.StandardErrorResponse;
import com.ford.cloudnative.base.app.web.filter.RequestFilter;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.springframework.boot.autoconfigure.web.ServerProperties;
import org.springframework.context.ApplicationContext;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.validation.BindException;
import org.springframework.validation.MapBindingResult;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.context.request.ServletWebRequest;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.server.ResponseStatusException;

import com.ford.cloudnative.base.api.BaseBodyError;
import com.ford.cloudnative.base.api.BaseBodyError.BaseBodyErrorBuilder;
import com.ford.cloudnative.base.api.BaseBodyResponse;
import com.ford.cloudnative.base.app.TestUtils;
import com.ford.cloudnative.base.app.web.exception.BaseBodyResponseException;
import com.ford.cloudnative.base.app.web.tracer.RequestTracer;

import javax.validation.Validation;

@SuppressWarnings("unchecked")
@RunWith(SpringRunner.class)
public class ErrorResponseBuilderTest {

	private static final String TRACE_ID = "TRACE-ID";
	final long START_TIME_TIMESTAMP_MS = 1234567890L;
	final long START_TIME_TIMESTAMP_SECS = 1234567L;
	final HttpStatus DEFAULT_DATA_ERRORS_HTTP_STATUS = HttpStatus.UNPROCESSABLE_ENTITY;
	
	@Mock
	RequestTracer requestTracer;
	
	ErrorResponseBuilder errorResponseBuilder;
	
	Throwable error;
	WebRequest webRequest;
	RequestWrapper requestWrapper;
    ApplicationContext ctx;


    @Before
	public void setup() {
		webRequest = new ServletWebRequest(new MockHttpServletRequest());
		webRequest.setAttribute(RequestFilter.START_TIME_ATTRIBUTE, START_TIME_TIMESTAMP_MS, WebRequest.SCOPE_REQUEST);
		requestWrapper = new RequestWrapper.WebRequestWrapper(webRequest);

		when(requestTracer.getTraceId()).thenReturn(TRACE_ID);
		
		error = new IllegalArgumentException("ERROR-MESSAGE");

        ctx = mock(ApplicationContext.class);
        when(ctx.getBean(RequestTracer.class)).thenReturn(requestTracer);
        ExceptionHandlerProperties properties = new ExceptionHandlerProperties();
        properties.setUseBaseBodyResponse(true);
        properties.setUseEmptyValues(true);
        properties.getDataErrors().setIncludeCode(true);
        properties.getDataErrors().setIncludeValue(true);
        properties.getMessages().getWhiteList().setExceptions(Arrays.asList("**"));
        properties.getAttributes().setIncludeException(true);
        properties.getDataErrors().setStatusCode(DEFAULT_DATA_ERRORS_HTTP_STATUS.value());
        errorResponseBuilder = new ErrorResponseBuilder(ctx, new ServerProperties(), properties, new DefaultExceptionHandler(properties), Validation.buildDefaultValidatorFactory());
	}

	@Test
	public void testPopulateAttributes() throws Exception {
		Map<String, String> modifyAttributes = TestUtils.map("a=1","b=2");
		errorResponseBuilder.populateCommonAttributes((Map<String,Object>)(Map<String,?>)modifyAttributes, error, requestWrapper);
		
		Map<String, Object> expectedAttributes = (Map<String, Object>)(Map<String, ?>)TestUtils.map("a=1","b=2","exception=" + error.getClass().getName(),"referenceId=" + TRACE_ID);
		expectedAttributes.put("timestamp", START_TIME_TIMESTAMP_SECS);
		
		assertThat(modifyAttributes).isEqualTo(expectedAttributes);
	}
	
	@Test
	public void testBuildWithAttributes() throws Exception {
		BaseBodyErrorBuilder builder = errorResponseBuilder.buildWithCommonAttributes(error, requestWrapper);
		
		Map<String, Object> expectedAttributes = (Map<String, Object>)(Map<String, ?>)TestUtils.map("exception=" + error.getClass().getName(),"referenceId=" + TRACE_ID);
		expectedAttributes.put("timestamp", START_TIME_TIMESTAMP_SECS);
		
		assertThat(builder.build().getAttributes()).isEqualTo(expectedAttributes);
	}
	

    @Test
    public void testBuildResponseWithBaseBodyResponseException() throws Exception {
        BaseBodyResponseException ex = new BaseBodyResponseException("MESSAGE", HttpStatus.CONFLICT, "ERROR-CODE");
        
        ResponseEntity<ErrorResponse> buildErrorResponse = errorResponseBuilder.buildResponseEntity(ex, webRequest);
        
        BaseBodyError actualError = buildErrorResponse.getBody().getError();
        assertThat(actualError.getErrorCode()).isEqualTo("ERROR-CODE");
        assertThat(actualError.getMessages()).isEqualTo(new ArrayList<>(Arrays.asList("MESSAGE")));
        assertThat(actualError.getDataErrors()).isEmpty();
        assertThat(actualError.getAttributes()).hasSize(3);
        assertThat(actualError.getAttributes()).containsEntry("exception", ex.getClass().getName());
        assertThat(actualError.getAttributes()).containsEntry("timestamp", (long)START_TIME_TIMESTAMP_MS/1000);
        assertThat(actualError.getAttributes()).containsEntry("referenceId", TRACE_ID);
        
        assertThat(buildErrorResponse.getStatusCode()).isEqualTo(ex.getHttpStatus());
    }
    
    @Test
    public void testBuildResponseWithResponseStatusException() throws Exception {
        HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.add("X-HEADER1","value1");
        httpHeaders.add("X-HEADER2","value2");

        ResponseStatusException ex = new ResponseStatusException(HttpStatus.CONFLICT, "REASON", new RuntimeException("MESSAGE-SHOULD-BE-IGNORED")) {
            public HttpHeaders getResponseHeaders() { return httpHeaders; }
        };
        
        ResponseEntity<ErrorResponse> buildErrorResponse = errorResponseBuilder.buildResponseEntity(ex, webRequest);
        
        BaseBodyError actualError = buildErrorResponse.getBody().getError();
        assertThat(actualError.getErrorCode()).isNull();
        assertThat(actualError.getMessages()).isEqualTo(new ArrayList<>(Arrays.asList("REASON")));
        assertThat(actualError.getDataErrors()).isEmpty();
        assertThat(actualError.getAttributes()).hasSize(3);
        assertThat(actualError.getAttributes()).containsEntry("exception", ex.getClass().getName());
        assertThat(actualError.getAttributes()).containsEntry("timestamp", (long)START_TIME_TIMESTAMP_MS/1000);
        assertThat(actualError.getAttributes()).containsEntry("referenceId", TRACE_ID);
        
        assertThat(buildErrorResponse.getStatusCode()).isEqualTo(ex.getStatus());
        assertThat(buildErrorResponse.getHeaders()).isEqualTo(httpHeaders);
    }
    
    @Test
    public void testBuildResponseWithResponseStatusExceptionNoReason() throws Exception {
        ResponseStatusException ex = new ResponseStatusException(HttpStatus.CONFLICT, "", new RuntimeException("MESSAGE"));
        
        ResponseEntity<ErrorResponse> buildErrorResponse = errorResponseBuilder.buildResponseEntity(ex, webRequest);
        
        BaseBodyError actualError = buildErrorResponse.getBody().getError();
        assertThat(actualError.getErrorCode()).isNull();
        assertThat(actualError.getMessages().get(0)).contains("MESSAGE");
        assertThat(actualError.getDataErrors()).isEmpty();
        assertThat(actualError.getAttributes()).hasSize(3);
        assertThat(actualError.getAttributes()).containsEntry("exception", ex.getClass().getName());
        assertThat(actualError.getAttributes()).containsEntry("timestamp", (long)START_TIME_TIMESTAMP_MS/1000);
        assertThat(actualError.getAttributes()).containsEntry("referenceId", TRACE_ID);
        
        assertThat(buildErrorResponse.getStatusCode()).isEqualTo(ex.getStatus());
    }
    
    
    @Test
    public void testBuildResponseWithMethodArgumentNotValidException() throws Exception {
        MapBindingResult bindingResult = new MapBindingResult(new HashMap<>(), "objectName");
        bindingResult.rejectValue("field1", "errorCode1", "defaultMessage1");
        bindingResult.rejectValue("field2", "errorCode2", "defaultMessage2");
        MethodArgumentNotValidException ex = new MethodArgumentNotValidException(null, bindingResult);
        
        ResponseEntity<ErrorResponse> buildErrorResponse = errorResponseBuilder.buildResponseEntity(ex, webRequest);

        BaseBodyError actualError = buildErrorResponse.getBody().getError();
        assertThat(actualError.getErrorCode()).isNull();
        assertThat(actualError.getMessages().get(0)).contains("Error count: 2");
        assertThat(actualError.getDataErrors().size()).isEqualTo(2);
        assertThat(actualError.getDataErrors().get(0).getName()).isEqualTo("field1");
        assertThat(actualError.getDataErrors().get(0).getCode()).isEqualTo("errorCode1");
        assertThat(actualError.getDataErrors().get(0).getMessage()).isEqualTo("defaultMessage1");
        assertThat(actualError.getDataErrors().get(1).getName()).isEqualTo("field2");
        assertThat(actualError.getDataErrors().get(1).getCode()).isEqualTo("errorCode2");
        assertThat(actualError.getDataErrors().get(1).getMessage()).isEqualTo("defaultMessage2");
        assertThat(actualError.getAttributes()).hasSize(3);
        assertThat(actualError.getAttributes()).containsEntry("exception", ex.getClass().getName());
        assertThat(actualError.getAttributes()).containsEntry("timestamp", (long)START_TIME_TIMESTAMP_MS/1000);
        assertThat(actualError.getAttributes()).containsEntry("referenceId", TRACE_ID);

        assertThat(buildErrorResponse.getStatusCode()).isEqualTo(DEFAULT_DATA_ERRORS_HTTP_STATUS);
    }

    @Test
    public void testBuildResponseWithBindingResult() throws Exception {
        MapBindingResult bindingResult = new MapBindingResult(new HashMap<>(), "objectName");
        bindingResult.rejectValue("field1", "errorCode1", "defaultMessage1");
        bindingResult.rejectValue("field2", "errorCode2", "defaultMessage2");
        BindException ex = new BindException(bindingResult);

        ResponseEntity<ErrorResponse> buildErrorResponse = errorResponseBuilder.buildResponseEntity(ex, webRequest);

        BaseBodyError actualError = buildErrorResponse.getBody().getError();
        assertThat(actualError.getErrorCode()).isNull();
        assertThat(actualError.getMessages().get(0)).contains("Error count: 2");
        assertThat(actualError.getDataErrors().size()).isEqualTo(2);
        assertThat(actualError.getDataErrors().get(0).getName()).isEqualTo("field1");
        assertThat(actualError.getDataErrors().get(0).getCode()).isEqualTo("errorCode1");
        assertThat(actualError.getDataErrors().get(0).getMessage()).isEqualTo("defaultMessage1");
        assertThat(actualError.getDataErrors().get(1).getName()).isEqualTo("field2");
        assertThat(actualError.getDataErrors().get(1).getCode()).isEqualTo("errorCode2");
        assertThat(actualError.getDataErrors().get(1).getMessage()).isEqualTo("defaultMessage2");
        assertThat(actualError.getAttributes()).hasSize(3);
        assertThat(actualError.getAttributes()).containsEntry("exception", ex.getClass().getName());
        assertThat(actualError.getAttributes()).containsEntry("timestamp", (long)START_TIME_TIMESTAMP_MS/1000);
        assertThat(actualError.getAttributes()).containsEntry("referenceId", TRACE_ID);

        assertThat(buildErrorResponse.getStatusCode()).isEqualTo(DEFAULT_DATA_ERRORS_HTTP_STATUS);
    }
	
    @Test
    public void testBuildResponseWithGeneralException() throws Exception {
        RuntimeException ex = new RuntimeException("MESSAGE");
        
        ResponseEntity<ErrorResponse> buildErrorResponse = errorResponseBuilder.buildResponseEntity(ex, webRequest);
        
        BaseBodyError actualError = buildErrorResponse.getBody().getError();
        assertThat(actualError.getErrorCode()).isNull();
        assertThat(actualError.getMessages().get(0)).contains("MESSAGE");
        assertThat(actualError.getDataErrors()).isEmpty();
        assertThat(actualError.getAttributes()).hasSize(3);
        assertThat(actualError.getAttributes()).containsEntry("exception", ex.getClass().getName());
        assertThat(actualError.getAttributes()).containsEntry("timestamp", (long)START_TIME_TIMESTAMP_MS/1000);
        assertThat(actualError.getAttributes()).containsEntry("referenceId", TRACE_ID);
        
        assertThat(buildErrorResponse.getStatusCode()).isEqualTo(HttpStatus.INTERNAL_SERVER_ERROR);
    }
    
    @Test
    public void testBuildResponseWithCustomExceptionWithResponseStatus() throws Exception {
        CustomExceptionWithResponseStatus ex = new CustomExceptionWithResponseStatus("MESSAGE");
        
        ResponseEntity<ErrorResponse> buildErrorResponse = errorResponseBuilder.buildResponseEntity(ex, webRequest);
        
        BaseBodyError actualError = buildErrorResponse.getBody().getError();
        assertThat(actualError.getErrorCode()).isNull();
        assertThat(actualError.getMessages().get(0)).isEqualTo("REASON");
        assertThat(actualError.getDataErrors()).isEmpty();
        assertThat(actualError.getAttributes()).hasSize(3);
        assertThat(actualError.getAttributes()).containsEntry("exception", ex.getClass().getName());
        assertThat(actualError.getAttributes()).containsEntry("timestamp", (long)START_TIME_TIMESTAMP_MS/1000);
        assertThat(actualError.getAttributes()).containsEntry("referenceId", TRACE_ID);
        
        assertThat(buildErrorResponse.getStatusCode()).isEqualTo(HttpStatus.SERVICE_UNAVAILABLE);
    }
    
    @Test
    public void testBuildResponseWithCustomExceptionWithResponseStatusNoReason() throws Exception {
        CustomExceptionWithResponseStatusNoReason ex = new CustomExceptionWithResponseStatusNoReason("MESSAGE");
        
        ResponseEntity<ErrorResponse> buildErrorResponse = errorResponseBuilder.buildResponseEntity(ex, webRequest);
        
        BaseBodyError actualError = buildErrorResponse.getBody().getError();
        assertThat(actualError.getErrorCode()).isNull();
        assertThat(actualError.getMessages().get(0)).isEqualTo("MESSAGE");
        assertThat(actualError.getDataErrors()).isEmpty();
        assertThat(actualError.getAttributes()).hasSize(3);
        assertThat(actualError.getAttributes()).containsEntry("exception", ex.getClass().getName());
        assertThat(actualError.getAttributes()).containsEntry("timestamp", (long)START_TIME_TIMESTAMP_MS/1000);
        assertThat(actualError.getAttributes()).containsEntry("referenceId", TRACE_ID);
        
        assertThat(buildErrorResponse.getStatusCode()).isEqualTo(HttpStatus.SERVICE_UNAVAILABLE);
    }

    @Test
    public void testBuildResponseWithCustomResponseStatusExceptionWithResponseStatus() throws Exception {
        CustomResponseStatusException ex = new CustomResponseStatusException(HttpStatus.BAD_GATEWAY, "MESSAGE");

        ResponseEntity<ErrorResponse> buildErrorResponse = errorResponseBuilder.buildResponseEntity(ex, webRequest);

        BaseBodyError actualError = buildErrorResponse.getBody().getError();
        assertThat(actualError.getErrorCode()).isNull();
        assertThat(actualError.getMessages().get(0)).isEqualTo("MESSAGE");
        assertThat(actualError.getDataErrors()).isEmpty();
        assertThat(actualError.getAttributes()).hasSize(3);
        assertThat(actualError.getAttributes()).containsEntry("exception", ex.getClass().getName());
        assertThat(actualError.getAttributes()).containsEntry("timestamp", (long)START_TIME_TIMESTAMP_MS/1000);
        assertThat(actualError.getAttributes()).containsEntry("referenceId", TRACE_ID);

        assertThat(buildErrorResponse.getStatusCode()).isEqualTo(HttpStatus.BAD_GATEWAY);
    }

    @Test
    public void testBaseBodyResponseReturned() throws Exception {
        ExceptionHandlerProperties properties = new ExceptionHandlerProperties();
        properties.setUseBaseBodyResponse(true);
        properties.getAttributes().setIncludeException(true);
        errorResponseBuilder = new ErrorResponseBuilder(ctx, new ServerProperties(), properties, new DefaultExceptionHandler(properties), Validation.buildDefaultValidatorFactory());

        ResponseEntity<?> response = errorResponseBuilder.buildResponseEntity(new RuntimeException("TEST"), webRequest);
        assertThat(response.getBody()).isNotNull();
        assertThat(response.getBody()).isInstanceOf(BaseBodyResponse.class);
    }

    @Test
    public void testPopulatedStandardErrorResponseReturned() throws Exception {
        ExceptionHandlerProperties properties = new ExceptionHandlerProperties();
        properties.setUseBaseBodyResponse(false);
        properties.getAttributes().setIncludeException(true);
        properties.getMessages().getWhiteList().setExceptions(Arrays.asList("-none-"));
        errorResponseBuilder = new ErrorResponseBuilder(ctx, new ServerProperties(), properties, new DefaultExceptionHandler(properties), Validation.buildDefaultValidatorFactory());

        RuntimeException exception = new RuntimeException("TEST");
        ResponseEntity<?> response = errorResponseBuilder.buildResponseEntity(exception, webRequest);
        assertThat(response.getBody()).isNotNull();
        assertThat(response.getBody()).isInstanceOf(StandardErrorResponse.class);
        StandardErrorResponse standardErrorResponse = (StandardErrorResponse) response.getBody();
        assertThat(standardErrorResponse.getType()).isEqualTo(StandardErrorResponse.ERROR_TYPE);
        assertThat(standardErrorResponse.getTitle()).isNotBlank();
        assertThat(standardErrorResponse.getStatus()).isEqualTo(HttpStatus.INTERNAL_SERVER_ERROR.value());
        assertThat(standardErrorResponse.getTitle()).isNotBlank();
        assertThat(standardErrorResponse.getError()).isNotNull();
        assertThat(standardErrorResponse.getError().getAttributes()).containsEntry("exception", exception.getClass().getName());
        assertThat(standardErrorResponse.getError().getMessages()).hasSameElementsAs(Arrays.asList(DEFAULT_WHITE_LIST_GENERIC_MESSAGE));
    }


    @ResponseStatus(value=HttpStatus.SERVICE_UNAVAILABLE, reason = "REASON")
    public static class CustomExceptionWithResponseStatus extends RuntimeException {
        public CustomExceptionWithResponseStatus(String msg) {
            super(msg);
        }
    }
    
    @ResponseStatus(value=HttpStatus.SERVICE_UNAVAILABLE, reason = "")
    public static class CustomExceptionWithResponseStatusNoReason extends RuntimeException {
        public CustomExceptionWithResponseStatusNoReason(String msg) {
            super(msg);
        }
    }

    @ResponseStatus(value=HttpStatus.SERVICE_UNAVAILABLE, reason = "THIS ANNOTATION SHOULD BE IGNORED")
    public static class CustomResponseStatusException extends ResponseStatusException {
        public CustomResponseStatusException(HttpStatus httpStatus, String reason) {
            super(httpStatus, reason);
        }
    }

}
