package com.ford.cloudnative.base.app.web.exception.handler;

import com.ford.cloudnative.base.web.app.DummyApplication;
import com.jayway.jsonpath.DocumentContext;
import com.jayway.jsonpath.JsonPath;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;

import static org.assertj.core.api.Assertions.assertThat;

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = WebEnvironment.RANDOM_PORT, classes = DummyApplication.class,
        properties = {
            "spring.flyway.enabled=false",
            "cn.app.exception-handler.enabled=true"
        })
public class ErrorIntegrationTest {

    @Autowired
    TestRestTemplate restTemplate;

    @Test
    public void testInvalidURLReturns404() throws Exception {
        ResponseEntity<String> responseEntity = restTemplate.getForEntity("/does-not-exist", String.class);
        DocumentContext json = JsonPath.parse(responseEntity.getBody());

        assertThat(responseEntity.getStatusCode()).isEqualTo(HttpStatus.NOT_FOUND);
        assertThat(responseEntity.getHeaders().getContentType()).isEqualTo(MediaType.APPLICATION_PROBLEM_JSON);
        assertThat(json.read("$.status", Integer.class)).isEqualTo(404);
    }

}
