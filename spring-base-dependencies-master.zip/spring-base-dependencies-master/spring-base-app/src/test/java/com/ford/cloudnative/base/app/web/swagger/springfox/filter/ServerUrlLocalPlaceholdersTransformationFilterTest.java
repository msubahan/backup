package com.ford.cloudnative.base.app.web.swagger.springfox.filter;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.servers.Server;
import org.junit.Before;
import org.junit.Test;
import org.springframework.mock.web.MockHttpServletRequest;
import springfox.documentation.oas.web.OpenApiTransformationContext;

import java.util.ArrayList;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class ServerUrlLocalPlaceholdersTransformationFilterTest {

    OpenApiTransformationContext context;
    OpenAPI openApi;
    MockHttpServletRequest request;

    @Before
    public void setup() {
        openApi = new OpenAPI();
        openApi.setServers(new ArrayList<>());
        request = new MockHttpServletRequest();

        context = mock(OpenApiTransformationContext.class);
        when(context.getSpecification()).thenReturn(openApi);
        when(context.request()).thenReturn(Optional.of(request));
    }

    @Test
    @SuppressWarnings("unchecked")
    public void transform() {
        Server server1 = new Server().url("{scheme}://{host}:{port}");
        openApi.getServers().add(server1);

        Server server2 = new Server().url("{scheme}-xyz-{port}");
        openApi.getServers().add(server2);

        request.setScheme("ftp");
        request.setServerName("my-server");
        request.setServerPort(8888);

        new ServerUrlLocalPlaceholdersTransformationFilter().transform(context);
        assertThat(server1.getUrl()).isEqualTo("ftp://my-server:8888");
        assertThat(server2.getUrl()).isEqualTo("ftp-xyz-8888");
    }
}
