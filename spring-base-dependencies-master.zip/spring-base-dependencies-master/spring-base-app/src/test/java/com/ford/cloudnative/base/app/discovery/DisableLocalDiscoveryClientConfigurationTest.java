package com.ford.cloudnative.base.app.discovery;

import org.junit.After;
import org.junit.Test;
import org.springframework.beans.factory.NoSuchBeanDefinitionException;
import org.springframework.boot.test.util.TestPropertyValues;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class DisableLocalDiscoveryClientConfigurationTest {

    AnnotationConfigApplicationContext context;

    @After
    public void closeContext() {
        if (this.context != null)
            this.context.close();
    }

    @Test
    @SuppressWarnings("squid:S2699")
    public void should_registerDisableLocalDiscoveryClientConfigurationBean_whenDisableLocalDiscoveryIsEnabled() {
        this.context = load(DisableLocalDiscoveryClientConfiguration.class, "cn.app.disable-local-discovery-client.enabled=true");
        this.context.getBean(DisableLocalDiscoveryClientConfiguration.class);
    }

    @Test(expected = NoSuchBeanDefinitionException.class)
    @SuppressWarnings("squid:S2699")
    public void should_notRegisterDisableLocalDiscoveryClientConfigurationBean_whenDisableLocalDiscoveryIsDisabled() {
        this.context = load(DisableLocalDiscoveryClientConfiguration.class, "cn.app.disable-local-discovery-client.enabled=false");
        this.context.getBean(DisableLocalDiscoveryClientConfiguration.class);
    }

    private <R> AnnotationConfigApplicationContext load(Class<R> clazz, String... properties) {
        AnnotationConfigApplicationContext ctx = new AnnotationConfigApplicationContext();
        TestPropertyValues.of(properties).applyTo(ctx);
        ctx.register(clazz);
        ctx.refresh();
        return ctx;
    }
}
