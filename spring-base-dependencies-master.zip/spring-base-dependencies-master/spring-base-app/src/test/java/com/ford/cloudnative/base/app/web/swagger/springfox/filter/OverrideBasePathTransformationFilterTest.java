package com.ford.cloudnative.base.app.web.swagger.springfox.filter;

import com.ford.cloudnative.base.app.web.swagger.SwaggerProperties;
import io.swagger.models.Swagger;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;
import springfox.documentation.swagger2.web.SwaggerTransformationContext;

import static org.assertj.core.api.Assertions.assertThat;

public class OverrideBasePathTransformationFilterTest {

    SwaggerTransformationContext context;
    Swagger swagger;
    SwaggerProperties properties;

    @Before
    public void setup() {
        swagger = new Swagger();
        properties = new SwaggerProperties();

        context = Mockito.mock(SwaggerTransformationContext.class);
        Mockito.when(context.getSpecification()).thenReturn(swagger);
    }

    @Test
    @SuppressWarnings("unchecked")
    public void transformWithNoBasePathSet() {
        OverrideBasePathTransformationFilter filter = new OverrideBasePathTransformationFilter(properties);

        assertThat(swagger.getBasePath()).isNull();
        filter.transform(context);
        assertThat(swagger.getBasePath()).isNull();
    }

    @Test
    @SuppressWarnings("unchecked")
    public void transformWithBasePathSet() {
        OverrideBasePathTransformationFilter filter = new OverrideBasePathTransformationFilter(properties);
        properties.getApidoc().setBasePath("/override");

        assertThat(swagger.getBasePath()).isNull();
        filter.transform(context);
        assertThat(swagger.getBasePath()).isEqualTo("/override");
    }

}
