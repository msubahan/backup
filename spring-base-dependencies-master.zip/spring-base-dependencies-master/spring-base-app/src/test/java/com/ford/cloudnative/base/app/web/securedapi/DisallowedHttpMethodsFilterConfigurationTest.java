package com.ford.cloudnative.base.app.web.securedapi;

import io.swagger.models.HttpMethod;
import org.junit.After;
import org.junit.Test;
import org.springframework.beans.factory.NoSuchBeanDefinitionException;
import org.springframework.boot.test.util.TestPropertyValues;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import javax.servlet.Filter;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

public class DisallowedHttpMethodsFilterConfigurationTest {

    AnnotationConfigApplicationContext context;

    @After
    public void closeContext() {
        if (this.context != null)
            this.context.close();
    }

    @Test(expected = NoSuchBeanDefinitionException.class)
    public void should_notRegisterDisallowedHttpMethodsFilterConfigurationBean_whenParentPropertyConfiguration_isMissing() {
        this.context = load();
        this.context.getBean(DisallowedHttpMethodsFilterConfiguration.class);
    }

    @Test(expected = NoSuchBeanDefinitionException.class)
    public void should_notRegisterDisallowedHttpMethodsFilterConfigurationBean_whenParentPropertyConfiguration_isDisabled() {
        this.context = load("cn.app.secured-api.enabled=false");
        this.context.getBean(DisallowedHttpMethodsFilterConfiguration.class);
    }

    @Test
    public void should_listHeadAndNonCorsOptionsAsDisallowedHttpMethods_whenParentPropertyConfiguration_isEnabled_andIndividualProperties_AreMissing() {
        this.context = load("cn.app.secured-api.enabled=true");
        DisallowedHttpMethodsFilterConfiguration config = this.context.getBean(DisallowedHttpMethodsFilterConfiguration.class);
        assertThat(config).isNotNull();
        assertDisallowedHttpMethodsFilterRegistration();
        assertTrue(config.disallowedHttpMethods().contains(HttpMethod.HEAD.name()));
        assertTrue(config.disallowedHttpMethods().contains(HttpMethod.OPTIONS.name()));
    }

    @Test
    public void should_listHeadAndNonCorsOptionsAsDisallowedHttpMethods_whenParentPropertyConfiguration_isEnabled_andIndividualProperties_AreEnabled() {
        this.context = load("cn.app.secured-api.enabled=true",
                "cn.app.secured-api.http-method.disallow-head=true",
                "cn.app.secured-api.http-method.disallow-options-for-non-cors=true"
        );
        DisallowedHttpMethodsFilterConfiguration config = this.context.getBean(DisallowedHttpMethodsFilterConfiguration.class);
        assertThat(config).isNotNull();
        assertDisallowedHttpMethodsFilterRegistration();
        assertTrue(config.disallowedHttpMethods().contains(HttpMethod.HEAD.name()));
        assertTrue(config.disallowedHttpMethods().contains(HttpMethod.OPTIONS.name()));
    }

    @Test
    public void should_listHeadAndNonCorsOptionsAsSupportedHttpMethods_whenParentPropertyConfiguration_isEnabled_andIndividualProperties_AreDisabled() {
        this.context = load("cn.app.secured-api.enabled=true",
                "cn.app.secured-api.http-method.disallow-head=false",
                "cn.app.secured-api.http-method.disallow-options-for-non-cors=false"
        );
        DisallowedHttpMethodsFilterConfiguration config = this.context.getBean(DisallowedHttpMethodsFilterConfiguration.class);
        assertThat(config).isNotNull();
        assertDisallowedHttpMethodsFilterRegistration();
        assertFalse(config.disallowedHttpMethods().contains(HttpMethod.HEAD.name()));
        assertFalse(config.disallowedHttpMethods().contains(HttpMethod.OPTIONS.name()));
    }


    private void assertDisallowedHttpMethodsFilterRegistration() {
        FilterRegistrationBean filterRegistrationBean = this.context.getBean(FilterRegistrationBean.class);
        assertThat(filterRegistrationBean).isNotNull();
        Filter filter = filterRegistrationBean.getFilter();
        assertThat(filter.getClass()).isEqualTo(DisallowedHttpMethodsFilterConfiguration.DisallowedHttpMethodsFilter.class);
    }

    private AnnotationConfigApplicationContext load(String... properties) {
        AnnotationConfigApplicationContext ctx = new AnnotationConfigApplicationContext();
        TestPropertyValues.of(properties).applyTo(ctx);
        ctx.register(SecuredApiConfiguration.class);
        ctx.refresh();
        return ctx;
    }
}
