package com.ford.cloudnative.base.app.web.header;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.After;
import org.junit.Test;
import org.springframework.beans.factory.NoSuchBeanDefinitionException;
import org.springframework.boot.test.util.TestPropertyValues;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class ApplicationInfoHeaderConfigurationTest {

	AnnotationConfigApplicationContext context;
	
	@After
	public void closeContext() {
		if (this.context != null)
			this.context.close();
	}

	@Test(expected = NoSuchBeanDefinitionException.class)
	public void testAdviceIsNotRegisteredWithNoEnabledProperty() {
		this.context = load();
		this.context.getBean(ApplicationInfoHeaderResponseBodyAdvice.class);
	}
	
	@Test(expected = NoSuchBeanDefinitionException.class)
	public void testAdviceIsNotRegisteredWithFalseEnabledProperty() {
		this.context = load("cn.app.application-info-header.enabled=false");
		this.context.getBean(ApplicationInfoHeaderResponseBodyAdvice.class);
	}
	
	@Test
	public void testAdviceIsRegisteredWithTrueEnabledProperty() {
		this.context = load("cn.app.application-info-header.enabled=true");
		assertThat(this.context.getBean(ApplicationInfoHeaderResponseBodyAdvice.class)).isNotNull();
	}
	
	@Test
	public void testAdviceIsRegisteredWithCorrectProperties() {
		this.context = load(
				"cn.app.application-info-header.enabled=true",
				"cn.app.application-info-header.attributes.foo=bar"
				);
		ApplicationInfoHeaderResponseBodyAdvice advice = this.context.getBean(ApplicationInfoHeaderResponseBodyAdvice.class);
		assertThat(advice).isNotNull();
		assertThat(advice.headerValue).isEqualTo("foo=bar;");
	}
	
	private AnnotationConfigApplicationContext load(String... properties) {
		AnnotationConfigApplicationContext ctx = new AnnotationConfigApplicationContext();
		TestPropertyValues.of(properties).applyTo(ctx);
		ctx.register(ApplicationInfoHeaderConfiguration.class);
		ctx.refresh();
		return ctx;
	}
}
