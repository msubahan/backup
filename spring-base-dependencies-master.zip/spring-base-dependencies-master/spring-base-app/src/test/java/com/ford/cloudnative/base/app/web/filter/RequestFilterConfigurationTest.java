package com.ford.cloudnative.base.app.web.filter;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.Map;

import javax.servlet.FilterRegistration;

import org.junit.Test;
import org.springframework.boot.autoconfigure.web.servlet.ServletWebServerFactoryAutoConfiguration;
import org.springframework.boot.test.util.TestPropertyValues;
import org.springframework.boot.web.servlet.context.AnnotationConfigServletWebServerApplicationContext;

public class RequestFilterConfigurationTest {

	@Test
	public void testRequestFilterGetsRegistered() {
		try (AnnotationConfigServletWebServerApplicationContext context = new AnnotationConfigServletWebServerApplicationContext()) {
			TestPropertyValues.of("server.port=0").applyTo(context);
			context.register(ServletWebServerFactoryAutoConfiguration.class, RequestFilterConfiguration.class);
			context.refresh();
			
			Map<String, ? extends FilterRegistration> filterRegistrations = context.getServletContext().getFilterRegistrations();
			assertThat(filterRegistrations).containsKey("requestFilter");
			assertThat(filterRegistrations.get("requestFilter").getClassName()).isEqualTo(RequestFilter.class.getName());
		}
	}
}
