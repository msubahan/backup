package com.ford.cloudnative.base.app.web.securedapi;

import org.junit.After;
import org.junit.Test;
import org.springframework.beans.factory.NoSuchBeanDefinitionException;
import org.springframework.boot.test.util.TestPropertyValues;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import static org.assertj.core.api.Assertions.assertThat;

public class DisableTrailingSlashMatchConfigurationTest {

    AnnotationConfigApplicationContext context;

    @After
    public void closeContext() {
        if (this.context != null)
            this.context.close();
    }

    @Test(expected = NoSuchBeanDefinitionException.class)
    public void should_notRegisterDisableTrailingSlashMatchConfigurationBean_whenParentPropertyConfiguration_isMissing() {
        this.context = load();
        this.context.getBean(DisableTrailingSlashMatchConfiguration.class);
    }

    @Test(expected = NoSuchBeanDefinitionException.class)
    public void should_notRegisterDisableTrailingSlashMatchConfigurationBean_whenParentPropertyConfiguration_isDisabled() {
        this.context = load("cn.app.secured-api.enabled=false");
        this.context.getBean(DisableTrailingSlashMatchConfiguration.class);
    }

    @Test
    public void should_registerDisableTrailingSlashMatchConfigurationBean_whenParentPropertyConfiguration_isEnabled_andIndividualPropertyConfiguration_isMissing() {
        this.context = load("cn.app.secured-api.enabled=true");
        assertThat(this.context.getBean(DisableTrailingSlashMatchConfiguration.class)).isNotNull();
    }

    @Test(expected = NoSuchBeanDefinitionException.class)
    public void should_notRegisterDisableTrailingSlashMatchConfigurationBean_whenParentPropertyConfiguration_isEnabled_butIndividualPropertyConfiguration_isDisabled() {
        this.context = load("cn.app.secured-api.enabled=true",
                "cn.app.secured-api.path-match.use-trailing-slash-match=false"
        );
        this.context.getBean(DisableTrailingSlashMatchConfiguration.class);
    }

    @Test(expected = NoSuchBeanDefinitionException.class)
    public void should_notRegisterDisableTrailingSlashMatchConfigurationBean_whenParentPropertyConfiguration_isDisabled_butIndividualPropertyConfiguration_isEnabled() {
        this.context = load("cn.app.secured-api.enabled=false",
                "cn.app.secured-api.path-match.use-trailing-slash-match=true"
        );
        this.context.getBean(DisableTrailingSlashMatchConfiguration.class);
    }

    @Test
    public void should_registerDisableTrailingSlashMatchConfigurationBean_whenParentPropertyConfiguration_isEnabled_andIndividualPropertyConfiguration_isEnabled() {
        this.context = load("cn.app.secured-api.enabled=true",
                "cn.app.secured-api.path-match.use-trailing-slash-match=true"
        );
        assertThat(this.context.getBean(DisableTrailingSlashMatchConfiguration.class)).isNotNull();
    }

    private AnnotationConfigApplicationContext load(String... properties) {
        AnnotationConfigApplicationContext ctx = new AnnotationConfigApplicationContext();
        TestPropertyValues.of(properties).applyTo(ctx);
        ctx.register(SecuredApiConfiguration.class);
        ctx.refresh();
        return ctx;
    }
}
