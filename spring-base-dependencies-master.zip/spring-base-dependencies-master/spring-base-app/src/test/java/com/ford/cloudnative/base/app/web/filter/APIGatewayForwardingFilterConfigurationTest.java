package com.ford.cloudnative.base.app.web.filter;

import org.junit.After;
import org.junit.Test;
import org.springframework.beans.factory.NoSuchBeanDefinitionException;
import org.springframework.boot.autoconfigure.context.PropertyPlaceholderAutoConfiguration;
import org.springframework.boot.autoconfigure.web.servlet.ServletWebServerFactoryAutoConfiguration;
import org.springframework.boot.autoconfigure.web.servlet.WebMvcAutoConfiguration;
import org.springframework.boot.autoconfigure.web.servlet.WebMvcProperties;
import org.springframework.boot.test.util.TestPropertyValues;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.boot.web.servlet.context.AnnotationConfigServletWebServerApplicationContext;
import org.springframework.context.ApplicationContextException;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class APIGatewayForwardingFilterConfigurationTest {

    public static final String TEST_BASE_PATH = "/testbasepath";
    public static final String TEST_BASE_PATH_WITH_SUFFIX_SLASH = "/testbasepath/";
    public static final String TEST_BASE_PATH_WITHOUT_PREFIX_SLASH = "testbasepath";

    AnnotationConfigServletWebServerApplicationContext context;

    @After
    public void closeContext() {
        if (this.context != null)
            this.context.close();
    }

    @Test(expected = NoSuchBeanDefinitionException.class)
    public void should_notRegisterAPIGatewayForwardingFilter_byDefault() {
        this.context = load();
        this.context.getBean(APIGatewayForwardingFilterConfiguration.class);
    }

    @Test(expected = NoSuchBeanDefinitionException.class)
    public void should_notRegisterAPIGatewayForwardingFilter_whenDisabled() {
        this.context = load("cn.app.filters.api-gateway-filter.enabled=false", "cn.app.filters.api-gateway-filter.base-path=" + TEST_BASE_PATH);
        this.context.getBean(APIGatewayForwardingFilterConfiguration.class);
    }

    @Test(expected = ApplicationContextException.class)
    public void should_throwIllegalStateException_whenFilterIsEnabledAndBasePathIsNull() {
        this.context = load("cn.app.filters.api-gateway-filter.enabled=true");
    }

    @Test(expected = ApplicationContextException.class)
    public void should_throwIllegalStateException_whenFilterIsEnabledAndBasePathIsEmpty() {
        this.context = load("cn.app.filters.api-gateway-filter.enabled=true", "cn.app.filters.api-gateway-filter.base-path=");
    }

    @Test
    public void should_registerAPIGatewayForwardingFilterProperly_whenEnabled_withBasePath() {
        this.context = load("cn.app.filters.api-gateway-filter.enabled=true", "cn.app.filters.api-gateway-filter.base-path=" + TEST_BASE_PATH);
        assertRegistrationOfAPIGatewayForwardingFilterConfigurationBean();
        assertProperRegistrationOfAPIGatewayForwardingFilterBean("/testbasepath/*");
    }

    @Test
    public void should_registerAPIGatewayForwardingFilterProperly_whenBasePathContainsSuffixSlash() {
        this.context = load("cn.app.filters.api-gateway-filter.enabled=true", "cn.app.filters.api-gateway-filter.base-path=" + TEST_BASE_PATH_WITH_SUFFIX_SLASH);
        assertRegistrationOfAPIGatewayForwardingFilterConfigurationBean();
        assertProperRegistrationOfAPIGatewayForwardingFilterBean("/testbasepath/*");
    }

    @Test
    public void should_registerAPIGatewayForwardingFilterProperly_whenBasePathIsMissingPrefixSlash() {
        this.context = load("cn.app.filters.api-gateway-filter.enabled=true", "cn.app.filters.api-gateway-filter.base-path=" + TEST_BASE_PATH_WITHOUT_PREFIX_SLASH);
        assertRegistrationOfAPIGatewayForwardingFilterConfigurationBean();
        assertProperRegistrationOfAPIGatewayForwardingFilterBean("/testbasepath/*");
    }

    private void assertProperRegistrationOfAPIGatewayForwardingFilterBean(String uriPattern) {
        FilterRegistrationBean filterRegistrationBean = this.context.getBean(FilterRegistrationBean.class);
        assertThat(filterRegistrationBean).isNotNull();
        assertThat(filterRegistrationBean.getFilter().getClass()).isEqualTo(APIGatewayForwardingFilter.class);
        assertFalse(filterRegistrationBean.getUrlPatterns().isEmpty());
        assertTrue(filterRegistrationBean.getUrlPatterns().contains(uriPattern));
    }

    private void assertRegistrationOfAPIGatewayForwardingFilterConfigurationBean() {
        APIGatewayForwardingFilterConfiguration contextBean = this.context.getBean(APIGatewayForwardingFilterConfiguration.class);
        assertThat(contextBean).isNotNull();
    }

    @SuppressWarnings("deprecation")
    private AnnotationConfigServletWebServerApplicationContext load(String... properties) {
        AnnotationConfigServletWebServerApplicationContext ctx = new AnnotationConfigServletWebServerApplicationContext();
        TestPropertyValues.of(properties).applyTo(ctx);
        TestPropertyValues.of("server.port=0").applyTo(ctx);
        ctx.register(
                WebMvcProperties.class,
                ServletWebServerFactoryAutoConfiguration.class,
                WebMvcAutoConfiguration.EnableWebMvcConfiguration.class,
                APIGatewayForwardingFilterConfiguration.class,
                PropertyPlaceholderAutoConfiguration.class
        );
        // Note: Spring-boot-autoconfigure.2.4.5 -> WebMvcAutoConfiguration -> EnableWebMvcConfiguration uses this
        // deprecated class with suppressed deprecation warnings. Revisit in future spring boot upgrade to remove usage of ResourceProperties.
        ctx.registerBean(org.springframework.boot.autoconfigure.web.ResourceProperties.class);
        ctx.refresh();
        return ctx;
    }
}
