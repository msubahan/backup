package com.ford.cloudnative.base.app.web.exception.handler.servlet;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.when;

import java.util.Arrays;
import java.util.HashMap;

import com.ford.cloudnative.base.app.web.exception.handler.DefaultExceptionHandler;
import com.ford.cloudnative.base.app.web.exception.handler.ExceptionHandlerProperties;
import com.ford.cloudnative.base.app.web.exception.handler.ErrorResponseBuilder;
import com.ford.cloudnative.base.app.web.filter.RequestFilter;
import org.junit.Before;
import org.junit.Test;
import org.springframework.boot.autoconfigure.web.ServerProperties;
import org.springframework.context.ApplicationContext;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.validation.MapBindingResult;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.context.request.ServletWebRequest;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.util.WebUtils;

import com.ford.cloudnative.base.api.BaseBodyError;
import com.ford.cloudnative.base.api.BaseBodyResponse;
import com.ford.cloudnative.base.app.web.tracer.RequestTracer;

import javax.validation.Validation;

public class ControllerExceptionHandlerResponseEntityTest {

	final long START_TIME_TIMESTAMP_MS = 1234567890L;
	
	ErrorResponseBuilder errorResponseBuilder;
	ControllerExceptionHandler handler;
	ServletWebRequest webRequest;
	
	
	@Before
	public void setup() {
		webRequest = new ServletWebRequest(new MockHttpServletRequest());
		webRequest.setAttribute(RequestFilter.START_TIME_ATTRIBUTE, START_TIME_TIMESTAMP_MS, WebRequest.SCOPE_REQUEST);
		
		RequestTracer requestTracer = mock(RequestTracer.class);
		when(requestTracer.getTraceId()).thenReturn("TRACE-ID");
        ApplicationContext ctx = mock(ApplicationContext.class);
        when(ctx.getBean(RequestTracer.class)).thenReturn(requestTracer);
		ExceptionHandlerProperties properties = new ExceptionHandlerProperties();
		properties.setUseBaseBodyResponse(true);
		properties.getDataErrors().setIncludeCode(true);
		properties.getDataErrors().setIncludeValue(true);
		properties.getAttributes().setIncludeException(true);
		properties.getMessages().getWhiteList().setExceptions(Arrays.asList("**"));
		errorResponseBuilder = spy(new ErrorResponseBuilder(ctx, new ServerProperties(), properties, new DefaultExceptionHandler(properties), Validation.buildDefaultValidatorFactory()));
		
		handler = new ControllerExceptionHandler(errorResponseBuilder);
	}
	
	@Test
	public void testHandleExceptionInternal() throws Exception {
		IllegalArgumentException ex = new IllegalArgumentException("ERROR-MESSAGE");
		HttpStatus status = HttpStatus.BAD_GATEWAY;
		ResponseEntity<Object> entity = handler.handleExceptionInternal(ex, null, null, status, webRequest);
		
		assertThat(entity.getStatusCode()).isEqualTo(status);
		assertThat(entity.getBody()).isInstanceOf(BaseBodyResponse.class);
		BaseBodyError bodyError = ((BaseBodyResponse)entity.getBody()).getError();
		assertThat(bodyError.getMessages()).isEqualTo(Arrays.asList("ERROR-MESSAGE"));
		assertThat(bodyError.getAttributes()).containsEntry("referenceId","TRACE-ID");
	}
	
	@Test
	public void testHandleExceptionInternalServerErrorRequestAttribute() throws Exception {
		IllegalArgumentException ex = new IllegalArgumentException("ERROR-MESSAGE");
		HttpStatus status = HttpStatus.INTERNAL_SERVER_ERROR;
		ResponseEntity<Object> entity = handler.handleExceptionInternal(ex, null, null, status, webRequest);
		
		assertThat(webRequest.getAttribute(WebUtils.ERROR_EXCEPTION_ATTRIBUTE, WebRequest.SCOPE_REQUEST)).isNotNull();
	}
	
	@Test
	public void testHandleMethodArgumentNotValid() throws Exception {
		
		MapBindingResult bindingResult = new MapBindingResult(new HashMap<>(), "objectName");
		bindingResult.rejectValue("field1", "errorCode1", "defaultMessage1");
		bindingResult.rejectValue("field2", "errorCode2", "defaultMessage2");
		MethodArgumentNotValidException ex = new MethodArgumentNotValidException(null, bindingResult);
		
		ResponseEntity<Object> entity = handler.handleExceptionInternal(ex, null, null, null, webRequest);
		
		assertThat(entity.getStatusCode()).isEqualTo(HttpStatus.BAD_REQUEST);
		assertThat(entity.getBody()).isInstanceOf(BaseBodyResponse.class);
		BaseBodyError bodyError = ((BaseBodyResponse)entity.getBody()).getError();
		assertThat(bodyError.getAttributes()).containsEntry("referenceId","TRACE-ID");
		
		assertThat(bodyError.getMessages().size()).isEqualTo(1);
		assertThat(bodyError.getMessages().get(0)).contains("Error count: 2");
		
		assertThat(bodyError.getDataErrors().size()).isEqualTo(2);
		
		assertThat(bodyError.getDataErrors().get(0).getName()).isEqualTo("field1");
		assertThat(bodyError.getDataErrors().get(0).getCode()).isEqualTo("errorCode1");
		assertThat(bodyError.getDataErrors().get(0).getMessage()).isEqualTo("defaultMessage1");
		
		assertThat(bodyError.getDataErrors().get(1).getName()).isEqualTo("field2");
		assertThat(bodyError.getDataErrors().get(1).getCode()).isEqualTo("errorCode2");
		assertThat(bodyError.getDataErrors().get(1).getMessage()).isEqualTo("defaultMessage2");
	}
	
}
