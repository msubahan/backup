package com.ford.cloudnative.base.app.datasource.configure;

import com.ford.cloudnative.base.app.TestUtils;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.beans.factory.BeanCreationException;
import org.springframework.beans.factory.support.DefaultListableBeanFactory;
import org.springframework.cloud.Cloud;
import org.springframework.cloud.service.BaseServiceInfo;

import javax.sql.DataSource;
import java.util.*;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertThrows;
import static org.mockito.Mockito.*;

@RunWith(MockitoJUnitRunner.class)
public class DataSourceConfigureScanConfigurationTest {

	@Mock
	Cloud mockCloud;

	DataSourceConfigureScanConfiguration scanConfig;
	DefaultListableBeanFactory registry = new DefaultListableBeanFactory();
	
	@Before
	public void setup() {
		scanConfig = spy(new DataSourceConfigureScanConfiguration());
		doReturn(mockCloud).when(scanConfig).cloud();
		
	}
	
	@Test
	public void testUnknownDatabaseDriver() {
		when(mockCloud.getServiceInfos()).thenReturn(Arrays.asList(
				createUPServiceInfo("service1", "jdbc:unknownDB://service1-host")
				));

		BeanCreationException beanCreationException = assertThrows(BeanCreationException.class, () -> {
			scanConfig.registerBeanDefinitions(null, registry);
		});
		assertThat(beanCreationException.getMessage()).contains("Could not determine the database driver for service (service1)");
	}
	
	@Test
	public void testOtherServiceInfosAreIgnored() throws Exception {
		when(mockCloud.getServiceInfos()).thenReturn(Arrays.asList(
					mock(BaseServiceInfo.class)
				));
		
		
		scanConfig.registerBeanDefinitions(null, registry);
		assertThat(toList(registry.getBeanNamesIterator()).size()).isZero();
	}
	
	@Test
	public void testUserProvidedRelationalServiceInfosAreHandled() throws Exception {
		String service1JdbcDbUrl = "jdbc:h2:mem:service1-instance";
		String service2JdbcDbUrl = "jdbc:h2:mem:service2-instance";
		when(mockCloud.getServiceInfos()).thenReturn(Arrays.asList(
					createUPServiceInfo("service1", service1JdbcDbUrl),
					createUPServiceInfo("service2", service2JdbcDbUrl)
					
				));
		
		
		scanConfig.registerBeanDefinitions(null, registry);
		assertThat(toList(registry.getBeanNamesIterator()).size()).isEqualTo(2);
		assertThat(registry.getBean("service1", DataSource.class).getConnection().getMetaData().getURL()).isEqualTo(service1JdbcDbUrl);
		assertThat(registry.getBean("service2", DataSource.class).getConnection().getMetaData().getURL()).isEqualTo(service2JdbcDbUrl);
		
	}
	
	UserProvidedRelationalServiceInfo createUPServiceInfo(String name, String jdbcDbUrl) {
		Map<String, Object> serviceData = new HashMap<>();
		serviceData.put("name", name);
		serviceData.put("credentials", TestUtils.map("jdbcDbUrl=" + jdbcDbUrl));
		return new UserProvidedRelationalServiceInfo(serviceData);
	}
	
	<T> List<T> toList(Iterator<T> iterator) {
		List<T> list = new ArrayList<>();
		iterator.forEachRemaining(list::add);
		return list;
	}
}
