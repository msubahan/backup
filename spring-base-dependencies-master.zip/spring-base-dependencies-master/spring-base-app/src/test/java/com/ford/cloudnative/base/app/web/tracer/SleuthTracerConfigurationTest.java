package com.ford.cloudnative.base.app.web.tracer;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import org.junit.After;
import org.junit.Test;
import org.springframework.boot.test.util.TestPropertyValues;
import org.springframework.cloud.sleuth.autoconfig.TraceConfiguration;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import brave.Span;
import brave.Tracer;
import brave.propagation.TraceContext;

public class SleuthTracerConfigurationTest {

	AnnotationConfigApplicationContext context;
	Tracer mockTracer = mock(Tracer.class);
	
	@After
	public void closeContext() {
		if (this.context != null)
			this.context.close();
	}

	@Test
	public void testDisabledTracerBeanIfThereIsNoTracerBean() {
		this.context = load(false);
		assertThat(this.context.getBean(RequestTracer.class).isEnabled()).isFalse();
	}
	
	@Test
	public void testEnabledTracerBeanIfThereIsTracerBean() {
		this.context = load(true);
		assertThat(this.context.getBean(RequestTracer.class).isEnabled()).isTrue();
	}
	
	@Test
	public void testEnabledTracerBeanIfThereIsTracerBeanAndTrueSleuthEnabledProperty() {
		this.context = load(true, "spring.sleuth.enabled=true");
		assertThat(this.context.getBean(RequestTracer.class).isEnabled()).isTrue();
	}
	
	@Test
	public void testEnabledTracerBeanReturnsTraceIdIfCurrentSpanPresent() {
		Span mockSpan = mock(Span.class);
		TraceContext mockTraceContext = TraceContext.newBuilder().spanId(1).traceId(0x1234567890123456L).build();
		when(mockSpan.context()).thenReturn(mockTraceContext);
		when(mockTracer.currentSpan()).thenReturn(mockSpan);
		this.context = load(true);
		RequestTracer requestTracerBean = this.context.getBean(RequestTracer.class);
		assertThat(requestTracerBean.isEnabled()).isTrue();
		assertThat(requestTracerBean.getTraceId()).isEqualTo("1234567890123456");
	}
	
	@Test
	public void testEnabledTracerBeanReturnsNullIfCurrentSpanMissing() {
		this.context = load(true);
		RequestTracer requestTracerBean = this.context.getBean(RequestTracer.class);
		assertThat(requestTracerBean.isEnabled()).isTrue();
		assertThat(requestTracerBean.getTraceId()).isNull();
	}
	
	@Test
	public void testDisabledTracerBeanReturnsNullForTraceId() {
		this.context = load(false);
		RequestTracer requestTracerBean = this.context.getBean(RequestTracer.class);
		assertThat(requestTracerBean.isEnabled()).isFalse();
		assertThat(requestTracerBean.getTraceId()).isNull();
	}
	
	private AnnotationConfigApplicationContext load(boolean registerTracerBean, String... properties) {
		AnnotationConfigApplicationContext ctx = new AnnotationConfigApplicationContext();
		TestPropertyValues.of(properties).applyTo(ctx);
		if (registerTracerBean) {
			ctx.getDefaultListableBeanFactory().registerSingleton("mockTracer", mockTracer);
			ctx.register(TraceConfiguration.class);
		}
		ctx.register(SleuthRequestTracerConfiguration.class);
		ctx.register(DefaultRequestTracerConfiguration.class);
		ctx.refresh();
		return ctx;
	}
	
	
}
