package com.ford.cloudnative.base.app;

import java.util.LinkedHashMap;
import java.util.Map;

public class TestUtils {

	
	public static Map<String, String> map(String... values) {
		Map<String, String> map = new LinkedHashMap<>();
		for (int i = 0; i < values.length; i++) {
			String[] parts = values[i].split("=");
			map.put(parts[0], parts[1]);
		}
		return map;
	}
	
}
