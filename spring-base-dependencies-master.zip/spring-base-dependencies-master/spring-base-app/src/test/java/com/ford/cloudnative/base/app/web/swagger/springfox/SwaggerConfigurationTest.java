package com.ford.cloudnative.base.app.web.swagger.springfox;

import org.junit.After;
import org.junit.Test;
import org.springframework.beans.factory.NoSuchBeanDefinitionException;
import org.springframework.boot.autoconfigure.web.servlet.ServletWebServerFactoryAutoConfiguration;
import org.springframework.boot.autoconfigure.web.servlet.WebMvcAutoConfiguration.EnableWebMvcConfiguration;
import org.springframework.boot.autoconfigure.web.servlet.WebMvcProperties;
import org.springframework.boot.test.util.TestPropertyValues;
import org.springframework.boot.web.servlet.context.AnnotationConfigServletWebServerApplicationContext;
import org.springframework.web.servlet.mvc.condition.PatternsRequestCondition;
import springfox.documentation.RequestHandler;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spi.service.contexts.DocumentationContext;
import springfox.documentation.spi.service.contexts.DocumentationContextBuilder;
import springfox.documentation.spring.web.WebMvcPatternsRequestConditionWrapper;
import springfox.documentation.spring.web.plugins.Docket;

import java.util.Arrays;
import java.util.function.Predicate;

import static com.ford.cloudnative.base.app.web.swagger.springfox.SwaggerConfiguration.SetupSwaggerConfiguration.or;
import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class SwaggerConfigurationTest {

	AnnotationConfigServletWebServerApplicationContext context;
	
	@After
	public void closeContext() {
		if (this.context != null)
			this.context.close();
	}

	@Test(expected = NoSuchBeanDefinitionException.class)
	public void testSwaggerDocketIsNotRegisteredWithNoEnabledProperty() {
		this.context = load();
		this.context.getBean(Docket.class);
	}
	
	@Test(expected = NoSuchBeanDefinitionException.class)
	public void testSwaggerDocketIsNotRegisteredWithFalseEnabledProperty() {
		this.context = load("cn.app.swagger.enabled=false");
		this.context.getBean(Docket.class);
	}
	
	@Test
	public void testSwaggerDocketIsRegisteredWithTrueEnabledProperty() {
		this.context = load("cn.app.swagger.enabled=true");
		assertThat(this.context.getBean(Docket.class)).isNotNull();
	}
	
	@Test
	public void testSwaggerDocketConfiguredProperly() {
		this.context = load(
				"cn.app.swagger.enabled=true",
				"cn.app.swagger.scanPackages=java.util;java.io",
				"cn.app.swagger.useDefaultResponseMessages=true",
				"cn.app.swagger.display.title=TITLE",
				"cn.app.swagger.display.description=DESCRIPTION",
				"cn.app.swagger.display.contactName=CONTACT-NAME",
				"cn.app.swagger.display.contactEmail=CONTACT-EMAIL",
				"cn.app.swagger.display.contactUrl=CONTACT-URL",
				"cn.app.swagger.display.version=VERSION",
				"cn.app.swagger.display.license=LICENSE",
				"cn.app.swagger.display.licenseUrl=LICENSE-URL",
				"cn.app.swagger.display.termsOfServiceUrl=TERMS-OF-SERVICE-URL"
				);
		
		Docket docket = this.context.getBean(Docket.class);
		assertThat(docket).isNotNull();
		
		DocumentationContext doc = docket.configure(new DocumentationContextBuilder(DocumentationType.SWAGGER_2));
		assertThat(doc).isNotNull();
		assertThat(doc.getApiInfo().getTitle()).isEqualTo("TITLE");
		assertThat(doc.getApiInfo().getDescription()).isEqualTo("DESCRIPTION");
		assertThat(doc.getApiInfo().getContact().getName()).isEqualTo("CONTACT-NAME");
		assertThat(doc.getApiInfo().getContact().getEmail()).isEqualTo("CONTACT-EMAIL");
		assertThat(doc.getApiInfo().getContact().getUrl()).isEqualTo("CONTACT-URL");
		assertThat(doc.getApiInfo().getVersion()).isEqualTo("VERSION");
		assertThat(doc.getApiInfo().getLicense()).isEqualTo("LICENSE");
		assertThat(doc.getApiInfo().getLicenseUrl()).isEqualTo("LICENSE-URL");
		assertThat(doc.getApiInfo().getTermsOfServiceUrl()).isEqualTo("TERMS-OF-SERVICE-URL");
		
		assertThat(doc.getApiSelector().getRequestHandlerSelector().test(withDeclaringClass(java.util.List.class))).isTrue();
		assertThat(doc.getApiSelector().getRequestHandlerSelector().test(withDeclaringClass(java.io.Writer.class))).isTrue();
		assertThat(doc.getApiSelector().getRequestHandlerSelector().test(withDeclaringClass(java.lang.String.class))).isFalse();
	}

	@SuppressWarnings({"deprecation", "unchecked"})
	private RequestHandler withDeclaringClass(Class clz) {
		RequestHandler requestHandler = mock(RequestHandler.class);
		when(requestHandler.declaringClass()).thenReturn(clz);
		when(requestHandler.getPatternsCondition()).thenReturn(new WebMvcPatternsRequestConditionWrapper("/", new PatternsRequestCondition("/")));
		return requestHandler;
	}

	@SuppressWarnings("deprecation")
	private AnnotationConfigServletWebServerApplicationContext load(String... properties) {
		AnnotationConfigServletWebServerApplicationContext ctx = new AnnotationConfigServletWebServerApplicationContext();
		TestPropertyValues.of(properties).applyTo(ctx);
		TestPropertyValues.of("server.port=0").applyTo(ctx);
		ctx.register(
				WebMvcProperties.class,
				ServletWebServerFactoryAutoConfiguration.class,
				EnableWebMvcConfiguration.class,
				SwaggerConfiguration.class
				);
		// Note: Spring-boot-autoconfigure.2.4.5 -> WebMvcAutoConfiguration -> EnableWebMvcConfiguration uses this
		// deprecated class with suppressed deprecation warnings. Revisit in future spring boot upgrade to remove usage of ResourceProperties.
		ctx.registerBean(org.springframework.boot.autoconfigure.web.ResourceProperties.class);
		ctx.refresh();
		return ctx;
	}

	@Test
	@SuppressWarnings("unchecked")
	public void testOr() {
		Predicate alwaysTrue = x -> true;
		Predicate alwaysFalse = x -> false;

		Predicate<?> or1 = or(Arrays.asList(alwaysTrue, alwaysFalse));
		assertThat(or1.test(null)).isTrue();

		Predicate<?> or2 = or(Arrays.asList(alwaysFalse, alwaysTrue));
		assertThat(or2.test(null)).isTrue();

		Predicate<?> or3 = or(Arrays.asList(alwaysTrue, alwaysTrue));
		assertThat(or3.test(null)).isTrue();

		Predicate<?> or4 = or(Arrays.asList(alwaysFalse, alwaysFalse));
		assertThat(or4.test(null)).isFalse();
	}
}
