package com.ford.cloudnative.base.app.web.exception.handler.servlet;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.when;

import java.util.Arrays;
import java.util.Map;

import com.ford.cloudnative.base.app.web.exception.handler.DefaultExceptionHandler;
import com.ford.cloudnative.base.app.web.exception.handler.ExceptionHandlerProperties;
import com.ford.cloudnative.base.app.web.exception.handler.ErrorResponseBuilder;
import com.ford.cloudnative.base.app.web.filter.RequestFilter;
import org.junit.Before;
import org.junit.Test;
import org.springframework.boot.autoconfigure.web.ServerProperties;
import org.springframework.boot.web.error.ErrorAttributeOptions;
import org.springframework.boot.web.error.ErrorAttributeOptions.Include;
import org.springframework.context.ApplicationContext;
import org.springframework.http.HttpStatus;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.web.context.request.RequestAttributes;
import org.springframework.web.context.request.ServletWebRequest;
import org.springframework.web.context.request.WebRequest;

import com.ford.cloudnative.base.api.BaseBodyError;
import com.ford.cloudnative.base.app.web.tracer.RequestTracer;

import javax.validation.Validation;

public class FallbackErrorAttributesHandlerTest {

	final long START_TIME_TIMESTAMP_MS = 1234567890L;
	final long START_TIME_TIMESTAMP_SECS = 1234567L;
	
	ErrorResponseBuilder errorResponseBuilder;
	FallbackErrorAttributesHandler handler;
	ErrorAttributeOptions errorAttributeOptions = ErrorAttributeOptions.of(Arrays.asList(Include.EXCEPTION, Include.MESSAGE));
	
	
	@Before
	public void setup() {
		RequestTracer requestTracer = mock(RequestTracer.class);
		when(requestTracer.getTraceId()).thenReturn("TRACE-ID");
        ApplicationContext ctx = mock(ApplicationContext.class);
        when(ctx.getBean(RequestTracer.class)).thenReturn(requestTracer);
		ExceptionHandlerProperties properties = new ExceptionHandlerProperties();
		properties.setUseBaseBodyResponse(false);
		properties.getAttributes().setIncludeException(true);
		properties.getMessages().getWhiteList().setExceptions(Arrays.asList("**"));
		errorResponseBuilder = spy(new ErrorResponseBuilder(ctx, new ServerProperties(), properties, new DefaultExceptionHandler(properties), Validation.buildDefaultValidatorFactory()));
		
		handler = new FallbackErrorAttributesHandler(errorResponseBuilder);
	}
	
	@Test
	public void testErrorAttributes() throws Exception {
		IllegalArgumentException ex = new IllegalArgumentException("ERROR-MESSAGE");
		
		WebRequest requestAttributes = new ServletWebRequest(new MockHttpServletRequest());
		requestAttributes.setAttribute(RequestFilter.START_TIME_ATTRIBUTE, START_TIME_TIMESTAMP_MS, WebRequest.SCOPE_REQUEST);
		requestAttributes.setAttribute("javax.servlet.error.status_code", HttpStatus.SERVICE_UNAVAILABLE.value(), RequestAttributes.SCOPE_REQUEST);
		requestAttributes.setAttribute("javax.servlet.error.exception", ex, RequestAttributes.SCOPE_REQUEST);
		
		Map<String, Object> errorAttributes = handler.getErrorAttributes(requestAttributes, errorAttributeOptions);
		
		assertThat(errorAttributes.get("value")).isNull();
		assertThat(errorAttributes.get("error")).isInstanceOf(BaseBodyError.class);
		BaseBodyError bodyError = (BaseBodyError)errorAttributes.get("error");
		assertThat(bodyError.getMessages()).contains(ex.getMessage());
		assertThat(bodyError.getAttributes()).containsEntry("referenceId", "TRACE-ID");
		assertThat(bodyError.getAttributes()).containsEntry("timestamp", START_TIME_TIMESTAMP_SECS);
		assertThat(bodyError.getAttributes()).containsEntry("exception", ex.getClass().getName());
	}
}
