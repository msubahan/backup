package com.ford.cloudnative.base.app.web.exception.handler.servlet;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.ford.cloudnative.base.app.web.exception.handler.DefaultExceptionHandler;
import com.ford.cloudnative.base.app.web.exception.handler.ErrorResponseBuilder;
import com.ford.cloudnative.base.app.web.exception.handler.HtmlErrorView;
import org.junit.Test;
import org.springframework.boot.autoconfigure.validation.ValidationAutoConfiguration;
import org.springframework.boot.autoconfigure.web.ServerProperties;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.web.context.support.AnnotationConfigWebApplicationContext;
import org.springframework.web.servlet.View;

public class ErrorViewConfigurationTest {
	
	@Test
	public void testCustomErrorViewIsRegistered() throws Exception {
		try (AnnotationConfigWebApplicationContext context = new AnnotationConfigWebApplicationContext()) {
			context.register(HtmlErrorView.class, ErrorViewConfiguration.class, ErrorResponseBuilder.class);
			context.register(DefaultExceptionHandler.class);
			context.register(ValidationAutoConfiguration.class);
			context.register(ServerProperties.class);
			context.refresh();
			
			View view = context.getBean("error", View.class);
			Map<String, String> model = new HashMap<>();
			model.put("error","ERROR-DATA");
			MockHttpServletResponse response = new MockHttpServletResponse();
			view.render(model, null, response);
			
			assertThat(response.getContentAsString()).contains("ERROR-DATA");
		}
	}
	
	@Test
	public void testCustomErrorViewIsNotRegisteredIfAnotherErrorViewIsRegistered() throws Exception {
		try (AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext()) {
			context.getDefaultListableBeanFactory().registerSingleton("error", new View() {
				public void render(Map<String, ?> model, HttpServletRequest request, HttpServletResponse response) throws Exception {
					response.getWriter().write("dummy-view");
				}
				public String getContentType() { return "text/html"; }
			});
			
			context.register(HtmlErrorView.class, ErrorViewConfiguration.class, ErrorResponseBuilder.class);
			context.register(DefaultExceptionHandler.class);
			context.register(ValidationAutoConfiguration.class);
			context.register(ServerProperties.class);
			context.refresh();
			
			View view = context.getBean("error", View.class);
			MockHttpServletResponse response = new MockHttpServletResponse();
			view.render(null, null, response);
			
			assertThat(response.getContentAsString()).contains("dummy-view");
		}
	}
	
}
