package com.ford.cloudnative.base.web.app;

import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DummyApplication {

}
