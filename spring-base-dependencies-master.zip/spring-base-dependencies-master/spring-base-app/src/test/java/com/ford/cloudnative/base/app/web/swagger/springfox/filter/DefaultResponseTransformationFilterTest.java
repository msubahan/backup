package com.ford.cloudnative.base.app.web.swagger.springfox.filter;

import io.swagger.models.Operation;
import io.swagger.models.Path;
import io.swagger.models.Response;
import io.swagger.models.Swagger;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;
import springfox.documentation.swagger2.web.SwaggerTransformationContext;

import java.util.Collections;
import java.util.Map;

import static org.assertj.core.api.Assertions.assertThat;

public class DefaultResponseTransformationFilterTest {

    SwaggerTransformationContext context;
    Swagger swagger;

    @Before
    public void setup() {
        swagger = new Swagger();

        context = Mockito.mock(SwaggerTransformationContext.class);
        Mockito.when(context.getSpecification()).thenReturn(swagger);
    }

    @Test
    @SuppressWarnings("unchecked")
    public void testTransformRenamedPathDefaultKey() {
        Response errorResponse = new Response();
        Operation operation = new Operation();
        operation.addResponse("200", new Response());
        operation.addResponse(DefaultResponseTransformationFilter.DEFAULT_RESPONSE_CODE, errorResponse);

        Path path = new Path();
        path.setPost(operation);
        swagger.setPaths(Collections.singletonMap("", path));

        DefaultResponseTransformationFilter filter = new DefaultResponseTransformationFilter();
        Map<String, Response> responses = swagger.getPath("").getOperations().get(0).getResponses();

        assertThat(responses).doesNotContainKey("default");
        filter.transform(context);
        assertThat(responses).containsEntry("default", errorResponse);
    }

    @Test
    @SuppressWarnings("unchecked")
    public void testTransformRenamedGlobalDefaultKey() {
        Response errorResponse = new Response();
        Operation operation = new Operation();
        operation.addResponse("200", new Response());
        operation.addResponse(DefaultResponseTransformationFilter.DEFAULT_RESPONSE_CODE, errorResponse);

        swagger.setResponses(operation.getResponses());

        DefaultResponseTransformationFilter filter = new DefaultResponseTransformationFilter();
        Map<String, Response> responses = swagger.getResponses();

        assertThat(responses).doesNotContainKey("default");
        filter.transform(context);
        assertThat(responses).containsEntry("default", errorResponse);
    }

}
