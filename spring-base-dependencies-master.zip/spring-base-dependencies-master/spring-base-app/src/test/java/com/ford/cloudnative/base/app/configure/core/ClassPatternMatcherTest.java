package com.ford.cloudnative.base.app.configure.core;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.exc.InputCoercionException;
import com.fasterxml.jackson.core.exc.StreamReadException;
import com.fasterxml.jackson.core.io.JsonEOFException;
import org.junit.Test;


import java.io.IOException;
import java.security.AccessControlException;
import java.util.Arrays;

import static org.assertj.core.api.Assertions.assertThat;

public class ClassPatternMatcherTest {

    @Test
    public void testIsMatch() throws Exception {
        ClassPatternMatcher exceptionMatcher = new ClassPatternMatcher(Arrays.asList("java.lang.RuntimeException", "**.JsonParse*"));

        assertThat(exceptionMatcher.isMatch(RuntimeException.class)).isTrue();
        assertThat(exceptionMatcher.isMatch(SecurityException.class)).isTrue();
        assertThat(exceptionMatcher.isMatch(AccessControlException.class)).isTrue();
        assertThat(exceptionMatcher.isMatch(AccessControlException.class)).isTrue();

        assertThat(exceptionMatcher.isMatch(IOException.class)).isFalse();
        assertThat(exceptionMatcher.isMatch(StreamReadException.class)).isFalse();
        assertThat(exceptionMatcher.isMatch(JsonParseException.class)).isTrue();
        assertThat(exceptionMatcher.isMatch(JsonEOFException.class)).isTrue();

        assertThat(exceptionMatcher.isMatch(InputCoercionException.class)).isFalse();
    }

}
