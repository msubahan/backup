package com.ford.cloudnative.base.app.configure;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.TimeZone;

import org.junit.After;
import org.junit.Test;
import org.springframework.boot.test.util.TestPropertyValues;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class ConfigureConfigurationTest {

	final static TimeZone TEST_TIME_ZONE = TimeZone.getTimeZone("Asia/Beirut"); 
	AnnotationConfigApplicationContext context;

	@After
	public void closeContext() {
		if (this.context != null)
			this.context.close();
	}

	@Test
	public void testTimeZoneConfigurationIsNotUpdated() {
		TimeZone.setDefault(TEST_TIME_ZONE);
		this.context = load();
		assertThat(TimeZone.getDefault()).isEqualTo(TEST_TIME_ZONE);
	}

	@Test
	public void testTimeZoneConfigurationIsUpdated() {
		TimeZone.setDefault(TEST_TIME_ZONE);
		this.context = load("cn.app.configure.default-time-zone=UTC");
		assertThat(TimeZone.getDefault()).isEqualTo(TimeZone.getTimeZone("UTC"));
	}

	private AnnotationConfigApplicationContext load(String... properties) {
		AnnotationConfigApplicationContext ctx = new AnnotationConfigApplicationContext();
		TestPropertyValues.of(properties).applyTo(ctx);
		ctx.register(ConfigureConfiguration.class);
		ctx.refresh();
		return ctx;
	}

}
