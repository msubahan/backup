package com.ford.cloudnative.base.web.app.swagger_test;

import com.ford.cloudnative.base.api.StandardErrorResponse;
import com.ford.cloudnative.base.api.annotation.ApiProperty;
import com.ford.cloudnative.base.app.web.swagger.springfox.annotation.ApiOperationExt;
import com.ford.cloudnative.base.app.web.swagger.springfox.annotation.ApiOperationSecurity;
import com.ford.cloudnative.base.app.web.swagger.ApiSecurityScheme;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import lombok.Data;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;
import java.time.LocalDate;
import java.time.ZonedDateTime;
import java.util.List;
import java.util.Map;

@RestController("/")
public class SwaggerTestController {

    @ApiResponses({
        @ApiResponse(code = 200, message = "Ok", response = MyResponse.class),
        @ApiResponse(code = 0, message = "All Errors", response = StandardErrorResponse.class)
    })
    @ApiProperty.Long(name = "x-long", value = 1234L)
    @ApiProperty.Float(name = "x-float", value = 12.34f)
    @GetMapping(produces = {MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_PROBLEM_JSON_VALUE})
    public MyResponse myResponse(
            @ApiParam(required = true) @ApiProperty(name = "x-string1", value = "value1") String id,
            @ApiParam(required = false) @ApiProperty.Integer(name = "$items.maxLength", value = 2) List<@Size(max = 2) String> states
    ) {
        return new MyResponse();
    }

    @ApiOperation(value = "")
    @ApiOperationExt(clearAuthorizations = true)
    @ApiOperationSecurity(ApiSecurityScheme.APPLICATION_ID)
    @PostMapping
    public MyResponse myResponsePost() {
        return new MyResponse();
    }

    @Data
    public static class MyResponse {
        @Size(min = 5, max = 10)
        @ApiProperty.Double(name = "x-double", value = 1.0)
        List<@Size(min = 1, max = 100) @Pattern(regexp = "^.{0,100}$") @ApiProperty(name = "x-string2", value = "value2") String> names;

        @ApiProperty(name = "x-string3", value = "value3")
        @ApiProperty.Integer(name = "x-int-1", value = 1)
        @ApiProperty.Integer(name = "x-int-2", value = 2)
        @ApiProperty.Json(name = "x-json", value = "{\"prop\":\"value\"}")
        Map<String, @ApiProperty.Boolean(name = "x-bool", value = true) Object> mapOfObjectValues;
        Map<String, @ApiProperty.Boolean(name = "x-bool2", value = false) @Size(min = 1, max = 15) String> mapOfStringValues;

        @Size(min = 20, max = 30)
        @ApiProperty.Null(name = "minLength")
        @ApiProperty.Integer(name = "maxLength", value = 11)  // overrides @Size.max
        String name;

        List<@ApiProperty.Integer(name = "maxLength", value = 10) LocalDate> localDates;
        List<@ApiProperty.Integer(name = "maxLength", value = 50) ZonedDateTime> zonedDateTimes;

        String optionalField;
        @NotNull String requiredField;
    }
}
