package com.ford.cloudnative.base.app.web.exception.handler.servlet;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

import com.ford.cloudnative.base.api.ErrorResponse;
import com.ford.cloudnative.base.api.StandardErrorResponse;
import com.ford.cloudnative.base.app.web.exception.StandardErrorResponseException;
import com.ford.cloudnative.base.app.web.exception.handler.DefaultExceptionHandler;
import com.ford.cloudnative.base.app.web.exception.handler.ErrorResponseBuilder;
import com.ford.cloudnative.base.app.web.exception.handler.ExceptionHandlerProperties;
import com.ford.cloudnative.base.app.web.exception.handler.RequestWrapper;
import com.ford.cloudnative.base.app.web.filter.RequestFilter;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.boot.autoconfigure.web.ServerProperties;
import org.springframework.context.ApplicationContext;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.context.request.ServletWebRequest;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.util.WebUtils;

import com.ford.cloudnative.base.api.BaseBodyError;
import com.ford.cloudnative.base.app.web.exception.BaseBodyResponseException;
import com.ford.cloudnative.base.app.web.tracer.RequestTracer;

import javax.validation.Validation;

@RunWith(MockitoJUnitRunner.class)
public class ControllerExceptionHandlerTest {
	
	final long START_TIME_TIMESTAMP_MS = 1234567890L;
	
	ErrorResponseBuilder errorResponseBuilder;
	ControllerExceptionHandler handler;
	ServletWebRequest webRequest;
	RequestWrapper requestWrapper;
	
	
	@Before
	public void setup() {
		webRequest = new ServletWebRequest(new MockHttpServletRequest());
		webRequest.setAttribute(RequestFilter.START_TIME_ATTRIBUTE, START_TIME_TIMESTAMP_MS, WebRequest.SCOPE_REQUEST);
		requestWrapper = new RequestWrapper.WebRequestWrapper(webRequest);
		
		RequestTracer requestTracer = mock(RequestTracer.class);
		when(requestTracer.getTraceId()).thenReturn("TRACE-ID");
        ApplicationContext ctx = mock(ApplicationContext.class);
        when(ctx.getBean(RequestTracer.class)).thenReturn(requestTracer);
		ExceptionHandlerProperties properties = new ExceptionHandlerProperties();
		properties.getMessages().getWhiteList().setExceptions(Arrays.asList("**"));
		errorResponseBuilder = spy(new ErrorResponseBuilder(ctx, new ServerProperties(), properties, new DefaultExceptionHandler(properties), Validation.buildDefaultValidatorFactory()));
		
		handler = new ControllerExceptionHandler(errorResponseBuilder);
	}

	@Test
	public void testBodyResponseExceptionIsHandledProperly() throws Exception {
			BaseBodyError bodyError = mock(BaseBodyError.class);
			Map<String, Object> bodyErrorAttributes = new HashMap<>();
			when(bodyError.getAttributes()).thenReturn(bodyErrorAttributes);
			HttpStatus httpStatus = HttpStatus.BAD_GATEWAY;
			BaseBodyResponseException exception = new BaseBodyResponseException(bodyError, httpStatus);
			
			ResponseEntity<?> entity = handler.handleUncaughtException(exception, webRequest);
			
			//--verify(baseBodyErrorResolver).populateAttributes(bodyErrorAttributes, exception, requestWrapper);
			assertThat(entity.getStatusCode()).isEqualTo(httpStatus);
			assertThat(entity.getBody()).isInstanceOf(ErrorResponse.class);
			assertThat(((ErrorResponse)entity.getBody()).getError()).isNotNull();
	}

	@Test
	public void testStandardErrorResponseExceptionWrapperIsHandledProperly() throws Exception {
		BaseBodyError bodyError = mock(BaseBodyError.class);
		Map<String, Object> bodyErrorAttributes = new HashMap<>();
		when(bodyError.getAttributes()).thenReturn(bodyErrorAttributes);
		HttpStatus httpStatus = HttpStatus.BAD_GATEWAY;
		StandardErrorResponseException exception = new StandardErrorResponseException(bodyError, httpStatus);

		ResponseEntity<?> entity = handler.handleUncaughtException(exception, webRequest);

		//--verify(baseBodyErrorResolver).populateAttributes(bodyErrorAttributes, exception, requestWrapper);
		assertThat(entity.getStatusCode()).isEqualTo(httpStatus);
		assertThat(entity.getBody()).isInstanceOf(ErrorResponse.class);
		assertThat(((ErrorResponse)entity.getBody()).getError()).isNotNull();
	}
	
	@Test
	public void testGeneralExceptionIsHandledProperly() throws Exception {
			Exception exception = new IllegalArgumentException("ERROR-MESSAGE");
			
			ResponseEntity<?> entity = handler.handleUncaughtException(exception, webRequest);
			
			assertThat(entity.getStatusCode()).isEqualTo(HttpStatus.INTERNAL_SERVER_ERROR);
			assertThat(entity.getBody()).isInstanceOf(ErrorResponse.class);
			BaseBodyError bodyError = ((ErrorResponse)entity.getBody()).getError();
			assertThat(bodyError.getMessages()).isEqualTo(Arrays.asList("ERROR-MESSAGE"));
			assertThat(bodyError.getAttributes()).containsEntry("referenceId","TRACE-ID");
	}
	
	@Test
	public void testGeneralExceptionAnnotatedWithResponseStatusIsHandledProperly() throws Exception {
			Exception exception = new TestServiceUnavailableException();
			
			ResponseEntity<?> entity = handler.handleUncaughtException(exception, webRequest);
			
			assertThat(entity.getStatusCode()).isEqualTo(HttpStatus.SERVICE_UNAVAILABLE);
	}
	
	@Test
	public void testErrorExceptionAttributePopulatedIfInternalServerError() throws Exception {
			BaseBodyError bodyError = mock(BaseBodyError.class);
			HttpStatus httpStatus = HttpStatus.INTERNAL_SERVER_ERROR;
			BaseBodyResponseException exception = new BaseBodyResponseException(bodyError, httpStatus);
			
			ResponseEntity<?> entity = handler.handleUncaughtException(exception, webRequest);
			
			assertThat(requestWrapper.getAttribute(WebUtils.ERROR_EXCEPTION_ATTRIBUTE)).isNotNull();
	}
	
	@ResponseStatus(HttpStatus.SERVICE_UNAVAILABLE)
	public class TestServiceUnavailableException extends RuntimeException {
		
	}
}
