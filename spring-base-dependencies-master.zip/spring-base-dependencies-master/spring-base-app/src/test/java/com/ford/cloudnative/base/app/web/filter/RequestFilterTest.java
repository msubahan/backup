package com.ford.cloudnative.base.app.web.filter;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.mock;

import javax.servlet.FilterChain;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

import org.assertj.core.data.Offset;
import org.junit.Test;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;

import com.ford.cloudnative.base.app.web.filter.RequestFilter;

public class RequestFilterTest {

	@Test
	public void testRequestTimeAttributeGetsPopulated() throws Exception {
		RequestFilter filter = new RequestFilter();
		
		ServletRequest request = new MockHttpServletRequest();
		ServletResponse response = new MockHttpServletResponse();
		FilterChain filterChain = mock(FilterChain.class);
		filter.doFilter(request, response, filterChain);
		
		Object time = request.getAttribute(RequestFilter.START_TIME_ATTRIBUTE);
		assertThat(time).isInstanceOf(Long.class);
		assertThat((long)time).isCloseTo(System.currentTimeMillis(), Offset.offset(10000L)); //check within 10secs of current time
	}
	
}
