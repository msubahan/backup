package com.ford.cloudnative.base.app.datasource.configure;


import static org.assertj.core.api.Assertions.assertThat;

import java.util.HashMap;
import java.util.Map;

import org.junit.Test;

import com.ford.cloudnative.base.app.datasource.configure.UserProvidedRelationalServiceInfo;

public class UserProvidedRelationalServiceInfoTest {

	@Test
	public void testServiceIdAndData() throws Exception {
		Map<String, Object> serviceData = new HashMap<>();
		String serviceName = "SERVICE-NAME";
		serviceData.put("name", serviceName);
		UserProvidedRelationalServiceInfo serviceInfo = new UserProvidedRelationalServiceInfo(serviceData);
		
		assertThat(serviceInfo.getId()).isEqualTo(serviceName);
		assertThat(serviceInfo.getServiceData()).isEqualTo(serviceData);
		
	}
	
}
