package com.ford.cloudnative.base.app.web.swagger.springfox.filter;

import com.ford.cloudnative.base.app.web.swagger.SwaggerProperties;
import io.swagger.v3.oas.models.OpenAPI;
import org.junit.Before;
import org.junit.Test;
import springfox.documentation.oas.web.OpenApiTransformationContext;

import java.util.ArrayList;
import java.util.Arrays;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class OverrideServersTransformationFilterTest {

    OpenApiTransformationContext context;
    OpenAPI openApi;
    SwaggerProperties properties;

    @Before
    public void setup() {
        openApi = new OpenAPI();
        openApi.setServers(new ArrayList<>());
        properties = new SwaggerProperties();

        context = mock(OpenApiTransformationContext.class);
        when(context.getSpecification()).thenReturn(openApi);
    }

    @Test
    @SuppressWarnings("unchecked")
    public void transformWithNoConfig() {
        new OverrideServersTransformationFilter(properties).transform(context);
        assertThat(openApi.getServers()).hasSize(1);
        assertThat(openApi.getServers().get(0).getUrl()).isEqualTo("{scheme}://{host}:{port}"); //default
    }

    @Test
    @SuppressWarnings("unchecked")
    public void transformWithConfig() {
        properties.getApidoc().setBasePath("/my-path");
        properties.getApidoc().setSchemes(Arrays.asList("http","https"));
        properties.getApidoc().setHost("test.com");

        new OverrideServersTransformationFilter(properties).transform(context);
        assertThat(openApi.getServers()).hasSize(2);
        assertThat(openApi.getServers().get(0).getUrl()).isEqualTo("http://test.com/my-path");
        assertThat(openApi.getServers().get(1).getUrl()).isEqualTo("https://test.com/my-path");
    }

}
