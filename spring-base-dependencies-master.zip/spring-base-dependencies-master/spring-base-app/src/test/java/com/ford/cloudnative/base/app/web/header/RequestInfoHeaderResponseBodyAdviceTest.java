package com.ford.cloudnative.base.app.web.header;

import static com.ford.cloudnative.base.app.web.filter.RequestFilter.START_TIME_ATTRIBUTE;
import static com.ford.cloudnative.base.app.web.header.RequestInfoHeaderResponseBodyAdvice.REQUEST_INFO_HEADER_NAME;
import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.ford.cloudnative.base.app.web.header.RequestInfoHeaderResponseBodyAdvice;
import com.ford.cloudnative.base.app.web.tracer.RequestTracer;
import com.ford.cloudnative.base.web.app.DummyController;

import lombok.Data;

@RunWith(SpringRunner.class)
public class RequestInfoHeaderResponseBodyAdviceTest {
	
	private RequestInfoHeaderResponseBodyAdvice bodyAdvice;
	private RequestInfoHeaderResponseBodyAdvice bodyAdviceWithSleuth;

	@Before
	public void setup() {
		bodyAdvice = new RequestInfoHeaderResponseBodyAdvice(new MockRequestTracer(false, null));
		bodyAdviceWithSleuth = new RequestInfoHeaderResponseBodyAdvice(new MockRequestTracer(true, "TRACE-ID"));
	}

	@Test
	public void testWithNoBodyAdvice() throws Exception {
		MockMvc mockMvc = mockMvc();
		
		MockHttpServletResponse response = mockMvc.perform(get("/dummy")).andReturn().getResponse();
		assertThat(response.getHeader(REQUEST_INFO_HEADER_NAME)).isNull();
	}
	
	@Test
	public void testBodyAdviceWithNoSleuthTraceIdAndTimeAttribute() throws Exception {
		MockMvc mockMvc = mockMvc(bodyAdvice);
		
		MockHttpServletResponse response = mockMvc.perform(get("/dummy")).andReturn().getResponse();
		assertThat(response.getHeader(REQUEST_INFO_HEADER_NAME)).isNull();
	}

	@Test
	public void testBodyAdviceWithSleuthTraceId() throws Exception {
		MockMvc mockMvc = mockMvc(bodyAdviceWithSleuth);
		
		MockHttpServletResponse response = mockMvc.perform(get("/dummy")).andReturn().getResponse();
		assertThat(response.getHeader(REQUEST_INFO_HEADER_NAME)).isEqualTo("referenceId=TRACE-ID; ");
	}
	
	@Test
	public void testBodyAdviceWithTimeAttribute() throws Exception {
		MockMvc mockMvc = mockMvc(bodyAdvice);
		
		MockHttpServletResponse response = mockMvc.perform(get("/dummy").requestAttr(START_TIME_ATTRIBUTE, 1234567890L)).andReturn().getResponse();
		assertThat(response.getHeader(REQUEST_INFO_HEADER_NAME)).doesNotContain("referenceId=");
		assertThat(response.getHeader(REQUEST_INFO_HEADER_NAME)).containsPattern("timestamp=\\d+; execution=\\d+; ");
	}
	
	@Test
	public void testBodyAdviceWithSleuthTraceIdAndTimeAttribute() throws Exception {
		MockMvc mockMvc = mockMvc(bodyAdviceWithSleuth);
		
		MockHttpServletResponse response = mockMvc.perform(get("/dummy").requestAttr(START_TIME_ATTRIBUTE, 1234567890L)).andReturn().getResponse();
		assertThat(response.getHeader(REQUEST_INFO_HEADER_NAME)).contains("referenceId=TRACE-ID; ");
		assertThat(response.getHeader(REQUEST_INFO_HEADER_NAME)).containsPattern("timestamp=\\d+; execution=\\d+; ");
	}
	
	private MockMvc mockMvc(Object... advices) {
		return MockMvcBuilders
				.standaloneSetup(new DummyController())
				.setControllerAdvice(advices)
				.build();
	}
	
	//@Data
	public static class MockRequestTracer implements RequestTracer {
		final boolean enabled;
		final String traceId;

		MockRequestTracer(boolean enabled, String traceId) {
			this.enabled = enabled;
			this.traceId = traceId;
		}

		@Override
		public String getTraceId() {
			return this.traceId;
		}

		@Override
		public boolean isEnabled() {
			return this.enabled;
		}
	}
	
	
}
