package com.ford.cloudnative.base.app.web.swagger.springfox;

import com.ford.cloudnative.base.web.app.DummyApplication;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultHandlers;

import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = WebEnvironment.RANDOM_PORT, classes = DummyApplication.class,
        properties = {
            "spring.flyway.enabled=false",
            "cn.app.swagger.enabled=true",
            "cn.app.swagger.scanPackages=com.ford.cloudnative.base.web.app.swagger_test",
            "cn.app.swagger.extensions.x-nullable=true",
            "cn.app.swagger.security.application-id.enabled=true",
            "cn.app.swagger.security.application-id.paths=/**",
            "cn.app.swagger.security.azure-ad.enabled=true",
            "cn.app.swagger.security.azure-ad.paths=/**",
            "cn.app.swagger.security.azure-ad.scopes.read=read description",
            "cn.app.swagger.security.azure-ad.scopes.write=write description",
            "cn.app.swagger.security.azure-ad.scopes.foo=foo description",
        })
@AutoConfigureMockMvc
public class SwaggerIntegrationTest {

    @Autowired
    MockMvc mockMvc;

    @Test
    public void testSwaggerPluginsAndFilters() throws Exception {
        String myResponseProperties = "$.definitions.MyResponse.properties";
        String baseBodyErrorProperties = "$.definitions.BaseBodyError.properties";
        String baseBodyDataErrorProperties = "$.definitions.BaseBodyDataError.properties";
        String operationGet = "$.paths['/'].get";
        String operationPost = "$.paths['/'].post";
        MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.get("/v2/api-docs"))
                .andDo(MockMvcResultHandlers.print())
                .andExpect(jsonPath(myResponseProperties + ".names.type").value("array"))
                // ArrayMinMaxItemsAnnotationPlugin
                .andExpect(jsonPath(myResponseProperties + ".names.minItems").value(5))
                .andExpect(jsonPath(myResponseProperties + ".names.maxItems").value(10))
                // ArrayItemsAnnotationPlugin
                .andExpect(jsonPath(myResponseProperties + ".names.items.type").value("string"))
                .andExpect(jsonPath(myResponseProperties + ".names.items.minLength").value(1))
                .andExpect(jsonPath(myResponseProperties + ".names.items.maxLength").value(100))
                .andExpect(jsonPath(myResponseProperties + ".names.items.pattern").value("^.{0,100}$"))
                // ErrorResponseAnnotationPlugin
                .andExpect(jsonPath(baseBodyErrorProperties + ".attributes['x-nullable']").value(true))
                .andExpect(jsonPath(baseBodyErrorProperties + ".errorCode['x-nullable']").value(true))
                .andExpect(jsonPath(baseBodyErrorProperties + ".messages['x-nullable']").value(true))
                .andExpect(jsonPath(baseBodyErrorProperties + ".dataErrors['x-nullable']").value(true))
                .andExpect(jsonPath(baseBodyDataErrorProperties + ".code['x-nullable']").value(true))
                .andExpect(jsonPath(baseBodyDataErrorProperties + ".value['x-nullable']").value(true))
                .andExpect(jsonPath(baseBodyDataErrorProperties + ".name['x-nullable']").value(true))
                .andExpect(jsonPath(baseBodyDataErrorProperties + ".message['x-nullable']").value(true))
                // AlternativeTypeRuleDefaultsProviderPlugin  -- Map<String, Object>
                .andExpect(jsonPath(myResponseProperties + ".mapOfObjectValues.additionalProperties").exists())
                .andExpect(jsonPath(myResponseProperties + ".mapOfStringValues.additionalProperties.type").value("string"))
                // ApiPropertyAnnotationPlugin (operation/parameter/definitions[field/list/map])
                .andExpect(jsonPath(operationGet + "['x-long']").value(1234L))
                .andExpect(jsonPath(operationGet + "['x-float']").value(12.34f))
                .andExpect(jsonPath(operationGet + ".parameters[?(@.name == 'id')]['x-string1']").value("value1"))
                .andExpect(jsonPath(myResponseProperties + ".names['x-double']").value(1.0))
                .andExpect(jsonPath(myResponseProperties + ".names.items['x-string2']").value("value2"))
                .andExpect(jsonPath(myResponseProperties + ".mapOfObjectValues['x-string3']").value("value3"))
                .andExpect(jsonPath(myResponseProperties + ".mapOfObjectValues['x-int-1']").value(1))
                .andExpect(jsonPath(myResponseProperties + ".mapOfObjectValues['x-int-2']").value(2))
                .andExpect(jsonPath(myResponseProperties + ".mapOfObjectValues['x-json'].prop").value("value"))
                // PrefixedExtensionsTransformationFilter
                .andExpect(jsonPath(myResponseProperties + ".names.items['x-string2']").value("value2"))
                .andExpect(jsonPath(operationGet + ".parameters[?(@.name == 'states')].items.maxLength").value(2))
                // DefaultResponseTransformationFilter
                .andExpect(jsonPath(operationGet + ".responses['200'].schema['$ref']").value("#/definitions/MyResponse"))
                .andExpect(jsonPath(operationGet + ".responses['default'].schema['$ref']").value("#/definitions/StandardErrorResponse"))
                // VendorExtensionsOverrideTransformationFilter
                .andExpect(jsonPath(myResponseProperties + ".name.minLength").doesNotExist())
                .andExpect(jsonPath(myResponseProperties + ".name.maxLength").value(11))
                // SpringfoxUpdateConfiguration
                .andExpect(jsonPath(myResponseProperties + ".localDates.items.type").value("string"))
                .andExpect(jsonPath(myResponseProperties + ".localDates.items.format").value("date"))
                .andExpect(jsonPath(myResponseProperties + ".localDates.items.maxLength").value(10))
                .andExpect(jsonPath(myResponseProperties + ".zonedDateTimes.items.type").value("string"))
                .andExpect(jsonPath(myResponseProperties + ".zonedDateTimes.items.format").value("date-time"))
                .andExpect(jsonPath(myResponseProperties + ".zonedDateTimes.items.maxLength").value(50))
                // XNullableModelPropertyParameterPlugin
                .andExpect(jsonPath(myResponseProperties + ".optionalField['x-nullable']").value(true))
                .andExpect(jsonPath(myResponseProperties + ".requiredField['x-nullable']").doesNotExist())
                .andExpect(jsonPath(operationGet + ".parameters[?(@.name == 'id')]['x-nullable']").doesNotExist())
                .andExpect(jsonPath(operationGet + ".parameters[?(@.name == 'states')]['x-nullable']").value(true))
                // MapAdditionalPropertiesModelPropertyBuilderPlugin
                .andExpect(jsonPath(myResponseProperties + ".mapOfObjectValues.additionalProperties['x-bool']").value(true))
                .andExpect(jsonPath(myResponseProperties + ".mapOfObjectValues.additionalProperties.type").doesNotExist())
                .andExpect(jsonPath(myResponseProperties + ".mapOfStringValues.additionalProperties['x-bool2']").value(false))
                .andExpect(jsonPath(myResponseProperties + ".mapOfStringValues.additionalProperties.type").value("string"))
                .andExpect(jsonPath(myResponseProperties + ".mapOfStringValues.additionalProperties.minLength").value(1))
                .andExpect(jsonPath(myResponseProperties + ".mapOfStringValues.additionalProperties.maxLength").value(15))
                // ApiOperationExtAnnotationPlugin
                // + ApiOperationSecurityAnnotationPlugin + ApiOperationSecurityTransformationFilter
                .andExpect(jsonPath(operationGet + ".security[?(@['azure-ad'])]").exists())
                .andExpect(jsonPath(operationGet + ".security[?(@['application-id'])]").exists())
                .andExpect(jsonPath(operationPost + ".security[?(@['azure-ad'])]").doesNotExist())
                .andExpect(jsonPath(operationPost + ".security[?(@['application-id'])]").exists())

                .andReturn();
    }
    
}
