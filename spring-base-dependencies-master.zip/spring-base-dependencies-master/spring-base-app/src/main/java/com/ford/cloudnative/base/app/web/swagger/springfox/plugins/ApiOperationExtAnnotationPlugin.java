package com.ford.cloudnative.base.app.web.swagger.springfox.plugins;

import com.ford.cloudnative.base.app.web.swagger.springfox.annotation.ApiOperationExt;
import org.springframework.core.annotation.Order;
import org.springframework.util.ReflectionUtils;
import springfox.documentation.builders.OperationBuilder;
import springfox.documentation.service.SecurityReference;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spi.service.OperationBuilderPlugin;
import springfox.documentation.spi.service.contexts.OperationContext;
import springfox.documentation.swagger.common.SwaggerPluginSupport;

import javax.annotation.PostConstruct;
import java.lang.reflect.Field;
import java.util.List;

@Order(SwaggerPluginSupport.OAS_PLUGIN_ORDER + 50)
public class ApiOperationExtAnnotationPlugin implements OperationBuilderPlugin {

    Field securityReferencesField;

    @SuppressWarnings({"squid:S2259","squid:S3011"})
    @PostConstruct
    public void init() {
        securityReferencesField = ReflectionUtils.findField(OperationBuilder.class, "securityReferences");
        securityReferencesField.setAccessible(true);
    }

    @Override
    public void apply(OperationContext context) {
        ApiOperationExt annotation = context.findAnnotation(ApiOperationExt.class).orElse(null);
        if (annotation == null) return;

        if (annotation.clearAuthorizations()) {
            List<SecurityReference> securityReferences = (List<SecurityReference>)ReflectionUtils.getField(securityReferencesField, context.operationBuilder());
            if (securityReferences != null) securityReferences.clear();
        }
    }

    @Override
    public boolean supports(DocumentationType delimiter) {
        return SwaggerPluginSupport.pluginDoesApply(delimiter);
    }
}
