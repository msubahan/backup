package com.ford.cloudnative.base.app.web.swagger.springfox.annotation;

import com.ford.cloudnative.base.app.web.swagger.ApiSecurityScheme;

import java.lang.annotation.ElementType;
import java.lang.annotation.Repeatable;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Target({ElementType.METHOD})
@Retention(RetentionPolicy.RUNTIME)
@Repeatable(ApiOperationSecurity.Container.class)
public @interface ApiOperationSecurity {
    ApiSecurityScheme[] value() default {};
    String[] other() default {};

    @Target({ElementType.METHOD})
    @Retention(RetentionPolicy.RUNTIME)
    @interface Container {
        ApiOperationSecurity[] value();
    }
}
