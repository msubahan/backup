package com.ford.cloudnative.base.app.web.securedapi;

import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.PathMatchConfigurer;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

/**
 * Disable Trailing Slash Match - When enabled, does not treat /endpoint/ same as /endpoint
 */
@Configuration
@ConditionalOnProperty(prefix = "cn.app.secured-api", name = "path-match.use-trailing-slash-match", matchIfMissing = true)
public class DisableTrailingSlashMatchConfiguration implements WebMvcConfigurer {

    @Override
    public void configurePathMatch(PathMatchConfigurer configurer) {
        configurer.setUseTrailingSlashMatch(false);
    }
}
