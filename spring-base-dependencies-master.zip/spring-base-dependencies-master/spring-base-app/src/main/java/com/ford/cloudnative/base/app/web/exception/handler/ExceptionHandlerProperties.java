package com.ford.cloudnative.base.app.web.exception.handler;

import lombok.Data;
import org.springframework.beans.ConversionNotSupportedException;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.http.converter.HttpMessageNotWritableException;
import org.springframework.web.HttpMediaTypeException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.MissingPathVariableException;
import org.springframework.web.server.MediaTypeNotSupportedStatusException;
import org.springframework.web.server.MethodNotAllowedException;
import org.springframework.web.server.NotAcceptableStatusException;
import org.springframework.web.server.ServerWebInputException;
import org.springframework.web.server.UnsupportedMediaTypeStatusException;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

@Data
@ConfigurationProperties(prefix = "cn.app.exception-handler")
public class ExceptionHandlerProperties {
    public static final String DEFAULT_WHITE_LIST_GENERIC_MESSAGE = "No message available";

    @SuppressWarnings("deprecation")
    protected static final String[] DEFAULT_WHITE_LIST_EXCEPTIONS = {
                    "com.ford.**",
                    "org.springframework.web.bind.MissingRequestValueException", // Spring Boot 2.4+
                    MethodArgumentNotValidException.class.getName(),
                    HttpMediaTypeException.class.getName(),
                    UnsupportedMediaTypeStatusException.class.getName(),
                    MediaTypeNotSupportedStatusException.class.getName(), // superseded by (above) UnsupportedMediaTypeStatusException
                    ServerWebInputException.class.getName(),
                    NotAcceptableStatusException.class.getName(),
                    MethodNotAllowedException.class.getName()
            };

    protected static final String[] DEFAULT_LOGGING_EXCLUDE_EXCEPTIONS = {
                    // default was based on ResponseEntityExceptionHandler exceptions that return 5xx
                    MissingPathVariableException.class.getName(),
                    HttpMessageNotWritableException.class.getName(),
                    ConversionNotSupportedException.class.getName()
            };

    boolean enabled;
    boolean useBaseBodyResponse;
    boolean useEmptyValues;
    ExceptionHandlerDataErrorProperties dataErrors = new ExceptionHandlerDataErrorProperties();
    ExceptionHandlerAttributesProperties attributes = new ExceptionHandlerAttributesProperties();
    ExceptionHandlerMessagesProperties messages = new ExceptionHandlerMessagesProperties();
    ExceptionHandlerLoggingProperties logging = new ExceptionHandlerLoggingProperties();

    @Data
    public static class ExceptionHandlerDataErrorProperties {
        int statusCode = 400;  // Bad Request
        boolean includeCode;
        boolean includeValue;
    }

    @Data
    public static class ExceptionHandlerAttributesProperties {
        boolean includeException;
    }

    @Data
    public static class ExceptionHandlerMessagesProperties {
        ExceptionHandlerMessagesWhiteListProperties whiteList = new ExceptionHandlerMessagesWhiteListProperties();
    }

    @Data
    public static class ExceptionHandlerMessagesWhiteListProperties {
        List<String> exceptions = Arrays.asList(DEFAULT_WHITE_LIST_EXCEPTIONS);
        String genericMessage = DEFAULT_WHITE_LIST_GENERIC_MESSAGE;
    }

    @Data
    public static class ExceptionHandlerLoggingProperties {
        List<String> includeExceptions = Collections.emptyList();
        List<String> excludeExceptions = Collections.emptyList();
        List<String> defaultExcludeExceptions = Arrays.asList(DEFAULT_LOGGING_EXCLUDE_EXCEPTIONS);
    }

}
