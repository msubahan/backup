package com.ford.cloudnative.base.app.web.exception.handler.servlet;

import java.util.*;

import com.ford.cloudnative.base.api.ErrorResponse;
import com.ford.cloudnative.base.app.web.exception.handler.ErrorResponseBuilder;
import org.springframework.boot.web.error.ErrorAttributeOptions;
import org.springframework.boot.web.servlet.error.DefaultErrorAttributes;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.WebRequest;

import javax.servlet.ServletException;

/**
 * Media types text/html and those that are not handled (i.e. application/json) are forwarded to /error.
 * /error will rely on these default/fallback error attributes for error payload
 */
@Component
public class FallbackErrorAttributesHandler extends DefaultErrorAttributes {
	
    ErrorResponseBuilder errorResponseBuilder;

    public FallbackErrorAttributesHandler(ErrorResponseBuilder errorResponseBuilder) {
    	this.errorResponseBuilder = errorResponseBuilder;
	}

	// Request attribute 'javax.servlet.error.status_code' will be used to determine response status. This attribute, however, is overridden before
	// this method using the same generated error (if present) response entity object; Controller Advice --> StandardHostValue::status
    @Override
	@SuppressWarnings("null")
    public Map<String, Object> getErrorAttributes(WebRequest webRequest, ErrorAttributeOptions options) {
		Throwable error = getCauseThrowable(webRequest);
		ResponseEntity<ErrorResponse> errorResponseEntity = this.errorResponseBuilder.buildResponseEntity(error, webRequest);
        return this.errorResponseBuilder.getErrorAttributes(errorResponseEntity);
    }

	Throwable getCauseThrowable(WebRequest webRequest) {
		Throwable error = super.getError(webRequest);
		if (error != null) {
			while (error instanceof ServletException && error.getCause() != null) {
				error = error.getCause();
			}
		}
		return error;
	}
}
