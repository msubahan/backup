package com.ford.cloudnative.base.app.web.swagger.springfox;

import com.ford.cloudnative.base.app.web.swagger.SwaggerProperties;
import com.ford.cloudnative.base.app.web.swagger.SwaggerProperties.Display;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingClass;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.util.StringUtils;
import springfox.bean.validators.configuration.BeanValidatorPluginsConfiguration;
import springfox.documentation.RequestHandler;
import springfox.documentation.builders.ApiInfoBuilder;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.service.Contact;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.paths.DefaultPathProvider;
import springfox.documentation.spring.web.plugins.ApiSelectorBuilder;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;
import springfox.documentation.swagger2.web.WebMvcSwaggerTransformationFilter;

import javax.servlet.ServletContext;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.function.Predicate;

@Configuration
@ConditionalOnProperty(prefix = "cn.app.swagger", name = "enabled")
@SuppressWarnings("squid:S1118")
public class SwaggerConfiguration {

    @Configuration
    @ConditionalOnClass({Docket.class, BeanValidatorPluginsConfiguration.class, WebMvcSwaggerTransformationFilter.class})
    @EnableConfigurationProperties(SwaggerProperties.class)
    @EnableSwagger2
    @Import({ BeanValidatorPluginsConfiguration.class, SpringfoxConfiguration.class })
    public static class SetupSwaggerConfiguration {

        @Autowired
        SwaggerProperties properties;

        @Bean
        @SuppressWarnings("squid:S3776")
        public Docket api(ServletContext servletContext, @Autowired(required = false) List<SwaggerCustomizer> customizers) {

            Docket docket = new Docket(DocumentationType.SWAGGER_2)
                    .apiInfo(apiInfo())
                    .useDefaultResponseMessages(properties.isUseDefaultResponseMessages());

            if (properties.isHost()) {
                docket.host(properties.getApidoc().getHost());
            }

            // revert back to old v2.9.2 logic where context-path was placed in basePath and not prepended to endpoint paths
            String contextPath = servletContext.getContextPath();
            if (StringUtils.hasLength(contextPath)) {
                if (!properties.isBasePath()) properties.getApidoc().setBasePath(contextPath);
                docket.pathProvider(new DefaultPathProvider() {
                    @Override
                    public String getOperationPath(String operationPath) {
                        String path = super.getOperationPath(operationPath);
                        return path.startsWith(contextPath) ? path.substring(contextPath.length()) : path;
                    }
                });
            }

            // NOTE: For setting of basePath, see OverrideBasePathTransformationFilter (Swagger 2) or OverrideServersTransformationFilter (OAS 3)

            if (properties.isSchemes()) {
                docket.protocols(new HashSet<>(properties.getApidoc().getSchemes()));
            }

            SwaggerSecurity swaggerSecurity = new SwaggerSecurity(this.properties);
            if (!swaggerSecurity.getSecuritySchemes().isEmpty()) {
                docket.securitySchemes(swaggerSecurity.getSecuritySchemes())
                        .securityContexts(swaggerSecurity.getSecurityContexts());
            }

            // add selector paths
            ApiSelectorBuilder selectors = docket.select();
            List<Predicate<RequestHandler>> handlerPredicates = new ArrayList<>();
            String[] scanPackages = String.join(";", properties.getScanPackages()).trim().split(";");  // handle ; for backwards compatibility
            for (String basePackage : scanPackages) {
                if (!basePackage.trim().isEmpty()) {
                    handlerPredicates.add(RequestHandlerSelectors.basePackage(basePackage.trim()));
                }
            }
            if (!handlerPredicates.isEmpty()) {
                selectors.apis(or(handlerPredicates));
            }
            selectors.build();

            // customize
            if (customizers != null) {
                for (SwaggerCustomizer customizer : customizers) {
                    docket = customizer.customize(docket);
                }
            }

            return docket;
        }

        static <T> Predicate<T> or(Collection<Predicate<T>> predicates) {
            return t -> predicates.stream().anyMatch(predicate -> predicate.test(t));
        }

        ApiInfo apiInfo() {
            Display display = properties.getDisplay();
            return new ApiInfoBuilder()
                    .title(display.getTitle())
                    .description(display.getDescription())
                    .contact(valueOrNull(new Contact(display.getContactName(), display.getContactUrl(), display.getContactEmail())))
                    .version(display.getVersion())
                    .license(display.getLicense())
                    .licenseUrl(display.getLicenseUrl())
                    .termsOfServiceUrl(display.getTermsOfServiceUrl())
                    .build();
        }

        Contact valueOrNull(Contact contact) {
            return contact.getName() == null && contact.getUrl() == null && contact.getEmail() == null ? null : contact;
        }
    }

    @Slf4j
    @Configuration
    @ConditionalOnMissingClass("springfox.documentation.spring.web.plugins.Docket")
    public static class MissingDependenciesDocket {
        public MissingDependenciesDocket() {
            missingSpringFoxDependencies(log);
        }
    }

    @Slf4j
    @Configuration
    @ConditionalOnMissingClass("springfox.bean.validators.configuration.BeanValidatorPluginsConfiguration")
    public static class MissingDependenciesValidator {
        public MissingDependenciesValidator() {
            missingSpringFoxDependencies(log);
        }
    }

    @Slf4j
    @Configuration
    @ConditionalOnMissingClass("springfox.boot.starter.autoconfigure.OpenApiAutoConfiguration")
    public static class MissingDependenciesSpringFoxBootStarter {
        public MissingDependenciesSpringFoxBootStarter() {
            missingSpringFoxDependencies(log);
        }
    }

    static void missingSpringFoxDependencies(org.slf4j.Logger log) {
        log.error(
                "*****************************************************************************************************************\n" +
                        "*  Unable to auto-configure the Cloud Native 'swagger' extension due to missing dependencies.\n" +
                        "*  Ensure the following dependency is added to your project to resolve the issue and enable this extension:\n" +
                        "*    - io.springfox:springfox-boot-starter\n" +
                        "*****************************************************************************************************************");
        throw new IllegalStateException("Dependency not satisfied. See above error message.");
    }
}
