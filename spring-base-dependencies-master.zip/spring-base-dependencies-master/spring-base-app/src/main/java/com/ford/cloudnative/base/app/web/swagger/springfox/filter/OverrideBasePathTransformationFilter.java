package com.ford.cloudnative.base.app.web.swagger.springfox.filter;

import com.ford.cloudnative.base.app.web.swagger.SwaggerProperties;
import io.swagger.models.Swagger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.annotation.Order;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.swagger2.web.SwaggerTransformationContext;
import springfox.documentation.swagger2.web.WebMvcSwaggerTransformationFilter;

import javax.servlet.http.HttpServletRequest;

import static springfox.documentation.spi.DocumentationType.SWAGGER_2;
import static springfox.documentation.swagger.common.SwaggerPluginSupport.SWAGGER_PLUGIN_ORDER;

@Order(SWAGGER_PLUGIN_ORDER + 10)
public class OverrideBasePathTransformationFilter implements WebMvcSwaggerTransformationFilter {
    final SwaggerProperties properties;

    @Autowired
    public OverrideBasePathTransformationFilter(SwaggerProperties properties) {
        this.properties = properties;
    }

    @Override
    public Swagger transform(final SwaggerTransformationContext<HttpServletRequest> context) {
        Swagger swagger = context.getSpecification();
        if (properties.isBasePath()) swagger.basePath(properties.getApidoc().getBasePath());
        return swagger;
    }

    @Override
    public boolean supports(final DocumentationType documentationType) {
        return SWAGGER_2.equals(documentationType);
    }
}
