package com.ford.cloudnative.base.app.web.filter;

import java.io.IOException;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.filter.OncePerRequestFilter;

public class RequestFilter extends OncePerRequestFilter {
	public static final String START_TIME_ATTRIBUTE = "cn.app.startTime";

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain) throws ServletException, IOException {
    	request.setAttribute(START_TIME_ATTRIBUTE, System.currentTimeMillis());
    	filterChain.doFilter(request, response);
    }
}

