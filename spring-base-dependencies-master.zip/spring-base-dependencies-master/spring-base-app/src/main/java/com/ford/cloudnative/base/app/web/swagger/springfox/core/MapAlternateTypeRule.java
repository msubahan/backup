package com.ford.cloudnative.base.app.web.swagger.springfox.core;

import com.fasterxml.classmate.ResolvedType;
import springfox.documentation.schema.AlternateTypeRule;

import java.util.Map;

// Overrides all map-related rules defined in Defaults.defaultRules.
// All Map objects will be treated as maps and none of them as regular Objects.
public class MapAlternateTypeRule extends AlternateTypeRule {

    public MapAlternateTypeRule() {
        super(null, null, 0);
    }

    @Override
    public ResolvedType alternateFor(ResolvedType type) {
        return type;
    }

    @Override
    public boolean appliesTo(ResolvedType type) {
        return Map.class.isAssignableFrom(type.getErasedType());
    }
}
