package com.ford.cloudnative.base.app.web.exception.handler;

import com.ford.cloudnative.base.api.ErrorResponse;
import com.ford.cloudnative.base.app.web.exception.handler.ErrorResponseBuilder.ErrorResponseBuilderProxy;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

public interface ExceptionHandler {

    ResponseEntity<ErrorResponse> handleError(Throwable error, RequestWrapper requestWrapper, HttpStatus overrideStatus, ErrorResponseBuilderProxy builder);

}
