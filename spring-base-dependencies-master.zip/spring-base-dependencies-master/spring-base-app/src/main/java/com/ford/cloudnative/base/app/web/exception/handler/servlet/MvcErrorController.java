package com.ford.cloudnative.base.app.web.exception.handler.servlet;

import com.ford.cloudnative.base.app.web.exception.handler.ExceptionHandlerProperties;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.boot.autoconfigure.web.ServerProperties;
import org.springframework.boot.autoconfigure.web.servlet.error.BasicErrorController;
import org.springframework.boot.autoconfigure.web.servlet.error.ErrorViewResolver;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.boot.web.servlet.error.ErrorAttributes;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpServletRequest;
import java.util.Map;
import java.util.stream.Collectors;

@Controller
@RequestMapping("${server.error.path:${error.path:/error}}")
@EnableConfigurationProperties({ ServerProperties.class, ExceptionHandlerProperties.class })
public class MvcErrorController extends BasicErrorController {
    boolean useProblemJsonContentType;

    public MvcErrorController(ErrorAttributes errorAttributes, ServerProperties serverProperties, ObjectProvider<ErrorViewResolver> errorViewResolvers,
                              ExceptionHandlerProperties exceptionHandlerProperties) {
        super(errorAttributes, serverProperties.getError(), errorViewResolvers.orderedStream().collect(Collectors.toList()));
        this.useProblemJsonContentType = !exceptionHandlerProperties.isUseBaseBodyResponse();
    }

    @Override
    @RequestMapping
    public ResponseEntity<Map<String, Object>> error(HttpServletRequest request) {
        ResponseEntity<Map<String, Object>> responseEntity = super.error(request);
        if (this.useProblemJsonContentType && responseEntity.hasBody() && responseEntity.getHeaders().getContentType() == null) {
            return responseEntityWithProblemJsonContentType(responseEntity);
        } else {
            return responseEntity;
        }
    }

    private <T> ResponseEntity<T> responseEntityWithProblemJsonContentType(ResponseEntity<T> responseEntity) {
        return ResponseEntity.status(responseEntity.getStatusCode())
                .headers(responseEntity.getHeaders())
                .contentType(MediaType.APPLICATION_PROBLEM_JSON)
                .body(responseEntity.getBody());
    }

}
