package com.ford.cloudnative.base.app.web.securedapi;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;

import javax.servlet.*;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * Disallowed HTTP Method Filter - When enabled, black lists the HEAD and non-CORS OPTIONS HTTP methods (if not disabled individually)
 */
@Configuration
public class DisallowedHttpMethodsFilterConfiguration {

    @Value("${cn.app.secured-api.http-method.disallow-head:true}")
    boolean disallowHttpHeadMethod;

    @Value("${cn.app.secured-api.http-method.disallow-options-for-non-cors:true}")
    boolean disallowNonCorsHttpOptionsMethod;

    @Bean
    public FilterRegistrationBean<DisallowedHttpMethodsFilter> disallowedHttpMethodFilterRegistrationBean() {
        FilterRegistrationBean<DisallowedHttpMethodsFilter> disallowedHttpMethodsFilterBean = new FilterRegistrationBean<>();
        disallowedHttpMethodsFilterBean.setFilter(new DisallowedHttpMethodsFilter());
        return disallowedHttpMethodsFilterBean;
    }

    class DisallowedHttpMethodsFilter implements Filter {

        @Override
        public void doFilter(ServletRequest request, ServletResponse response, FilterChain filterChain)
                throws IOException, ServletException {

            if (disallowedHttpMethods().contains(((HttpServletRequest) request).getMethod())) {
                ((HttpServletResponse) response).setStatus(HttpServletResponse.SC_METHOD_NOT_ALLOWED);
            } else {
                filterChain.doFilter(request, response);
            }
        }
    }

    protected List<String> disallowedHttpMethods() {
        List<String> disallowedHttpMethods = new ArrayList<>();
        if (disallowHttpHeadMethod) disallowedHttpMethods.add(HttpMethod.HEAD.name());
        if (disallowNonCorsHttpOptionsMethod) disallowedHttpMethods.add(HttpMethod.OPTIONS.name());
        return disallowedHttpMethods;
    }
}
