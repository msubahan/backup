package com.ford.cloudnative.base.app.web.swagger.springfox;

import springfox.documentation.spring.web.plugins.Docket;

public interface SwaggerCustomizer {
    default Docket customize(Docket docket) { return docket; }
}
