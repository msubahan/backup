package com.ford.cloudnative.base.app.web.swagger.springfox.plugins;

import com.ford.cloudnative.base.app.web.swagger.springfox.annotation.ApiOperationSecurity;
import com.ford.cloudnative.base.app.web.swagger.ApiSecurityScheme;
import org.springframework.core.annotation.Order;
import springfox.documentation.service.AuthorizationScope;
import springfox.documentation.service.SecurityReference;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spi.service.OperationBuilderPlugin;
import springfox.documentation.spi.service.contexts.OperationContext;
import springfox.documentation.swagger.common.SwaggerPluginSupport;

import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import static java.util.stream.Collectors.toList;

@Order(SwaggerPluginSupport.OAS_PLUGIN_ORDER + 51)
public class ApiOperationSecurityAnnotationPlugin implements OperationBuilderPlugin {

    @Override
    public void apply(OperationContext context) {
        Collection<ApiOperationSecurity> apiOperationSecurities = getAnnotations(context);
        if (apiOperationSecurities.isEmpty()) return;

        // fetch existing
        List<SecurityReference> securityReferences = context.operationBuilder().build().getSecurityReferences().entrySet().stream()
                .map(entry -> new SecurityReference(entry.getKey(), entry.getValue().toArray(new AuthorizationScope[0])))
                .collect(toList());

        // add on
        apiOperationSecurities.stream().forEach(apiOperationSecurity -> {
            Collection<String> securitySchemeNames = getSecuritySchemeNames(apiOperationSecurity);
            String joinedSchemeNames = String.join(",", securitySchemeNames);
            if (securitySchemeNames.size() > 1) joinedSchemeNames = "," + joinedSchemeNames;
            securityReferences.add(new SecurityReference(joinedSchemeNames, new AuthorizationScope[0]));
        });

        context.operationBuilder().authorizations(securityReferences);
    }

    Collection<ApiOperationSecurity> getAnnotations(OperationContext context) {
        Optional<ApiOperationSecurity> annotation = context.findAnnotation(ApiOperationSecurity.class);
        if (annotation.isPresent()) return Collections.singleton(annotation.get());

        Optional<ApiOperationSecurity.Container> container = context.findAnnotation(ApiOperationSecurity.Container.class);
        if (container.isPresent()) return Arrays.asList(container.get().value());

        return Collections.emptyList();
    }

    Collection<String> getSecuritySchemeNames(ApiOperationSecurity apiOperationSecurity) {
        List<String> names = Arrays.stream(apiOperationSecurity.value()).map(ApiSecurityScheme::getSchemeName).collect(Collectors.toList());
        names.addAll(Arrays.asList(apiOperationSecurity.other()));
        return names;
    }

    @Override
    public boolean supports(DocumentationType delimiter) {
        return SwaggerPluginSupport.pluginDoesApply(delimiter);
    }
}
