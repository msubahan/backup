package com.ford.cloudnative.base.app.datasource.configure;

import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.BeanCreationException;
import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
import org.springframework.beans.factory.support.BeanDefinitionRegistry;
import org.springframework.boot.jdbc.DatabaseDriver;
import org.springframework.cloud.Cloud;
import org.springframework.cloud.CloudFactory;
import org.springframework.cloud.service.ServiceInfo;
import org.springframework.cloud.service.common.RelationalServiceInfo;
import org.springframework.cloud.service.relational.DataSourceCreator;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.ImportBeanDefinitionRegistrar;
import org.springframework.core.type.AnnotationMetadata;

@Configuration
public class DataSourceConfigureScanConfiguration implements ImportBeanDefinitionRegistrar {
	private static final Logger logger = LoggerFactory.getLogger(DataSourceConfigureScanConfiguration.class);
	
	@Override
	public void registerBeanDefinitions(AnnotationMetadata importingClassMetadata, BeanDefinitionRegistry registry) {
		List<ServiceInfo> serviceInfos = cloud().getServiceInfos();
		ConfigurableListableBeanFactory beanFactory = (ConfigurableListableBeanFactory) registry;

		for (ServiceInfo serviceInfo : serviceInfos) {
			if (serviceInfo instanceof UserProvidedRelationalServiceInfo) {
				DataSource dataSource = createDataSource((UserProvidedRelationalServiceInfo)serviceInfo);
				beanFactory.registerSingleton(serviceInfo.getId(), dataSource);
				logger.info("Created DataSource bean for service: {}", serviceInfo.getId());
			}
		}
	}

	protected Cloud cloud() {
		return new CloudFactory().getCloud();
	}
	
	DataSource createDataSource(UserProvidedRelationalServiceInfo serviceInfo) {
		Map<String, Object> serviceData = serviceInfo.getServiceData();
		@SuppressWarnings("unchecked")
		Map<String, String> credentials = (Map<String, String>)serviceData.get("credentials");
		String jdbcUrl = credentials.get("jdbcDbUrl");
		
		DatabaseDriver databaseDriver = DatabaseDriver.fromJdbcUrl(jdbcUrl);
		if (databaseDriver == DatabaseDriver.UNKNOWN) {
			logger.warn("Could not determine the database driver for service ({}) jdbc url: {}", serviceInfo.getId(), jdbcUrl);
			throw new BeanCreationException(String.format("Could not determine the database driver for service (%s) jdbc url: %s. Cannot support and auto-configure this particular JDBC URL. Consider to manually register the DataSource in the application code base.", serviceInfo.getId(), jdbcUrl));
		}
		
		UpsRelationalServiceInfo upsServiceInfo = new UpsRelationalServiceInfo(serviceInfo.getId(), jdbcUrl);
		return new UpsDataSourceCreator(databaseDriver.getDriverClassName(), databaseDriver.getValidationQuery()).create(upsServiceInfo, null);
	}


	public static class UpsRelationalServiceInfo extends RelationalServiceInfo {
		public UpsRelationalServiceInfo(String id, String jdbcUrl) {
			super(id, "dummy://uri", jdbcUrl, null);
		}
	}
	
	public static class UpsDataSourceCreator extends DataSourceCreator<UpsRelationalServiceInfo> {
		public UpsDataSourceCreator(String driverClassName, String validationQuery) {
			super("dummy-driver-system-property-key", new String[] {driverClassName}, validationQuery);
		}
	}
}
