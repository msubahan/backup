package com.ford.cloudnative.base.app.datasource.configure;

import java.util.Map;

import org.springframework.cloud.service.BaseServiceInfo;

public class UserProvidedRelationalServiceInfo extends BaseServiceInfo {

	Map<String, Object> serviceData;

	public UserProvidedRelationalServiceInfo(Map<String, Object> serviceData) {
		super((String)serviceData.get("name"));
		this.serviceData = serviceData;
	}
	
	public Map<String, Object> getServiceData() {
		return this.serviceData;
	}

}
