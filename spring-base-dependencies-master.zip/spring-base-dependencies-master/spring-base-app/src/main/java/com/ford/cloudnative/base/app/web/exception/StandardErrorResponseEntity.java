package com.ford.cloudnative.base.app.web.exception;

import com.ford.cloudnative.base.api.BaseBodyError;
import com.ford.cloudnative.base.api.StandardErrorResponse;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.MultiValueMap;

public class StandardErrorResponseEntity extends ResponseEntity<StandardErrorResponse> {

	public StandardErrorResponseEntity(String message, HttpStatus httpStatus) {
		this(message, null, null, httpStatus);
	}

	public StandardErrorResponseEntity(String message, String errorCode, HttpStatus httpStatus) {
		this(message, errorCode, null, httpStatus);
	}

	public StandardErrorResponseEntity(BaseBodyError error, HttpStatus httpStatus) {
		this(error, null, httpStatus);
	}

	public StandardErrorResponseEntity(String message, MultiValueMap<String, String> headers, HttpStatus httpStatus) {
		this(message, null, headers, httpStatus);
	}

	public StandardErrorResponseEntity(String message, String errorCode, MultiValueMap<String, String> headers, HttpStatus httpStatus) {
		this(BaseBodyError.builder()
						.errorCode(errorCode)
						.message(message)
						.build(),
				headers,
				httpStatus
		);
	}

	public StandardErrorResponseEntity(BaseBodyError error, MultiValueMap<String, String> headers, HttpStatus status) {
		super(StandardErrorResponse.error(error, status.value()), headers, status);
	}

}
