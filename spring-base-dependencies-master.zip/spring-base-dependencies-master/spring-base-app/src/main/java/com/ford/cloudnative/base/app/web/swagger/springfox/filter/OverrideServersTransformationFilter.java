package com.ford.cloudnative.base.app.web.swagger.springfox.filter;

import com.ford.cloudnative.base.app.web.swagger.SwaggerProperties;
import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.servers.Server;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.annotation.Order;
import springfox.documentation.oas.web.OpenApiTransformationContext;
import springfox.documentation.oas.web.WebMvcOpenApiTransformationFilter;
import springfox.documentation.spi.DocumentationType;

import javax.servlet.http.HttpServletRequest;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.stream.Collectors;

import static springfox.documentation.spi.DocumentationType.OAS_30;
import static springfox.documentation.swagger.common.SwaggerPluginSupport.SWAGGER_PLUGIN_ORDER;

// This is a workaround to bug https://github.com/springfox/springfox/issues/3483
// This class is not a general fix and is a workaround to our use-case only
@Order(SWAGGER_PLUGIN_ORDER + 10)
public class OverrideServersTransformationFilter implements WebMvcOpenApiTransformationFilter {
    final SwaggerProperties properties;

    @Autowired
    public OverrideServersTransformationFilter(SwaggerProperties properties) {
        this.properties = properties;
    }

    @Override
    public OpenAPI transform(final OpenApiTransformationContext<HttpServletRequest> context) {
        OpenAPI openApi = context.getSpecification();

        List<Server> servers = getConfigServers().stream()
                .map(configServer -> new Server().url(configServer.getUrl()))
                .collect(Collectors.toList());
        openApi.servers(servers);

        return openApi;
    }

    List<springfox.documentation.service.Server> getConfigServers() {
        String hostPort = properties.isHost() ? properties.getApidoc().getHost() : "{host}:{port}";
        String basePath = properties.isBasePath() ? properties.getApidoc().getBasePath() : "";
        Collection<String> schemes = properties.isSchemes() ? new HashSet<>(properties.getApidoc().getSchemes()) : Collections.singletonList("{scheme}");
        return schemes.stream().map(scheme -> {
                    String url = String.format("%s://%s%s", scheme, hostPort, basePath);
                    return new springfox.documentation.service.Server(null, url,null, Collections.emptyList(), Collections.emptyList());
                }).collect(Collectors.toList());
    }

    @Override
    public boolean supports(final DocumentationType documentationType) {
        return OAS_30.equals(documentationType);
    }
}
