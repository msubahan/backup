package com.ford.cloudnative.base.app.web.swagger.springfox.filter;

import io.swagger.models.Operation;
import io.swagger.models.Path;
import io.swagger.models.Swagger;
import org.springframework.core.annotation.Order;
import org.springframework.util.StringUtils;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.swagger2.web.SwaggerTransformationContext;
import springfox.documentation.swagger2.web.WebMvcSwaggerTransformationFilter;

import javax.servlet.http.HttpServletRequest;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

import static springfox.documentation.spi.DocumentationType.SWAGGER_2;
import static springfox.documentation.swagger.common.SwaggerPluginSupport.SWAGGER_PLUGIN_ORDER;

@Order(SWAGGER_PLUGIN_ORDER + 10)
public class ApiOperationSecurityTransformationFilter implements WebMvcSwaggerTransformationFilter {
    static final String DEFAULT_RESPONSE_CODE = "0";

    @Override
    public Swagger transform(final SwaggerTransformationContext<HttpServletRequest> context) {
        Swagger swagger = context.getSpecification();
        if (swagger.getPaths() != null) {
            swagger.getPaths().values().stream()
                    .map(Path::getOperations)
                    .flatMap(Collection::stream)
                    .map(Operation::getSecurity)
                    .forEach(this::normalizeSecurityGroups);
        }
        return swagger;
    }

    void normalizeSecurityGroups(List<Map<String, List<String>>> securityItems) {
        if (securityItems == null) return;

        List<Map<String, List<String>>> updatedSecurityItems = securityItems.stream()
                .map(securityItem -> {
                    String schemeName = securityItem.keySet().iterator().next();
                    if (!schemeName.startsWith(",")) return securityItem;
                    return Arrays.stream(StringUtils.tokenizeToStringArray(schemeName, ",", false, true))
                            .collect(Collectors.toMap(Function.identity(), x -> Collections.<String>emptyList()));
                })
                .collect(Collectors.toList());

        securityItems.clear();
        securityItems.addAll(updatedSecurityItems);
    }

    @Override
    public boolean supports(final DocumentationType documentationType) {
        return SWAGGER_2.equals(documentationType);
    }

}
