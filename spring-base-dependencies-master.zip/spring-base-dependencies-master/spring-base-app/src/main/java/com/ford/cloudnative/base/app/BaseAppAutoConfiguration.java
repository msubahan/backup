package com.ford.cloudnative.base.app;

import com.ford.cloudnative.base.app.datasource.configure.DataSourceConfigureConfiguration;
import com.ford.cloudnative.base.app.datasource.populate.DataSourcePopulateConfiguration;
import com.ford.cloudnative.base.app.rabbit.LocalRabbitConfiguration;
import com.ford.cloudnative.base.app.web.filter.APIGatewayForwardingFilterConfiguration;
import com.ford.cloudnative.base.app.web.filter.RequestFilterConfiguration;
import com.ford.cloudnative.base.app.web.header.ApplicationInfoHeaderConfiguration;
import com.ford.cloudnative.base.app.web.header.RequestInfoHeaderConfiguration;
import com.ford.cloudnative.base.app.web.securedapi.SecuredApiConfiguration;
import com.ford.cloudnative.base.app.web.swagger.springfox.SwaggerConfiguration;
import com.ford.cloudnative.base.app.web.tracer.DefaultRequestTracerConfiguration;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;

@Configuration
@Import({
	DefaultRequestTracerConfiguration.class,
	RequestFilterConfiguration.class,
	RequestInfoHeaderConfiguration.class,
	ApplicationInfoHeaderConfiguration.class,
	SwaggerConfiguration.class,
	DataSourceConfigureConfiguration.class,
	DataSourcePopulateConfiguration.class,
	LocalRabbitConfiguration.class,
	APIGatewayForwardingFilterConfiguration.class,
	SecuredApiConfiguration.class
})
public class BaseAppAutoConfiguration {

}
