package com.ford.cloudnative.base.app.web.exception.handler;

import com.ford.cloudnative.base.api.ErrorResponse;
import com.ford.cloudnative.base.app.configure.core.ClassPatternMatcher;
import com.ford.cloudnative.base.app.web.exception.handler.ErrorResponseBuilder.ErrorResponseBuilderProxy;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static org.springframework.web.util.WebUtils.ERROR_MESSAGE_ATTRIBUTE;

@Slf4j
public class DefaultExceptionHandler implements ExceptionHandler {

    final ClassPatternMatcher loggingIncludeExceptionPatternMatcher;
    final ClassPatternMatcher loggingExcludeExceptionPatternMatcher;

    public DefaultExceptionHandler(ExceptionHandlerProperties properties) {
        this.loggingIncludeExceptionPatternMatcher = new ClassPatternMatcher(properties.getLogging().getIncludeExceptions());
        this.loggingExcludeExceptionPatternMatcher = new ClassPatternMatcher(combineLists(properties.getLogging().getDefaultExcludeExceptions(), properties.getLogging().getExcludeExceptions()));
    }

    public ResponseEntity<ErrorResponse> handleError(Throwable error, RequestWrapper requestWrapper, HttpStatus overrideStatus, ErrorResponseBuilderProxy builder) {
        ResponseEntity<ErrorResponse> responseEntity = buildResponseEntity(error, requestWrapper, overrideStatus, builder);
        log(responseEntity, error, requestWrapper);
        return responseEntity;
    }

    protected ResponseEntity<ErrorResponse> buildResponseEntity(Throwable error, RequestWrapper requestWrapper, HttpStatus overrideStatus, ErrorResponseBuilderProxy builder) {
        return builder.buildResponseEntity(error, requestWrapper, overrideStatus);
    }

    protected void log(ResponseEntity<ErrorResponse> responseEntity, Throwable error, RequestWrapper requestWrapper) {
        log.trace("logged by exception handler: status = {}, javax.servlet.error.message = {}, error = ", responseEntity.getStatusCodeValue(), requestWrapper.getAttribute(ERROR_MESSAGE_ATTRIBUTE), error);
        if (isLoggable(responseEntity, error, requestWrapper)) {
            logError(responseEntity, error, requestWrapper);
        }
    }

    protected void logError(ResponseEntity<ErrorResponse> responseEntity, Throwable error, RequestWrapper requestWrapper) {
        if (error != null) {
            log.error("logged by exception handler: status = {}, error: ", responseEntity.getStatusCodeValue(), error);
        } else {
            log.error("logged by exception handler: status = {}, message = {}", responseEntity.getStatusCodeValue(), requestWrapper.getAttribute(ERROR_MESSAGE_ATTRIBUTE));
        }
    }

    protected boolean isLoggable(ResponseEntity<ErrorResponse> responseEntity, Throwable error, RequestWrapper requestWrapper) {
        Optional<Boolean> loggableByConfiguration = isLoggableByConfiguration(error);
        if (loggableByConfiguration.isPresent()) return loggableByConfiguration.get();

        return isLoggableFallbackLogic(responseEntity, error, requestWrapper);
    }

    protected Optional<Boolean> isLoggableByConfiguration(Throwable error) {
        if (error != null) {
            if (this.loggingIncludeExceptionPatternMatcher.isMatch(error.getClass())) return Optional.of(true);
            if (this.loggingExcludeExceptionPatternMatcher.isMatch(error.getClass())) return Optional.of(false);
        }
        return Optional.empty(); // not accounted
    }

    @SuppressWarnings("unused")
    protected boolean isLoggableFallbackLogic(ResponseEntity<ErrorResponse> responseEntity, Throwable error, RequestWrapper requestWrapper) {
        return responseEntity.getStatusCode().is5xxServerError();
    }

    <T> List<T> combineLists(List<T> list1, List<T> list2) {
        return Stream.concat(list1.stream(), list2.stream()).collect(Collectors.toList());
    }

}
