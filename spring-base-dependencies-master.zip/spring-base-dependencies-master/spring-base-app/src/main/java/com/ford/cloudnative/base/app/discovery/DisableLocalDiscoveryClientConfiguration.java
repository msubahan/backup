package com.ford.cloudnative.base.app.discovery;

import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.context.annotation.Profile;

@Configuration
@ConditionalOnProperty(prefix = "cn.app.disable-local-discovery-client", name = "enabled")
@Profile("!cloud")
@Import(DisableEurekaClientBootstrap.class)
public class DisableLocalDiscoveryClientConfiguration {

}
