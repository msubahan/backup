package com.ford.cloudnative.base.app.web.swagger.springfox.plugins;


import com.ford.cloudnative.base.api.BaseBodyError;
import com.ford.cloudnative.base.api.BaseBodyError.BaseBodyDataError;
import com.ford.cloudnative.base.app.web.swagger.springfox.core.PropertyVendorExtension;
import org.springframework.core.annotation.Order;
import springfox.bean.validators.plugins.Validators;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spi.schema.ModelPropertyBuilderPlugin;
import springfox.documentation.spi.schema.contexts.ModelPropertyContext;

import javax.validation.constraints.NotNull;
import java.util.Collections;
import java.util.Optional;

@Order(Validators.BEAN_VALIDATOR_PLUGIN_ORDER - 50)
public class ErrorResponseModelPropertyBuilderPlugin implements ModelPropertyBuilderPlugin {
    static final PropertyVendorExtension X_NULLABLE = new PropertyVendorExtension("x-nullable", true);

    @Override
    public boolean supports(DocumentationType delimiter) {
        return true;
    }

    @Override
    public void apply(ModelPropertyContext context) {
        if (context.getOwner() == null) return;
        Class<?> ownerClass = context.getOwner().getType().getErasedType();

        if (BaseBodyError.class.isAssignableFrom(ownerClass) || BaseBodyDataError.class.isAssignableFrom(ownerClass)) {
            Optional<NotNull> notNull = PluginUtils.extractAnnotation(context, NotNull.class);
            if (!notNull.isPresent()) context.getSpecificationBuilder().vendorExtensions(Collections.singletonList(X_NULLABLE));
        }
    }

}
