package com.ford.cloudnative.base.app.web.header;

import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.ford.cloudnative.base.app.web.tracer.RequestTracer;

@Configuration
@ConditionalOnProperty(prefix = "cn.app.request-info-header", name = "enabled", matchIfMissing = false)
public class RequestInfoHeaderConfiguration {
	
	@Bean
	@ConditionalOnMissingBean
	public RequestInfoHeaderResponseBodyAdvice requestInfoHeaderResponseBodyAdvice(RequestTracer requestTracer) {
		return new RequestInfoHeaderResponseBodyAdvice(requestTracer);
	}
	
}
