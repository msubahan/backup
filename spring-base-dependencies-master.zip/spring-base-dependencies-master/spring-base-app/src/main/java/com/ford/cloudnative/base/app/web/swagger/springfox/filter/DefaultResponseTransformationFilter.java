package com.ford.cloudnative.base.app.web.swagger.springfox.filter;

import io.swagger.models.Operation;
import io.swagger.models.Path;
import io.swagger.models.Swagger;
import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.PathItem;
import org.springframework.core.annotation.Order;
import springfox.documentation.oas.web.OpenApiTransformationContext;
import springfox.documentation.oas.web.WebMvcOpenApiTransformationFilter;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.swagger2.web.SwaggerTransformationContext;
import springfox.documentation.swagger2.web.WebMvcSwaggerTransformationFilter;

import javax.servlet.http.HttpServletRequest;
import java.util.Collection;
import java.util.Map;

import static springfox.documentation.spi.DocumentationType.OAS_30;
import static springfox.documentation.spi.DocumentationType.SWAGGER_2;
import static springfox.documentation.swagger.common.SwaggerPluginSupport.SWAGGER_PLUGIN_ORDER;

@Order(SWAGGER_PLUGIN_ORDER + 10)
public class DefaultResponseTransformationFilter implements WebMvcSwaggerTransformationFilter, WebMvcOpenApiTransformationFilter {
    static final String DEFAULT_RESPONSE_CODE = "0";

    @Override
    public Swagger transform(final SwaggerTransformationContext<HttpServletRequest> context) {
        Swagger swagger = context.getSpecification();
        renameDefaultKey(swagger.getResponses());
        if (swagger.getPaths() != null) {
            swagger.getPaths().values().stream()
                    .map(Path::getOperations)
                    .flatMap(Collection::stream)
                    .map(Operation::getResponses)
                    .forEach(this::renameDefaultKey);
        }
        return swagger;
    }

    @Override
    public OpenAPI transform(OpenApiTransformationContext<HttpServletRequest> context) {
        OpenAPI openApi = context.getSpecification();
        if (openApi.getPaths() != null) {
            openApi.getPaths().values().stream()
                    .map(PathItem::readOperations)
                    .flatMap(Collection::stream)
                    .map(io.swagger.v3.oas.models.Operation::getResponses)
                    .forEach(this::renameDefaultKey);
        }
        return openApi;
    }

    <T> void renameDefaultKey(Map<String, T> responseMap) {
        if (responseMap != null && responseMap.containsKey(DEFAULT_RESPONSE_CODE)) {
            responseMap.put("default", responseMap.get(DEFAULT_RESPONSE_CODE));
            responseMap.remove(DEFAULT_RESPONSE_CODE);
        }
    }

    @Override
    public boolean supports(final DocumentationType documentationType) {
        return SWAGGER_2.equals(documentationType) || OAS_30.equals(documentationType);
    }

}
