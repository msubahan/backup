package com.ford.cloudnative.base.app.web.filter;

import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.Ordered;

@Configuration
public class RequestFilterConfiguration {
	
    @Bean
    public FilterRegistrationBean<RequestFilter> registerRequestFilter() {
        FilterRegistrationBean<RequestFilter> registrationBean = new FilterRegistrationBean<>(new RequestFilter());
        registrationBean.setOrder(Ordered.HIGHEST_PRECEDENCE); //first filter in order capture earliest start time possible
        return registrationBean;
    }
}
