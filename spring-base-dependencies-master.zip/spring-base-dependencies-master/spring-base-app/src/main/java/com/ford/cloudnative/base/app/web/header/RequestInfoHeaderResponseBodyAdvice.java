package com.ford.cloudnative.base.app.web.header;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.MethodParameter;
import org.springframework.http.MediaType;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.http.server.ServerHttpRequest;
import org.springframework.http.server.ServerHttpResponse;
import org.springframework.http.server.ServletServerHttpRequest;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.servlet.mvc.method.annotation.ResponseBodyAdvice;

import com.ford.cloudnative.base.app.web.filter.RequestFilter;
import com.ford.cloudnative.base.app.web.tracer.RequestTracer;

@ControllerAdvice
public class RequestInfoHeaderResponseBodyAdvice implements ResponseBodyAdvice<Object> {
	private static final Logger logger = LoggerFactory.getLogger(RequestInfoHeaderResponseBodyAdvice.class.getName());
	public static final String REQUEST_INFO_HEADER_NAME = "X-Request-Info";

	RequestTracer requestTracer;
    
    public RequestInfoHeaderResponseBodyAdvice(RequestTracer requestTracer) {
    	this.requestTracer = requestTracer;
    }
    
    @Override
    public boolean supports(MethodParameter returnType, Class<? extends HttpMessageConverter<?>> converterType) {
        return true;
    }

    @Override
    public Object beforeBodyWrite(Object body, MethodParameter returnType, MediaType selectedContentType, Class<? extends HttpMessageConverter<?>> selectedConverterType, ServerHttpRequest request, ServerHttpResponse response) {
    	if (request instanceof ServletServerHttpRequest) {
    		HttpServletRequest servletRequest = ((ServletServerHttpRequest) request).getServletRequest();
    		StringBuilder attributes = new StringBuilder();
    		
    		Object startTimeAttribute = servletRequest.getAttribute(RequestFilter.START_TIME_ATTRIBUTE);
    		if (startTimeAttribute != null) {
    			long startTime = (Long)startTimeAttribute;
    			attributes.append("timestamp=").append(startTime/1000).append("; ");
    			
    			long totalTime = System.currentTimeMillis() - startTime;
    			attributes.append("execution=").append(totalTime).append("; ");
    			logger.debug("Total Execution time took {} ms", totalTime);
    		}
    		
    		String traceId = this.requestTracer.getTraceId();
    		if (traceId != null) {
    			attributes.append("referenceId=").append(traceId).append("; ");
    		}
    		
    		if (attributes.length() > 0)
    			response.getHeaders().add(REQUEST_INFO_HEADER_NAME, attributes.toString());
    	}
    	
        return body;
    }
}