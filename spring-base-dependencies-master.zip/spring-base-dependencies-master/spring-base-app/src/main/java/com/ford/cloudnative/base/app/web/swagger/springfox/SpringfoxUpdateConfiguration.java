package com.ford.cloudnative.base.app.web.swagger.springfox;

import org.springframework.util.ReflectionUtils;
import springfox.documentation.schema.ScalarType;
import springfox.documentation.schema.ScalarTypes;

import javax.annotation.PostConstruct;
import java.lang.reflect.Field;
import java.lang.reflect.Type;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.time.ZonedDateTime;
import java.util.Map;

public class SpringfoxUpdateConfiguration {

    @PostConstruct
    public void init() throws IllegalAccessException {
        registerJavaDateTimeApiClassesAsScalarTypes();
    }

    @SuppressWarnings({"null", "squid:S3011"})
    void registerJavaDateTimeApiClassesAsScalarTypes() throws IllegalAccessException {
        Field field = ReflectionUtils.findField(ScalarTypes.class, "SCALAR_TYPE_LOOKUP");
        field.setAccessible(true);
        Map<Type, ScalarType> lookup = (Map<Type, ScalarType>) field.get(null);
        lookup.put(LocalDate.class, ScalarType.DATE);
        lookup.put(LocalDateTime.class, ScalarType.DATE_TIME);
        lookup.put(Instant.class, ScalarType.DATE_TIME);
        lookup.put(OffsetDateTime.class, ScalarType.DATE_TIME);
        lookup.put(ZonedDateTime.class, ScalarType.DATE_TIME);
    }
}
