package com.ford.cloudnative.base.app.web.header;

import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.core.MethodParameter;
import org.springframework.http.MediaType;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.http.server.ServerHttpRequest;
import org.springframework.http.server.ServerHttpResponse;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.servlet.mvc.method.annotation.ResponseBodyAdvice;

@ControllerAdvice
public class ApplicationInfoHeaderResponseBodyAdvice implements ResponseBodyAdvice<Object> {
	public static final String APPLICATION_INFO_HEADER_NAME = "X-Application-Info";
	
	String headerValue;

	public ApplicationInfoHeaderResponseBodyAdvice(Map<String, String> attributes) {
		init(attributes);
	}
	
	public void init(Map<String, String> attributes) {
		if (attributes != null && !attributes.isEmpty())
			this.headerValue = attributes.entrySet().stream().map(e -> String.format("%s=%s;", e.getKey(), e.getValue())).collect(Collectors.joining(" "));
	}
    
    @Override
    public boolean supports(MethodParameter returnType, Class<? extends HttpMessageConverter<?>> converterType) {
        return true;
    }

    @Override
    public Object beforeBodyWrite(Object body, MethodParameter returnType, MediaType selectedContentType, Class<? extends
    HttpMessageConverter<?>> selectedConverterType, ServerHttpRequest request, ServerHttpResponse response) {
		if (this.headerValue != null)
			response.getHeaders().add(APPLICATION_INFO_HEADER_NAME, this.headerValue);
        return body;
    }
}