package com.ford.cloudnative.base.app.web.exception;

import lombok.Getter;
import lombok.Setter;
import org.springframework.http.HttpStatus;

import com.ford.cloudnative.base.api.BaseBodyError;
import com.ford.cloudnative.base.api.BaseBodyResponse;

@SuppressWarnings({"serial","squid:S1948","squid:S1165"})
public class BaseBodyResponseException extends RuntimeException {

	BaseBodyError bodyError;
	@Getter	@Setter	HttpStatus httpStatus;
	
	public BaseBodyResponseException(BaseBodyError bodyError, HttpStatus httpStatus) {
		super(bodyError != null && bodyError.getMessages() != null && !bodyError.getMessages().isEmpty() ? bodyError.getMessages().get(0) : null);
		this.bodyError = bodyError;
		this.httpStatus = httpStatus;
	}
	
	public BaseBodyResponseException(String message, HttpStatus httpStatus) {
		this(message, httpStatus, null);
	}

	public BaseBodyResponseException(String message, HttpStatus httpStatus, String errorCode) {
		this(BaseBodyError.builder()
				.errorCode(errorCode)
				.message(message)
				.build(),
			httpStatus
			);
	}

	public BaseBodyError getError() {
		return this.bodyError;
	}

	public BaseBodyResponse<Object> getBodyResponse() {
		return BaseBodyResponse.error(this.bodyError);
	}
}
