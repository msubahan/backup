package com.ford.cloudnative.base.app.web.swagger.springfox.plugins;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.annotation.Order;
import springfox.bean.validators.plugins.Validators;
import springfox.documentation.builders.ModelSpecificationBuilder;
import springfox.documentation.schema.PropertySpecification;
import springfox.documentation.schema.plugins.SchemaPluginsManager;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spi.schema.ModelPropertyBuilderPlugin;
import springfox.documentation.spi.schema.contexts.ModelPropertyContext;

import java.lang.reflect.AnnotatedElement;
import java.lang.reflect.AnnotatedType;
import java.util.Collection;

@Order(Validators.BEAN_VALIDATOR_PLUGIN_ORDER - 100)
public class ArrayItemsModelPropertyBuilderPlugin implements ModelPropertyBuilderPlugin {
    public static final String ITEMS_EXTENSION_PREFIX = "$items.";
    static final String PROPERTY_NAME_MARKER = "___aiap_property_marker";

    @Autowired
    SchemaPluginsManager schemaPluginsManager;

    @Override
    public boolean supports(DocumentationType delimiter) {
        return true;
    }

    @Override
    public void apply(ModelPropertyContext context) {
        PropertySpecification contextPropertySpec = context.getSpecificationBuilder().build();
        if (contextPropertySpec.getName().equals(PROPERTY_NAME_MARKER)) return;

        PropertySpecification itemsPropertySpec = getCollectionTypePropertySpecification(context);
        if (itemsPropertySpec != null) mergePropertySpec(context, contextPropertySpec, itemsPropertySpec);
    }

    PropertySpecification getCollectionTypePropertySpecification(ModelPropertyContext context) {
        AnnotatedElement element = PluginUtils.getAnnotatedElement(context);
        if (!PluginUtils.isInstanceOf(element, Collection.class)) return null;
        AnnotatedType collectionType = PluginUtils.getAnnotatedTypeOfArgument(element, 0);

        return PluginUtils.getPropertySpecification(context, collectionType, PROPERTY_NAME_MARKER, schemaPluginsManager);
    }

    void mergePropertySpec(ModelPropertyContext context, PropertySpecification contextPropertySpec, PropertySpecification srcPropertySpec) {
        ModelSpecificationBuilder modelSpecificationBuilder = new ModelSpecificationBuilder().copyOf(contextPropertySpec.getType());
        modelSpecificationBuilder.collectionModelIfExists(collectionSpecificationBuilder ->
            collectionSpecificationBuilder.model(modelSpecificationBuilder2 ->
                modelSpecificationBuilder2.facets(modelFacetsBuilder -> {
                    PluginUtils.mergeFacets(modelFacetsBuilder, srcPropertySpec.getFacets());
                    context.getSpecificationBuilder().vendorExtensions(PluginUtils.prefixVendorExtensions(srcPropertySpec.getVendorExtensions(), ITEMS_EXTENSION_PREFIX));
                })
            )
        );
        context.getSpecificationBuilder().type(modelSpecificationBuilder.build());
    }
}
