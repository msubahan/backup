package com.ford.cloudnative.base.app.web.swagger.springfox.core;

import lombok.Data;
import springfox.documentation.service.VendorExtension;

@Data
public class PropertyVendorExtension implements VendorExtension<Object> {
	final String name;
	final Object value;
}
