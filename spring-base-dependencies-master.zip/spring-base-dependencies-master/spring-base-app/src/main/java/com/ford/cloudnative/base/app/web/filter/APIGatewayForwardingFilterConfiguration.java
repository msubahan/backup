package com.ford.cloudnative.base.app.web.filter;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Slf4j
@Configuration
@ConditionalOnProperty(prefix = "cn.app.filters.api-gateway-filter", name = "enabled")
public class APIGatewayForwardingFilterConfiguration {

    public static final String FORWARD_SLASH = "/";

    @Value("${cn.app.filters.api-gateway-filter.base-path:}")
    String apiGatewayBasePath;

    @Bean
    public FilterRegistrationBean<APIGatewayForwardingFilter> apiGatewayForwardingFilter() {
        apiGatewayBasePath = handlePrefixAndSuffixSlash(apiGatewayBasePath);
        FilterRegistrationBean<APIGatewayForwardingFilter> registrationBean = new FilterRegistrationBean<>();
        registrationBean.setFilter(new APIGatewayForwardingFilter(apiGatewayBasePath));
        registrationBean.addUrlPatterns(apiGatewayBasePath + "/*");
        return registrationBean;
    }

    private String handlePrefixAndSuffixSlash(String basePath) {
        if (basePath == null || basePath.isEmpty()) {
            log.error("\n" +
                "**********************************************************************************************************************************************\n" +
                "*  Unable to register API Gateway Forwarding Filter for missing API Gateway Base Path value.                                                 *\n" +
                "*  Make sure cn.app.filters.api-gateway-filter.base-path property is not empty when cn.app.filters.api-gateway-filter.enabled is TRUE.       *\n" +
                "**********************************************************************************************************************************************");
            throw new IllegalStateException("API Gateway Base Path cannot be null or empty when filter is enabled.");
        }

        if (!basePath.startsWith(FORWARD_SLASH)) {
            basePath = FORWARD_SLASH + basePath;
        }

        if (basePath.endsWith(FORWARD_SLASH)) {
            basePath = basePath.substring(0, basePath.length() - 1);
        }

        return basePath;
    }
}
