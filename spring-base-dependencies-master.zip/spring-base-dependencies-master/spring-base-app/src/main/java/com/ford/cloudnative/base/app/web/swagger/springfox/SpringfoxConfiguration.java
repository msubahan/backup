package com.ford.cloudnative.base.app.web.swagger.springfox;

import com.ford.cloudnative.base.app.web.swagger.SwaggerProperties;
import com.ford.cloudnative.base.app.web.swagger.springfox.filter.OverrideServersTransformationFilter;
import com.ford.cloudnative.base.app.web.swagger.springfox.plugins.AlternativeTypeRuleDefaultsProviderPlugin;
import com.ford.cloudnative.base.app.web.swagger.springfox.plugins.ApiOperationExtAnnotationPlugin;
import com.ford.cloudnative.base.app.web.swagger.springfox.plugins.ResponseProducesDefaultsProviderPlugin;
import com.ford.cloudnative.base.app.web.swagger.springfox.plugins.XNullableModelPropertyParameterPlugin;
import com.ford.cloudnative.base.app.web.swagger.springfox.filter.ApiOperationSecurityTransformationFilter;
import com.ford.cloudnative.base.app.web.swagger.springfox.filter.PrefixedExtensionsTransformationFilter;
import com.ford.cloudnative.base.app.web.swagger.springfox.filter.DefaultResponseTransformationFilter;
import com.ford.cloudnative.base.app.web.swagger.springfox.filter.OverrideBasePathTransformationFilter;
import com.ford.cloudnative.base.app.web.swagger.springfox.filter.ServerUrlLocalPlaceholdersTransformationFilter;
import com.ford.cloudnative.base.app.web.swagger.springfox.filter.VendorExtensionsOverrideTransformationFilter;
import com.ford.cloudnative.base.app.web.swagger.springfox.plugins.ApiPropertyAnnotationPlugin;
import com.ford.cloudnative.base.app.web.swagger.springfox.plugins.ArrayItemsModelPropertyBuilderPlugin;
import com.ford.cloudnative.base.app.web.swagger.springfox.plugins.ArrayMinMaxItemsAnnotationPlugin;
import com.ford.cloudnative.base.app.web.swagger.springfox.plugins.ErrorResponseModelPropertyBuilderPlugin;
import com.ford.cloudnative.base.app.web.swagger.springfox.plugins.MapAdditionalPropertiesModelPropertyBuilderPlugin;
import com.ford.cloudnative.base.app.web.swagger.springfox.plugins.ApiOperationSecurityAnnotationPlugin;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.web.WebMvcSwaggerTransformationFilter;

import java.util.HashSet;

@Configuration
@EnableConfigurationProperties(SwaggerProperties.class)
@ConditionalOnClass({Docket.class, WebMvcSwaggerTransformationFilter.class})
@Import(SpringfoxUpdateConfiguration.class)
public class SpringfoxConfiguration {

    @Bean
    @ConditionalOnMissingBean
    public ApiOperationSecurityTransformationFilter apiOperationSecurityTransformationFilter() {
        return new ApiOperationSecurityTransformationFilter();
    }

    @Bean
    @ConditionalOnMissingBean
    public DefaultResponseTransformationFilter defaultResponseTransformationFilter() {
        return new DefaultResponseTransformationFilter();
    }

    @Bean
    @ConditionalOnMissingBean
    public OverrideBasePathTransformationFilter overrideBasePathTransformationFilter(SwaggerProperties properties) {
        return new OverrideBasePathTransformationFilter(properties);
    }

    @Bean
    @ConditionalOnMissingBean
    public OverrideServersTransformationFilter overrideServersTransformationFilter(SwaggerProperties properties) {
        return new OverrideServersTransformationFilter(properties);
    }

    @Bean
    @ConditionalOnMissingBean
    public PrefixedExtensionsTransformationFilter prefixedExtensionsTransformationFilter() {
        return new PrefixedExtensionsTransformationFilter();
    }

    @Bean
    @ConditionalOnMissingBean
    public ServerUrlLocalPlaceholdersTransformationFilter serverUrlLocalPlaceholdersTransformationFilter() {
        return new ServerUrlLocalPlaceholdersTransformationFilter();
    }

    @Bean
    @ConditionalOnMissingBean
    public VendorExtensionsOverrideTransformationFilter vendorExtensionsOverrideTransformationFilter() {
        return new VendorExtensionsOverrideTransformationFilter();
    }

    @Bean
    @ConditionalOnMissingBean
    public AlternativeTypeRuleDefaultsProviderPlugin alternativeTypeRuleDefaultsProviderPlugin() {
        return new AlternativeTypeRuleDefaultsProviderPlugin();
    }

    @Bean
    @ConditionalOnMissingBean
    public ApiOperationExtAnnotationPlugin apiOperationExtAnnotationPlugin() {
        return new ApiOperationExtAnnotationPlugin();
    }

    @Bean
    @ConditionalOnMissingBean
    public ApiOperationSecurityAnnotationPlugin apiOperationSecurityAnnotationPlugin() {
        return new ApiOperationSecurityAnnotationPlugin();
    }

    @Bean
    @ConditionalOnMissingBean
    public ApiPropertyAnnotationPlugin apiPropertyAnnotationPlugin() {
        return new ApiPropertyAnnotationPlugin();
    }

    @Bean
    @ConditionalOnMissingBean
    public ArrayItemsModelPropertyBuilderPlugin arrayItemsAnnotationPlugin() {
        return new ArrayItemsModelPropertyBuilderPlugin();
    }

    @Bean
    @ConditionalOnMissingBean
    public ArrayMinMaxItemsAnnotationPlugin arrayMinMaxItemsAnnotationPlugin() {
        return new ArrayMinMaxItemsAnnotationPlugin();
    }

    @Bean
    @ConditionalOnMissingBean
    public ErrorResponseModelPropertyBuilderPlugin errorResponseAnnotationPlugin() {
        return new ErrorResponseModelPropertyBuilderPlugin();
    }

    @Bean
    @ConditionalOnMissingBean
    public MapAdditionalPropertiesModelPropertyBuilderPlugin mapAdditionalPropertiesModelPropertyBuilderPlugin() {
        return new MapAdditionalPropertiesModelPropertyBuilderPlugin();
    }

    @Bean
    @ConditionalOnMissingBean
    public ResponseProducesDefaultsProviderPlugin responseProducesDefaultProviderPlugin(SwaggerProperties properties) {
        return new ResponseProducesDefaultsProviderPlugin(new HashSet<>(properties.getDefaultProduces()));
    }

    @Bean
    @ConditionalOnMissingBean
    @ConditionalOnProperty(prefix = "cn.app.swagger.extensions", name = "x-nullable")
    public XNullableModelPropertyParameterPlugin xNullableModelPropertyParameterPlugin() {
        return new XNullableModelPropertyParameterPlugin();
    }

}
