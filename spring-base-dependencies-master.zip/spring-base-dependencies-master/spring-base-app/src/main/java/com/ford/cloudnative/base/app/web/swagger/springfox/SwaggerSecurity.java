package com.ford.cloudnative.base.app.web.swagger.springfox;

import com.ford.cloudnative.base.app.web.swagger.SwaggerProperties;
import com.ford.cloudnative.base.app.web.swagger.SwaggerProperties.SecurityProperties;
import com.ford.cloudnative.base.app.web.swagger.SwaggerProperties.SecurityProperties.ApiKeySecurityProperties;
import com.ford.cloudnative.base.app.web.swagger.SwaggerProperties.SecurityProperties.BaseSecurityProperties;
import com.ford.cloudnative.base.app.web.swagger.SwaggerProperties.SecurityProperties.OAuth2SecurityProperties;
import lombok.Getter;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;
import springfox.documentation.builders.OAuthBuilder;
import springfox.documentation.builders.PathSelectors;
import springfox.documentation.service.ApiKey;
import springfox.documentation.service.AuthorizationScope;
import springfox.documentation.service.ClientCredentialsGrant;
import springfox.documentation.service.SecurityReference;
import springfox.documentation.service.SecurityScheme;
import springfox.documentation.spi.service.contexts.OperationContext;
import springfox.documentation.spi.service.contexts.SecurityContext;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.function.Predicate;
import java.util.stream.Collectors;

public class SwaggerSecurity {
    public static final String AZURE_PROVIDER_URL_V1 = "https://login.microsoftonline.com/c990bb7a-51f4-439b-bd36-9c07fb1041c0/oauth2/token";
    public static final String AZURE_PROVIDER_URL_V2 = "https://login.microsoftonline.com/c990bb7a-51f4-439b-bd36-9c07fb1041c0/oauth2/v2.0/token";
    public static final String ADFS_PROVIDER_URL_QA = "https://corpqa.sts.ford.com/adfs/oauth2/token";
    public static final String ADFS_PROVIDER_URL_PROD = "https://corp.sts.ford.com/adfs/oauth2/token";

    SecurityProperties properties;

    @Getter List<SecurityScheme> securitySchemes = new ArrayList<>();
    @Getter List<SecurityContext> securityContexts = new ArrayList<>();

    public SwaggerSecurity(SwaggerProperties properties) {
        this.properties = properties.getSecurity();
        init();
    }

    void init() {
        configure(properties.getAdfs());
        configure(properties.getAzureAd());
        configure(properties.getApic());
        configure(properties.getApplicationId());
        configure(properties.getCatAuthToken());
    }

    void configure(ApiKeySecurityProperties apiKey) {
        if (!apiKey.isEnabled()) return;
        securitySchemes.add(new ApiKey(apiKey.getApiSecurityScheme().getSchemeName(), apiKey.getName(), apiKey.getIn()));
        addSecurityContext(apiKey);
    }

    void configure(OAuth2SecurityProperties oauth2) {
        if (!oauth2.isEnabled()) return;
        String tokenUrl = getTokenUrl(oauth2);

        securitySchemes.add(new OAuthBuilder()
                .name(oauth2.getApiSecurityScheme().getSchemeName())
                .grantTypes(Collections.singletonList(new ClientCredentialsGrant(tokenUrl)))
                .scopes(buildScopes(oauth2))
                .build());

        addSecurityContext(oauth2);
    }

    String getTokenUrl(OAuth2SecurityProperties oauth2) {
        String tokenUrl = oauth2.getTokenUrl();
        if (StringUtils.hasLength(tokenUrl)) return tokenUrl;

        // some security schemes have a fallback URL
        String env = oauth2.getEnv() != null ? oauth2.getEnv().trim().toLowerCase() : "";
        switch(oauth2.getApiSecurityScheme()) {
            case ADFS: return env.equals("qa") ? ADFS_PROVIDER_URL_QA : ADFS_PROVIDER_URL_PROD;
            case AZURE_AD: return env.equals("v1") ? AZURE_PROVIDER_URL_V1 : AZURE_PROVIDER_URL_V2;
            default: break;
        }

        throw new IllegalArgumentException("Missing property value for cn.app.swagger.security." + oauth2.getApiSecurityScheme().getSchemeName() + ".token-url");
    }

    void addSecurityContext(BaseSecurityProperties scheme) {
        if (CollectionUtils.isEmpty(scheme.getPaths())) return;

        List<Predicate<String>> pathPredicates = scheme.getPaths().stream().map(PathSelectors::ant).collect(Collectors.toList());
        Predicate<OperationContext> operationContextPredicate = oc -> pathPredicates.stream().anyMatch(pathPredicate -> pathPredicate.test(oc.requestMappingPattern()));

        SecurityReference securityReference = SecurityReference.builder()
                .reference(scheme.getApiSecurityScheme().getSchemeName())
                .scopes(new AuthorizationScope[0])
                .build();

        securityContexts.add(SecurityContext.builder()
                .operationSelector(operationContextPredicate)
                .securityReferences(Collections.singletonList(securityReference))
                .build());
    }

    List<AuthorizationScope> buildScopes(OAuth2SecurityProperties oauth2) {
        String schemeName = oauth2.getApiSecurityScheme().getSchemeName();
        if (CollectionUtils.isEmpty(oauth2.getScopes()))
            throw new IllegalArgumentException("Must set at least one scope for '" + schemeName + "' security scheme; i.e.  cn.app.swagger.security." + schemeName + ".scopes.<name>=<description>");

        return oauth2.getScopes().entrySet().stream()
                .map(entry -> new AuthorizationScope(entry.getKey(), entry.getValue()))
                .collect(Collectors.toList());
    }
}
