package com.ford.cloudnative.base.app.web.exception;

import com.ford.cloudnative.base.api.BaseBodyError;
import org.springframework.http.HttpStatus;

public class StandardErrorResponseException extends BaseBodyResponseException {

	public StandardErrorResponseException(BaseBodyError bodyError, HttpStatus httpStatus) {
		super(bodyError, httpStatus);
	}

	public StandardErrorResponseException(String message, HttpStatus httpStatus) {
		super(message, httpStatus);
	}

	public StandardErrorResponseException(String message, HttpStatus httpStatus, String errorCode) {
		super(message, httpStatus, errorCode);
	}

}
