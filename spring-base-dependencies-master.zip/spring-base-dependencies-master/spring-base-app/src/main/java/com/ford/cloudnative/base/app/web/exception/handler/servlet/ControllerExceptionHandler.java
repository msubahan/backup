package com.ford.cloudnative.base.app.web.exception.handler.servlet;

import com.ford.cloudnative.base.app.web.exception.handler.ErrorResponseBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.context.request.RequestAttributes;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;
import org.springframework.web.util.WebUtils;

@ControllerAdvice
@Order(Ordered.LOWEST_PRECEDENCE - 10)
public class ControllerExceptionHandler extends ResponseEntityExceptionHandler {
	ErrorResponseBuilder errorResponseBuilder;

	@Autowired
	public ControllerExceptionHandler(ErrorResponseBuilder errorResponseBuilder) {
		this.errorResponseBuilder = errorResponseBuilder;
	}

	// @ExceptionHandler({HttpRequestMethodNotSupportedException.class, HttpMediaTypeNotSupportedException.class, ... <see ResponseEntityExceptionHandler.handleException() for entire list of exceptions>})
	@Override
	protected ResponseEntity<Object> handleExceptionInternal(Exception ex, Object body, HttpHeaders headers, HttpStatus overrideStatus, WebRequest request) {
		return handleException(ex, request, overrideStatus);
	}

	@ExceptionHandler(Exception.class)
	@ResponseBody
	protected ResponseEntity<Object> handleUncaughtException(Exception ex, WebRequest request) {
		return handleException(ex, request, null);
	}

	ResponseEntity<Object> handleException(Exception ex, WebRequest request, HttpStatus overrideStatus) {
		ResponseEntity<?> responseEntity = this.errorResponseBuilder.buildResponseEntity(ex, request, overrideStatus);

		if (request != null && HttpStatus.INTERNAL_SERVER_ERROR.equals(responseEntity.getStatusCode()))
			request.setAttribute(WebUtils.ERROR_EXCEPTION_ATTRIBUTE, ex, RequestAttributes.SCOPE_REQUEST);

		return (ResponseEntity<Object>) responseEntity;
	}

}
