package com.ford.cloudnative.base.app.web.securedapi;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonToken;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.deser.std.StdScalarDeserializer;
import com.fasterxml.jackson.databind.module.SimpleModule;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.io.IOException;

/**
 * Strict String Deserializer - When enabled, does not deserialize non-string values (e.g., true, 103) to String
 */
@Configuration
@ConditionalOnProperty(prefix = "cn.app.secured-api", name = "use-strict-string-deserializer", matchIfMissing = true)
public class StrictStringDeserializerConfiguration {

    StrictStringDeserializer strictStringDeserializer = new StrictStringDeserializer();

    @Bean
    SimpleModule strictStringSimpleModule() {
        SimpleModule simpleModule = new SimpleModule();
        simpleModule.addDeserializer(String.class, strictStringDeserializer);
        return simpleModule;
    }

    static class StrictStringDeserializer extends StdScalarDeserializer<String> {

        StrictStringDeserializer() {
            super(String.class);
        }

        @Override
        public boolean isCachable() {
            return true;
        }

        @Override
        public String deserialize(JsonParser jsonParser, DeserializationContext context) throws IOException {
            if (jsonParser.hasToken(JsonToken.VALUE_STRING)) return jsonParser.getText();
            return (String) context.handleUnexpectedToken(_valueClass, jsonParser);
        }
    }
}
