package com.ford.cloudnative.base.app.web.securedapi;

import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;

@Configuration
@ConditionalOnProperty(prefix = "cn.app.secured-api", name = "enabled")
@Import({
        DisableTrailingSlashMatchConfiguration.class,
        DisallowedHttpMethodsFilterConfiguration.class,
        StrictStringDeserializerConfiguration.class
})
public class SecuredApiConfiguration {

}
