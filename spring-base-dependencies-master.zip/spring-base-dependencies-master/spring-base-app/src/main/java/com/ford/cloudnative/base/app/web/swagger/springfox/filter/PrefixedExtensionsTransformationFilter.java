package com.ford.cloudnative.base.app.web.swagger.springfox.filter;

import com.ford.cloudnative.base.app.web.swagger.springfox.plugins.PluginUtils;
import io.swagger.models.Swagger;
import io.swagger.models.parameters.AbstractSerializableParameter;
import io.swagger.models.parameters.Parameter;
import io.swagger.models.properties.AbstractProperty;
import io.swagger.models.properties.ArrayProperty;
import io.swagger.models.properties.MapProperty;
import io.swagger.models.properties.ObjectProperty;
import io.swagger.models.properties.Property;
import org.springframework.core.annotation.Order;
import org.springframework.util.CollectionUtils;
import org.springframework.util.ReflectionUtils;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.swagger2.web.SwaggerTransformationContext;
import springfox.documentation.swagger2.web.WebMvcSwaggerTransformationFilter;

import javax.servlet.http.HttpServletRequest;
import java.lang.reflect.Field;
import java.util.Map;

import static com.ford.cloudnative.base.app.web.swagger.springfox.plugins.ArrayItemsModelPropertyBuilderPlugin.ITEMS_EXTENSION_PREFIX;
import static com.ford.cloudnative.base.app.web.swagger.springfox.plugins.MapAdditionalPropertiesModelPropertyBuilderPlugin.ADDITIONAL_PROPERTIES_EXTENSION_PREFIX;
import static springfox.documentation.spi.DocumentationType.SWAGGER_2;
import static springfox.documentation.swagger.common.SwaggerPluginSupport.SWAGGER_PLUGIN_ORDER;

@Order(SWAGGER_PLUGIN_ORDER + 20)
public class PrefixedExtensionsTransformationFilter implements WebMvcSwaggerTransformationFilter {
    static final Field PROPERTY_TYPE_FIELD = ReflectionUtils.findField(AbstractProperty.class, "type");
    static { staticInit(); }

    @SuppressWarnings("squid:S3011")
    static void staticInit() {
        PROPERTY_TYPE_FIELD.setAccessible(true);
    }

    @Override
    public Swagger transform(final SwaggerTransformationContext<HttpServletRequest> context) {
        Swagger swagger = context.getSpecification();

        swagger.getDefinitions().values().stream()
                .filter(model -> !CollectionUtils.isEmpty(model.getProperties()))
                .flatMap(model -> model.getProperties().values().stream())
                .forEach(property -> {
                    if (property instanceof ArrayProperty) {
                        movePrefixedExtensions(property, ((ArrayProperty) property).getItems(), ITEMS_EXTENSION_PREFIX);
                    }
                    if (property instanceof MapProperty) {
                        Property toProperty = ((MapProperty) property).getAdditionalProperties();
                        movePrefixedExtensions(property, toProperty, ADDITIONAL_PROPERTIES_EXTENSION_PREFIX);
                        // from 42Crunch audit perspective, better to have no type defined instead of a map value (additionalProperties) type of 'object'
                        if (toProperty instanceof ObjectProperty) clearType((ObjectProperty)toProperty);
                    }
                });

        PluginUtils.getAllParameters(swagger).forEach(parameter -> {
                    if (parameter instanceof AbstractSerializableParameter<?>) {
                        movePrefixedExtensions(parameter, ((AbstractSerializableParameter<?>) parameter).getItems(), ITEMS_EXTENSION_PREFIX);
                    }
                });

        return swagger;
    }

    void movePrefixedExtensions(Property srcProperty, Property destProperty, String prefix) {
        if (destProperty != null) movePrefixedExtensions(srcProperty.getVendorExtensions(), destProperty.getVendorExtensions(), prefix);
    }

    void movePrefixedExtensions(Parameter srcParameter, Property destProperty, String prefix) {
        if (destProperty != null) movePrefixedExtensions(srcParameter.getVendorExtensions(), destProperty.getVendorExtensions(), prefix);
    }

    void movePrefixedExtensions(Map<String, Object> srcVendorExtensions, Map<String, Object> destVendorExtensions, String prefix) {
        srcVendorExtensions.entrySet().removeIf(entry -> {
            String key = entry.getKey();
            if (!key.startsWith(prefix)) return false;
            String keyWithoutPrefix = key.substring(prefix.length());
            destVendorExtensions.put(keyWithoutPrefix, entry.getValue());
            return true;
        });
    }

    void clearType(AbstractProperty property) {
        ReflectionUtils.setField(PROPERTY_TYPE_FIELD, property, null);
    }

    @Override
    public boolean supports(final DocumentationType documentationType) {
        return SWAGGER_2.equals(documentationType);
    }
}
