package com.ford.cloudnative.base.app.web.exception.handler.servlet;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.ford.cloudnative.base.app.web.exception.handler.ErrorResponseBuilder;
import com.ford.cloudnative.base.app.web.exception.handler.HtmlErrorView;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionMessage;
import org.springframework.boot.autoconfigure.condition.ConditionOutcome;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.autoconfigure.condition.SpringBootCondition;
import org.springframework.boot.autoconfigure.template.TemplateAvailabilityProvider;
import org.springframework.boot.autoconfigure.template.TemplateAvailabilityProviders;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ConditionContext;
import org.springframework.context.annotation.Conditional;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.type.AnnotatedTypeMetadata;
import org.springframework.web.servlet.View;


/**
 * Default ErrorMvcAutoConfiguration$WhitelabelErrorViewConfiguration uses a HTML template based on SpEL that requires certain
 * attributes such as 'timestamp' be part of the data model returned by DefaultErrorAttributes . Since we modified the model with
 * FallbackErrorAttributesHandler class, we need to alter the view to avoid exceptions due to these attributes have been removed.
 */
@Configuration
@SuppressWarnings("squid:S1118")
public class ErrorViewConfiguration {

	@ConditionalOnProperty(prefix = "server.error.whitelabel", name = "enabled", matchIfMissing = true)
	@Conditional(ErrorTemplateMissingCondition.class)
	public static class CustomWhitelabelErrorViewConfiguration {

		@Autowired
		ErrorResponseBuilder errorResponseBuilder;

		@Bean(name = "error")
		@ConditionalOnMissingBean(name = "error")
		public View defaultErrorView(HtmlErrorView htmlErrorView) {
			return new View() {
				@Override
				public void render(Map<String, ?> model, HttpServletRequest request, HttpServletResponse response) throws Exception {
					if (response.getContentType() == null)
						response.setContentType(getContentType());

					Map<String, ?> errorModel = errorResponseBuilder.filterErrorResponseFields(model);
					String html = htmlErrorView.errorPageHtml(errorModel, response.getCharacterEncoding());
                    response.getWriter().append(html);
				}
				
				@Override
				public String getContentType() {
					return "text/html";
				}
			};
		}
	}

	//Copied from ErrorMvcAutoConfiguration$ErrorTemplateMissingCondition
	private static class ErrorTemplateMissingCondition extends SpringBootCondition {
		@Override
		public ConditionOutcome getMatchOutcome(ConditionContext context, AnnotatedTypeMetadata metadata) {
			ConditionMessage.Builder message = ConditionMessage.forCondition("ErrorTemplate Missing");
			TemplateAvailabilityProviders providers = new TemplateAvailabilityProviders(context.getClassLoader());
			TemplateAvailabilityProvider provider = providers.getProvider("error", context.getEnvironment(), context.getClassLoader(), context.getResourceLoader());
			if (provider != null)
				return ConditionOutcome.noMatch(message.foundExactly("template from " + provider));
			return ConditionOutcome.match(message.didNotFind("error template view").atAll());
		}

	}

}
