package com.ford.cloudnative.base.app.web.tracer;

public interface RequestTracer {
	String getTraceId();
	boolean isEnabled();
}
