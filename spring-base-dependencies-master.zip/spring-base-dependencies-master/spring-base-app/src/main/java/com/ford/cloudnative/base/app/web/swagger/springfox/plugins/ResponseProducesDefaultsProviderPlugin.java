package com.ford.cloudnative.base.app.web.swagger.springfox.plugins;

import lombok.RequiredArgsConstructor;
import lombok.experimental.Delegate;
import org.springframework.core.annotation.Order;
import org.springframework.http.MediaType;
import springfox.documentation.RequestHandler;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spi.service.DefaultsProviderPlugin;
import springfox.documentation.spi.service.contexts.DocumentationContextBuilder;

import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

@Order(0)
// In addition to defaulting 'produces', this class serves as a workaround to https://github.com/springfox/springfox/issues/3503
public class ResponseProducesDefaultsProviderPlugin implements DefaultsProviderPlugin {
    final Set<MediaType> defaultProduces;

    public ResponseProducesDefaultsProviderPlugin(Set<MediaType> defaultProduces) {
        this.defaultProduces = defaultProduces;
    }

    @Override
    public DocumentationContextBuilder create(DocumentationType documentationType) {
        throw new UnsupportedOperationException();
    }

    @Override
    public DocumentationContextBuilder apply(DocumentationContextBuilder builder) {
        List<RequestHandler> requestHandlers = builder.build().getRequestHandlers().stream()
                .map(OverrideRequestHandler::new)
                .collect(Collectors.toList());
        builder.requestHandlers(requestHandlers);
        return builder;
    }

    @Override
    public boolean supports(DocumentationType delimiter) {
        return true;
    }

    public class OverrideRequestHandler extends DelegateRequestHandler {
        public OverrideRequestHandler(RequestHandler requestHandler) {
            super(requestHandler);
        }

        @Override
        public Set<MediaType> produces() {
            Set<MediaType> produces = super.produces();
            return produces.isEmpty() ? defaultProduces : produces;
        }
    }
}

@RequiredArgsConstructor
class DelegateRequestHandler implements RequestHandler {
    @Delegate final RequestHandler requestHandler;
}
