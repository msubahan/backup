package com.ford.cloudnative.base.app.web.swagger.springfox.plugins;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ford.cloudnative.base.api.annotation.ApiProperty;
import com.ford.cloudnative.base.api.annotation.ApiProperty.Container;
import com.ford.cloudnative.base.app.web.swagger.springfox.core.PropertyVendorExtension;
import org.springframework.core.annotation.Order;
import springfox.documentation.service.VendorExtension;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spi.schema.ModelPropertyBuilderPlugin;
import springfox.documentation.spi.schema.contexts.ModelPropertyContext;
import springfox.documentation.spi.service.OperationBuilderPlugin;
import springfox.documentation.spi.service.ParameterBuilderPlugin;
import springfox.documentation.spi.service.contexts.OperationContext;
import springfox.documentation.spi.service.contexts.ParameterContext;

import java.lang.annotation.Annotation;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.stream.Collectors;

import static springfox.documentation.swagger.common.SwaggerPluginSupport.OAS_PLUGIN_ORDER;

@Order(OAS_PLUGIN_ORDER + 50)
@SuppressWarnings("squid:S3740")
public class ApiPropertyAnnotationPlugin implements ModelPropertyBuilderPlugin, ParameterBuilderPlugin, OperationBuilderPlugin {
    ObjectMapper objectMapper = new ObjectMapper();

    @Override
    public boolean supports(DocumentationType documentationType) {
        return true;
    }

    @Override
    public void apply(ModelPropertyContext context) {
        Consumer<List<VendorExtension>> addExtensions = extensions -> context.getSpecificationBuilder().vendorExtensions(extensions);
        Function<Class<? extends Annotation>, Optional<?>> extractAnnotation = annotationClass -> PluginUtils.extractAnnotation(context, annotationClass);
        withExtensions(addExtensions, extractAnnotation);
    }

    @Override
    public void apply(ParameterContext context) {
        Consumer<List<VendorExtension>> addExtensions = extensions -> context.requestParameterBuilder().extensions(extensions);
        Function<Class<? extends Annotation>, Optional<?>> extractAnnotation = annotationClass -> PluginUtils.extractAnnotation(context, annotationClass);
        withExtensions(addExtensions, extractAnnotation);
    }

    @Override
    public void apply(OperationContext context) {
        Consumer<List<VendorExtension>> addExtensions = extensions -> context.operationBuilder().extensions(extensions);
        Function<Class<? extends Annotation>, Optional<?>> extractAnnotation = context::findAnnotation;
        withExtensions(addExtensions, extractAnnotation);
    }

    void withExtensions(
            Consumer<List<VendorExtension>> consumer,
            Function<Class<? extends Annotation>, Optional<?>> extractAnnotation
    ) {
        withExtensions(consumer, extractAnnotation, Container.class, ApiProperty.Container::value, ApiProperty.class, ApiProperty::name, ApiProperty::value);
        withExtensions(consumer, extractAnnotation, ApiProperty.Boolean.Container.class, ApiProperty.Boolean.Container::value, ApiProperty.Boolean.class, ApiProperty.Boolean::name, ApiProperty.Boolean::value);
        withExtensions(consumer, extractAnnotation, ApiProperty.Integer.Container.class, ApiProperty.Integer.Container::value, ApiProperty.Integer.class, ApiProperty.Integer::name, ApiProperty.Integer::value);
        withExtensions(consumer, extractAnnotation, ApiProperty.Long.Container.class, ApiProperty.Long.Container::value, ApiProperty.Long.class, ApiProperty.Long::name, ApiProperty.Long::value);
        withExtensions(consumer, extractAnnotation, ApiProperty.Double.Container.class, ApiProperty.Double.Container::value, ApiProperty.Double.class, ApiProperty.Double::name, ApiProperty.Double::value);
        withExtensions(consumer, extractAnnotation, ApiProperty.Float.Container.class, ApiProperty.Float.Container::value, ApiProperty.Float.class, ApiProperty.Float::name, ApiProperty.Float::value);
        withExtensions(consumer, extractAnnotation, ApiProperty.Json.Container.class, ApiProperty.Json.Container::value, ApiProperty.Json.class, ApiProperty.Json::name, a -> parseJson(a.value()));
        withExtensions(consumer, extractAnnotation, ApiProperty.Null.Container.class, ApiProperty.Null.Container::value, ApiProperty.Null.class, ApiProperty.Null::name, a -> null);
    }

    <T extends Annotation, A extends Annotation> void withExtensions(
            Consumer<List<VendorExtension>> withExtensions,
            Function<Class<? extends Annotation>, Optional<?>> extractAnnotation,
            Class<T> containerClazz, Function<T, A[]> getAnnotations,
            Class<A> clazz, Function<A, String> getName, Function<A, Object> getValue
    ) {
        extractAnnotation.apply(containerClazz).ifPresent(container -> {
            List<PropertyVendorExtension> extensions = getExtensions(getAnnotations.apply((T) container), getName, getValue);
            withExtensions.accept(Collections.unmodifiableList(extensions));
        });
        extractAnnotation.apply(clazz).ifPresent(a -> {
            PropertyVendorExtension extensions = new PropertyVendorExtension(getName.apply((A) a), getValue.apply((A) a));
            withExtensions.accept(Collections.singletonList(extensions));
        });
    }

    <A> List<PropertyVendorExtension> getExtensions(A[] elements, Function<A, String> getName, Function<A, Object> getValue) {
        return Arrays.stream(elements).map(a -> new PropertyVendorExtension(getName.apply(a), getValue.apply(a))).collect(Collectors.toList());
    }

    Object parseJson(String s) {
        try {
            return this.objectMapper.readValue(s, Object.class);
        } catch (JsonProcessingException e) {
            throw new IllegalArgumentException(e);
        }
    }
}
