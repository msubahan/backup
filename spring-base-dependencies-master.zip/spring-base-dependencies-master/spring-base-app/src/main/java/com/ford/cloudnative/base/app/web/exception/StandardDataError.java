package com.ford.cloudnative.base.app.web.exception;

import com.ford.cloudnative.base.app.web.exception.StandardDataError.StandardDataErrorValidator;

import javax.validation.Constraint;
import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import javax.validation.Payload;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Target({ElementType.METHOD, ElementType.FIELD, ElementType.PARAMETER, ElementType.TYPE_USE, ElementType.ANNOTATION_TYPE})
@Retention(RetentionPolicy.RUNTIME)
@Constraint(validatedBy = {StandardDataErrorValidator.class})
public @interface StandardDataError {
    // if there is more than one constraint (ignoring @FordDataError) on the target, then the message attribute should be set; otherwise it will be randomly assigned to one of the other constraints
    String message() default "";

    String code() default "";
    String name() default "";

    // mandatory constraint fields
    Class<?>[] groups() default {};
    Class<? extends Payload>[] payload() default {};

    class StandardDataErrorValidator implements ConstraintValidator<StandardDataError, Object> {
        @Override
        public boolean isValid(Object value, ConstraintValidatorContext context) {
            return true;
        }
    }
}
