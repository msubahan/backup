package com.ford.cloudnative.base.app.web.filter;

import org.springframework.web.filter.OncePerRequestFilter;

import javax.servlet.FilterChain;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

public class APIGatewayForwardingFilter extends OncePerRequestFilter {

    final String apiGatewayBasePath;

    APIGatewayForwardingFilter(String apiGatewayBasePath) {
        this.apiGatewayBasePath = apiGatewayBasePath;
    }

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
            throws ServletException, IOException {
        String requestURI = stripAPIGatewayBasePath(request.getRequestURI());
        RequestDispatcher dispatcher = request.getRequestDispatcher(requestURI);
        dispatcher.forward(request, response);
    }

    private String stripAPIGatewayBasePath(String requestURI) {
        if (!requestURI.startsWith(apiGatewayBasePath)) return requestURI;
        return requestURI.substring(apiGatewayBasePath.length());
    }
}
