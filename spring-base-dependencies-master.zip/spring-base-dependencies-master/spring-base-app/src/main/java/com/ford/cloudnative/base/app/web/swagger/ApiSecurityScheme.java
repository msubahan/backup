package com.ford.cloudnative.base.app.web.swagger;

import lombok.Getter;

public enum ApiSecurityScheme {
    ADFS("adfs"),
    APIC("apic"),
    APPLICATION_ID("application-id"),
    AZURE_AD("azure-ad"),
    CAT_AUTH_TOKEN("cat-auth-token")
    ;

    @Getter
    String schemeName;

    ApiSecurityScheme(String schemeName) {
        this.schemeName = schemeName;
    }
}
