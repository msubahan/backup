package com.ford.cloudnative.base.app.datasource.populate;

import lombok.RequiredArgsConstructor;
import org.flywaydb.core.Flyway;
import org.flywaydb.core.api.callback.Callback;
import org.flywaydb.core.api.migration.JavaMigration;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingClass;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.autoconfigure.flyway.FlywayAutoConfiguration.FlywayConfiguration;
import org.springframework.boot.autoconfigure.flyway.FlywayConfigurationCustomizer;
import org.springframework.boot.autoconfigure.flyway.FlywayProperties;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.boot.jdbc.DatabaseDriver;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.ResourceLoader;
import org.springframework.jdbc.support.JdbcUtils;
import org.springframework.jdbc.support.MetaDataAccessException;
import org.springframework.util.ReflectionUtils;

import javax.annotation.PostConstruct;
import javax.sql.DataSource;
import java.lang.reflect.Method;
import java.util.Arrays;
import java.util.Collections;
import java.util.stream.Stream;


@Configuration
@ConditionalOnProperty(prefix = "cn.app.datasource-populate", name = "enabled")
@SuppressWarnings("squid:S1118")
public class DataSourcePopulateConfiguration {
    private static final Logger logger = LoggerFactory.getLogger(DataSourcePopulateConfiguration.class);

    @Configuration
    @ConditionalOnClass({JdbcUtils.class, FlywayProperties.class, Flyway.class})
    @EnableConfigurationProperties(FlywayProperties.class)
    public static class SetupDataSourcePopulateConfiguration {
        @Bean
        @ConditionalOnMissingBean
        public DataSourcePopulatorInitializer myDatabaseInitializer(ApplicationContext context, Flyway flyway, FlywayMigrator flywayMigrator,
                                                                    @Value("${spring.flyway.locations:classpath:db/migration}") String[] locations) {
            return new DataSourcePopulatorInitializer(context, flyway, flywayMigrator, locations);
        }

        @Bean  // we register this bean to skip FlywayAutoConfiguration$FlywayConfiguration
        public Flyway flyway(FlywayProperties properties,
                             ObjectProvider<FlywayConfigurationCustomizer> fluentConfigurationCustomizers,
                             ObjectProvider<Callback> callbacks, ResourceLoader resourceLoader,
                             ObjectProvider<JavaMigration> javaMigrations) {

            properties.setUrl(null);
            properties.setUser(null);

            properties.setCheckLocation(false);
            properties.setLocations(Collections.emptyList());

            FlywayConfiguration flywayConfiguration = new FlywayConfiguration();

            return flywayConfiguration.flyway(properties, null,
                    resourceLoader, new NullObjectProvider<>(),
                    new NullObjectProvider<>(), fluentConfigurationCustomizers,
                    javaMigrations, callbacks);
        }

        @Bean
        public FlywayMigrator flywayMigrator() {
            return new FlywayMigrator();
        }
    }

    @RequiredArgsConstructor
    public static class DataSourcePopulatorInitializer {
        private final ApplicationContext context;
        private final Flyway configuredFlyway;
        private final FlywayMigrator flywayMigrator;
        private final String[] origLocations;

        @PostConstruct
        public void initialize() throws MetaDataAccessException {
            for (String beanName : this.context.getBeanNamesForType(DataSource.class)) {
                initializeDataSource(this.context.getBean(beanName, DataSource.class), beanName);
            }
        }

        public void initializeDataSource(DataSource dataSource, String beanName) throws MetaDataAccessException {
            logger.info("Attempting to populate data source '{}'", beanName);

            org.flywaydb.core.api.configuration.Configuration origFlywayConfig = this.configuredFlyway.getConfiguration();

            // normalize locations property and check if at least one location found with SQL scripts
            String vendor = getDatabaseDriver(dataSource).getId();
            String[] locations = Stream.of(this.origLocations)
                    .map(location -> location.replace("{name}", beanName).replace("{vendor}", vendor))
                    .toArray(String[]::new);

            if (Stream.of(locations).noneMatch(this::hasResources)) {
                logger.info("No SQL scripts found for datasource name '{}'; database type = {}; locations = {}", beanName, vendor, Arrays.asList(locations));
                return;
            } else {
                logger.info("SQL scripts found for datasource name '{}' in '{}'", beanName, Arrays.asList(locations));
            }


            Flyway flyway = Flyway.configure()
                    .configuration(origFlywayConfig)
                    .dataSource(dataSource)
                    .locations(locations)
                    .table(origFlywayConfig.getTable().replace("{name}", beanName).replaceAll("[^a-zA-Z0-9_]", "_"))
                    .load();

            flywayMigrator.migrate(flyway);
        }

        // copied from FlywayAutoConfiguration$LocationResolver.getDatabaseDriver()
        private DatabaseDriver getDatabaseDriver(DataSource dataSource) throws MetaDataAccessException {
            return JdbcUtils.extractDatabaseMetaData(dataSource, databaseMetaDataCallBack ->
                    DatabaseDriver.fromJdbcUrl(databaseMetaDataCallBack.getURL()));
        }

        private boolean hasResources(String directory) {
            try {
                return this.context.getResources(directory + "/*").length > 0;
            } catch (Exception e) {
                return false;
            }
        }
    }

    public static class FlywayMigrator {
        public void migrate(Flyway flyway) {
            // using reflection in order to workaround the breaking signature change in Flyway.migrate method
            // between versions 6.4 and 7.x - backward compatibility support for Spring Boot 2.3 apps
            Method migrate = ReflectionUtils.findMethod(Flyway.class, "migrate");
            ReflectionUtils.invokeMethod(migrate, flyway);
        }
    }

    @Configuration
    @ConditionalOnMissingClass("org.flywaydb.core.Flyway")
    public static class MissingDependencies {
        private static final Logger logger = LoggerFactory.getLogger(MissingDependencies.class);

        public MissingDependencies() {
            logger.error(
                    "*****************************************************************************************************************\n" +
                            "*  Unable to auto-configure the Cloud Native 'datasource-populate' extension due to missing dependencies.\n" +
                            "*  Consider adding the following dependencies to your project to resolve the issue and enable this extension:\n" +
                            "*    - org.flywaydb:flyway-core\n" +
                            "*****************************************************************************************************************");
            throw new IllegalStateException("Dependency not satisfied. See above error message.");
        }
    }

    public static class NullObjectProvider<T> implements ObjectProvider<T> {
		public T getObject() throws BeansException { return null; }
		public T getObject(Object... args) throws BeansException { return null; }
		public T getIfAvailable() throws BeansException { return null; }
		public T getIfUnique() throws BeansException { return null; }
	}
}
