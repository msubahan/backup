package com.ford.cloudnative.base.app.web.exception.handler.servlet;

import com.ford.cloudnative.base.api.ErrorResponse;
import com.ford.cloudnative.base.app.web.exception.BaseBodyResponseException;
import com.ford.cloudnative.base.app.web.exception.handler.ErrorResponseBuilder;
import com.ford.cloudnative.base.app.web.exception.handler.RequestWrapper.ServletRequestWrapper;
import org.springframework.beans.factory.ListableBeanFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.core.annotation.AnnotationAwareOrderComparator;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.web.AuthenticationEntryPoint;
import org.springframework.security.web.access.AccessDeniedHandler;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerExceptionResolver;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Objects;

@Component
@ConditionalOnClass(AuthenticationEntryPoint.class)
public class WebSecurityResponseExceptionHandler implements AuthenticationEntryPoint, AccessDeniedHandler {
    final ErrorResponseBuilder errorResponseBuilder;
    final List<HandlerExceptionResolver> resolvers;

    @Autowired
    public WebSecurityResponseExceptionHandler(ErrorResponseBuilder errorResponseBuilder, ListableBeanFactory beanFactory) {
        this.errorResponseBuilder = errorResponseBuilder;
        this.resolvers = new ArrayList<>(beanFactory.getBeansOfType(HandlerExceptionResolver.class).values());
        AnnotationAwareOrderComparator.sort(this.resolvers);
    }

    @Override
    public void commence(HttpServletRequest request, HttpServletResponse response, AuthenticationException authException) throws IOException, ServletException {
        resolveException(request, response, authException, HttpStatus.UNAUTHORIZED, null, "Invalid credentials.");
    }

    @Override
    public void handle(HttpServletRequest request, HttpServletResponse response, AccessDeniedException accessDeniedException) throws IOException, ServletException {
        resolveException(request, response, accessDeniedException, HttpStatus.FORBIDDEN, null, "Not authorized.");
    }

    @SuppressWarnings("null")
    public void resolveException(HttpServletRequest request, HttpServletResponse response, Throwable error, HttpStatus overrideStatus, String overrideMessage, String overrideGenericMessage) {
        ResponseEntity<ErrorResponse> responseEntity = this.errorResponseBuilder.buildResponseEntity(error, new ServletRequestWrapper(request), overrideStatus);
        if (overrideGenericMessage != null) this.errorResponseBuilder.overrideMessagesIfGenericMessage(responseEntity.getBody().getError(), overrideGenericMessage);
        if (overrideMessage != null) responseEntity.getBody().getError().setMessages(Collections.singletonList(overrideMessage));
        BaseBodyResponseException responseException = new BaseBodyResponseException(responseEntity.getBody().getError(), responseEntity.getStatusCode());

        this.resolvers.stream().map(resolver -> resolver.resolveException(request, response, null, responseException)).filter(Objects::nonNull).findFirst();
    }

}
