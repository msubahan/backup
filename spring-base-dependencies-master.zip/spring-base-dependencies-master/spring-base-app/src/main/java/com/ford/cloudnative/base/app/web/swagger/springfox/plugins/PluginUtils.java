package com.ford.cloudnative.base.app.web.swagger.springfox.plugins;

import com.fasterxml.jackson.databind.introspect.BeanPropertyDefinition;
import com.ford.cloudnative.base.app.web.swagger.springfox.core.PropertyVendorExtension;
import io.swagger.models.Swagger;
import io.swagger.models.parameters.Parameter;
import org.springframework.util.CollectionUtils;
import springfox.bean.validators.plugins.Validators;
import springfox.documentation.builders.ModelFacetsBuilder;
import springfox.documentation.builders.ModelPropertyBuilder;
import springfox.documentation.builders.PropertySpecificationBuilder;
import springfox.documentation.schema.CollectionElementFacet;
import springfox.documentation.schema.ElementFacet;
import springfox.documentation.schema.EnumerationFacet;
import springfox.documentation.schema.NumericElementFacet;
import springfox.documentation.schema.PropertySpecification;
import springfox.documentation.schema.StringElementFacet;
import springfox.documentation.schema.plugins.SchemaPluginsManager;
import springfox.documentation.service.VendorExtension;
import springfox.documentation.spi.schema.contexts.ModelPropertyContext;
import springfox.documentation.spi.service.contexts.ParameterContext;

import java.lang.annotation.Annotation;
import java.lang.reflect.AnnotatedElement;
import java.lang.reflect.AnnotatedParameterizedType;
import java.lang.reflect.AnnotatedType;
import java.lang.reflect.Field;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class PluginUtils {

    private PluginUtils() {}

    @SuppressWarnings("squid:S3655")
    public static AnnotatedElement getAnnotatedElement(ModelPropertyContext context) { // logic mimics Validators.extractAnnotation
        if (context.getBeanPropertyDefinition().isPresent()) {
            AnnotatedElement result = getAnnotatedElement(context.getBeanPropertyDefinition().get());
            if (result != null) return result;
        }
        if (context.getAnnotatedElement().isPresent()) {
            AnnotatedElement annotatedElement = context.getAnnotatedElement().orElse(null);
            if (annotatedElement instanceof Field) return ((Field) annotatedElement).getAnnotatedType();
        }
        return null;
    }

    public static AnnotatedElement getAnnotatedElement(BeanPropertyDefinition beanPropertyDefinition) {
        if (beanPropertyDefinition.getGetter() != null && beanPropertyDefinition.getGetter().getMember() != null) {
            AnnotatedElement result = beanPropertyDefinition.getGetter().getMember().getAnnotatedReturnType();
            if (result != null) return result;
        }
        if (beanPropertyDefinition.getField() != null) {
            return beanPropertyDefinition.getField().getAnnotated().getAnnotatedType();
        }
        return null;
    }

    public static boolean isInstanceOf(AnnotatedElement annotatedElement, Class<?> clazz) {
        Class<?> elClass = getClassOf(annotatedElement);
        return elClass != null && clazz.isAssignableFrom(elClass);
    }

    public static Class<?> getClassOf(AnnotatedElement annotatedElement) {
        if (annotatedElement instanceof AnnotatedType) {
            Type type = ((AnnotatedType)annotatedElement).getType();
            if (type instanceof ParameterizedType) type = ((ParameterizedType) type).getRawType();
            if (type instanceof Class) return (Class<?>) type;
        }
        return null;
    }

    public static AnnotatedType getAnnotatedTypeOfArgument(AnnotatedElement annotatedElement, int argumentIndex) {
        if (annotatedElement instanceof AnnotatedParameterizedType)
            return ((AnnotatedParameterizedType) annotatedElement).getAnnotatedActualTypeArguments()[argumentIndex];
        return null;
    }

    public static <T extends Annotation> Optional<T> extractAnnotation(ModelPropertyContext context, Class<T> annotationType) {
        return Validators.extractAnnotation(context, annotationType);
    }

    public static <T extends Annotation> Optional<T> extractAnnotation(ParameterContext context, Class<T> annotationType) {
        return Validators.annotationFromParameter(context, annotationType);
    }

    @SuppressWarnings("squid:S3740")
    public static List<VendorExtension> prefixVendorExtensions(List<VendorExtension> srcVendorExtensions, String prefix) {
        return srcVendorExtensions.stream()
                .map(e -> new PropertyVendorExtension(prefix + e.getName(), e.getValue()))
                .collect(Collectors.toList());
    }

    public static void mergeFacets(ModelFacetsBuilder modelFacetsBuilder, List<ElementFacet> srcFacets) {
        for (ElementFacet facet : srcFacets) {
            if (facet instanceof StringElementFacet) modelFacetsBuilder.stringFacet(b -> b.copyOf(facet));
            if (facet instanceof CollectionElementFacet) modelFacetsBuilder.collectionFacet(b -> b.copyOf(facet));
            if (facet instanceof NumericElementFacet) modelFacetsBuilder.numericFacet(b -> b.copyOf(facet));
            if (facet instanceof EnumerationFacet) modelFacetsBuilder.enumerationFacet(b -> b.copyOf(facet));
        }
    }

    public static PropertySpecification getPropertySpecification(ModelPropertyContext context, AnnotatedType annotatedType, String propertyName, SchemaPluginsManager schemaPluginsManager) {
        ModelPropertyBuilder modelPropertyBuilder = new ModelPropertyBuilder().name(propertyName).type(null).qualifiedType(null);
        PropertySpecificationBuilder propertySpecificationBuilder = new PropertySpecificationBuilder(propertyName);
        ModelPropertyContext modelPropertyContext = new ModelPropertyContext(
                modelPropertyBuilder,
                propertySpecificationBuilder,
                annotatedType,
                context.getResolver(),
                context.getOwner());

        return schemaPluginsManager.propertySpecification(modelPropertyContext);
    }

    public static Stream<Parameter> getAllParameters(Swagger swagger) {
        Stream<Parameter> swaggerParameters = streamMapValues(swagger.getParameters());
        Stream<Parameter> pathParameters = streamMapValues(swagger.getPaths()).flatMap(p -> streamCollection(p.getParameters()));
        Stream<Parameter> operationParameters = streamMapValues(swagger.getPaths()).flatMap(p -> streamCollection(p.getOperations())).flatMap(o -> streamCollection(o.getParameters()));
        return Stream.concat(swaggerParameters, Stream.concat(pathParameters, operationParameters));
    }

    static <T> Stream<T> streamCollection(Collection<T> collection) {
        return CollectionUtils.isEmpty(collection) ? Stream.empty() : collection.stream();
    }

    static <V> Stream<V> streamMapValues(Map<?, V> map) {
        return CollectionUtils.isEmpty(map) ? Stream.empty() : map.values().stream();
    }

}
