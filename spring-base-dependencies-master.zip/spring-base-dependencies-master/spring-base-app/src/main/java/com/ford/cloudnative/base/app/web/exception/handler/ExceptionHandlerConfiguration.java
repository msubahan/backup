package com.ford.cloudnative.base.app.web.exception.handler;

import com.ford.cloudnative.base.app.web.exception.handler.servlet.MvcExceptionHandlerConfiguration;
import com.ford.cloudnative.base.app.web.tracer.DefaultRequestTracerConfiguration;
import com.ford.cloudnative.base.app.web.tracer.SleuthRequestTracerConfiguration;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;

@Configuration
@ConditionalOnProperty(prefix = "cn.app.exception-handler", name = "enabled", matchIfMissing = false)
@Import({
    ErrorResponseBuilder.class,
    HtmlErrorView.class,
    SleuthRequestTracerConfiguration.class,  // test classes import ExceptionHandlerConfiguration directly; add request tracer configurations also
    DefaultRequestTracerConfiguration.class,
    MvcExceptionHandlerConfiguration.class
})
@EnableConfigurationProperties(ExceptionHandlerProperties.class)
public class ExceptionHandlerConfiguration {

    @Bean
    @ConditionalOnMissingBean
    public ExceptionHandler exceptionHandler(ExceptionHandlerProperties properties) {
        return new DefaultExceptionHandler(properties);
    }

}
