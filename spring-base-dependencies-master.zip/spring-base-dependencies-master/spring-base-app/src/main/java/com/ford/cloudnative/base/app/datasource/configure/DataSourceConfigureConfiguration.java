package com.ford.cloudnative.base.app.datasource.configure;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.autoconfigure.ImportAutoConfiguration;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingClass;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.cloud.service.common.RelationalServiceInfo;
import org.springframework.cloud.service.relational.DataSourceCreator;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;

/****************************************************************************************************************
 * Targetted service must have a field 'jdbcDbUrl' set.
 * cf cups DB-SERVICE-NAME -p '{"jdbcDbUrl":"jdbc:mysql://db-user:xxxxx@10.0.0.103:3306/database-name"}'
 * 
 * DataSource created using DataSourceCreator implementation which attempts to create a pool data source; otherwise
 * fallbacks to a simple datasource.
 * 
 ****************************************************************************************************************/
@Configuration
@ConditionalOnProperty(prefix = "cn.app.datasource-configure", name = "enabled")
@Profile("cloud")
@SuppressWarnings("squid:S1118")
public class DataSourceConfigureConfiguration {

	@Configuration
	@ConditionalOnClass({RelationalServiceInfo.class, DataSourceCreator.class})
	@ImportAutoConfiguration(DataSourceConfigureScanConfiguration.class)
	public static class ImportDataSourceConfigureScanConfiguration {
	}
	
	@Configuration
	@ConditionalOnMissingClass({"org.springframework.cloud.service.common.RelationalServiceInfo", "org.springframework.cloud.service.relational.DataSourceCreator"})
	public static class MissingDependencies {
		private static final Logger logger = LoggerFactory.getLogger(MissingDependencies.class);
		public MissingDependencies() {
			logger.error(
					"*****************************************************************************************************************\n" +
					"*  Unable to auto-configure the Cloud Native 'datasource-configure' extension due to missing dependencies.\n" + 
					"*  Consider adding the following dependencies to your project to resolve the issue and enable this extension:\n" + 
					"*    - org.springframework.boot:spring-boot-starter-cloud-connectors\n" + 
					"*****************************************************************************************************************");
			throw new IllegalStateException("Dependency not satisfied. See above error message.");
		}
	}	
}
