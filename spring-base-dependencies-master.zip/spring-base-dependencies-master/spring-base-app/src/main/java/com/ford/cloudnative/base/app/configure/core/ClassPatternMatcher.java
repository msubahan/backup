package com.ford.cloudnative.base.app.configure.core;

import org.springframework.util.AntPathMatcher;

import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class ClassPatternMatcher {
    final AntPathMatcher antClassMatcher = new AntPathMatcher(".");
    final Map<Class<?>, Boolean> matchCache = new ConcurrentHashMap<>();

    final List<String> antPatterns;

    public ClassPatternMatcher(List<String> antPatterns) {
        this.antPatterns = antPatterns;
    }

    public boolean isMatch(Class<?> clz) {
        if (matchCache.containsKey(clz))
            return this.matchCache.get(clz);

        boolean result = false;
        if (antPatterns.stream().anyMatch(pattern -> this.antClassMatcher.match(pattern, clz.getName()))) {
            result = true;
        } else if (clz.getSuperclass() != null) {
            result = isMatch(clz.getSuperclass());
        }

        this.matchCache.put(clz, result);
        return result;
    }
}
