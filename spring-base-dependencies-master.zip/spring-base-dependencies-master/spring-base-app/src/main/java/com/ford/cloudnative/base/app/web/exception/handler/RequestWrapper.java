package com.ford.cloudnative.base.app.web.exception.handler;

import org.springframework.boot.web.error.ErrorAttributeOptions;
import org.springframework.boot.web.servlet.error.DefaultErrorAttributes;
import org.springframework.web.context.request.RequestAttributes;
import org.springframework.web.context.request.WebRequest;

import lombok.Data;
import org.springframework.web.util.WebUtils;

import javax.servlet.ServletRequest;
import java.util.Collections;
import java.util.Map;
import java.util.Optional;

public interface RequestWrapper {
    Object getAttribute(String name);

    Map<String, Object> getErrorAttributes(ErrorAttributeOptions options);

    Optional<Integer> getErrorStatusCodeAttribute();

    @Data
    public static class WebRequestWrapper implements RequestWrapper {
        static DefaultErrorAttributes defaultErrorAttributes = new DefaultErrorAttributes();
        final WebRequest webRequest;
        
        public Object getAttribute(String name) {
            return webRequest.getAttribute(name, RequestAttributes.SCOPE_REQUEST);
        }

        public Map<String, Object> getErrorAttributes(ErrorAttributeOptions options) {
            return defaultErrorAttributes.getErrorAttributes(webRequest, options);
        }

        public Optional<Integer> getErrorStatusCodeAttribute() {
            return Optional.ofNullable((Integer)getAttribute(WebUtils.ERROR_STATUS_CODE_ATTRIBUTE));
        }
    }

    @Data
    public static class ServletRequestWrapper implements RequestWrapper {
        final ServletRequest servletRequest;
        
        public Object getAttribute(String name) {
            return servletRequest.getAttribute(name);
        }

        public Map<String, Object> getErrorAttributes(ErrorAttributeOptions options) {
            return Collections.emptyMap(); // not expected; wrapper used when security exceptions are thrown
        }

        public Optional<Integer> getErrorStatusCodeAttribute() {
            return Optional.ofNullable((Integer)getAttribute(WebUtils.ERROR_STATUS_CODE_ATTRIBUTE));
        }
    }

}
