package com.ford.cloudnative.base.app.rabbit;

import io.arivera.oss.embedded.rabbitmq.EmbeddedRabbitMq;
import io.arivera.oss.embedded.rabbitmq.EmbeddedRabbitMqConfig;
import io.arivera.oss.embedded.rabbitmq.RabbitMqEnvVar;
import io.arivera.oss.embedded.rabbitmq.Version;
import io.arivera.oss.embedded.rabbitmq.bin.RabbitMqCommand.ProcessExecutorFactory;
import io.arivera.oss.embedded.rabbitmq.helpers.ErlangVersionException;
import io.arivera.oss.embedded.rabbitmq.util.ArchiveType;
import io.arivera.oss.embedded.rabbitmq.util.OperatingSystem;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.rabbit.connection.CachingConnectionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingClass;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;
import org.zeroturnaround.exec.ProcessExecutor;

import javax.annotation.PostConstruct;
import java.io.IOException;
import java.net.ServerSocket;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Configuration
@ConditionalOnProperty(prefix = "cn.app.local-rabbit", name = "enabled")
@Profile("!cloud")
@SuppressWarnings("squid:S1118")
public class LocalRabbitConfiguration {

	public static final String START_LOG = "*****************************************************************************************************************\n";
	public static final String END_LOG = "*****************************************************************************************************************";

	@ConfigurationProperties(prefix = "cn.app.local-rabbit")
	@Data
	public static class LocalRabbitProperties {
		boolean enabled;

		// new rabbitmq instance
		String version;
		long downloadReadTimeoutInMillis = 10000;
		long downloadConnectionTimeoutInMillis = 10000;
		long defaultRabbitMqCtlTimeoutInMillis = 15000;
		long rabbitMqServerInitializationTimeoutInMillis = 15000;
		long erlangCheckTimeoutInMillis = 10000;
		Map<String, String> envVars = new HashMap<>();

		// existing rabbitmq instance
		String host;
		int port;
		String username;
		String password;
	}

	@Component
	@Slf4j
	@ConditionalOnClass({CachingConnectionFactory.class, EmbeddedRabbitMq.class})
	@EnableConfigurationProperties(LocalRabbitProperties.class)
	public static class LocalRabbitConnectionFactory extends CachingConnectionFactory {
		static int localStartedRabbitMqPort = -1;  //static - one instance per JVM run

		@Autowired
		LocalRabbitProperties properties;
		
		@PostConstruct
		public void init() {
			// if version set, then we download & start rabbitmq server on behalf of user
			if (this.properties.getVersion() != null) {
				startLocalRabbitServer();
			} else {
				this.setHost(this.properties.getHost());
				this.setPort(this.properties.getPort());
				this.setUsername(this.properties.getUsername());
				this.setUsername(this.properties.getPassword());
			}
		}
		
		private void startLocalRabbitServer() {
			if (localStartedRabbitMqPort == -1) {
				logger.info("Starting local instance of RabbitMQ...");
				
				int[] openPorts = getTwoRandomOpenPorts();
				
				//configure
				EmbeddedRabbitMqConfig rabbitMqConfig = new EmbeddedRabbitMqConfig.Builder()
						.version(new VersionImpl(this.properties.getVersion()))
						.deleteDownloadedFileOnErrors(false)
						.rabbitMqServerInitializationTimeoutInMillis(this.properties.getRabbitMqServerInitializationTimeoutInMillis())
						.defaultRabbitMqCtlTimeoutInMillis(this.properties.getDefaultRabbitMqCtlTimeoutInMillis())
						.erlangCheckTimeoutInMillis(this.properties.getErlangCheckTimeoutInMillis())
						.downloadConnectionTimeoutInMillis(this.properties.getDownloadConnectionTimeoutInMillis())
						.downloadReadTimeoutInMillis(this.properties.getDownloadReadTimeoutInMillis())
						.envVar(RabbitMqEnvVar.NODENAME, "rabbit-" + openPorts[0])
						.envVar(RabbitMqEnvVar.NODE_PORT, String.valueOf(openPorts[0]))
						.envVar(RabbitMqEnvVar.DIST_PORT, String.valueOf(openPorts[1]))
						.envVars(this.properties.getEnvVars())
						// the way library attempts to destroy processes does not work; override & resort to own shutdown hook
						.processExecutorFactory(new ProcessExecutorFactory() {
							@Override
							public ProcessExecutor createInstance() {
								return new ProcessExecutor() {
									@Override
									public ProcessExecutor destroyOnExit() {
										return this;
									}
								};
							}
						})
						.build();
				EmbeddedRabbitMq rabbitMq = new EmbeddedRabbitMq(rabbitMqConfig);
				
				//start
				try {
					rabbitMq.start();
				} catch (ErlangVersionException e) {
					logger.error(
							START_LOG +
							"*  Unable to start local rabbit instance due to Erlang installation issue.\n" +
							"*  Error Message: \" + e.getMessage(\n" + 
							"*  Ensure Erlang is installed on the local machine and the 'erl' command is on the PATH.\n" +
							END_LOG);
					throw e;
				}
				
				//on shutdown, stop server
				Runtime.getRuntime().addShutdownHook(new Thread(() -> {
			    	logger.info("Stopping local instance of RabbitMQ...");
			    	rabbitMq.stop();
			    	logger.info("Local instance of RabbitMQ stopped.");
				}));

				setLocalStartedRabbitMqPort(rabbitMqConfig);

				// set connection factory settings
				this.setHost("localhost");
				this.setPort(localStartedRabbitMqPort);
				this.setUsername("guest");
				this.setPassword("guest");

				logger.info("Local instance of RabbitMQ started on port " + localStartedRabbitMqPort);
			}
		}

		static void setLocalStartedRabbitMqPort(EmbeddedRabbitMqConfig rabbitMqConfig) {
			localStartedRabbitMqPort = rabbitMqConfig.getRabbitMqPort();
		}

		static int[] getTwoRandomOpenPorts() {
			try (ServerSocket socket1 = new ServerSocket(0); ServerSocket socket2 = new ServerSocket(0)) {
				return new int[] {socket1.getLocalPort(), socket2.getLocalPort()};
			} catch (IOException e) { throw new IllegalStateException(e);	}
		}
	}
	
	@Configuration
	@ConditionalOnMissingClass("org.springframework.amqp.rabbit.connection.CachingConnectionFactory")
	@SuppressWarnings("squid:S1118")
	public static class MissingDependencies {
		private static final Logger logger = LoggerFactory.getLogger(MissingDependencies.class);

		public MissingDependencies() {
			logger.error(
					START_LOG +
					"*  Unable to auto-configure the Cloud Native 'local-rabbit' extension due to missing dependencies.\n" + 
					"*  Consider adding the following dependency to your project to resolve the issue and enable this extension:\n" + 
					"*    - org.springframework.boot:spring-boot-starter-amqp\n" + 
					END_LOG);
			throw new IllegalStateException("Dependency not satisfied. See above error message.");
		}
	}
	
	@Configuration
	@ConditionalOnMissingClass("io.arivera.oss.embedded.rabbitmq.EmbeddedRabbitMq")
	public static class MissingDependencies2 {
		private static final Logger logger = LoggerFactory.getLogger(MissingDependencies2.class);
		MissingDependencies2() {
			logger.error(
					START_LOG +
					"*  Unable to auto-configure the Cloud Native 'local-rabbit' extension due to missing dependencies.\n" + 
					"*  Consider adding the following dependency to your project to resolve the issue and enable this extension:\n" + 
					"*    - io.arivera.oss:embedded-rabbitmq\n" +
					END_LOG);
			throw new IllegalStateException("Dependency not satisfied. See above error message.");
		}
	}
	
	public static class VersionImpl implements Version {
		private final String version;

		public VersionImpl(String version) {
			this.version = version;
		}

		@Override
		public String getVersionAsString() {
			return this.version;
		}

		@Override
		public String getVersionAsString(CharSequence separator) {
			return this.version;
		}

		@Override
		public ArchiveType getArchiveType(OperatingSystem operatingSystem) {
			return operatingSystem == OperatingSystem.WINDOWS ? ArchiveType.ZIP : ArchiveType.TAR_XZ;
		}

		@Override
		public String getExtractionFolder() {
			return "rabbitmq_server-" + this.getVersionAsString();
		}

		@Override
		public String getMinimumErlangVersion() {
			return null;
		}

		@Override
		public List<Integer> getVersionComponents() {
			return Collections.emptyList();
		}
	}
}
