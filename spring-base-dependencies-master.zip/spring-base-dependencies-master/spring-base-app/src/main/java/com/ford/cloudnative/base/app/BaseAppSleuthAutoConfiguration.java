package com.ford.cloudnative.base.app;

import com.ford.cloudnative.base.app.web.tracer.SleuthRequestTracerConfiguration;
import org.springframework.boot.autoconfigure.AutoConfigureAfter;
import org.springframework.boot.autoconfigure.AutoConfigureBefore;
import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
import org.springframework.cloud.sleuth.SpanNamer;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;

@Configuration
@AutoConfigureAfter(name = {
        "org.springframework.cloud.sleuth.autoconfig.TraceConfiguration", // sleuth 3.x support for Spring Boot 2.4+
        "org.springframework.cloud.sleuth.autoconfig.brave.BraveAutoConfiguration", // sleuth 3.x support for Spring Boot 2.4+
        "org.springframework.cloud.sleuth.autoconfig.TraceAutoConfiguration" // sleuth 2.x support for Spring Boot 2.3
})
@ConditionalOnBean(SpanNamer.class)
@AutoConfigureBefore({
        BaseAppAutoConfiguration.class,
        BaseAppBeforeWebAutoConfiguration.class
})
@Import(SleuthRequestTracerConfiguration.class)
public class BaseAppSleuthAutoConfiguration {

}
