package com.ford.cloudnative.base.app.web.exception;

import org.springframework.http.HttpStatus;

import java.lang.annotation.*;

@Target({ElementType.TYPE, ElementType.METHOD, ElementType.ANNOTATION_TYPE})
@Retention(RetentionPolicy.RUNTIME)
@Documented
@SuppressWarnings("deprecation")
public @interface StandardError {
	HttpStatus DEFAULT_UNUSED_HTTP_STATUS = HttpStatus.DESTINATION_LOCKED; // default value cannot be null;rely on unlikely http status
	HttpStatus status() default HttpStatus.DESTINATION_LOCKED;

	String errorCode() default "";

	String[] messages() default {};
}
