package com.ford.cloudnative.base.app.web.swagger.springfox.plugins;

import com.ford.cloudnative.base.app.web.swagger.springfox.core.PropertyVendorExtension;
import org.springframework.core.annotation.Order;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spi.schema.ModelPropertyBuilderPlugin;
import springfox.documentation.spi.schema.contexts.ModelPropertyContext;
import springfox.documentation.spi.service.ParameterBuilderPlugin;
import springfox.documentation.spi.service.contexts.ParameterContext;

import java.util.Collections;

import static springfox.documentation.spi.DocumentationType.SWAGGER_2;
import static springfox.documentation.swagger.common.SwaggerPluginSupport.OAS_PLUGIN_ORDER;

@Order(OAS_PLUGIN_ORDER + 50)
public class XNullableModelPropertyParameterPlugin implements ModelPropertyBuilderPlugin, ParameterBuilderPlugin {
    static final PropertyVendorExtension X_NULLABLE_TRUE = new PropertyVendorExtension("x-nullable", true);

    @Override
    public boolean supports(DocumentationType documentationType) {
        return SWAGGER_2.equals(documentationType);
    }

    @Override
    public void apply(ModelPropertyContext context) {
        Boolean required = context.getSpecificationBuilder().build().getRequired();

        if (isNotRequired(required)) {
            context.getSpecificationBuilder().vendorExtensions(Collections.singletonList(X_NULLABLE_TRUE));
        }
    }

    @Override
    public void apply(ParameterContext context) {
        Boolean required = context.requestParameterBuilder().build().getRequired();

        if (isNotRequired(required)) {
            context.requestParameterBuilder().extensions(Collections.singletonList(X_NULLABLE_TRUE));
        }
    }

    boolean isNotRequired(Boolean required) {
        return required == null || !required.booleanValue();
    }
}
