package com.ford.cloudnative.base.app.datasource.configure;

import org.springframework.cloud.cloudfoundry.CloudFoundryServiceInfoCreator;
import org.springframework.cloud.cloudfoundry.Tags;

import java.util.Map;

public class UserProvidedRelationalServiceInfoCreator extends CloudFoundryServiceInfoCreator<UserProvidedRelationalServiceInfo> {

	public UserProvidedRelationalServiceInfoCreator() {
		super(new Tags());
	}

	@Override
	public boolean accept(Map<String, Object> serviceData) {
		Object credentials = serviceData.get("credentials");
		return credentials instanceof Map && ((Map<?,?>)credentials).containsKey("jdbcDbUrl");
	}

	@Override
	public UserProvidedRelationalServiceInfo createServiceInfo(Map<String, Object> serviceData) {
		return new UserProvidedRelationalServiceInfo(serviceData);
	}
}
