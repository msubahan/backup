package com.ford.cloudnative.base.app.web.exception.handler;

import com.ford.cloudnative.base.api.BaseBodyError;
import com.ford.cloudnative.base.api.BaseBodyError.BaseBodyDataError;
import com.ford.cloudnative.base.api.BaseBodyError.BaseBodyErrorBuilder;
import com.ford.cloudnative.base.api.ErrorResponse;
import com.ford.cloudnative.base.api.BaseBodyResponse;
import com.ford.cloudnative.base.api.StandardErrorResponse;
import com.ford.cloudnative.base.app.configure.core.ClassPatternMatcher;
import com.ford.cloudnative.base.app.web.exception.BaseBodyResponseException;
import com.ford.cloudnative.base.app.web.exception.StandardDataError;
import com.ford.cloudnative.base.app.web.exception.StandardError;
import com.ford.cloudnative.base.app.web.filter.RequestFilter;
import com.ford.cloudnative.base.app.web.tracer.RequestTracer;
import lombok.Getter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.web.ErrorProperties.IncludeAttribute;
import org.springframework.boot.autoconfigure.web.ServerProperties;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.boot.web.error.ErrorAttributeOptions;
import org.springframework.boot.web.error.ErrorAttributeOptions.Include;
import org.springframework.context.ApplicationContext;
import org.springframework.core.annotation.AnnotatedElementUtils;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.server.ResponseStatusException;

import javax.validation.ConstraintViolation;
import javax.validation.Validator;
import javax.validation.ValidatorFactory;
import javax.validation.metadata.BeanDescriptor;
import javax.validation.metadata.ConstraintDescriptor;
import javax.validation.metadata.PropertyDescriptor;
import java.lang.annotation.Annotation;
import java.lang.reflect.AnnotatedElement;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Function;
import java.util.stream.Collectors;

@Component
@EnableConfigurationProperties(ExceptionHandlerProperties.class)
public class ErrorResponseBuilder {
    public static final String ERROR_FIELD = "error";
    public static final String EXCEPTION_ATTRIBUTE = "exception";

    final ApplicationContext ctx;
    @Getter final ExceptionHandlerProperties properties;
    final HttpStatus dataErrorsHttpStatus;
    final ClassPatternMatcher whiteListExceptionPatternMatcher;
    final ExceptionHandler exceptionHandler;
    final ValidatorFactory validatorFactory;
    final ErrorAttributeOptions errorAttributeOptions;

    ErrorResponseBuilderProxy errorResponseBuilderProxy = new ErrorResponseBuilderProxy();
    Map<AnnotatedElement, Map<AnnotatedElement, ? extends Annotation>> findAnnotationCache = new ConcurrentHashMap<>();
    Map<Class<?>, Map<String, StandardDataError>> standardDataErrorByPropertyByClassCache = new ConcurrentHashMap<>();
	RequestTracer requestTracer;

	@Autowired
	public ErrorResponseBuilder(ApplicationContext ctx, ServerProperties serverProperties, ExceptionHandlerProperties properties, ExceptionHandler exceptionHandler, ValidatorFactory validatorFactory) {
		this.ctx = ctx;
        this.properties = properties;
		this.dataErrorsHttpStatus = HttpStatus.valueOf(properties.getDataErrors().getStatusCode());
        this.whiteListExceptionPatternMatcher = new ClassPatternMatcher(properties.getMessages().getWhiteList().getExceptions());
        this.exceptionHandler = exceptionHandler;
        this.validatorFactory = validatorFactory;
        this.errorAttributeOptions = getErrorAttributeOptions(serverProperties, properties);
    }

    ErrorAttributeOptions getErrorAttributeOptions(ServerProperties serverProperties, ExceptionHandlerProperties properties) {
        ErrorAttributeOptions options = ErrorAttributeOptions.defaults();
        if (properties.getAttributes().isIncludeException()) options = options.including(Include.EXCEPTION);
        if (serverProperties.getError().getIncludeMessage() != IncludeAttribute.NEVER) options = options.including(Include.MESSAGE);
        return options;
    }

    public ResponseEntity<ErrorResponse> buildResponseEntity(Throwable error, WebRequest webRequest) {
        return buildResponseEntity(error, webRequest, null);
    }

    public ResponseEntity<ErrorResponse> buildResponseEntity(Throwable error, WebRequest webRequest, HttpStatus overrideStatus) {
        return buildResponseEntity(error, new RequestWrapper.WebRequestWrapper(webRequest), overrideStatus);
    }

    public ResponseEntity<ErrorResponse> buildResponseEntity(Throwable error, RequestWrapper requestWrapper) {
        return buildResponseEntity(error, requestWrapper, null);
    }

    public ResponseEntity<ErrorResponse> buildResponseEntity(Throwable error, RequestWrapper requestWrapper, HttpStatus overrideStatus) {
	    return this.exceptionHandler.handleError(error, requestWrapper, overrideStatus, this.errorResponseBuilderProxy);
    }

    @SuppressWarnings({"null", "squid:S3776"})
    ResponseEntity<ErrorResponse> doBuildResponseEntity(Throwable error, RequestWrapper requestWrapper, HttpStatus overrideStatus) {
        ResponseEntity<ErrorResponse> responseEntity = handleErrorResponse(error, requestWrapper);
        BaseBodyError bodyError = responseEntity.getBody().getError();

        // override message and set status (if not already defined) from @ResponseStatus annotation; logic does not apply for ResponseStatusException
        ResponseStatus responseStatus = error != null && !(error instanceof ResponseStatusException) ? findAnnotation(error.getClass(), ResponseStatus.class) : null;
        if (responseStatus != null) {
            if (StringUtils.hasLength(responseStatus.reason())) bodyError.setMessages(Collections.singletonList(responseStatus.reason()));
            if (overrideStatus == null) overrideStatus = responseStatus.code();
        }

        // override attributes from @StandardError annotation
        StandardError standardError = error != null ? findAnnotation(error.getClass(), StandardError.class) : null;
        if (standardError != null) {
            if (StringUtils.hasLength(standardError.errorCode())) bodyError.setErrorCode(standardError.errorCode());
            if (standardError.messages().length > 0) bodyError.setMessages(Arrays.asList(standardError.messages()));
            if (standardError.status() != StandardError.DEFAULT_UNUSED_HTTP_STATUS) overrideStatus = standardError.status();
        }

        if (error != null) {
            overrideMessagesIfExceptionIsNotInWhiteList(error, bodyError);
        }

        // http status of error responses with data-error(s) should match '**.data-errors.statusCode' property
        if (!CollectionUtils.isEmpty(bodyError.getDataErrors())) {
            overrideStatus = this.dataErrorsHttpStatus;
        }

        if (!this.properties.isUseEmptyValues()) {
            nullOutEmptyBodyErrorFields(bodyError);
        }

        if (overrideStatus != null && responseEntity.getStatusCode() != overrideStatus) {
            return responseEntity(bodyError, overrideStatus);
        }

        return responseEntity;
    }

    void overrideMessagesIfExceptionIsNotInWhiteList(Throwable error, BaseBodyError bodyError) {
        if (!this.whiteListExceptionPatternMatcher.isMatch(error.getClass())) {
            bodyError.setMessages(Collections.singletonList(getGenericMessage()));
        }
    }

    public void overrideMessagesIfGenericMessage(BaseBodyError bodyError, String overrideMessage) {
        List<String> messages = bodyError.getMessages();
        if (messages != null && messages.size() == 1 && messages.get(0).equals(getGenericMessage())) {
            bodyError.setMessages(Collections.singletonList(overrideMessage));
        }
    }

    String getGenericMessage() {
        return this.properties.getMessages().getWhiteList().getGenericMessage();
    }

    void nullOutEmptyBodyErrorFields(BaseBodyError bodyError) {
	    if (CollectionUtils.isEmpty(bodyError.getDataErrors())) bodyError.setDataErrors(null);
	    if (CollectionUtils.isEmpty(bodyError.getMessages())) bodyError.setMessages(null);
	    if (CollectionUtils.isEmpty(bodyError.getAttributes())) bodyError.setAttributes(null);
    }

    ResponseEntity<ErrorResponse> handleErrorResponse(Throwable error, RequestWrapper requestWrapper) {
        if (error == null)
            return handleNoException(requestWrapper);

        if (error instanceof BaseBodyResponseException)
            return handleBaseBodyResponseException(error, requestWrapper, (BaseBodyResponseException) error);

        if (error instanceof BindingResult)
            return handleBindingResult(error, requestWrapper, (BindingResult) error);

        // Spring Boot 2.3 compatibility
        if (error instanceof MethodArgumentNotValidException)
            return handleBindingResult(error, requestWrapper, ((MethodArgumentNotValidException)error).getBindingResult());

        if (error instanceof ResponseStatusException)
            return handleResponseStatusException(error, requestWrapper, (ResponseStatusException) error);

        return handleGeneralError(error, requestWrapper);
    }

    ResponseEntity<ErrorResponse> handleNoException(RequestWrapper requestWrapper) {
        BaseBodyErrorBuilder baseBodyErrorBuilder = this.buildWithCommonAttributes(null, requestWrapper);
        // rely on request attributes if no error object is present
        populateBaseBodyErrorFromRequestAttributes(baseBodyErrorBuilder, requestWrapper);
        HttpStatus status = getStatusFromRequestAttributes(requestWrapper);
        return responseEntity(baseBodyErrorBuilder.build(), status);
    }

    ResponseEntity<ErrorResponse> handleBaseBodyResponseException(Throwable error, RequestWrapper requestWrapper, BaseBodyResponseException bodyResponseEx) {
        // populate any missing common error attributes (for existing attributes structure)
        Map<String, Object> errorAttributes = bodyResponseEx.getError().getAttributesMutable();
        populateCommonAttributes(errorAttributes, error, requestWrapper);

        return responseEntity(bodyResponseEx.getError(), bodyResponseEx.getHttpStatus());
    }

    ResponseEntity<ErrorResponse> handleResponseStatusException(Throwable error, RequestWrapper requestWrapper, ResponseStatusException responseStatusEx) {
        BaseBodyError bodyError =
                this.buildWithCommonAttributes(error, requestWrapper)
                        .message(StringUtils.hasLength(responseStatusEx.getReason()) ? responseStatusEx.getReason() : responseStatusEx.getMessage())
                        .build();

        return responseEntity(bodyError, responseStatusEx.getStatus(), responseStatusEx.getResponseHeaders());
    }

    ResponseEntity<ErrorResponse> handleGeneralError(Throwable error, RequestWrapper requestWrapper) {
        BaseBodyError bodyError =
                this.buildWithCommonAttributes(error, requestWrapper)
                        .message(error.getMessage())
                        .build();

        return responseEntity(bodyError, HttpStatus.INTERNAL_SERVER_ERROR);
    }

    ResponseEntity<ErrorResponse> handleBindingResult(Throwable error, RequestWrapper requestWrapper, BindingResult bindingResult) {
        BaseBodyError bodyError =
                this.buildWithCommonAttributes(error, requestWrapper)
                    .message(String.format("Validation failed for object='%s'. Error count: %s", bindingResult.getObjectName(), bindingResult.getErrorCount()))
                    .dataErrors(toDataErrors(bindingResult.getFieldErrors()))
                    .build();

        return responseEntity(bodyError, this.dataErrorsHttpStatus);
    }

    ResponseEntity<ErrorResponse> responseEntity(BaseBodyError bodyError, HttpStatus status) {
        return responseEntity(bodyError, status, null);
    }

    ResponseEntity<ErrorResponse> responseEntity(BaseBodyError bodyError, HttpStatus status, HttpHeaders httpHeaders) {
        if (this.properties.isUseBaseBodyResponse()) { // original
            return new ResponseEntity<>(BaseBodyResponse.error(bodyError), httpHeaders, status);
        }

        return ResponseEntity.status(status.value())
                .headers(httpHeaders)
                .contentType(MediaType.APPLICATION_PROBLEM_JSON)
                .body(StandardErrorResponse.error(bodyError, status.value()));
    }

    List<BaseBodyDataError> toDataErrors(List<FieldError> fieldErrors) {
        boolean includeCode = this.properties.getDataErrors().isIncludeCode();
        boolean includeValue = this.properties.getDataErrors().isIncludeValue();
        Set<StandardDataError> standardDataErrors = new HashSet<>();
        return fieldErrors.stream()
                .map(fieldError -> {
                    StandardDataError standardDataError = getFordDataError(fieldError);
                    if (standardDataError != null && !standardDataErrors.add(standardDataError)) return null; // ensures only one dataError entry per @FordDataError

                    return BaseBodyDataError.builder()
                        .name(defaultIfBlank(standardDataError != null ? standardDataError.name() : null, fieldError.getField()))
                        .message(defaultIfBlank(standardDataError != null ? standardDataError.message() : null, fieldError.getDefaultMessage()))
                        .code(defaultIfBlank(standardDataError != null ? standardDataError.code() : null, includeCode ? fieldError.getCode() : null))
                        .value(includeValue && fieldError.getRejectedValue() != null ? String.valueOf(fieldError.getRejectedValue()) : null)
                        .build();
                })
                .filter(Objects::nonNull)
                .collect(Collectors.toList());
    }

	StandardDataError getFordDataError(FieldError fieldError) {
	    try {
            Class<?> rootBeanClass = fieldError.unwrap(ConstraintViolation.class).getRootBeanClass();
            return getFordDataErrorsForClass(rootBeanClass).get(fieldError.getField());
        } catch (Exception e) { /*ignore*/ }
	    return  null;
    }

    Map<String, StandardDataError> getFordDataErrorsForClass(Class<?> beanClass) {
        return standardDataErrorByPropertyByClassCache.computeIfAbsent(beanClass, aClass -> {
            Map<String, StandardDataError> fordDataErrorByProperty = new HashMap<>();
            Validator validator = this.validatorFactory.getValidator();
            BeanDescriptor constraints = validator.getConstraintsForClass(aClass);
            for (PropertyDescriptor propertyDescriptor : constraints.getConstrainedProperties()) { // all properties of class
                Optional<StandardDataError> fordDataErrorOpt = (Optional<StandardDataError>) propertyDescriptor.getConstraintDescriptors()
                        .stream()
                        .map(ConstraintDescriptor::getAnnotation)
                        .filter(StandardDataError.class::isInstance)
                        .findFirst();
                if (fordDataErrorOpt.isPresent()) {
                    fordDataErrorByProperty.put(propertyDescriptor.getPropertyName(), fordDataErrorOpt.get());
                }
            }
            return fordDataErrorByProperty;
        });
    }

    BaseBodyErrorBuilder buildWithCommonAttributes(Throwable error, RequestWrapper requestWrapper) {
        BaseBodyErrorBuilder builder = BaseBodyError.builder();

        Map<String, Object> attributes = new HashMap<>();
        populateCommonAttributes(attributes, error, requestWrapper);
        builder.attributes(attributes);

        return builder;
    }

    void populateCommonAttributes(Map<String, Object> attributes, Throwable error, RequestWrapper requestWrapper) {
        if (error != null && this.properties.getAttributes().isIncludeException())
            attributes.putIfAbsent(EXCEPTION_ATTRIBUTE, error.getClass().getName());

        Long startTime = getStartTime(requestWrapper);
        if (startTime != null) attributes.putIfAbsent("timestamp", (long)startTime/1000);

        String traceId = getRequestTracer().getTraceId();
        if (traceId != null) attributes.putIfAbsent("referenceId", traceId);
    }

    Long getStartTime(RequestWrapper requestWrapper) {
        return (Long)requestWrapper.getAttribute(RequestFilter.START_TIME_ATTRIBUTE);
    }

    HttpStatus getStatusFromRequestAttributes(RequestWrapper requestWrapper) {
        try {
            Optional<Integer> errorStatusCodeAttribute = requestWrapper.getErrorStatusCodeAttribute();
            if (errorStatusCodeAttribute.isPresent()) return HttpStatus.valueOf(errorStatusCodeAttribute.get());
        } catch (Exception ex) { /* ignore */ }
        return HttpStatus.INTERNAL_SERVER_ERROR;
    }

    void populateBaseBodyErrorFromRequestAttributes(BaseBodyErrorBuilder baseBodyErrorBuilder, RequestWrapper requestWrapper) {
        Map<String, Object> errorAttributes = requestWrapper.getErrorAttributes(this.errorAttributeOptions);

        @SuppressWarnings("squid:S1192")
        String exception = valueOf(errorAttributes.get("exception"));
        if (exception != null) baseBodyErrorBuilder.attribute(EXCEPTION_ATTRIBUTE, exception);

        String message = valueOf(errorAttributes.get("message"));
        baseBodyErrorBuilder.messages(Collections.singletonList(StringUtils.hasLength(message) ? message : "No message available"));
    }

    @SuppressWarnings("unchecked")
    <A extends Annotation> A findAnnotation(AnnotatedElement element, Class<A> annotationType) {
        Map<AnnotatedElement, A> annotatedElementsByType = (Map<AnnotatedElement, A>)this.findAnnotationCache.computeIfAbsent(annotationType, a -> new ConcurrentHashMap<>());
        return annotatedElementsByType.computeIfAbsent(element, e -> AnnotatedElementUtils.findMergedAnnotation(e, annotationType));
    }

    RequestTracer getRequestTracer() { // RequestTracer bean needs to be lazily resolved
        if (this.requestTracer == null) this.requestTracer = ctx.getBean(RequestTracer.class);
        return this.requestTracer;
    }

    @SuppressWarnings("squid:S2259")
    public Map<String, Object> getErrorAttributes(ResponseEntity<ErrorResponse> errorResponseEntity) {
        Map<String, Object> errorAttributes = new HashMap<>();
        ErrorResponse response = errorResponseEntity.getBody();

        if (response instanceof BaseBodyResponse) {
            errorAttributes.put(ERROR_FIELD, response.getError());
        } else {
            StandardErrorResponse standardErrorResponse = (StandardErrorResponse) response;
            errorAttributes.put("type", standardErrorResponse.getType());
            errorAttributes.put("title", standardErrorResponse.getTitle());
            errorAttributes.put("status", standardErrorResponse.getStatus());
            errorAttributes.put(ERROR_FIELD, standardErrorResponse.getError());
        }

        return errorAttributes;
    }

    public Map<String, Object> filterErrorResponseFields(Map<String, ?> modelMap) {
        List<String> whiteListFields = Arrays.asList("type", "title", "status", ERROR_FIELD);
        return whiteListFields.stream().filter(modelMap::containsKey).collect(Collectors.toMap(Function.identity(), modelMap::get));
    }

    String defaultIfBlank(String s, String defaultValue) {
        return StringUtils.hasLength(s) ? s : defaultValue;
    }

    String valueOf(Object o) {
        return o != null ? String.valueOf(o) : null;
    }

    public class ErrorResponseBuilderProxy {
	    private ErrorResponseBuilderProxy() {}

        public ResponseEntity<ErrorResponse> buildResponseEntity(Throwable error, RequestWrapper requestWrapper, HttpStatus overrideStatus) {
            return ErrorResponseBuilder.this.doBuildResponseEntity(error, requestWrapper, overrideStatus);
        }
    }
}
