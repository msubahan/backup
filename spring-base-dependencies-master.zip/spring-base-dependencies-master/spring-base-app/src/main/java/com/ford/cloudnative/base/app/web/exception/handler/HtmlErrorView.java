package com.ford.cloudnative.base.app.web.exception.handler;

import org.springframework.stereotype.Component;
import org.springframework.web.util.HtmlUtils;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;

@Component
public class HtmlErrorView {
    ObjectWriter objectWriter;
    
    static String customErrorView =
            "<html><body><h1>Whitelabel Error Page</h1>"
                    + "<p>This application has no explicit mapping for /error, so you are seeing this as a fallback.</p><hr/>"
                    + "<div><pre>%s</pre></div>"
                    + "</body></html>";

    public HtmlErrorView() {
        this.objectWriter = new ObjectMapper().writerWithDefaultPrettyPrinter();
    }
    
    public String errorPageHtml(Object errorBody, String encoding) {
        try {
            String json = objectWriter.writeValueAsString(errorBody);
            String jsonHtml = HtmlUtils.htmlEscape(json, encoding);
            return String.format(customErrorView, jsonHtml);
        } catch (JsonProcessingException e) {
            return String.format(customErrorView, "");
        }
    }
}
