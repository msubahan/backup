package com.ford.cloudnative.base.app.discovery;

import java.util.LinkedHashMap;

import org.springframework.context.EnvironmentAware;
import org.springframework.context.annotation.DeferredImportSelector;
import org.springframework.core.env.ConfigurableEnvironment;
import org.springframework.core.env.Environment;
import org.springframework.core.env.MapPropertySource;
import org.springframework.core.type.AnnotationMetadata;


public class DisableEurekaClientBootstrap implements DeferredImportSelector, EnvironmentAware {

	@Override
	public void setEnvironment(Environment env) {
		if(env instanceof ConfigurableEnvironment) {
			ConfigurableEnvironment configEnv = (ConfigurableEnvironment)env;
			LinkedHashMap<String, Object> map = new LinkedHashMap<>();
			map.put("eureka.client.enabled", false);
			MapPropertySource propertySource = new MapPropertySource("disableEurekaClientBootstrap", map);
			configEnv.getPropertySources().addLast(propertySource);
		}
	}

	@Override
	public String[] selectImports(AnnotationMetadata importingClassMetadata) {
		return new String[0];
	}
}
