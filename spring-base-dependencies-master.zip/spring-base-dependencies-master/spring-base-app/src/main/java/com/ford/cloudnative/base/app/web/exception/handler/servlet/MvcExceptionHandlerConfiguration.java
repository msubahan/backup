package com.ford.cloudnative.base.app.web.exception.handler.servlet;

import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.autoconfigure.condition.ConditionalOnWebApplication;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;

@Configuration
@ConditionalOnProperty(prefix = "cn.app.exception-handler", name = "enabled", matchIfMissing = false)
@ConditionalOnWebApplication(type = ConditionalOnWebApplication.Type.SERVLET)
@Import({
        ErrorViewConfiguration.class,
        ControllerExceptionHandler.class,
        FallbackErrorAttributesHandler.class,
        MvcErrorController.class,
        WebSecurityResponseExceptionHandler.class
})
public class MvcExceptionHandlerConfiguration {
}
