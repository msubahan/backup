package com.ford.cloudnative.base.app;

import org.springframework.boot.autoconfigure.AutoConfigureBefore;
import org.springframework.boot.autoconfigure.web.servlet.error.ErrorMvcAutoConfiguration;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;

import com.ford.cloudnative.base.app.configure.ConfigureConfiguration;
import com.ford.cloudnative.base.app.discovery.DisableLocalDiscoveryClientConfiguration;
import com.ford.cloudnative.base.app.web.exception.handler.ExceptionHandlerConfiguration;

@Configuration
@AutoConfigureBefore(ErrorMvcAutoConfiguration.class) //needed for ErrorViewConfiguration$CustomWhitelabelErrorViewConfiguration#defaultErrorView @ConditionalOnMissingBean
@Import({
	ConfigureConfiguration.class,
	ExceptionHandlerConfiguration.class,
	DisableLocalDiscoveryClientConfiguration.class
})
public class BaseAppBeforeWebAutoConfiguration {

}
