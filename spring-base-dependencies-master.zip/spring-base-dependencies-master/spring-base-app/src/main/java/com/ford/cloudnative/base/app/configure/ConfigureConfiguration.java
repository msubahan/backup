package com.ford.cloudnative.base.app.configure;

import java.util.TimeZone;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@Configuration
@SuppressWarnings("squid:S1118")
public class ConfigureConfiguration {

	@ConfigurationProperties(prefix = "cn.app.configure", ignoreUnknownFields = true)
	@lombok.Data
	public static class ConfigureProperties {
		TimeZone defaultTimeZone;
	}

	@Configuration
	@EnableConfigurationProperties(ConfigureProperties.class)
	public static class ConfigureInitConfiguration {

		@Autowired
		ConfigureProperties properties;

		@PostConstruct
		public void init() {
			if (properties.getDefaultTimeZone() != null) {
				TimeZone.setDefault(properties.getDefaultTimeZone());
			}
		}
	}

}
