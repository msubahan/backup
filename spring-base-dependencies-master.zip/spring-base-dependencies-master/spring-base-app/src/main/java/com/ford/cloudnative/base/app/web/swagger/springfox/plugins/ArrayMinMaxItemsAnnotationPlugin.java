package com.ford.cloudnative.base.app.web.swagger.springfox.plugins;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.annotation.Order;
import springfox.bean.validators.plugins.Validators;
import springfox.documentation.schema.plugins.SchemaPluginsManager;
import springfox.documentation.service.AllowableRangeValues;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spi.schema.ModelPropertyBuilderPlugin;
import springfox.documentation.spi.schema.contexts.ModelPropertyContext;

import javax.validation.constraints.Size;
import java.util.Optional;

import static springfox.bean.validators.plugins.RangeAnnotations.stringLengthRange;

@Order(Validators.BEAN_VALIDATOR_PLUGIN_ORDER - 50)
public class ArrayMinMaxItemsAnnotationPlugin implements ModelPropertyBuilderPlugin {

    @Autowired
    SchemaPluginsManager schemaPluginsManager;

    @Override
    public boolean supports(DocumentationType delimiter) {
        return true;
    }

    @Override
    @SuppressWarnings("deprecation")
    public void apply(ModelPropertyContext context) {
        Optional<Size> size = PluginUtils.extractAnnotation(context, Size.class);

        if (size.isPresent()) {
            AllowableRangeValues allowableRangeValues = stringLengthRange(size.get());

            context.getBuilder().allowableValues(allowableRangeValues);
            context.getSpecificationBuilder()
                    .collectionFacet(s -> {
                        s.minItems(tryGetInteger(allowableRangeValues.getMin()).orElse(null));
                        s.maxItems(tryGetInteger(allowableRangeValues.getMax()).orElse(null));
                    });
        }
    }

    private Optional<Integer> tryGetInteger(String min) {
        try {
            return Optional.of(Integer.valueOf(min));
        } catch (NumberFormatException e) {
            return Optional.empty();
        }
    }

}
