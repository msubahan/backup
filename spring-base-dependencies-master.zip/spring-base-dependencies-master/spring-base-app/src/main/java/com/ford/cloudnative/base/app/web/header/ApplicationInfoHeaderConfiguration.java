package com.ford.cloudnative.base.app.web.header;

import java.util.Map;

import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.ford.cloudnative.base.app.web.header.ApplicationInfoHeaderConfiguration.ApplicationInfoProperties;

import lombok.Data;

@Configuration
@ConditionalOnProperty(prefix = "cn.app.application-info-header", name = "enabled", matchIfMissing = false)
@EnableConfigurationProperties(ApplicationInfoProperties.class)
public class ApplicationInfoHeaderConfiguration {
	
	@ConfigurationProperties(prefix = "cn.app.application-info-header", ignoreUnknownFields = true)
	@Data
	public static class ApplicationInfoProperties {
		boolean enabled;
		Map<String, String> attributes;
	}
	
	@Bean
	@ConditionalOnMissingBean
	public ApplicationInfoHeaderResponseBodyAdvice applicationInfoHeaderResponseBodyAdvice(ApplicationInfoProperties properties) {
		return new ApplicationInfoHeaderResponseBodyAdvice(properties.getAttributes());
	}
	
}
