package com.ford.cloudnative.base.app.web.swagger;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.http.MediaType;
import org.springframework.util.CollectionUtils;

import javax.annotation.PostConstruct;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Map;

import static org.springframework.util.StringUtils.hasLength;

@ConfigurationProperties(prefix = "cn.app.swagger")
@Data
public class SwaggerProperties {
    boolean enabled;

    List<String> scanPackages = Collections.emptyList();
    boolean useDefaultResponseMessages;
    Display display = new Display();
    SecurityProperties security = new SecurityProperties();
    Apidoc apidoc = new Apidoc();
    List<MediaType> defaultProduces = Arrays.asList(MediaType.APPLICATION_JSON, MediaType.APPLICATION_PROBLEM_JSON);
    Extensions extensions = new Extensions();

    @Data
    public static class Display {
        String title;
        String description;
        String contactName;
        String contactEmail;
        String contactUrl;
        String version;
        String license;
        String licenseUrl;
        String termsOfServiceUrl;
    }

    @Data
    public static class Apidoc {
        String host;
        String basePath;
        List<String> schemes;
    }

    @Data
    public static class Extensions {
        boolean xNullable;
    }

    @Data
    public static class SecurityProperties {
        OAuth2SecurityProperties apic = new OAuth2SecurityProperties(ApiSecurityScheme.APIC);
        OAuth2SecurityProperties adfs = new OAuth2SecurityProperties(ApiSecurityScheme.ADFS);
        OAuth2SecurityProperties azureAd = new OAuth2SecurityProperties(ApiSecurityScheme.AZURE_AD);
        ApiKeySecurityProperties applicationId = new ApiKeySecurityProperties(ApiSecurityScheme.APPLICATION_ID, "Application-Id", "header");
        ApiKeySecurityProperties catAuthToken = new ApiKeySecurityProperties(ApiSecurityScheme.CAT_AUTH_TOKEN, "auth-token", "header");

        public SecurityProperties() {
            adfs.setScopes(Collections.singletonMap("unused", "unused"));
        }

        @Data
        public abstract static class BaseSecurityProperties {
            final ApiSecurityScheme apiSecurityScheme;
            boolean enabled;
            List<String> paths;
        }

        @Value
        @EqualsAndHashCode(callSuper = true)
        public static class ApiKeySecurityProperties extends BaseSecurityProperties {
            final String name;
            final String in;
            public ApiKeySecurityProperties(ApiSecurityScheme scheme, String name, String in) { super(scheme); this.name = name; this.in = in; }
        }

        @Data
        @EqualsAndHashCode(callSuper = true)
        public static class OAuth2SecurityProperties extends BaseSecurityProperties {
            Map<String, String> scopes;
            String tokenUrl;
            String env;
            public OAuth2SecurityProperties(ApiSecurityScheme scheme) { super(scheme); }
        }
    }

    @PostConstruct
    void normalize() {
        this.display.title = valueOrNull(this.display.title);
        this.display.description = valueOrNull(this.display.description);
        this.display.contactName = valueOrNull(this.display.contactName);
        this.display.contactEmail = valueOrNull(this.display.contactEmail);
        this.display.contactUrl = valueOrNull(this.display.contactUrl);
        this.display.version = valueOrNull(this.display.version);
        this.display.license = valueOrNull(this.display.license);
        this.display.licenseUrl = valueOrNull(this.display.licenseUrl);
        this.display.termsOfServiceUrl = valueOrNull(this.display.termsOfServiceUrl);
    }

    static String valueOrNull(String value) {
        return hasLength(value) ? value : null;
    }

    public boolean isHost() {
        return hasLength(this.apidoc.host);
    }

    public boolean isBasePath() {
        return hasLength(this.apidoc.basePath);
    }

    public boolean isSchemes() {
        return !CollectionUtils.isEmpty(this.apidoc.schemes);
    }

}
