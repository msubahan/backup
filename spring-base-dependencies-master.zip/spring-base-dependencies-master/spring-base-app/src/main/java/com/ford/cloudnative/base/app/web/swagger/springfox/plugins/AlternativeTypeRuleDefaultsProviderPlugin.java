package com.ford.cloudnative.base.app.web.swagger.springfox.plugins;

import com.ford.cloudnative.base.app.web.swagger.springfox.core.MapAlternateTypeRule;
import org.springframework.core.annotation.Order;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spi.service.DefaultsProviderPlugin;
import springfox.documentation.spi.service.contexts.DocumentationContextBuilder;

import java.util.Collections;

@Order(0)
public class AlternativeTypeRuleDefaultsProviderPlugin implements DefaultsProviderPlugin {

    @Override
    public DocumentationContextBuilder create(DocumentationType documentationType) {
        throw new UnsupportedOperationException();
    }

    @Override
    public DocumentationContextBuilder apply(DocumentationContextBuilder builder) {
        return builder
                .rules(Collections.singletonList(new MapAlternateTypeRule()));
    }

    @Override
    public boolean supports(DocumentationType delimiter) {
        return true;
    }

}
