package com.ford.cloudnative.base.app.web.swagger.springfox.filter;

import com.ford.cloudnative.base.app.web.swagger.SwaggerProperties;
import io.swagger.v3.oas.models.OpenAPI;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.annotation.Order;
import springfox.documentation.oas.web.OpenApiTransformationContext;
import springfox.documentation.oas.web.WebMvcOpenApiTransformationFilter;
import springfox.documentation.spi.DocumentationType;

import javax.servlet.http.HttpServletRequest;

import static springfox.documentation.spi.DocumentationType.OAS_30;
import static springfox.documentation.swagger.common.SwaggerPluginSupport.SWAGGER_PLUGIN_ORDER;


@Order(SWAGGER_PLUGIN_ORDER + 11)
public class ServerUrlLocalPlaceholdersTransformationFilter implements WebMvcOpenApiTransformationFilter {

    @Autowired
    SwaggerProperties properties;

    @Override
    public OpenAPI transform(final OpenApiTransformationContext<HttpServletRequest> context) {
        OpenAPI openApi = context.getSpecification();

        context.request().ifPresent(request -> {
            String scheme = request.getScheme();
            String host = request.getServerName();
            int port = request.getServerPort();

            openApi.getServers().forEach(server ->
                    server.setUrl(server.getUrl()
                            .replace("{scheme}", scheme)
                            .replace("{host}", host)
                            .replace("{port}", String.valueOf(port))
                    )
            );
        });

        return openApi;
    }


    @Override
    public boolean supports(final DocumentationType documentationType) {
        return OAS_30.equals(documentationType);
    }
}
