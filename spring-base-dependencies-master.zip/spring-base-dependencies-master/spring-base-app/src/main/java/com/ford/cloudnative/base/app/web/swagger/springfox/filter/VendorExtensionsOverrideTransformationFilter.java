package com.ford.cloudnative.base.app.web.swagger.springfox.filter;

import com.ford.cloudnative.base.app.web.swagger.springfox.plugins.PluginUtils;
import io.swagger.models.ArrayModel;
import io.swagger.models.ComposedModel;
import io.swagger.models.Model;
import io.swagger.models.ModelImpl;
import io.swagger.models.Swagger;
import io.swagger.models.parameters.AbstractSerializableParameter;
import io.swagger.models.parameters.Parameter;
import io.swagger.models.properties.ArrayProperty;
import io.swagger.models.properties.MapProperty;
import io.swagger.models.properties.ObjectProperty;
import io.swagger.models.properties.Property;
import io.swagger.models.properties.RefProperty;
import io.swagger.models.refs.GenericRef;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import org.springframework.util.ReflectionUtils;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.swagger2.web.SwaggerTransformationContext;
import springfox.documentation.swagger2.web.WebMvcSwaggerTransformationFilter;

import javax.servlet.http.HttpServletRequest;
import java.lang.reflect.Field;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import static springfox.documentation.spi.DocumentationType.SWAGGER_2;
import static springfox.documentation.swagger.common.SwaggerPluginSupport.SWAGGER_PLUGIN_ORDER;

@Component
@Order(SWAGGER_PLUGIN_ORDER + 40)
public class VendorExtensionsOverrideTransformationFilter implements WebMvcSwaggerTransformationFilter {

    @Override
    public Swagger transform(final SwaggerTransformationContext<HttpServletRequest> context) {
        Swagger swagger = context.getSpecification();
        NormalizeSchema normalizeSchema = new NormalizeSchema();
        normalizeSchema.normalize(swagger.getDefinitions().values());
        PluginUtils.getAllParameters(swagger).forEach(normalizeSchema::normalize);
        return swagger;
    }

    @Override
    public boolean supports(final DocumentationType documentationType) {
        return SWAGGER_2.equals(documentationType);
    }

    public static class NormalizeSchema {
        Set<Object> normalized = new HashSet<>();

        void normalize(Collection<Model> models) {
            if (!CollectionUtils.isEmpty(models)) models.forEach(this::normalize);
        }

        void normalize(Model model) {
            normalize(model, model.getVendorExtensions());
            normalize(model.getProperties());

            if (model instanceof ModelImpl) {
                normalize(((ModelImpl) model).getAdditionalProperties());
            } else if (model instanceof ArrayModel) {
                normalize(((ArrayModel) model).getItems());
            } else if (model instanceof ComposedModel) {
                ComposedModel composedModel = (ComposedModel) model;
                normalize(composedModel.getChild());
                normalize(composedModel.getParent());
                normalize(Collections.unmodifiableList(composedModel.getInterfaces()));
                normalize(Collections.unmodifiableList(composedModel.getAllOf()));
            }

        }

        void normalize(Map<String, Property> properties) {
            if (!CollectionUtils.isEmpty(properties)) properties.values().forEach(this::normalize);
        }

        void normalize(Property property) {
            if (property != null) {
                normalize(property, property.getVendorExtensions());
            }

            if (property instanceof ObjectProperty) {
                normalize(((ObjectProperty) property).getProperties());
            } else if (property instanceof ArrayProperty) {
                normalize(((ArrayProperty) property).getItems());
            } else if (property instanceof MapProperty) {
                normalize(((MapProperty) property).getAdditionalProperties());
            }
        }

        void normalize(Parameter parameter) {
            if (parameter != null) {
                normalize(parameter, parameter.getVendorExtensions());
            }

            if (parameter instanceof AbstractSerializableParameter<?>) {
                normalize(((AbstractSerializableParameter<?>) parameter).getItems());
            }
        }

        @SuppressWarnings("squid:S3011")
        void normalize(Object o, Map<String, Object> vendorExtensions) {
            if (CollectionUtils.isEmpty(vendorExtensions)) return;
            if (!normalized.add(o)) return;

            List<String> potentialKeys = vendorExtensions.keySet().stream().filter(key -> !key.startsWith("x-")).collect(Collectors.toList());
            for (String key : potentialKeys) {
                boolean isRef = key.equals("$ref");  // RefProperty & RefModel requires special logic
                String fieldName = isRef ? "genericRef" : key;
                Field field = ReflectionUtils.findField(o.getClass(), fieldName);
                if (field != null) {
                    field.setAccessible(true);
                    Object value = isRef ? new GenericRef() : vendorExtensions.get(key);
                    ReflectionUtils.setField(field, o, value);
                    if (!isRef && !(o instanceof RefProperty)) vendorExtensions.remove(key);
                }
            }
        }
    }
}
