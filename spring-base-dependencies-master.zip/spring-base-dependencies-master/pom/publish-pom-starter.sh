#!/bin/sh

# CLI usage: BOOST_PUBLISH_TEAM_REPO_USER=user BOOST_PUBLISH_TEAM_REPO_PASS=**** ./publish-pom-starter.sh

./mvnw org.apache.maven.plugins:maven-deploy-plugin:2.8.2:deploy-file \
       -Durl=https://www.nexus.ford.com/content/groups/PCFDevEnablement_public_release_repository \
       -DrepositoryId=nexus \
       -Dfile=pom-starter.xml \
       -DpomFile=pom-starter.xml \
       -s settings.xml

# LOCAL DEPLOY
#./mvnw org.apache.maven.plugins:maven-deploy-plugin:2.8.2:deploy-file -Durl=file:///C:/temp/nexus-team-repo-private -DrepositoryId=foo -Dfile=pom-starter.xml -DpomFile=pom-starter.xml
