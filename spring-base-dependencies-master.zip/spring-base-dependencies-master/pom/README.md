This project generates the BOM that manages the versions for the following dependencies:
- [Cloud Native Spring Base API](https://github.ford.com/PCFDev-Libraries/cloudnative-library-spring-base-api)
- [Cloud Native Spring Base App](https://github.ford.com/PCFDev-Libraries/cloudnative-library-spring-base-app)
- [Cloud Native Spring Base Client](https://github.ford.com/PCFDev-Libraries/cloudnative-library-spring-base-client)

<br/>

## Publish

### Release Version

In [pom-starter.xml](pom-starter.xml) and [pom.xml](pom.xml), update the BOM version as well as the versions to all the referenced dependencies. In Bash, run the following command (with the correct credentials) to publish the new versioned BOM in Nexus:

```
BOOST_PUBLISH_TEAM_REPO_USER=user BOOST_PUBLISH_TEAM_REPO_PASS=**** ./publish-pom-starter.sh
BOOST_PUBLISH_TEAM_REPO_USER=user BOOST_PUBLISH_TEAM_REPO_PASS=**** ./publish-pom.sh
```

### Snapshot Version

In [SNAPSHOT-pom-starter.xml](SNAPSHOT-pom-starter.xml), update the BOM SNAPSHOT version as well as the SNAPSHOT versions to all the referenced dependencies. In Bash, run the following command (with the correct credentials) to publish the new versioned SNAPSHOT BOM in Nexus:

```
BOOST_PUBLISH_TEAM_REPO_USER=user BOOST_PUBLISH_TEAM_REPO_PASS=**** ./SNAPSHOT-publish-pom-starter.sh
```

NOTE: The nexus repo which this BOM is published to is hardcoded inside the scripts