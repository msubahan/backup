package com.ford.cloudnative.validators;

import com.ford.cloudnative.annotations.BlacklistCharsValidator;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import java.text.Normalizer;

public class CheckBlacklistCharacters implements ConstraintValidator<BlacklistCharsValidator, Object> {
    private String regex;

    @Override
    public void initialize(BlacklistCharsValidator blacklistCharsValidator) {
        String unwanted = new String(blacklistCharsValidator.chars());
        this.regex = "[" + unwanted + "]";
    }

    @Override
    public boolean isValid(Object object, ConstraintValidatorContext context) {
        return ValidatorHelper.isValid(new CheckString(), object);
    }

    private class CheckString implements CheckStringExecutor {
        public boolean execute(String value) {
            value = Normalizer.normalize(value, Normalizer.Form.NFKC);
            String removedUnwanted = value.replaceAll(regex, "");
            return (removedUnwanted.length() == value.length());
        }
    }
}
