package com.ford.cloudnative.validators;

public interface CheckStringExecutor {

    boolean execute(String string);
}
