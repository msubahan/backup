package com.ford.cloudnative.configurations;

import com.ford.cloudnative.annotations.*;
import com.ford.cloudnative.base.api.BaseBodyResponse;
import com.ford.cloudnative.services.SanitizerService;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.ResponseEntity;

import static com.ford.cloudnative.services.SanitizerService.Tool;

@Aspect
@Configuration
public class AspectConfiguration {
    @Around("@annotation(htmlEncodeInputOutputData)")
    public Object htmlInputOutputEncoderAspect(ProceedingJoinPoint pjp, HtmlEncodeInputOutputData htmlEncodeInputOutputData) throws Throwable {
        boolean loggingEnabled = htmlEncodeInputOutputData.loggingEnabled();
        Object[] args = pjp.getArgs();
        sanitizeInput(loggingEnabled, args, Tool.HTML_ENCODER);
        Object obj = (Object) pjp.proceed(args);
        sanitizeOutput(loggingEnabled, obj, Tool.HTML_ENCODER);
        return obj;
    }

    @Around("@annotation(htmlEncodeInputData)")
    public Object htmlInputEncoderAspect(ProceedingJoinPoint pjp, HtmlEncodeInputData htmlEncodeInputData) throws Throwable {
        boolean loggingEnabled = htmlEncodeInputData.loggingEnabled();
        Object[] args = pjp.getArgs();
        sanitizeInput(loggingEnabled, args, SanitizerService.Tool.HTML_ENCODER);
        return (Object) pjp.proceed(args);
    }

    @Around("@annotation(uriEncodeInputData)")
    public Object uriInputEncoderAspect(ProceedingJoinPoint pjp, UriEncodeInputData uriEncodeInputData) throws Throwable {
        boolean loggingEnabled = uriEncodeInputData.loggingEnabled();
        Object[] args = pjp.getArgs();
        sanitizeInput(loggingEnabled, args, Tool.URI_ENCODER);
        return (Object) pjp.proceed(args);
    }

    @Around("@annotation(whitelistRegexInputData)")
    public Object whitelistInputAspect(ProceedingJoinPoint pjp, WhitelistRegexInputData whitelistRegexInputData) throws Throwable {
        boolean loggingEnabled = whitelistRegexInputData.loggingEnabled();
        String regex = whitelistRegexInputData.regex();
        Object[] args = pjp.getArgs();
        filterInput(loggingEnabled, args, Tool.WHITE_LIST_FILTER, regex);
        return (Object) pjp.proceed(args);
    }

    @Around("@annotation(blacklistRegexInputData)")
    public Object blacklistInputAspect(ProceedingJoinPoint pjp, BlacklistRegexInputData blacklistRegexInputData) throws Throwable {
        boolean loggingEnabled = blacklistRegexInputData.loggingEnabled();
        String regex = blacklistRegexInputData.regex();
        Object[] args = pjp.getArgs();
        filterInput(loggingEnabled, args, Tool.BLACK_LIST_FILTER, regex);
        return (Object) pjp.proceed(args);
    }

    @Around("@annotation(htmlEncodeOutputData)")
    public Object htmlOutputEncoderAspect(ProceedingJoinPoint pjp, HtmlEncodeOutputData htmlEncodeOutputData) throws Throwable {
        boolean loggingEnabled = htmlEncodeOutputData.loggingEnabled();
        Object[] args = pjp.getArgs();
        Object obj = (Object) pjp.proceed(args);
        sanitizeOutput(loggingEnabled, obj, Tool.HTML_ENCODER);
        return obj;
    }

    @Around("@annotation(removeScriptsTagsOutputData)")
    public Object removeOutputScriptsTagsAspect(ProceedingJoinPoint pjp, RemoveScriptsTagsOutputData removeScriptsTagsOutputData) throws Throwable {
        boolean loggingEnabled = removeScriptsTagsOutputData.loggingEnabled();
        Object[] args = pjp.getArgs();
        Object obj = (Object) pjp.proceed(args);
        callSanitizer(obj, loggingEnabled, Tool.SCRIPT_TAG_REMOVER);
        return obj;
    }

    @Around("@annotation(removeScriptsTagsInputData)")
    public Object removeInputScriptsTagsAspect(ProceedingJoinPoint pjp, RemoveScriptsTagsInputData removeScriptsTagsInputData) throws Throwable {
        boolean loggingEnabled = removeScriptsTagsInputData.loggingEnabled();
        Object[] args = pjp.getArgs();
        filterInput(loggingEnabled, args, Tool.SCRIPT_TAG_REMOVER, "");
        return (Object) pjp.proceed(args);
    }

    private void sanitizeInput(boolean loggingEnabled, Object[] args, Tool tool) {
        for (Object obj : args) {
            callSanitizer(obj, loggingEnabled, tool);
        }
    }

    private void filterInput(boolean loggingEnabled, Object[] args, Tool tool, String regex) {
        for (Object obj : args) {
            switch (tool) {
                case WHITE_LIST_FILTER:
                    SanitizerService.whitelistFilterStrings(obj, loggingEnabled, regex);
                    break;

                case BLACK_LIST_FILTER:
                    SanitizerService.blacklistFilterStrings(obj, loggingEnabled, regex);
                    break;

                case SCRIPT_TAG_REMOVER:
                    SanitizerService.sanitizeScriptTags(obj, loggingEnabled);
                    break;
                default:
            }
        }
    }

    private Object sanitizeOutput(boolean loggingEnabled, Object obj, Tool tool) {
        Class superClass = obj.getClass().getSuperclass();

        if (obj.getClass().getTypeName().endsWith("ResponseEntity")) {
            ResponseEntity result = (ResponseEntity) obj;
            if (result.hasBody()) {
                BaseBodyResponse response = (BaseBodyResponse) result.getBody();
                if (response == null || !response.hasResult()) {
                    return result;
                }
                callSanitizer(response.getResult(), loggingEnabled, tool);
                return result;
            }
        } else if (superClass.getTypeName().endsWith("BaseBodyResponse")) {
            callSanitizer(((BaseBodyResponse) obj).getResult(), loggingEnabled, tool);
        } else {
            callSanitizer(obj, loggingEnabled, tool);
        }
        return obj;
    }

    private void callSanitizer(Object obj, boolean loggingEnabled, Tool tool) {
        switch (tool) {
            case HTML_ENCODER:
                SanitizerService.htmlEncodeStrings(obj, loggingEnabled);
                break;

            case URI_ENCODER:
                SanitizerService.uriEncodeStrings(obj, loggingEnabled);
                break;

            case SCRIPT_TAG_REMOVER:
                SanitizerService.sanitizeScriptTags(obj, loggingEnabled);
                break;
            default:
        }
    }
}
