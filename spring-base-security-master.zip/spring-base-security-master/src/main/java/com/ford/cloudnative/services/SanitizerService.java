package com.ford.cloudnative.services;

import com.ford.cloudnative.helpers.SecurityHelper;
import lombok.extern.slf4j.Slf4j;
import org.owasp.encoder.Encode;

import java.lang.reflect.Field;
import java.text.Normalizer;
import java.util.Arrays;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

@Slf4j
public class SanitizerService {
    public enum Tool {
        SCRIPT_TAG_REMOVER, HTML_ENCODER, URI_ENCODER, WHITE_LIST_FILTER, BLACK_LIST_FILTER
    }

    public static void sanitizeScriptTags(Object clazz, boolean loggingEnabled) {
        sanitize(clazz, loggingEnabled, Tool.SCRIPT_TAG_REMOVER, "");
    }

    public static void whitelistFilterStrings(Object clazz, boolean loggingEnabled, String regex) {
        sanitize(clazz, loggingEnabled, Tool.WHITE_LIST_FILTER, regex);
    }

    public static void blacklistFilterStrings(Object clazz, boolean loggingEnabled, String regex) {
        sanitize(clazz, loggingEnabled, Tool.BLACK_LIST_FILTER, regex);
    }

    public static void htmlEncodeStrings(Object clazz, boolean loggingEnabled) {
        sanitize(clazz, loggingEnabled, Tool.HTML_ENCODER, "");
    }

    public static void uriEncodeStrings(Object clazz, boolean loggingEnabled) {
        sanitize(clazz, loggingEnabled, Tool.URI_ENCODER, "");
    }

    public static String removeScriptTagsFromString(String message) {
        if (message == null) {
            return null;
        }
        message = Normalizer.normalize(message, Normalizer.Form.NFKC);
        String[] scriptRegex = {"<(/)?[ ]*[script][^>]*>", "javascript:"};
        for (String regex : scriptRegex) {
            Pattern pattern = Pattern.compile(regex, Pattern.CASE_INSENSITIVE + Pattern.MULTILINE);
            Matcher matcher = pattern.matcher(message);
            StringBuffer str = new StringBuffer(message.length());
            while (matcher.find()) {
                matcher.appendReplacement(str, Matcher.quoteReplacement(" "));
            }
            matcher.appendTail(str);
            message = str.toString();
        }
        return message;
    }

    public static String htmlEncodeString(String data) {
        return Encode.forHtml(data);
    }

    public static String uriEncodeString(String data) {
        return Encode.forUriComponent(data);
    }

    public static String whitelistString(String data, String regex) {
        return applyWhitelist(data, regex);
    }

    public static String blacklistString(String data, String regex) {
        return applyBlacklist(data, regex);
    }

    private static void sanitize(Object clazz, boolean loggingEnabled, Tool tool, String regex) {
        if (clazz == null) {
            return;
        }
        try {
//            String packageNamePrefix = getPackageNamePrefix(clazz.getClass().getPackageName());
//            JAVA 8
            String packageNamePrefix = getPackageNamePrefix(clazz.getClass().getPackage().getName());
            if (isJavaLanguagePackage(packageNamePrefix)) {
                return;
            }

            Field[] fields = clazz.getClass().getDeclaredFields();
            for (Field field : fields) {
                processField(clazz, packageNamePrefix, field, loggingEnabled, tool, regex);
            }
        } catch (Exception e) {
            if (loggingEnabled) {
                log.error(e.getMessage());
            }
        }
    }

    private static void processField(Object clazz, String packageNamePrefix, Field field, boolean loggingEnabled, Tool tool, String regex) throws Exception {
        if (field.getType().equals(String.class)) {
            processStringField(clazz, field, loggingEnabled, tool, regex);
        } else if (field.getType().equals(String[].class)) {
            processStringArrayField(clazz, field, loggingEnabled, tool, regex);
        } else if (field.getType().equals(List.class)) {
            processList(clazz, packageNamePrefix, field, loggingEnabled, tool, regex);
        } else if (isAppDefinedFieldType(field, packageNamePrefix)) {
            field.setAccessible(true);
            sanitize(field.get(clazz), loggingEnabled, tool, regex);
        }
    }

    private static void processList(Object clazz, String packageNamePrefix, Field field, boolean loggingEnabled, Tool tool, String regex) throws IllegalAccessException {
        if (!field.getType().equals(List.class)) {
            return;
        }
        field.setAccessible(true);
        @SuppressWarnings("unchecked")
        List<Object> objectList = (List<Object>) field.get(clazz);
        if (objectList == null) {
            return;
        }
        Object sample = objectList.get(0);
        if (isAppDefinedObject(sample, packageNamePrefix)) {
            for (Object o : objectList) {
                sanitize(o, loggingEnabled, tool, regex);
            }
        }
        if (isListOfStrings(sample)) {
            for (int i = 0; i < objectList.size(); i++) {
                String encodedValue = clean((String) objectList.get(i), tool, regex);
                if (!encodedValue.equals(objectList.get(i))) {
                    objectList.set(i, encodedValue);
                    logEvent(encodedValue, loggingEnabled);
                }
            }
        }
    }

    private static String clean(String sample, Tool tool, String regex) {
        String result = "";
        switch (tool) {
            case SCRIPT_TAG_REMOVER:
                result = removeScriptTagsFromString(sample);
                break;
            case HTML_ENCODER:
                result = Encode.forHtml(sample);
                break;
            case URI_ENCODER:
                result = Encode.forUriComponent(sample);
                break;
            case WHITE_LIST_FILTER:
                result = applyWhitelist(sample, regex);
                break;
            case BLACK_LIST_FILTER:
                result = applyBlacklist(sample, regex);
                break;
            default:
        }
        return result;
    }

    private static String applyWhitelist(String sample, String regex) {
        if (sample == null) {
            return null;
        }
        sample = Normalizer.normalize(sample, Normalizer.Form.NFKC);
//        String[] matches = Pattern.compile(regex)
//                .matcher(sample)
//                .results()
//                .map(MatchResult::group)
//                .toArray(String[]::new);
//        sample = joinStringArray(matches);
// Java 8

        StringBuffer stringBuffer = new StringBuffer();
        for (int i = 0; i < sample.length(); i++) {
            char c = sample.charAt(i);
            if (Character.toString(c).matches(regex)) {
                stringBuffer.append(c);
            }
        }

        return stringBuffer.toString();
    }

    private static String applyBlacklist(String sample, String regex) {
        if (sample == null) {
            return null;
        }
        sample = Normalizer.normalize(sample, Normalizer.Form.NFKC);
        return sample.replaceAll(regex, "");
    }

    private static String joinStringArray(String[] arrayOfString) {
        return Arrays.asList(arrayOfString).stream().collect(Collectors.joining(""));
    }

    private static boolean isJavaLanguagePackage(String packageNamePrefix) {
        return packageNamePrefix.startsWith("java");
    }

    private static boolean isAppDefinedFieldType(Field field, String packageNamePrefix) {
        return field.getType().getTypeName().startsWith(packageNamePrefix);
    }

    private static boolean isAppDefinedObject(Object o, String packageNamePrefix) {
//        return o.getClass().getPackageName().startsWith(packageNamePrefix);
//        JAVA 8
        return o.getClass().getPackage().getName().startsWith(packageNamePrefix);
    }

    private static boolean isListOfStrings(Object o) {
        return o.getClass().getTypeName().endsWith("String");
    }

    private static String getPackageNamePrefix(String packageName) {
        if (packageName.startsWith("java")) {
            return packageName;
        }
        String[] namePieces = packageName.split("\\.");
        StringBuffer sb = new StringBuffer();
        for (int i = 0; i < 3; i++) {
            sb.append(namePieces[i] + ".");
        }
        sb.deleteCharAt(sb.length() - 1);
        return sb.toString();
    }

    private static void processStringField(Object clazz, Field field, boolean loggingEnabled, Tool tool, String regex) throws Exception {
        field.setAccessible(true);
        String value = (String) field.get(clazz);
        if (value == null || value.isEmpty()) {
            return;
        }
        String encodedValue = clean(value, tool, regex);
        if (!encodedValue.equals(value)) {
            field.set(clazz, encodedValue);
            logEvent(encodedValue, loggingEnabled);
        }
    }

    private static void processStringArrayField(Object clazz, Field field, boolean loggingEnabled, Tool tool, String regex) throws Exception {
        field.setAccessible(true);
        String[] values = (String[]) field.get(clazz);
        if (values == null) {
            return;
        }
        String[] sanitizedValues = new String[values.length];
        int idx = 0;
        for (String value : values) {
            sanitizedValues[idx++] = clean(value, tool, regex);
        }
        if (!Arrays.equals(values, sanitizedValues)) {
            field.set(clazz, sanitizedValues);
            logEvent(Arrays.toString(sanitizedValues), loggingEnabled);
        }
    }

    private static void logEvent(String value, boolean loggingEnabled) {
        if (loggingEnabled) {
            String principal = SecurityHelper.getJwtSubject();
            log.warn("Suspicious input received from " + principal + " :: " + value);
        }
    }
}
