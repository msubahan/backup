package com.ford.cloudnative.validators;

import com.ford.cloudnative.annotations.BlacklistRegexValidator;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import java.text.Normalizer;

public class CheckBlacklistRegex implements ConstraintValidator<BlacklistRegexValidator, Object> {
    private String regex;

    @Override
    public void initialize(BlacklistRegexValidator blacklistRegexValidator) {
        this.regex = blacklistRegexValidator.regex();
    }

    @Override
    public boolean isValid(Object object, ConstraintValidatorContext context) {
        return ValidatorHelper.isValid(new CheckString(), object);
    }

    private class CheckString implements CheckStringExecutor {
        public boolean execute(String value) {
            value = Normalizer.normalize(value, Normalizer.Form.NFKC);
            String removed = value.replaceAll(regex, "");
            return (removed.length() == value.length());
        }
    }
}
