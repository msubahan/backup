package com.ford.cloudnative.validators;

import java.util.List;

public class ValidatorHelper {

    private ValidatorHelper() {}

    public static boolean isValid(CheckStringExecutor checkStringExecutor, Object object) {
        if (object == null) {
            return true;
        }

        if (object instanceof String) {
            return checkStringExecutor.execute((String) object);
        }

        if (object instanceof List) {
            return isValidStringList(checkStringExecutor, object);
        }

        if (object instanceof String[]) {
            return isValidStringArray(checkStringExecutor, (String[]) object);
        }

        return true;
    }

    private static boolean isValidStringList(CheckStringExecutor checkStringExecutor, Object object) {
        if (((List<?>) object).isEmpty()) {
            return true;
        }

        if (!isStringList(object)) {
            return true;
        }

        @SuppressWarnings({"unchecked"})
        List<String> valueList = (List) object;
        for (String value : valueList) {
            if (value == null) {
                continue;
            }

            if (!checkStringExecutor.execute(value)) {
                return false;
            }
        }

        return true;
    }

    private static boolean isValidStringArray(CheckStringExecutor checkStringExecutor, String[] object) {
        String[] strings = object;
        for (String value : strings) {
            if (value == null) {
                continue;
            }

            if (!checkStringExecutor.execute(value)) {
                return false;
            }
        }

        return true;
    }

    private static boolean isStringList(Object object) {
        return (((List<?>) object).get(0) instanceof String);
    }
}
