package com.ford.cloudnative.helpers;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.security.oauth2.server.resource.authentication.JwtAuthenticationToken;
import org.springframework.stereotype.Component;

import java.util.Map;

@Component
public class SecurityHelper {
    public static Jwt getJwt() {
        Authentication principal = SecurityContextHolder.getContext().getAuthentication();
        if (principal instanceof JwtAuthenticationToken) {
            return ((JwtAuthenticationToken) principal).getToken();
        }
        return null;
    }

    public static String getJwtSubject() {
        Jwt jwt = getJwt();
        if (null == jwt) {
            return "unknown";
        }
        Map<String, Object> claims = jwt.getClaims();
        String subject = (null == claims.get("sub")) ? (String) claims.get("appid") : (String) claims.get("sub");
        return (subject);
    }
}
