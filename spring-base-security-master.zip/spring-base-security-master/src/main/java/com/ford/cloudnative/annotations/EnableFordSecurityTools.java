package com.ford.cloudnative.annotations;

import com.ford.cloudnative.services.SanitizerService;
import com.ford.cloudnative.configurations.AspectConfiguration;
import org.springframework.context.annotation.Import;

import java.lang.annotation.*;

@Target(ElementType.TYPE)
@Retention(RetentionPolicy.RUNTIME)
@Documented
@Import({AspectConfiguration.class, SanitizerService.class})
public @interface EnableFordSecurityTools {
}
