package com.ford.cloudnative.validators;

import com.ford.cloudnative.annotations.WhitelistRegexValidator;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import java.text.Normalizer;

public class CheckWhitelistRegex implements ConstraintValidator<WhitelistRegexValidator, Object> {
    private String regex;

    @Override
    public void initialize(WhitelistRegexValidator whitelistRegexValidator) {
        this.regex = whitelistRegexValidator.regex();
    }

    @Override
    public boolean isValid(Object object, ConstraintValidatorContext context) {
        return ValidatorHelper.isValid(new CheckString(), object);
    }

    private class CheckString implements CheckStringExecutor {
        public boolean execute(String value) {
            value = Normalizer.normalize(value, Normalizer.Form.NFKC);
            String unmatched = value.replaceAll(regex, "");
            return (unmatched.isEmpty());
        }
    }
}
