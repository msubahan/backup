package com.ford.cloudnative.annotations;

import com.ford.cloudnative.validators.CheckWhitelistCharacters;

import javax.validation.Constraint;
import javax.validation.Payload;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Constraint(validatedBy = {CheckWhitelistCharacters.class})
@Target({ElementType.FIELD, ElementType.PARAMETER})
@Retention(RetentionPolicy.RUNTIME)
public @interface WhitelistCharsValidator {
    String message() default "Whitelist validation constraint not met." +
            " Found: ${validatedValue}";

    public char[] chars();

    Class<?>[] groups() default {};

    Class<? extends Payload>[] payload() default {};
}
