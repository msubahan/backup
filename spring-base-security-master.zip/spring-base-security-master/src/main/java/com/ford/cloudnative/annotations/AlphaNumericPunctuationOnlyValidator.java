package com.ford.cloudnative.annotations;

import com.ford.cloudnative.validators.CheckForAlphaNumericPunctuationCharacters;

import javax.validation.Constraint;
import javax.validation.Payload;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Constraint(validatedBy = {CheckForAlphaNumericPunctuationCharacters.class})
@Target({ElementType.FIELD, ElementType.PARAMETER})
@Retention(RetentionPolicy.RUNTIME)
public @interface AlphaNumericPunctuationOnlyValidator {
    String message() default "Must contain only AlphaNumeric content and punctuation." +
            " Found: ${validatedValue}";

    Class<?>[] groups() default {};

    Class<? extends Payload>[] payload() default {};
}
