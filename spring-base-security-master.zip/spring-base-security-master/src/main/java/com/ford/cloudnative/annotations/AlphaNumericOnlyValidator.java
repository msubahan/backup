package com.ford.cloudnative.annotations;

import com.ford.cloudnative.validators.CheckForAphaNumericCharacters;

import javax.validation.Constraint;
import javax.validation.Payload;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Constraint(validatedBy = {CheckForAphaNumericCharacters.class})
@Target({ElementType.FIELD, ElementType.PARAMETER})
@Retention(RetentionPolicy.RUNTIME)
public @interface AlphaNumericOnlyValidator {
    String message() default "Must contain only AlphaNumeric content." +
            " Found: ${validatedValue}";

    Class<?>[] groups() default {};

    Class<? extends Payload>[] payload() default {};
}
