package com.ford.cloudnative.validators;

import com.ford.cloudnative.annotations.WhitelistCharsValidator;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import java.text.Normalizer;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class CheckWhitelistCharacters implements ConstraintValidator<WhitelistCharsValidator, Object> {
    private String regex;

    @Override
    public void initialize(WhitelistCharsValidator whitelistCharsValidator) {
        String allowed = new String(whitelistCharsValidator.chars());
        this.regex = "[^" + allowed + "\\s:]";
    }

    @Override
    public boolean isValid(Object object, ConstraintValidatorContext context) {
        return ValidatorHelper.isValid(new CheckString(), object);
    }

    private class CheckString implements CheckStringExecutor {
        public boolean execute(String value) {
            value = Normalizer.normalize(value, Normalizer.Form.NFKC);
            Pattern pattern = Pattern.compile(regex);
            Matcher matcher = pattern.matcher(value);
            return (!matcher.find());
        }
    }
}
