package com.ford.cloudnative.annotations;

import com.ford.cloudnative.validators.CheckBlacklistCharacters;

import javax.validation.Constraint;
import javax.validation.Payload;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Constraint(validatedBy = {CheckBlacklistCharacters.class})
@Target({ElementType.FIELD, ElementType.PARAMETER})
@Retention(RetentionPolicy.RUNTIME)
public @interface BlacklistCharsValidator {
    String message() default "Blacklist validation constraint not met." +
            " Found: ${validatedValue}";

    public char[] chars();

    Class<?>[] groups() default {};

    Class<? extends Payload>[] payload() default {};
}
