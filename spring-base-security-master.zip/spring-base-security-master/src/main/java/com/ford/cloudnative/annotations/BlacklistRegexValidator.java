package com.ford.cloudnative.annotations;

import com.ford.cloudnative.validators.CheckBlacklistRegex;

import javax.validation.Constraint;
import javax.validation.Payload;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Constraint(validatedBy = {CheckBlacklistRegex.class})
@Target({ElementType.FIELD, ElementType.PARAMETER})
@Retention(RetentionPolicy.RUNTIME)
public @interface BlacklistRegexValidator {
    String message() default "Blacklist validation constraint not met." +
            " Found: ${validatedValue}";

    public String regex() default "";

    Class<?>[] groups() default {};

    Class<? extends Payload>[] payload() default {};
}
