package com.ford.cloudnative.validators;

import com.ford.cloudnative.annotations.NoSuspiciousCharactersValidator;
import org.owasp.encoder.Encode;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

public class CheckForSuspiciousCharacters implements ConstraintValidator<NoSuspiciousCharactersValidator, Object> {

    @Override
    public boolean isValid(Object object, ConstraintValidatorContext context) {
        return ValidatorHelper.isValid(new CheckString(), object);
    }

    private class CheckString implements CheckStringExecutor {
        public boolean execute(String value) {
            return (Encode.forHtml(value).equals(value));
        }
    }
}
