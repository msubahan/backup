package com.ford.cloudnative;

import com.ford.cloudnative.configurations.AspectConfiguration;
import com.ford.cloudnative.services.SanitizerService;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;

import javax.validation.ConstraintViolation;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Set;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

@SpringBootTest
@EnableAspectJAutoProxy(proxyTargetClass = true)
@ContextConfiguration(classes = {UnitTestHelper.class, AspectConfiguration.class, SanitizerService.class})
@RunWith(SpringRunner.class)
public class BlacklistRegexValidatorTest {
    @Autowired
    UnitTestHelper helper;

    @Test
    public void emptyString() {
        TestValidationsClass validationsClass = TestValidationsClass.builder().blacklistedRegex("").build();
        Set<ConstraintViolation<TestValidationsClass>> violations = helper.runValidations(validationsClass);
        assertTrue(violations.isEmpty());
    }

    @Test
    public void validCharactersString() {
        TestValidationsClass validationsClass = TestValidationsClass.builder().blacklistedRegex(" abc 123 ").build();
        Set<ConstraintViolation<TestValidationsClass>> violations = helper.runValidations(validationsClass);
        assertTrue(violations.isEmpty());
    }

    @Test
    public void invalidCharactersString() {
        String[] testInput = {"<", ">", "{}'", "<script>", "\""};
        for (String input : testInput) {
            TestValidationsClass validationsClass = TestValidationsClass.builder().blacklistedRegex(input).build();
            Set<ConstraintViolation<TestValidationsClass>> violations = helper.runValidations(validationsClass);
            assertFalse(violations.isEmpty());
            ConstraintViolation constraintViolation = (ConstraintViolation) (violations.toArray())[0];
            assertThat(constraintViolation.getMessage()).startsWith("Blacklist validation constraint not met.");
            assertThat(constraintViolation.getMessage()).contains(input);
        }
    }

    @Test
    public void emptyStringArray() {
        TestValidationsClass validationsClass = TestValidationsClass.builder().arrayBlacklistedRegex(null).build();
        Set<ConstraintViolation<TestValidationsClass>> violations = helper.runValidations(validationsClass);
        assertTrue(violations.isEmpty());
    }

    @Test
    public void validCharactersArray() {
        String[] strArray = {" abc 123 "};
        TestValidationsClass validationsClass = TestValidationsClass.builder().arrayBlacklistedRegex(strArray).build();
        Set<ConstraintViolation<TestValidationsClass>> violations = helper.runValidations(validationsClass);
        assertTrue(violations.isEmpty());
    }

    @Test
    public void invalidCharactersArray() {
        String[] testInput = {">", "`", "=", "<script>"};
        TestValidationsClass validationsClass = TestValidationsClass.builder().arrayBlacklistedRegex(testInput).build();
        Set<ConstraintViolation<TestValidationsClass>> violations = helper.runValidations(validationsClass);
        assertFalse(violations.isEmpty());
        ConstraintViolation constraintViolation = (ConstraintViolation) (violations.toArray())[0];
        assertThat(constraintViolation.getMessage()).startsWith("Blacklist validation constraint not met.");
    }

    @Test
    public void emptyStringList() {
        TestValidationsClass validationsClass = TestValidationsClass.builder().listBlacklistedRegex(null).build();
        Set<ConstraintViolation<TestValidationsClass>> violations = helper.runValidations(validationsClass);
        assertTrue(violations.isEmpty());
    }

    @Test
    public void validCharactersList() {
        TestValidationsClass validationsClass = TestValidationsClass.builder().listBlacklistedRegex(Collections.singletonList(" abc 123 ")).build();
        Set<ConstraintViolation<TestValidationsClass>> violations = helper.runValidations(validationsClass);
        assertTrue(violations.isEmpty());
    }

    @Test
    public void invalidCharactersList() {
        List<String> testInput = new ArrayList<>();
        testInput.add(">");
        testInput.add("`");
        testInput.add("=");
        testInput.add("<script>");
        TestValidationsClass validationsClass = TestValidationsClass.builder().listBlacklistedRegex(testInput).build();
        Set<ConstraintViolation<TestValidationsClass>> violations = helper.runValidations(validationsClass);
        assertFalse(violations.isEmpty());
        ConstraintViolation constraintViolation = (ConstraintViolation) (violations.toArray())[0];
        assertThat(constraintViolation.getMessage()).startsWith("Blacklist validation constraint not met.");
    }
}
