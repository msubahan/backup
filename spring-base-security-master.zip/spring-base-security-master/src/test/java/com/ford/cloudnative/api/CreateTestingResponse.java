package com.ford.cloudnative.api;

import com.ford.cloudnative.base.api.BaseBodyResponse;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

public class CreateTestingResponse extends BaseBodyResponse<CreateTestingResponse.CreateTestResponseResult> {

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class CreateTestResponseResult {
        String test;
    }

}
