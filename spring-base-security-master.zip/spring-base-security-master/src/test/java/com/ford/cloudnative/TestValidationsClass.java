package com.ford.cloudnative;

import com.ford.cloudnative.annotations.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class TestValidationsClass {
    @AlphaNumericOnlyValidator
    String alphaNumeric;

    @AlphaNumericOnlyValidator
    String[] arrayAlphaNumeric;

    @AlphaNumericOnlyValidator
    List<String> listAlphaNumeric;

    @AlphaNumericPunctuationOnlyValidator
    String alphaNumericPunctuation;

    @AlphaNumericPunctuationOnlyValidator
    String[] arrayAlphaNumericPunctuation;

    @AlphaNumericPunctuationOnlyValidator
    List<String> listAlphaNumericPunctuation;

    @NoSuspiciousCharactersValidator
    String noSuspicious;

    @NoSuspiciousCharactersValidator
    String[] arrayNoSuspicious;

    @NoSuspiciousCharactersValidator
    List<String> listNoSuspicious;

    @WhitelistCharsValidator(chars = {'a', 'b', 'c'})
    String whitelistedChars;

    @WhitelistCharsValidator(chars = {'a', 'b', 'c'})
    String[] arrayWhitelistedChars;

    @WhitelistCharsValidator(chars = {'a', 'b', 'c'})
    List<String> listWhitelistedChars;

    @WhitelistRegexValidator(regex = "[A-Za-z\\d\\s]") // AlphaNumeric and whitespace
    String whitelistedRegex;

    @WhitelistRegexValidator(regex = "[A-Za-z\\d\\s]") // AlphaNumeric and whitespace
    String[] arrayWhitelistedRegex;

    @WhitelistRegexValidator(regex = "[A-Za-z\\d\\s]") // AlphaNumeric and whitespace
    List<String> listWhitelistedRegex;

    @BlacklistCharsValidator(chars = {'d', 'e', 'f'})
    String blacklistedChars;

    @BlacklistCharsValidator(chars = {'d', 'e', 'f'})
    String[] arrayBlacklistedChars;

    @BlacklistCharsValidator(chars = {'d', 'e', 'f'})
    List<String> listBlacklistedChars;

    @BlacklistRegexValidator(regex = "[<>{}'\"]")
    String blacklistedRegex;

    @BlacklistRegexValidator(regex = "[<>{}'\"]")
    String[] arrayBlacklistedRegex;

    @BlacklistRegexValidator(regex = "[<>{}'\"]")
    List<String> listBlacklistedRegex;
}
