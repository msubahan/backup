package com.ford.cloudnative;

import com.ford.cloudnative.annotations.NoSuspiciousCharactersValidator;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;

import java.util.List;

@Data
@Builder
public class TestClass {
    String singleString;
    String[] stringArray;
    List<String> stringList;
    int singleInt;
    InnerTestClass innerTestClass;
    List<InnerTestClass> innerTestClassList;

    @Data
    @AllArgsConstructor
    public static class InnerTestClass {
        @NoSuspiciousCharactersValidator
        String singleString;
    }
}
