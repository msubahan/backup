package com.ford.cloudnative;

import com.ford.cloudnative.services.SanitizerService;
import org.junit.Test;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertEquals;

public class SanitizerStaticMethodTest {
    @Test
    public void blacklistString_success() {
        String regex = "[</>]";
        String result = SanitizerService.blacklistString(UnitTestHelper.getMaliciousString(), regex);
        assertThat(result).doesNotContain("<").doesNotContain(">").doesNotContain("/");
    }

    @Test
    public void whitelistString_success() {
        String alphaNumeric = SanitizerService.whitelistString(UnitTestHelper.getMaliciousString(), "[a-zA-Z]");
        assertThat(alphaNumeric.replaceAll("[a-zA-Z]", "")).isEmpty();
    }

    @Test
    public void uriEncodeString_success() {
        String encoded = SanitizerService.uriEncodeString(UnitTestHelper.getMaliciousString());
        assertEquals(UnitTestHelper.getUriEncodedSanitizedString(), encoded);
    }

    @Test
    public void htmlEncodeString_success() {
        String encoded = SanitizerService.htmlEncodeString(UnitTestHelper.getMaliciousString());
        assertEquals(UnitTestHelper.getHtmlEncodedSanitizedString(), encoded);
    }

}
