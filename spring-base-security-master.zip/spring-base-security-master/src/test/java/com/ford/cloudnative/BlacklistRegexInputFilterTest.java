package com.ford.cloudnative;

import com.ford.cloudnative.configurations.AspectConfiguration;
import com.ford.cloudnative.services.SanitizerService;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;

@SpringBootTest
@EnableAspectJAutoProxy(proxyTargetClass = true)
@ContextConfiguration(classes = {UnitTestHelper.class, AspectConfiguration.class, SanitizerService.class})
@RunWith(SpringRunner.class)
public class BlacklistRegexInputFilterTest {
    private final ByteArrayOutputStream outContent = new ByteArrayOutputStream();
    private final PrintStream originalOut = System.out;
    String blacklistResult = "scriptalerttestscriptor 11";

    @Before
    public void setup() {
        System.setOut(new PrintStream(outContent));
    }

    @After
    public void restoreStreams() {
        System.setOut(originalOut);
    }

    @Autowired
    UnitTestHelper testHelper;

    @Test
    public void blacklistRegexInputWithLogging() {
        TestClass testClass = UnitTestHelper.getPopulatedTestClass();
        testHelper.blacklistRegexInput(testClass);
        assertEquals(blacklistResult, testClass.getSingleString());
        assertEquals(1, testClass.singleInt);
        assertEquals(blacklistResult, testClass.getStringArray()[0]);
        assertEquals(blacklistResult, testClass.getStringList().get(0));
        assertEquals(blacklistResult, testClass.getInnerTestClass().getSingleString());
        assertNotEquals(UnitTestHelper.getMaliciousString(), testClass.getInnerTestClassList().get(0).getSingleString());
        assertThat(outContent.toString()).contains("Suspicious input received");
    }

    @Test
    public void blacklistRegexInputNoLogging() {
        TestClass testClass = UnitTestHelper.getPopulatedTestClass();
        testHelper.blacklistRegexInputNoLogging(testClass);
        assertEquals(blacklistResult, testClass.getSingleString());
        assertThat(outContent.toString()).isEmpty();
    }
}
