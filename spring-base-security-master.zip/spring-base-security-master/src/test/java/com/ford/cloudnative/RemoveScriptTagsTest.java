package com.ford.cloudnative;

import com.ford.cloudnative.configurations.AspectConfiguration;
import com.ford.cloudnative.services.SanitizerService;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.util.Arrays;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;

@SpringBootTest
@EnableAspectJAutoProxy(proxyTargetClass = true)
@ContextConfiguration(classes = {UnitTestHelper.class, AspectConfiguration.class, SanitizerService.class})
@RunWith(SpringRunner.class)
public class RemoveScriptTagsTest {
    private final ByteArrayOutputStream outContent = new ByteArrayOutputStream();
    private final PrintStream originalOut = System.out;

    @Before
    public void setup() {
        System.setOut(new PrintStream(outContent));
    }

    @After
    public void restoreStreams() {
        System.setOut(originalOut);
    }

    @Autowired
    UnitTestHelper unitTestHelper;

    @Test
    public void removeScriptTagsFromOutputWithLogging() {
        TestClass testClass = UnitTestHelper.getPopulatedTestClass();
        unitTestHelper.removeOutputScriptTags(testClass);

        assertThat(testClass.getStringList()).doesNotContain("script");
        assertThat(Arrays.toString(testClass.getStringArray())).doesNotContain("script");
        assertThat(Arrays.toString(testClass.getStringList().toArray())).doesNotContain("script");
        assertThat(testClass.getInnerTestClass().getSingleString()).doesNotContain("script");
        List<TestClass.InnerTestClass> testClasses = testClass.innerTestClassList;
        assertThat(Arrays.toString(testClasses.toArray())).doesNotContain("script");
        assertThat(outContent.toString()).contains("Suspicious input received");
    }

    @Test
    public void removeScriptTagsFromOutputNoLogging() {
        TestClass testClass = UnitTestHelper.getPopulatedTestClass();
        unitTestHelper.removeOutputScriptTagsNoLogging(testClass);
        assertThat(testClass.getStringList().contains("script")).isFalse();
        assertThat(outContent.toString()).isEmpty();
    }

    @Test
    public void removeScriptTagsFromOutputEmptyClassNoException() {
        TestClass testClass = TestClass.builder().build();
        assertDoesNotThrow(() -> unitTestHelper.removeOutputScriptTags(testClass));
    }

    @Test
    public void removeScriptTagsFromInputWithLogging() {
        TestClass testClass = UnitTestHelper.getPopulatedTestClass();
        unitTestHelper.removeInputScriptTags(testClass);

        assertThat(testClass.getStringList().contains("script")).isFalse();
        assertThat(Arrays.toString(testClass.getStringArray())).doesNotContain("script");
        assertThat(Arrays.toString(testClass.getStringList().toArray())).doesNotContain("script");
        assertThat(testClass.getInnerTestClass().getSingleString()).doesNotContain("script");
        List<TestClass.InnerTestClass> testClasses = testClass.innerTestClassList;
        assertThat(Arrays.toString(testClasses.toArray())).doesNotContain("script");
        assertThat(outContent.toString()).contains("Suspicious input received");
    }

    @Test
    public void removeScriptTagsFromInputNoLogging() {
        TestClass testClass = UnitTestHelper.getPopulatedTestClass();
        unitTestHelper.removeInputScriptTagsNoLogging(testClass);
        assertThat(testClass.getStringList().contains("script")).isFalse();
        assertThat(outContent.toString()).isEmpty();
    }

    @Test
    public void removeScriptTagsFromInputEmptyClassNoException() {
        TestClass testClass = TestClass.builder().build();
        assertDoesNotThrow(() -> unitTestHelper.removeInputScriptTags(testClass));
    }

    @Test
    public void removeScriptCaseInsensitive() {
        String test = SanitizerService.removeScriptTagsFromString("< sCrIpT  > < sC\nrIpT  >");
        test = test.replaceAll("\\s", "");
//        assertThat(test.isBlank()).isTrue();
//        Java 8
        assertThat(test).isEmpty();
    }

    @Test
    public void breakJavascriptDirective() {
        String test = SanitizerService.removeScriptTagsFromString("javascript:alert(123);");
        assertThat(test).doesNotContain("javascript");
    }

    @Test
    public void removeScriptTagsFromString() {
        String result = SanitizerService.removeScriptTagsFromString(UnitTestHelper.getMaliciousString());
        assertThat(UnitTestHelper.getMaliciousString()).contains("script");
        assertThat(result).doesNotContain("script");
    }
}
