package com.ford.cloudnative;

import com.ford.cloudnative.configurations.AspectConfiguration;
import com.ford.cloudnative.services.SanitizerService;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;

@SpringBootTest
@EnableAspectJAutoProxy(proxyTargetClass = true)
@ContextConfiguration(classes = {UnitTestHelper.class, AspectConfiguration.class, SanitizerService.class})
@RunWith(SpringRunner.class)
public class UriEncodeInputDataTest {
    @Autowired
    UnitTestHelper testHelper;

    @Test
    public void testEncoderNullObjectWithoutException() {
        TestClass testClass = TestClass.builder().build();
        assertDoesNotThrow(() -> testHelper.uriEncodeInput(testClass));
    }

    @Test
    public void testMaliciousEncoderSuccess() {
        TestClass testClass = UnitTestHelper.getPopulatedTestClass();
        testHelper.uriEncodeInput(testClass);
        assertEquals(UnitTestHelper.getUriEncodedSanitizedString(), testClass.getSingleString());
        assertEquals(1, testClass.singleInt);
        assertEquals(UnitTestHelper.getUriEncodedSanitizedString(), testClass.getStringArray()[0]);
        assertEquals(UnitTestHelper.getUriEncodedSanitizedString(), testClass.getStringList().get(0));
        assertEquals(UnitTestHelper.getUriEncodedSanitizedString(), testClass.getInnerTestClass().getSingleString());
        assertNotEquals(UnitTestHelper.getMaliciousString(), testClass.getInnerTestClassList().get(0).getSingleString());
    }
}
