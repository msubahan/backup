package com.ford.cloudnative;

import com.ford.cloudnative.api.CreateTestingResponse;
import com.ford.cloudnative.configurations.AspectConfiguration;
import com.ford.cloudnative.services.SanitizerService;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;

@SpringBootTest
@EnableAspectJAutoProxy(proxyTargetClass = true)
@ContextConfiguration(classes = {UnitTestHelper.class, AspectConfiguration.class, SanitizerService.class})
@RunWith(SpringRunner.class)
public class HtmlEncodeOutputDataTest {
    private final ByteArrayOutputStream outContent = new ByteArrayOutputStream();
    private final PrintStream originalOut = System.out;

    @Before
    public void setup() {
        System.setOut(new PrintStream(outContent));
    }

    @After
    public void restoreStreams() {
        System.setOut(originalOut);
    }

    @Autowired
    UnitTestHelper testHelper;

    public void encodeNullObjectWithoutException() {
        TestClass testClass = TestClass.builder().build();
        assertDoesNotThrow(() -> testHelper.htmlEncodeOutput(testClass));
    }

    @Test
    public void maliciousEncoderWithLogging() {
        TestClass testClass = UnitTestHelper.getPopulatedTestClass();
        testHelper.htmlEncodeOutput(testClass);
        assertEquals(UnitTestHelper.getHtmlEncodedSanitizedString(), testClass.getSingleString());
        assertEquals(1, testClass.singleInt);
        assertEquals(UnitTestHelper.getHtmlEncodedSanitizedString(), testClass.getStringArray()[0]);
        assertEquals(UnitTestHelper.getHtmlEncodedSanitizedString(), testClass.getStringList().get(0));
        assertEquals(UnitTestHelper.getHtmlEncodedSanitizedString(), testClass.getInnerTestClass().getSingleString());
        assertNotEquals(UnitTestHelper.getMaliciousString(), testClass.getInnerTestClassList().get(0).getSingleString());
        assertThat(outContent.toString()).contains("Suspicious input received");
    }

    @Test
    public void maliciousEncoderNoLogging() {
        TestClass testClass = UnitTestHelper.getPopulatedTestClass();
        testHelper.htmlEncodeOutputNoLogging(testClass);
        assertEquals(UnitTestHelper.getHtmlEncodedSanitizedString(), testClass.getSingleString());
        assertThat(outContent.toString()).isEmpty();
    }

    @Test
    public void maliciousEncoderResponseEntity_success() {
        ResponseEntity responseEntity = testHelper.htmlEncodeOutputBaseBody(UnitTestHelper.getMaliciousString());
        CreateTestingResponse createTestingResponse = (CreateTestingResponse) responseEntity.getBody();
        CreateTestingResponse.CreateTestResponseResult responseResult = createTestingResponse.getResult();
        assertEquals(UnitTestHelper.getHtmlEncodedSanitizedString(), responseResult.getTest());
    }
}
