package com.ford.cloudnative;

import com.ford.cloudnative.annotations.*;
import com.ford.cloudnative.api.CreateTestingResponse;
import com.ford.cloudnative.api.CreateTestingResponse.CreateTestResponseResult;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import javax.validation.ConstraintViolation;
import javax.validation.Validation;
import javax.validation.Validator;
import javax.validation.ValidatorFactory;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

@Component
public class UnitTestHelper {

    @HtmlEncodeInputOutputData(loggingEnabled = true)
    TestClass htmlEncodeInputOutput(TestClass testClass) {
        return testClass;
    }

    @HtmlEncodeInputOutputData(loggingEnabled = false)
    TestClass htmlEncodeInputOutputNoLogging(TestClass testClass) {
        return testClass;
    }

    @RemoveScriptsTagsOutputData(loggingEnabled = true)
    TestClass removeOutputScriptTags(TestClass testClass) {
        return testClass;
    }

    @RemoveScriptsTagsOutputData(loggingEnabled = false)
    TestClass removeOutputScriptTagsNoLogging(TestClass testClass) {
        return testClass;
    }

    @RemoveScriptsTagsInputData(loggingEnabled = true)
    TestClass removeInputScriptTags(TestClass testClass) {
        return testClass;
    }

    @RemoveScriptsTagsInputData(loggingEnabled = false)
    TestClass removeInputScriptTagsNoLogging(TestClass testClass) {
        return testClass;
    }

    @HtmlEncodeInputData(loggingEnabled = true)
    TestClass htmlEncodeInput(TestClass testClass) {
        return testClass;
    }

    @HtmlEncodeInputData(loggingEnabled = false)
    TestClass htmlEncodeInputNoLogging(TestClass testClass) {
        return testClass;
    }

    @HtmlEncodeOutputData(loggingEnabled = true)
    TestClass htmlEncodeOutput(TestClass testClass) {
        return testClass;
    }

    @HtmlEncodeOutputData(loggingEnabled = false)
    TestClass htmlEncodeOutputNoLogging(TestClass testClass) {
        return testClass;
    }

    @HtmlEncodeOutputData(loggingEnabled = false)
    ResponseEntity<CreateTestingResponse> htmlEncodeOutputBaseBody(String data) {
        CreateTestResponseResult testingResponse = CreateTestResponseResult.builder()
                .test(data).build();
        CreateTestingResponse response = CreateTestingResponse.result(testingResponse, CreateTestingResponse.class);
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @UriEncodeInputData(loggingEnabled = true)
    TestClass uriEncodeInput(TestClass testClass) {
        return testClass;
    }

    @UriEncodeInputData(loggingEnabled = false)
    TestClass uriEncodeInputNoLogging(TestClass testClass) {
        return testClass;
    }

    @WhitelistRegexInputData(loggingEnabled = true, regex = "[A-Za-z\\d\\s]") // AlphaNumeric and whitespace
    TestClass whitelistRegexInput(TestClass testClass) {
        return testClass;
    }

    @WhitelistRegexInputData(loggingEnabled = false, regex = "[A-Za-z\\d\\s]") // AlphaNumeric and whitespace
    TestClass whitelistRegexInputNoLogging(TestClass testClass) {
        return testClass;
    }

    @BlacklistRegexInputData(loggingEnabled = true, regex = "[^A-Za-z\\d\\s]") // Non AlphaNumeric and whitespace
    TestClass blacklistRegexInput(TestClass testClass) {
        return testClass;
    }

    @BlacklistRegexInputData(loggingEnabled = false, regex = "[^A-Za-z\\d\\s]") // Non AlphaNumeric and whitespace
    TestClass blacklistRegexInputNoLogging(TestClass testClass) {
        return testClass;
    }

    Set<ConstraintViolation<TestValidationsClass>> runValidations(TestValidationsClass testClass) {
        ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
        Validator validator = factory.getValidator();
        Set<ConstraintViolation<TestValidationsClass>> violations = validator.validate(testClass);
        return violations;
    }

    static String alphaNumeric = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
    static String alphaNumericpunctuation = "abcdefghijklmnopqrstuvwxyzABCDEFGH?I?JKLMNOPQRSTUVWXYZ0123456789.,-?!:;'\"";

    static String getHtmlEncodedSanitizedString() {
        return "&lt;script&gt;alert(&#39;test&#39;)&lt;/script&gt;&#39;or 1=1--";
    }

    static String getUriEncodedSanitizedString() {
        return "%3Cscript%3Ealert%28%27test%27%29%3C%2Fscript%3E%27or%201%3D1--";
    }

    static String getMaliciousString() {
        return "<script>alert('test')</script>'or 1=1--";
    }

    static String[] getMaliciousStringArray() {
        return new String[]{getMaliciousString(), getMaliciousString()};
    }

    static List<String> getMaliciousStringList() {
        ArrayList<String> stringList = new ArrayList<String>();
        stringList.add(getMaliciousString());
        stringList.add(getMaliciousString());
        return stringList;
    }

    static TestClass getPopulatedTestClass() {
        return TestClass.builder()
                .singleString(getMaliciousString())
                .singleInt(1)
                .stringArray(getMaliciousStringArray())
                .stringList(getMaliciousStringList())
                .innerTestClass(new TestClass.InnerTestClass(getMaliciousString()))
                .innerTestClassList(getMaliciousInnerClassList())
                .build();
    }

    static List<TestClass.InnerTestClass> getMaliciousInnerClassList() {
        List<TestClass.InnerTestClass> innerTestClassList = new ArrayList<>();
        TestClass.InnerTestClass innerTestClass = new TestClass.InnerTestClass(getMaliciousString());
        innerTestClassList.add(innerTestClass);
        innerTestClassList.add(innerTestClass);
        return innerTestClassList;
    }
}
