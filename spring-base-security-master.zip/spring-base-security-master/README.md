# Ford Cloud Native Application Security Tools

## Overview

This library provides convenient easy to implement application security related tool.
The list will grow over time and the community is encouraged to add additional functionality.
It uses AOP, Reflection, the OWASP Encoder lib, and other methods to provide a collection of annotations and methods used to sanitize and validate user input.
Filtering input annotations send all method arguments to the sanitizer service.  That service ignores objects whose package begins with "java", it is focused on app-defined packages.
If your method takes a string object, either map it to an app defined object or use one of the static string functions instead.

Input filter tools search/replace strings found in input objects AFTER they are mapped from user input.  
If combining these input tools with validators, know that the validators will run first if @Valid is applied and the class is decorated with ```@Validated```.

```java
@PostMapping
public ResponseEntity<CreateGreetingResponse> create(@Valid @RequestBody CreateGreetingRequest greetingRequest) {  
```

The AOP joinpoint is after the input is mapped to classes.  If combining input/output filtering tools with validators, do not use @Valid on the controller arguments.  Run those validations after the input tools run as insurance or add the validations to other objects/entities if the data is reorganized to new objects.
The output tool joinpoint is executed after all method logic completes and it passes the return value to the sanitizer service.

```java
@PostMapping
@WhitelistRegexInputData(loggingenabled = true, regex = "[A-Za-z\\d\\s]")
public ResponseEntity<CreateGreetingResponse> create(@RequestBody CreateGreetingRequest greetingRequest) {
  runFieldValidations(greetingRequest);
  ...
}
```
 
You can manually run the validators by using the technique displayed below:
```java
        ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
        Validator validator = factory.getValidator();
        validator.validate(testClass);
```

### Field-level validation annotations:
Field-level validators can handle String, String[], or List\<String\>, fields.  They are not applicable to other types.

- @AlphaNumericOnlyValidator: Fails if non-alphanumeric characters found
- @AlphaNumericPunctuationOnlyValidator: Fails if non-alphanumeric or punctuation characters found
- @BlacklistCharsValidator: Fails if characters found matching supplied blacklist characters parameter
- @BlacklistRegexValidator: Fails if characters found matching supplied regular expression parameter
- @NoSuspiciousCharactersValidator: Fails if the OWASP HTML Encoder finds HTML characters
- @WhitelistCharsValidator: Fails if characters found outside the supplied whitelist characters parameter
- @WhitelistRegexValidator: Fails if characters found outside the supplied whitelist regular expression parameter

Field-level validation annotations augment the existing javax.validation.contraints validators such as:
- @Notnull
- @Min
- @Max

Some provide the ability for tuning using character list parameters and regular expressions.

Example:
```java
public class TestValidationsClass {
    @AlphaNumericOnlyValidator
    String alphaNumeric;

    @AlphaNumericPunctuationOnlyValidator
    String alphaNumericPunctuation;

    @NoSuspiciousCharactersValidator
    String noSuspicious;

    @WhitelistCharsValidator(chars = {'a', 'b', 'c'})
    String whitelistedChars;

    @WhitelistRegexValidator(regex = "[A-Za-z\\d\\s]") // AlphaNumeric and whitespace
    String whitelistedRegex;

    @BlacklistCharsValidator(chars = {'d', 'e', 'f'})
    String blacklistedChars;

    @BlacklistRegexValidator(regex = "[<>{}'\"]")
    String blacklistedRegex;
}
```

Custom messages can also be returned if desired
```
@BlacklistCharsValidator(message = "Character d,e,f found in input", chars = {'d', 'e', 'f'})
```

### Method-level encoder annotations:
- @UriEncodeInputData - URI encode strings in input objects 
- @HtmlEncodeInputData - HTML encode strings in input objects
- @HtmlEncodeInputOutputData - HTML encode strings in both input and output (Will double encode HTML)
- @HtmlEncodeOutputData - HTML encode strings in output objects
- @RemoveScriptTagsInputData - Remove script tags in input objects
- @RemoveScriptTagsOutputData - Remove script tags in output objects
- @WhitelistRegexInputData - Filter input to match accepted characters supplied in regex
- @BlacklistRegexInputData - Filter input to omit characters supplied in regex

Method-level encoders use AOP and Reflection to parse through the method arguments and method return data looking for String data to encoded or otherwise sanitize.
Output filtering may not function for all return types so test your use case carefully.
The annotation names indicate what data is being addressed and what action/encoder is attempted.
Each annotation has a loggingenabled parameter, when enabled log data is generated including the user id or app id logged in when invalid data was detected.

Examples:
```java
    @HtmlEncodeInputOutputData(loggingenabled = true)
    TestClass htmlEncodeInputOutput(TestClass testClass) {
        return testClass;
    }

    @RemoveScriptsTagsOutputData(loggingenabled = true)
    TestClass removeOutputScriptTags(TestClass testClass) {
        return testClass;
    }

    @RemoveScriptsTagsInputData(loggingenabled = true)
    TestClass removeInputScriptTags(TestClass testClass) {
        return testClass;
    }

    @HtmlEncodeInputData(loggingenabled = true)
    TestClass htmlEncodeInput(TestClass testClass) {
        return testClass;
    }

    @HtmlEncodeOutputData(loggingenabled = true)
    TestClass htmlEncodeOutput(TestClass testClass) {
        return testClass;
    }

    @UriEncodeInputData(loggingenabled = true)
    TestClass uriEncodeInput(TestClass testClass) {
        return testClass;
    }

    @WhitelistRegexInputData(loggingenabled = true, regex = "[A-Za-z\\d\\s]") // AlphaNumeric and whitespace
    TestClass whitelistRegexInput(TestClass testClass) {
        return testClass;
    }

    @BlacklistRegexInputData(loggingenabled = true, regex = "[^A-Za-z\\d\\s]") // Non AlphaNumeric and whitespace
    TestClass blacklistRegexInput(TestClass testClass) {
        return testClass;
    }
```

### String functions
Some functionality is available as string functions from class SanitizerService:
- public static String removeScriptTagsFromString(String message)
- public static String htmlEncodeString(String data)
- public static String uriEncodeString(String data)
- public static String whitelistString(String data, String regex)
- public static String blacklistString(String data, String regex) 


### Implementation

#### Include Dependency
build.gradle:
```groovy
implementation 'com.ford.cloudnative:spring-base-security:1.0.5-RELEASE'
```

#### Enable Library
Include annotation @EnableFordSecurityTools in main class to enable validators:
```groovy
@SpringBootApplication
@EnableFordSecurityTools
public class TestApplication {
...
}
```
