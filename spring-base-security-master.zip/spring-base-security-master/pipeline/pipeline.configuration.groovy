/*##########################################################################################
### DEV ENABLEMENT - JENKINS PIPELINE OFFERING - Version 3.0.0
### NOTE:   PIPELINE CONFIGURATION FILE CONTAINS GENERIC AND ENVIRONMENT SPECIFIC
###         CONFIGURATION FOR JENKINS PIPELINE
##########################################################################################*/

CONFIGURATION = [
  
    integrations: [
      
        // third-party integrations
        thirdParty: [
            nexus: [
                enabled: true,
                credentialsId: 'nexus-private',   // Jenkins credentials ID
                repoUrl: '', // Set at DEV, PROD environment level using BOOST_PUBLISH_TEAM_REPO_URL env variable
            ],

            sonarQube: [
                enabled: true,
                credentialsId: 'sonar-private',   // Jenkins credentials ID
                projectKey: 'com.ford.cloudnative:Spring-Base-Security',
		        enableBreakBuildOnIssue: false,
            ],

            checkmarx: [
                enabled: true,
                credentialsId: 'checkmarx-private',   // Jenkins credentials ID
                serverUrl: 'https://www.checkmarx.ford.com',
                projectName: 'spring-base-security',
                teamPath: '\\CxServer\\Ford Enterprise\\Information Technology\\CAB',
                enableOSA: false,
            ],

            fossa: [
                enabled: true,
                credentialsId: 'fossa-private',   // Jenkins credentials ID
                projectName: 'spring-base-security',    // Consider using same value as rootProject.name from settings.gradle
                teamName: 'DevEnablement',          // The name of the Team as it appears in FOSSA
                policyName: 'Website/Hosted Service Use',      // Most Spring Boot apps can use 'Website/Hosted Service' as policy. Leaving it blank will use FOSSA's most restrictive policy.
                enableBreakBuildOnIssue: false,
            ],
         
        ],
    ],
  
    // cli environment variables (optional)
    env: [
        //if your Jenkins supports multiple JDK's (8 & 11) you may need to set JAVA_HOME
        //below is example where Jenkins defaults to 8, but we need 11 for this project;
        //you can set JDK 11 path in JAVA_HOME_ADOPTJDK11 env variable or replace the entire value with the direct path from Jenkins
        JAVA_HOME: "${JAVA_HOME_ADOPTJDK8}",
    ],

    // deploy environments (e.g. DEV, QA) and their space(s)
    cfEnvironments: [
        DEV: [
            spaces: [
                /*EDC1: [
                    apiEndpoint: 'https://api.sys.pp01.edc1.cf.ford.com',
                    org: 'TEAM-ORG',
                    space: 'TEAM-DEV',
                    credentialsId: 'pcf-pre-prod', // Jenkins credentials ID
                    env: [ // cli environment values for this space only
                        cfDomains: 'apps.pp01i.edc1.cf.ford.com',  // comma delimited list of CF route domains
                        cfManifestTarget: 'dev-edc1',     // key tied to the set of values to use in manifest yml file (see manifest-template-settings.json)
                    ]
                ],
                EDC2: [
                    apiEndpoint: 'https://api.sys.pp01.edc2.cf.ford.com',
                    org: 'TEAM-ORG',
                    space: 'TEAM-DEV',
                    credentialsId: 'pcf-pre-prod',
                    env: [
                        cfDomains: 'apps.pp01i.edc2.cf.ford.com', // comma delimited list of CF route domains
                        cfManifestTarget: 'dev-edc2',
                    ]
                ]*/
            ],
            env: [ // cli environment values for all DEV spaces
                // sample oauth2 configuration used by acceptance tests
                ACCEPTANCE_DEFAULT_OAUTH2_CLIENT_ACCESS_TOKEN_URI: 'https://corpqa.sts.ford.com/adfs/oauth2/token',
                ACCEPTANCE_DEFAULT_OAUTH2_APP_CLIENT_ID: 'urn:mywebsite',
                ACCEPTANCE_DEFAULT_OAUTH2_RESOURCE: 'urn:myservice',
                BOOST_PUBLISH_TEAM_REPO_URL: 'https://www.nexus.ford.com/repository/PCFDevEnablement_public_snapshot_repository',
            ],

            // credentials configuration for acceptance tests
            acceptanceTesting: [
                genericId: [
                    credentialsId: ''  // Jenkins credentials ID for Resource Owner Password Credentials
                ],
                clientCredentials: [
                    credentialsId: ''  // Jenkins credentials ID for Client Credentials
                ],
                basicAuthentication: [
                    credentialsId: ''  // Jenkins credentials ID for Basic Authentication
                ]
            ],

            // CF Environment specific integrations
            integrations: [

                // third-party integrations
                thirdParty: [
                    gitHub: [
                        branchName: 'master'
                    ],
                    nexus: [
                        // Applicable only for higher environments using same github branch.
                        // Set downloadMyPreviouslyBuiltArtifact to true to skip the build and download the previously built latest version of artifact from Nexus (if enabled).
                        // Use BOOST_OVERRIDE_DOWNLOAD_ARTIFACT_VERSION environment variable to override the artifact version to be downloaded from nexus.
                        downloadMyPreviouslyBuiltArtifact: false
                    ],
                ],

                // cloud services integrations
                cloud: [
                    config_server: [
                        enabled: false,
                        configured: false,
                        credentialsId: 'github-sshkey-private', // Jenkins credentials ID
                        repoSSHUrl: '[TEAM-CONFIG-REPO-SSH-URL]',
                    ],
                    credhub_secretzero: [
                        enabled: false,
                        credentialsId: 'jasypt-private', // Jenkins credentials ID
                    ],
                    smb_volume: [
                        enabled: false,
                        credentialsId: 'smbvolume-private', // Jenkins credentials ID
                        hostName: '',  // Ex: //dc18101nn01.prod.f01.dc1.ford.com
                        shareName: '', // Ex: q00568
                        mountPath: '', // Ex: /var/proj/Jab7/nas
                    ]
                ],
            ],

            // Vanity Url Mapping
            vanityUrl: [
                enabled: false,
                domain: '', // ex: cabfordair.ford.com
                hostName: '', // ex: wwwdev, wwwqa, www or empty if not applicable
                path: '', // optional
                appSpecificGSLB: false, // if true, provide value for 'appSpecificGSLBAppName' to map a route with 'cf.app.ford.com' domain
                appSpecificGSLBAppName: '' // app name in CNAME, ex: wwwdev-cabfordair
            ],

            // Container to Container Networking Policies
            c2cNetworkPolicies: [
                enabled: false,
                outbound: '',  // comma delimited list of valid app names with outbound policies
                inbound: '',   // comma delimited list of valid app names with inbound policies
                createAppsInternalRoute: false, // true if resolving through BOSH DNS; false if using service discovery
                deleteExternalRoutesForThisApp: false  // set to true if this app is accessible only via C2C
            ],
        ],

        PROD: [
            spaces: [
                /*EDC1: [
                    apiEndpoint: 'https://api.sys.pp01.edc1.cf.ford.com',
                    org: 'TEAM-ORG',
                    space: 'TEAM-DEV',
                    credentialsId: 'pcf-pre-prod', // Jenkins credentials ID
                    env: [ // cli environment values for this space only
                        cfDomains: 'apps.pp01i.edc1.cf.ford.com',  // comma delimited list of CF route domains
                        cfManifestTarget: 'dev-edc1',     // key tied to the set of values to use in manifest yml file (see manifest-template-settings.json)
                    ]
                ],
                EDC2: [
                    apiEndpoint: 'https://api.sys.pp01.edc2.cf.ford.com',
                    org: 'TEAM-ORG',
                    space: 'TEAM-DEV',
                    credentialsId: 'pcf-pre-prod',
                    env: [
                        cfDomains: 'apps.pp01i.edc2.cf.ford.com', // comma delimited list of CF route domains
                        cfManifestTarget: 'dev-edc2',
                    ]
                ]*/
            ],
            env: [ // cli environment values for all DEV spaces
               // sample oauth2 configuration used by acceptance tests
               ACCEPTANCE_DEFAULT_OAUTH2_CLIENT_ACCESS_TOKEN_URI: 'https://corpqa.sts.ford.com/adfs/oauth2/token',
               ACCEPTANCE_DEFAULT_OAUTH2_APP_CLIENT_ID: 'urn:mywebsite',
               ACCEPTANCE_DEFAULT_OAUTH2_RESOURCE: 'urn:myservice',
               BOOST_PUBLISH_TEAM_REPO_URL: 'https://www.nexus.ford.com/repository/PCFDevEnablement_public_release_repository'
            ],

            // credentials configuration for acceptance tests
            acceptanceTesting: [
                genericId: [
                    credentialsId: ''  // Jenkins credentials ID for Resource Owner Password Credentials
                ],
                clientCredentials: [
                    credentialsId: ''  // Jenkins credentials ID for Client Credentials
                ],
                basicAuthentication: [
                    credentialsId: ''  // Jenkins credentials ID for Basic Authentication
                ]
            ],

            // CF Environment specific integrations
            integrations: [

                // third-party integrations
                thirdParty: [
                    gitHub: [
                        branchName: 'master'
                    ],
                    nexus: [
                        // Applicable only for higher environments using same github branch.
                        // Set downloadMyPreviouslyBuiltArtifact to true to skip the build and download the previously built latest version of artifact from Nexus (if enabled).
                        // Use BOOST_OVERRIDE_DOWNLOAD_ARTIFACT_VERSION environment variable to override the artifact version to be downloaded from nexus.
                        downloadMyPreviouslyBuiltArtifact: false
                    ],
                ],

                // cloud services integrations
                cloud: [
                    config_server: [
                        enabled: false,
                        configured: false,
                        credentialsId: 'github-sshkey-private', // Jenkins credentials ID
                        repoSSHUrl: '[TEAM-CONFIG-REPO-SSH-URL]',
                    ],
                    credhub_secretzero: [
                        enabled: false,
                        credentialsId: 'jasypt-private', // Jenkins credentials ID
                    ],
                    smb_volume: [
                        enabled: false,
                        credentialsId: 'smbvolume-private', // Jenkins credentials ID
                        hostName: '',  // Ex: //dc18101nn01.prod.f01.dc1.ford.com
                        shareName: '', // Ex: q00568
                        mountPath: '', // Ex: /var/proj/Jab7/nas
                    ]
                ],
            ],

            // Vanity Url Mapping
            vanityUrl: [
                enabled: false,
                domain: '', // ex: cabfordair.ford.com
                hostName: '', // ex: wwwdev, wwwqa, www or empty if not applicable
                path: '', // optional
                appSpecificGSLB: false, // if true, provide value for 'appSpecificGSLBAppName' to map a route with 'cf.app.ford.com' domain
                appSpecificGSLBAppName: '' // app name in CNAME, ex: wwwdev-cabfordair
            ],

            // Container to Container Networking Policies
            c2cNetworkPolicies: [
                enabled: false,
                outbound: '',  // comma delimited list of valid app names with outbound policies
                inbound: '',   // comma delimited list of valid app names with inbound policies
                createAppsInternalRoute: false, // true if resolving through BOSH DNS; false if using service discovery
                deleteExternalRoutesForThisApp: false  // set to true if this app is accessible only via C2C
            ],
        ],
    ]

]
// DEV ENABLEMENT - PIPELINE CONFIGURATION FILE
