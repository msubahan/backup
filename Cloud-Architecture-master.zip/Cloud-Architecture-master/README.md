Ford Cloud Architecture
=======================

This repository contains how-to instructions and documentation related to Cloud Architecture in the Pivotal Cloud Foundry, OpenShift CaaS, and Azure platforms used at Ford. Ideally, this material reflects current state and is intended to help development teams and architects better understand the capabilities of our cloud platforms.

The information here is maintained by the Cloud Platform Architecture team within the Developer Enablement team. We provide learning resources, such as this repository, as well as lightweight consulting services to [product based teams](https://it2.spt.ford.com/sites/ITPDO/SitePages/Product-Based%20Teams.aspx).

# How-To Instructions and Questions
If you have a question about *how to do something* in our cloud platforms, this is a good place to start. Since the list of possible questions is inifinite, we cannot cover every scenario, but hopefully we have documented the most common ones. You will find how-to materials in this repository's [Wiki](https://github.ford.com/DevEnablement/Cloud-Architecture/wiki). If viewing through a web browser, click on the Wiki tab above to view.

If you cannot find what you are looking for in this repo, also check out the [One Ford Search](https://search.spt.ford.com/). The content available on Ford's intranet is vast, but with the right keywords, you might find the answer you're looking for. We have many more instructional videos and online learning resources on the Dev Enablement's [website](http://x.ford.com/devportal).

If you still need help, consider starting a new discussion in the [Dev Enablement Community]https://thehubat.ford.com/groups/pcf-community) forum. This is a discussion forum that the larger Dev Enablement team monitors and can give you guidance on your issue.

If you are looking for our team to deliver a presentation or you would like an architectural consultation, please submit a request on our [website](https://it2.spt.ford.com/sites/dev/Lists/Consultation/AllItems.aspx). We offer these engagements as our capacity permits.

# The Cloud Platform Architecture Team
Here is more info about our team.

**Vision:** Empowered app teams thriving in Ford’s PCF and OpenShift CaaS cloud platforms.

**Mission:** To shape the design of Ford's cloud platforms, and provide related learning resources and consulting services to app teams.

**Customers**

We serve Ford's product based teams (Software Developers and Architects). We collaborate with ITO Cloud Platform Eng/Ops teams to help shape the capabilities of the PCF, OpenShift, and Azure environments.

**Responsibilities**
- Develop easy-to-find, self-service instructional materials that demonstrate app development on Ford’s cloud platforms. Materials include written documents, videos, and source code. Additionally, deliver presentations and facilitate workshops to share learnings and empower app teams.
- Consult with app teams on application design and demonstrate the capabilities of Ford's cloud platforms including PCF, Azure, OpenShift CaaS, and Liberty in Containers. Perform Proof of Concept experiments with emerging technologies to develop patterns and best practices.
- Consult with app teams on advanced troubleshooting of unexpected app behaviors and poor performance helping to isolate and resolve root cause as team capacity permits.
- Guide and shape the design of Ford's cloud platforms. Work closely with Eng/Ops teams to identify the pain points of app teams, prioritize delivery of the highest value platform capabilities, and provide an app team perspective to platform management decisions.
